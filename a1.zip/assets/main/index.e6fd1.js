window.__require = function e(t, n, o) {
function a(i, r) {
if (!n[i]) {
if (!t[i]) {
var c = i.split("/");
c = c[c.length - 1];
if (!t[c]) {
var s = "function" == typeof __require && __require;
if (!r && s) return s(c, !0);
if (_) return _(c, !0);
throw new Error("Cannot find module '" + i + "'");
}
i = c;
}
var l = n[i] = {
exports: {}
};
t[i][0].call(l.exports, function(e) {
return a(t[i][1][e] || e);
}, l, l.exports, e, t, n, o);
}
return n[i].exports;
}
for (var _ = "function" == typeof __require && __require, i = 0; i < o.length; i++) a(o[i]);
return a;
}({
"BGUI.d": [ function(e, t) {
"use strict";
cc._RF.push(t, "1bd69oy6nNFeZCTarQyRNnY", "BGUI.d");
cc._RF.pop();
}, {} ],
BhvShake: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "6b367jbKq1JYYuAR/V3rR09", "BhvShake");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const {ccclass: a, property: _, menu: i} = cc._decorator;
let r = class extends BGUI.BhvShake {
constructor() {
super(...arguments);
this.movingMode = !1;
this.decayMode = !1;
this.damping = .01;
this.shakeTime = .5;
this.intensity = cc.v2(5, 5);
}
};
o([ _({
tooltip: "Chế độ chuyển động, chế độ di chuyển sẽ không khôi phục tọa độ của đối tượng trở lại trạng thái trước khi xảy ra rung lắc, thích hợp cho các đối tượng chuyển động"
}) ], r.prototype, "movingMode", void 0);
o([ _({
tooltip: "Chế độ phân rã, sẽ giảm dần theo cường độ của thời gian rung"
}) ], r.prototype, "decayMode", void 0);
o([ _({
visible: function() {
return !0 === this.decayMode;
},
tooltip: "Giảm chấn, tốc độ tại đó bán kính giảm dần trong quá trình rung"
}) ], r.prototype, "damping", void 0);
o([ _({
tooltip: "Thời gian rung"
}) ], r.prototype, "shakeTime", void 0);
o([ _({
tooltip: "Sự bù trừ của rung động x, y"
}) ], r.prototype, "intensity", void 0);
r = o([ a, i("BGUI/Movement/Shake") ], r);
n.default = r;
cc._RF.pop();
}, {} ],
BhvSine: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "5d9e7c1ptlDEqdve7SZk4bY", "BhvSine");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const {ccclass: a, property: _, menu: i} = cc._decorator;
Math.PI, Math.PI, Math.PI;
let r = class extends BGUI.BhvSine {
constructor() {
super(...arguments);
this.activeAtStart = !0;
this.movement = BGUI.MOVEMENT.vertical;
this.wave = BGUI.WAVE.sine;
this.period = 4;
this.periodRandom = 0;
this.periodOffset = 0;
this.periodOffsetRandom = 0;
this.magnitude = 50;
this.magnitudeRandom = 0;
}
};
o([ _({
tooltip: "Được kích hoạt ở chức năng bắt đầu"
}) ], r.prototype, "activeAtStart", void 0);
o([ _({
type: cc.Enum(BGUI.MOVEMENT),
tooltip: "Loại thuộc tính nào được sử dụng cho chuyển động chu kỳ sin"
}) ], r.prototype, "movement", void 0);
o([ _({
type: cc.Enum(BGUI.WAVE),
tooltip: "Dạng Sóng"
}) ], r.prototype, "wave", void 0);
o([ _({
tooltip: ""
}) ], r.prototype, "period", void 0);
o([ _({
tooltip: "Khoảng thời gian ngẫu nhiên"
}) ], r.prototype, "periodRandom", void 0);
o([ _({
tooltip: "Chu kỳ bù đắp"
}) ], r.prototype, "periodOffset", void 0);
o([ _({
tooltip: "Giá trị bù chu kỳ Ngẫu nhiên"
}) ], r.prototype, "periodOffsetRandom", void 0);
o([ _({
tooltip: "Phạm vi dao động"
}) ], r.prototype, "magnitude", void 0);
o([ _({
tooltip: "Giá trị ngẫu nhiên của biên độ dao động"
}) ], r.prototype, "magnitudeRandom", void 0);
r = o([ a, i("BGUI/Movement/Sine (Chức năng chuyển động)") ], r);
n.default = r;
cc._RF.pop();
}, {} ],
BundleDownLoad: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "271f8/NgIpEDYx7U0i7AOWF", "BundleDownLoad");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const {ccclass: a, property: _} = cc._decorator;
var i;
(function(e) {
e[e.UNKNOWN = -1] = "UNKNOWN";
e[e.MINI_CAOTHAP = 1] = "MINI_CAOTHAP";
e[e.MINI_XOCDIA = 2] = "MINI_XOCDIA";
e[e.MINI_POKER = 3] = "MINI_POKER";
e[e.MINI_POKEMON = 4] = "MINI_POKEMON";
e[e.MINI_TAIXIU = 5] = "MINI_TAIXIU";
e[e.MINI_BAUCUA = 6] = "MINI_BAUCUA";
e[e.MINI_XENG = 7] = "MINI_XENG";
e[e.MINI_LONGHO = 8] = "MINI_LONGHO";
e[e.MINI_CHANLE = 9] = "MINI_CHANLE";
e[e.MINI_HOAQUA = 39] = "MINI_HOAQUA";
e[e.SLOT_AVENGERS = 10] = "SLOT_AVENGERS";
e[e.SLOT_KHOBAU = 11] = "SLOT_KHOBAU";
e[e.SLOT_DECHEMAYA = 12] = "SLOT_DECHEMAYA";
e[e.SLOT_NUDIEPVIEN = 13] = "SLOT_NUDIEPVIEN";
e[e.SLOT_TREEOFFORTURE = 38] = "SLOT_TREEOFFORTURE";
e[e.SLOT_DANCING_GIRL = 45] = "SLOT_DANCING_GIRL";
e[e.CASINO_RONGHO = 20] = "CASINO_RONGHO";
e[e.CASINO_LODE = 21] = "CASINO_LODE";
e[e.CASINO_POKER = 22] = "CASINO_POKER";
e[e.CASINO_BAICAO = 23] = "CASINO_BAICAO";
e[e.CASINO_XIDZACH = 24] = "CASINO_XIDZACH";
e[e.CASINO_BACAY = 25] = "CASINO_BACAY";
e[e.CASINO_MAUBINH = 26] = "CASINO_MAUBINH";
e[e.CASINO_SAM = 27] = "CASINO_SAM";
e[e.CASINO_TIENLEN = 28] = "CASINO_TIENLEN";
e[e.TX_TOURNAMENT = 29] = "TX_TOURNAMENT";
e[e.GAME_LONGHO = 30] = "GAME_LONGHO";
e[e.LODE_NORMAL = 31] = "LODE_NORMAL";
e[e.LODE_79 = 32] = "LODE_79";
e[e.LODE_79_30P = 36] = "LODE_79_30P";
e[e.CASINO_TIENLEN_SOLO = 33] = "CASINO_TIENLEN_SOLO";
e[e.CASINO_SAM_SOLO = 34] = "CASINO_SAM_SOLO";
e[e.CASINO_MAUBINH_SOLO = 35] = "CASINO_MAUBINH_SOLO";
e[e.MINI_SICBO = 40] = "MINI_SICBO";
e[e.GAME_ID_TALKSHOWB79 = 41] = "GAME_ID_TALKSHOWB79";
e[e.GAME_ID_SHANKOEMEE = 42] = "GAME_ID_SHANKOEMEE";
e[e.GAME_ID_BOOGYI = 43] = "GAME_ID_BOOGYI";
e[e.GAME_ID_SHWESHAN = 44] = "GAME_ID_SHWESHAN";
e[e.KENO = 46] = "KENO";
e[e.LUCKY_WHEEL = 20231020] = "LUCKY_WHEEL";
})(i || (i = {}));
let r = class extends BGUI.BundleDownLoad {
constructor() {
super(...arguments);
this.isDownloadLocal = !1;
this.linkUrl = "";
this.bundleName = "";
this.prefabMainNameURL = "";
this.prgLoadGame = null;
this.lbMsg = null;
this.autoDownload = !1;
this.isClicked = !1;
this.gameID = i.UNKNOWN;
this.isDownloadBundleNotLoad = !1;
}
};
o([ _ ], r.prototype, "isDownloadLocal", void 0);
o([ _({
visible: function() {
return this.isDownloadLocal;
}
}) ], r.prototype, "linkUrl", void 0);
o([ _({
visible: function() {
return this.isDownloadLocal;
}
}) ], r.prototype, "bundleName", void 0);
o([ _({
visible: function() {
return this.isDownloadLocal;
}
}) ], r.prototype, "prefabMainNameURL", void 0);
o([ _(cc.ProgressBar) ], r.prototype, "prgLoadGame", void 0);
o([ _(cc.Label) ], r.prototype, "lbMsg", void 0);
o([ _({
visible: function() {
return !this.isDownloadBundleNotLoad;
}
}) ], r.prototype, "autoDownload", void 0);
o([ _({
visible: function() {
return !this.isDownloadBundleNotLoad;
}
}) ], r.prototype, "isClicked", void 0);
o([ _({
type: cc.Enum(i),
tooltip: "Bundle Game ID",
visible: function() {
return !this.autoDownload;
}
}) ], r.prototype, "gameID", void 0);
o([ _({
visible: function() {
return !this.autoDownload;
}
}) ], r.prototype, "isDownloadBundleNotLoad", void 0);
r = o([ a ], r);
n.default = r;
cc._RF.pop();
}, {} ],
CapchaF: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "c1accaCFshOp4HsTAkcFwRH", "CapchaF");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const {ccclass: a, property: _} = cc._decorator;
let i = class extends cc.Component {
constructor() {
super(...arguments);
this.capcha = null;
this.isTelco = !1;
this.capchaId = "";
this.mUrl = "";
}
start() {
this.refreshCapcha();
}
refreshCapcha() {
let e = "https://api.boss79.us:443/api?app_id=" + (() => cc.sys.isBrowser ? 21 : cc.sys.os == cc.sys.OS_ANDROID ? 23 : cc.sys.os == cc.sys.OS_IOS ? 22 : void 0) + "&c=124&at=";
this.isTelco && (e = "");
this.sendGetCaptcha(e);
}
getCapChaId() {
return this.capchaId;
}
resetCapcha() {
this.capcha.node.active = !1;
}
sendGetCaptcha(e) {
this.mUrl = e;
let t = this;
BGUI.Https.get(e, e => {
BGUI.ZLog.log(e);
let n = e;
t.capchaId = n.id;
let o = n.img;
o = o.replace(/\r\n/g, "");
t.loadImgBinary(o);
});
}
loadImgBinary(e) {
let t = "data:image/png;base64," + e, n = new Image();
n.width = 130;
n.height = 60;
let o = this;
n.onload = function() {
let e = new cc.Texture2D();
e.initWithElement(n);
e.handleLoadedTexture();
let t = new cc.SpriteFrame(e);
o.capcha.node.active = !0;
o.capcha.spriteFrame = t;
};
n.src = t;
}
};
o([ _(cc.Sprite) ], i.prototype, "capcha", void 0);
o([ _(cc.Boolean) ], i.prototype, "isTelco", void 0);
i = o([ a ], i);
n.default = i;
cc._RF.pop();
}, {} ],
CommonAssetDefined: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "d6570HA0PpN+42el5D4GKmQ", "CommonAssetDefined");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const a = e("./PrefabEDefined"), {ccclass: _, property: i} = cc._decorator;
let r = class extends BGUI.CommonAssetDefined {
constructor() {
super(...arguments);
this.WAITING_LAYOUT = null;
this.BUTTON_COMMON = null;
this.FADED_BACKGROUND = null;
this.FADED_BACKGROUND_FADED = null;
this.CENTER_NOTIFICATION = null;
this.TEXT_FLY = null;
this.POPUP_COMMON = null;
this.TOOLTIP_MESSAGE = null;
this.listPrefabDefined = [];
}
};
o([ i(cc.Prefab) ], r.prototype, "WAITING_LAYOUT", void 0);
o([ i(cc.Prefab) ], r.prototype, "BUTTON_COMMON", void 0);
o([ i(cc.Prefab) ], r.prototype, "FADED_BACKGROUND", void 0);
o([ i(cc.Prefab) ], r.prototype, "FADED_BACKGROUND_FADED", void 0);
o([ i(cc.Prefab) ], r.prototype, "CENTER_NOTIFICATION", void 0);
o([ i(cc.Prefab) ], r.prototype, "TEXT_FLY", void 0);
o([ i(cc.Prefab) ], r.prototype, "POPUP_COMMON", void 0);
o([ i(cc.Prefab) ], r.prototype, "TOOLTIP_MESSAGE", void 0);
o([ i(a.default) ], r.prototype, "listPrefabDefined", void 0);
r = o([ _ ], r);
n.default = r;
cc._RF.pop();
}, {
"./PrefabEDefined": "PrefabEDefined"
} ],
DemoLog: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "5a7cb6/NZNGo4EHiIFHic3M", "DemoLog");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const a = e("../framework/localize/LanguageMgr"), {ccclass: _, property: i} = cc._decorator;
let r = class extends BGUI.UIPopup {
constructor() {
super(...arguments);
this.edbAccount = null;
this.edbPass = null;
}
onClickLogin() {
var e = this.edbAccount.string.trim();
e = e.toLowerCase();
var t = this.edbPass.string.trim();
if (e.length <= 0) {
BGUI.UIPopupManager.instance.showPopup(a.LanguageMgr.getString("lobby.warning.account_not_enter"));
return;
}
if (t.length <= 0) {
BGUI.UIPopupManager.instance.showPopup(a.LanguageMgr.getString("lobby.warning.password_not_enter"));
return;
}
BGUI.UIWaitingLayout.showWaiting();
let n = this.edbAccount.string, o = window.md5(this.edbPass.string), _ = this.urlLogin(n, o, BGUI.PlatformInterface.OSName);
BGUI.Https.get(_, e => {
BGUI.UIWaitingLayout.hideWaiting();
this.onLoginSucess(e);
});
}
onLoginSucess(e) {
var t = e, n = t.success, o = t.errorCode;
if (n) {
BGUI.ZLog.log("===============onLoginSucess=======================", t);
BGUI.GameCoreManager.instance.isLoginSuccess = !0;
var _ = t.sessionKey, i = JSON.parse(this.Jacob__Codec__Base64__decode(_));
BGUI.UserManager.instance.mainUserInfo = i;
BGUI.UserManager.instance.mainUserInfo.sessionKey = t.sessionKey;
BGUI.UserManager.instance.mainUserInfo.accessToken = t.accessToken;
BGUI.UserManager.instance.mainUserInfo.identification = t.id;
BGUI.UserManager.instance.mainUserInfo.reference = t.reference;
BGUI.ZLog.log(BGUI.UserManager.instance.mainUserInfo);
BGUI.ZLog.log(BGUI.UserManager.instance.mainUserInfo.identification);
BGUI.UserManager.instance.mainUserInfo.username = this.edbAccount.string;
BGUI.NetworkPortal.instance.isConnected() || BGUI.NetworkPortal.instance.connect();
BGUI.EventDispatch.instance.emit(BGUI.EVENT_GAMECORE.LOGIN_SUCCESS);
this.hide();
} else {
BGUI.ZLog.log("===============onLogin FAILLLL=======================", t);
var r = "";
switch (parseInt(o)) {
case 1001:
r = a.LanguageMgr.getString("lobby.warning.server_lost_connect");
break;

case 4444:
r = a.LanguageMgr.getString("lobby.warning.account_logining_please_logout");
break;

case 1109:
r = a.LanguageMgr.getString("lobby.warning.account_banning");
break;

case 1008:
r = a.LanguageMgr.getString("lobby.warning.invalid_authentication_code");
break;

case 1021:
r = a.LanguageMgr.getString("lobby.warning.overtime_authentication");
break;

case 1114:
r = a.LanguageMgr.getString("lobby.warning.server_maintain_go_later");
break;

case 1007:
r = a.LanguageMgr.getString("lobby.warning.password_wrong");
break;

case 1109:
r = a.LanguageMgr.getString("lobby.warning.login_banned");
break;

case 1005:
r = a.LanguageMgr.getString("lobby.warning.unexist_user");
break;

case 2001:
r = a.LanguageMgr.getString("lobby.warning.you_not_create_username");
}
"" != r && BGUI.UIPopupManager.instance.showPopup(r);
if (2001 == o) {
this.hide();
BGUI.ZLog.log("GUI_DISPLAYNAME");
}
}
}
urlLogin(e, t, n) {
return "https://api.boss79.win:443/api?app_id=" + (() => cc.sys.isBrowser ? 11 : cc.sys.os == cc.sys.OS_ANDROID ? 13 : cc.sys.os == cc.sys.OS_IOS ? 12 : void 0) + "&c=3&un=" + e + "&pw=" + t + "&pf=" + n + "&at=";
}
Jacob__Codec__Base64__decode(e) {
var t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
let n, o, a, _, i, r, c, s = [], l = 0;
e = e.replace(/[^A-Za-z0-9\+\/\=]/g, "");
for (;l < e.length; ) {
n = (_ = t.indexOf(e.charAt(l++))) << 2 | (i = t.indexOf(e.charAt(l++))) >> 4;
o = (15 & i) << 4 | (r = t.indexOf(e.charAt(l++))) >> 2;
a = (3 & r) << 6 | (c = t.indexOf(e.charAt(l++)));
s.push(String.fromCharCode(n));
64 != r && s.push(String.fromCharCode(o));
64 != c && s.push(String.fromCharCode(a));
}
return s.join("");
}
};
o([ i(cc.EditBox) ], r.prototype, "edbAccount", void 0);
o([ i(cc.EditBox) ], r.prototype, "edbPass", void 0);
r = o([ _ ], r);
n.default = r;
cc._RF.pop();
}, {
"../framework/localize/LanguageMgr": "LanguageMgr"
} ],
DemoReg: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "53f85BYbRJNpafwQpBoitYG", "DemoReg");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const a = e("../framework/localize/LanguageMgr"), _ = e("../lobby/LobbyConst"), i = e("./CapchaF"), {ccclass: r, property: c} = cc._decorator;
let s = class extends BGUI.UIPopup {
constructor() {
super(...arguments);
this.edbAccount = null;
this.edbPass = null;
this.edbRePass = null;
this.edbCaptcha = null;
this.edbRef = null;
this.UICaptcha = null;
}
onClickReg() {
let e = this.edbAccount.string, t = window.md5(this.edbPass.string), n = window.md5(this.edbRePass.string), o = this.edbCaptcha.string;
if (e.length > 18 || e.length < 6 || e.indexOf(" ") > 0 || e.indexOf("@") > 0) {
BGUI.UIPopupManager.instance.showPopup(a.LanguageMgr.getString("lobby.warning.username_warning"));
return;
}
if (t !== n) {
BGUI.UIPopupManager.instance.showPopup(a.LanguageMgr.getString("lobby.warning.password_same_warning"));
return;
}
if (0 == o.length) {
BGUI.UIPopupManager.instance.showPopup(a.LanguageMgr.getString("lobby.warning.verify_code_wrong"));
return;
}
BGUI.UIWaitingLayout.showWaiting();
let _ = this.urlQuickRegister(e, t, o, this.UICaptcha.getCapChaId(), this.edbRef.string);
BGUI.Https.get(_, e => {
BGUI.UIWaitingLayout.hideWaiting();
BGUI.ZLog.log(e);
var t = e, n = t.success, o = t.errorCode;
if (n) {
BGUI.ZLog.log("==============REGISTER SUCCESS ===========");
this.requestLogin();
} else {
this.UICaptcha.refreshCapcha();
var _ = "";
switch (parseInt(o)) {
case 1001:
_ = a.LanguageMgr.getString("lobby.warning.internet_unstable");
break;

case 101:
_ = a.LanguageMgr.getString("lobby.warning.invalid_username");
break;

case 1006:
_ = a.LanguageMgr.getString("lobby.warning.username_exist");
break;

case 1007:
_ = a.LanguageMgr.getString("lobby.warning.invite_code_unexist");
break;

case 102:
_ = a.LanguageMgr.getString("lobby.warning.password_wrong");
break;

case 108:
_ = a.LanguageMgr.getString("lobby.warning.invite_code_wrong_type");
break;

case 115:
_ = a.LanguageMgr.getString("lobby.warning.captcha_wrong");
break;

case 1114:
_ = a.LanguageMgr.getString("lobby.warning.server_maintain_go_later");
}
"" != _ && BGUI.UIPopupManager.instance.showPopup(_);
}
});
}
requestLogin() {
let e = this.edbAccount.string, t = window.md5(this.edbPass.string), n = BGUI.PlatformInterface.platform, o = this.urlLogin(e, t, n);
BGUI.UIWaitingLayout.showWaiting();
BGUI.Https.getRaw(o, e => {
BGUI.UIWaitingLayout.hideWaiting();
this.onLoginSuccess(e);
});
}
urlLogin(e, t, n) {
let o = "https://api.boss79.win:443/api?app_id=" + (() => cc.sys.isBrowser ? 11 : cc.sys.os == cc.sys.OS_ANDROID ? 13 : cc.sys.os == cc.sys.OS_IOS ? 12 : void 0) + "&";
BGUI.ZLog.log(o);
return o + "c=3&un=" + e + "&pw=" + t + "&pf=" + n + "&at=";
}
urlQuickRegister(e, t, n, o, i) {
let r = "https://api.boss79.win:443/api?app_id=" + (() => cc.sys.isBrowser ? 11 : cc.sys.os == cc.sys.OS_ANDROID ? 13 : cc.sys.os == cc.sys.OS_IOS ? 12 : void 0) + "&", c = a.LanguageMgr.instance.getCurrentLanguage(), s = _.LobbyConst.APP_DEVICES, l = JSON.stringify(s);
return cc.sys.os == cc.sys.OS_IOS ? r + "c=1&un=" + e + "&pw=" + t + "&cp=" + n + "&cid=" + o + "&at=&utm_source=IOS&utm_medium=IOS&utm_term=IOS&utm_content=IOS&utm_campaign=IOS&reference=" + i + "&lang=" + c + "&di=" + l : cc.sys.os == cc.sys.OS_ANDROID ? r + "c=1&un=" + e + "&pw=" + t + "&cp=" + n + "&cid=" + o + "&at=&utm_source=ANDROID&utm_medium=ANDROID&utm_term=ANDROID&utm_content=ANDROID&utm_campaign=ANDROID&reference=" + i + "&lang=" + c + "&di=" + l : r + "c=1&un=" + e + "&pw=" + t + "&cp=" + n + "&cid=" + o + "&at=&reference=" + i + "&lang=" + c + "&di=" + l;
}
onLoginSuccess(e) {
this.hide();
BGUI.ZLog.log(e);
var t = e, n = t.success, o = t.errorCode;
if (n) BGUI.ZLog.log("==============LOGIN SUCCESS ==========="); else {
var _ = "";
switch (parseInt(o)) {
case 1001:
_ = a.LanguageMgr.getString("lobby.warning.server_lost_connect");
break;

case 4444:
_ = a.LanguageMgr.getString("lobby.warning.account_logining_please_logout");
break;

case 1109:
_ = a.LanguageMgr.getString("lobby.warning.account_banning");
break;

case 1008:
_ = a.LanguageMgr.getString("lobby.warning.invalid_authentication_code");
break;

case 1021:
_ = a.LanguageMgr.getString("lobby.warning.overtime_authentication");
break;

case 1114:
_ = a.LanguageMgr.getString("lobby.warning.server_maintain_go_later");
break;

case 1007:
_ = a.LanguageMgr.getString("lobby.warning.password_wrong");
break;

case 1109:
_ = a.LanguageMgr.getString("lobby.warning.login_banned");
break;

case 1005:
_ = a.LanguageMgr.getString("lobby.warning.unexist_user");
}
"" != _ && BGUI.UIPopupManager.instance.showPopup(_);
if (2001 == o) {
let e = this.edbAccount.string, t = window.md5(this.edbPass.string);
BGUI.UIPopupManager.instance.showPopupFromPrefab(BGUI.CommonAssetDefined.instance.getPrefabByName("GUI_DISPLAYNAME"), n => {
n.setInfo(e, t);
});
}
}
}
onRefreshCaptchaClicked() {
this.UICaptcha.refreshCapcha();
}
};
o([ c(cc.EditBox) ], s.prototype, "edbAccount", void 0);
o([ c(cc.EditBox) ], s.prototype, "edbPass", void 0);
o([ c(cc.EditBox) ], s.prototype, "edbRePass", void 0);
o([ c(cc.EditBox) ], s.prototype, "edbCaptcha", void 0);
o([ c(cc.EditBox) ], s.prototype, "edbRef", void 0);
o([ c(i.default) ], s.prototype, "UICaptcha", void 0);
s = o([ r ], s);
n.default = s;
cc._RF.pop();
}, {
"../framework/localize/LanguageMgr": "LanguageMgr",
"../lobby/LobbyConst": void 0,
"./CapchaF": "CapchaF"
} ],
DropDownItem: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "0e0c1OzYPVOfpEPKQp433tu", "DropDownItem");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const {ccclass: a, property: _} = cc._decorator;
let i = class extends BGUI.DropDownItem {
constructor() {
super(...arguments);
this.label = null;
this.sprite = null;
this.toggle = null;
}
};
o([ _(cc.Label) ], i.prototype, "label", void 0);
o([ _(cc.Sprite) ], i.prototype, "sprite", void 0);
o([ _(cc.Toggle) ], i.prototype, "toggle", void 0);
i = o([ a() ], i);
n.default = i;
cc._RF.pop();
}, {} ],
DropDownOptionData: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "fd5cfBXVIZC4Ks6evy9ygnF", "DropDownOptionData");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const {ccclass: a, property: _} = cc._decorator;
let i = class extends BGUI.DropDownOptionData {
constructor() {
super(...arguments);
this.optionString = "";
this.optionSf = void 0;
}
};
o([ _() ], i.prototype, "optionString", void 0);
o([ _(cc.SpriteFrame) ], i.prototype, "optionSf", void 0);
i = o([ a("DropDownOptionData") ], i);
n.default = i;
cc._RF.pop();
}, {} ],
DropDown: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "4c73768DrRIEpBrhG+kF/zC", "DropDown");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const a = e("./DropDownOptionData"), {ccclass: _, property: i} = cc._decorator;
let r = class extends BGUI.DropDown {
constructor() {
super(...arguments);
this.template = void 0;
this.labelCaption = void 0;
this.spriteCaption = void 0;
this.labelItem = void 0;
this.spriteItem = void 0;
this.optionDatas = [];
}
};
o([ i(cc.Node) ], r.prototype, "template", void 0);
o([ i(cc.Label) ], r.prototype, "labelCaption", void 0);
o([ i(cc.Sprite) ], r.prototype, "spriteCaption", void 0);
o([ i(cc.Label) ], r.prototype, "labelItem", void 0);
o([ i(cc.Sprite) ], r.prototype, "spriteItem", void 0);
o([ i([ a.default ]) ], r.prototype, "optionDatas", void 0);
r = o([ _() ], r);
n.default = r;
cc._RF.pop();
}, {
"./DropDownOptionData": "DropDownOptionData"
} ],
GG: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "7f69doihNlCKoMdkrMMlnHu", "GG");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const {ccclass: a, property: _} = cc._decorator;
let i = class extends cc.Component {
onLoad() {
BGUI.BundleManager.instance.loadBundleFromLocal("Lobby", null);
BGUI.BundleManager.instance.loadBundleFromLocal("Chat", null);
BGUI.BundleManager.instance.loadBundleFromLocal("MiniLongHo", null);
BGUI.BundleManager.instance.loadBundleFromLocal("MiniBauCua", null);
BGUI.BundleManager.instance.loadBundleFromLocal("MiniTaiXiuXocDia", null);
BGUI.BundleManager.instance.loadBundleFromLocal("LuckyWheel", null);
}
onClicked() {
BGUI.BundleManager.instance.getPrefabFromBundle("GUI_VONGQUAY_MAYMAN", "LuckyWheel", e => {
BGUI.UIPopupManager.instance.showPopupFromPrefab(e);
});
}
};
i = o([ a ], i);
n.default = i;
cc._RF.pop();
}, {} ],
GUIDisplayNameCtrl: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "0229bQUmbtCaa401iJUOch5", "GUIDisplayNameCtrl");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const a = e("../framework/localize/LanguageMgr"), _ = e("../lobby/LobbyConst"), {ccclass: i, property: r} = cc._decorator;
let c = class extends BGUI.UIPopup {
constructor() {
super(...arguments);
this.edbDisplayName = null;
this.m_userName = "";
this.m_pass = "";
}
setInfo(e, t) {
this.m_userName = e;
this.m_pass = t;
}
onCreateNameClicked() {
let e = this.edbDisplayName.string, t = this.urlUpdateNick(this.m_userName, this.m_pass, e, BGUI.PlatformInterface.platform);
BGUI.Https.getRaw(t, e => {
BGUI.ZLog.log(e);
var t = e, n = t.success, o = t.errorCode;
if (n) {
var _ = t.sessionKey, i = JSON.parse(this.Jacob__Codec__Base64__decode(_));
BGUI.ZLog.info(i);
BGUI.UserManager.instance.mainUserInfo = i;
BGUI.UserManager.instance.mainUserInfo.sessionKey = t.sessionKey;
BGUI.UserManager.instance.mainUserInfo.accessToken = t.accessToken;
BGUI.ZLog.info("BGUI.UserManager.instance.mainUserInfo === " + BGUI.UserManager.instance.mainUserInfo.xuTotal);
BGUI.NetworkPortal.instance.connect();
BGUI.EventDispatch.instance.emit(BGUI.EVENT_GAMECORE.LOGIN_SUCCESS);
} else {
var r = "";
switch (parseInt(o)) {
case 1001:
r = a.LanguageMgr.getString("lobby.warning.server_lost_connect");
break;

case 1005:
r = a.LanguageMgr.getString("lobby.warning.unexist_account");
break;

case 1007:
r = a.LanguageMgr.getString("lobby.warning.password_wrong");
break;

case 1109:
r = a.LanguageMgr.getString("lobby.warning.account_banning");
break;

case 106:
r = a.LanguageMgr.getString("lobby.warning.nickname_invalid");
break;

case 1010:
r = a.LanguageMgr.getString("lobby.warning.nickname_exist");
break;

case 1011:
r = a.LanguageMgr.getString("lobby.warning.nickname_not_same_username");
break;

case 1006:
r = a.LanguageMgr.getString("lobby.warning.nickname_had");
break;

case 116:
r = a.LanguageMgr.getString("lobby.warning.nickname_not_sentitive");
break;

case 1114:
r = a.LanguageMgr.getString("lobby.warning.server_maintain_go_later");
}
"" != r && BGUI.UIPopupManager.instance.showPopup(r);
}
});
}
urlUpdateNick(e, t, n, o) {
return _.LobbyConst.BASE_URL + "c=5&un=" + e + "&pw=" + t + "&nn=" + n + "&pf=" + o + "&at=&engine=cc";
}
Jacob__Codec__Base64__decode(e) {
var t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
let n, o, a, _, i, r, c, s = [], l = 0;
e = e.replace(/[^A-Za-z0-9\+\/\=]/g, "");
for (;l < e.length; ) {
n = (_ = t.indexOf(e.charAt(l++))) << 2 | (i = t.indexOf(e.charAt(l++))) >> 4;
o = (15 & i) << 4 | (r = t.indexOf(e.charAt(l++))) >> 2;
a = (3 & r) << 6 | (c = t.indexOf(e.charAt(l++)));
s.push(String.fromCharCode(n));
64 != r && s.push(String.fromCharCode(o));
64 != c && s.push(String.fromCharCode(a));
}
return s.join("");
}
};
o([ r(cc.EditBox) ], c.prototype, "edbDisplayName", void 0);
c = o([ i ], c);
n.default = c;
cc._RF.pop();
}, {
"../framework/localize/LanguageMgr": "LanguageMgr",
"../lobby/LobbyConst": void 0
} ],
GameCoreManager: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "bf59c/u3uZHebYRjv7AEd5R", "GameCoreManager");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const a = e("../localize/LanguageMgr"), {ccclass: _, property: i} = cc._decorator;
let r = class extends BGUI.GameCoreManager {
constructor() {
super(...arguments);
this.nMiniGames = null;
this.nWidgetShowJackpot = null;
this.nLayerMiniGame = null;
this.gameName = "";
this.listFontCommon = null;
this.listFontLanguage = [];
}
onLoad() {
super.onLoad();
a.LanguageMgr.updateLang();
cc.view.resizeWithBrowserSize(!0);
cc.view.enableAutoFullScreen(!0);
BGUI.Utils.alignView();
BGUI.ZLog.enable = !0;
BGUI.BundleManager.instance.loadBundleFromLocal("Lobby", () => {
BGUI.BundleManager.instance.getPrefabFromBundle("LobbySceneReal", "Lobby", e => {
BGUI.UIScreenManager.instance.initWithRootPrefab(e, () => {
this.scheduleOnce(() => {
BGUI.EventDispatch.instance.emit("AUTO_LOGIN_BY_TOKEN");
BGUI.ZLog.log("AUTO_LOGIN_BY_TOKEN");
}, 1);
});
});
});
}
};
o([ i(cc.Node) ], r.prototype, "nMiniGames", void 0);
o([ i(cc.Node) ], r.prototype, "nWidgetShowJackpot", void 0);
o([ i(cc.Node) ], r.prototype, "nLayerMiniGame", void 0);
o([ i(cc.String) ], r.prototype, "gameName", void 0);
o([ i(cc.Font) ], r.prototype, "listFontCommon", void 0);
o([ i(cc.Font) ], r.prototype, "listFontLanguage", void 0);
r = o([ _ ], r);
n.default = r;
cc._RF.pop();
}, {
"../localize/LanguageMgr": "LanguageMgr"
} ],
ItemGameIconCtrl: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "37834tOLglJHp/duiwpDaxs", "ItemGameIconCtrl");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const {ccclass: a, property: _} = cc._decorator;
let i = class extends cc.Component {
constructor() {
super(...arguments);
this._idx = -1;
}
setData(e, t) {
this._idx = t;
}
onClicked() {
console.log(this._idx);
}
};
i = o([ a ], i);
n.default = i;
cc._RF.pop();
}, {} ],
LabelFontSet: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "33abcbdMrBNLrJRIwRxlur2", "LabelFontSet");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const {ccclass: a, property: _} = cc._decorator, i = cc.Enum({
VN: 0,
EN: 1,
MM: 2,
TL: 3,
CAM: 4
});
let r = class {
constructor() {
this.language = i.VN;
this.fontName = null;
this.fontSize = 20;
}
setLang(e) {
this.language = e;
}
};
o([ _({
type: i
}) ], r.prototype, "language", void 0);
o([ _(cc.Font) ], r.prototype, "fontName", void 0);
o([ _({
type: cc.Integer
}) ], r.prototype, "fontSize", void 0);
r = o([ a("LabelFontSet") ], r);
n.default = r;
cc._RF.pop();
}, {} ],
LabelLocalized: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "3f121i5KA9Pwr7nSnv0oxa/", "LabelLocalized");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const a = e("./LabelFontSet"), _ = e("./LanguageMgr"), {ccclass: i, property: r, menu: c, requireComponent: s} = cc._decorator;
let l = class extends cc.Component {
constructor() {
super(...arguments);
this.isUseCCFont = !1;
this.fontSizeActive = _.LABEL_FONT_SIZE_CONFIG.NORMAL;
this.isCustomFontSize = !1;
this.textKey = "";
this.upperCaseString = !1;
this.isSystemFontUsed = !1;
this._localizedString = "";
this.lbFont = this.loadLang();
}
get notify() {
return this._updateText();
}
get localizedString() {
return _.LanguageMgr.getString(this.textKey) || "";
}
set localizedString(e) {
this.textKey = e;
}
loadLang() {
for (var e = [], t = 0; t < Object.keys(_.LANGUAGE).length; t++) {
var n = new a.default();
n.setLang(t);
e.push(n);
}
return e;
}
start() {
cc.Canvas.instance && cc.Canvas.instance.node.on(BGUI.EVENT_GAMECORE.EVENT_UPDATE_LANGUAGE_LABEL, this.updateLanguage, this);
}
updateLanguage() {
this._updateCustomFont();
this._updateText();
}
_updateCustomFont() {
if (!this.isUseCCFont) return;
let e = _.LanguageMgr.instance.getCurrentLanguage();
const t = Object.values(_.LANGUAGE).indexOf(e);
if (this.isCustomFontSize) {
this.lbFont[t].fontName && (this.node.getComponent(cc.Label).font = this.lbFont[t].fontName);
this.lbFont[t].fontSize && (this.node.getComponent(cc.Label).fontSize = this.lbFont[t].fontSize);
} else {
this.node.getComponent(cc.Label).fontSize = this.getSizeByKeyEnum(this.fontSizeActive);
if (this.fontSizeActive == _.LABEL_FONT_SIZE_CONFIG.TITLE_MENU || this.fontSizeActive == _.LABEL_FONT_SIZE_CONFIG.CONTENT_POPUP || this.fontSizeActive == _.LABEL_FONT_SIZE_CONFIG.CONTENT_MENU || this.fontSizeActive == _.LABEL_FONT_SIZE_CONFIG.NORMAL) {
this.node.getComponent(cc.Label).font = BGUI.GameCoreManager.instance.listFontCommon;
this.fontSizeActive == _.LABEL_FONT_SIZE_CONFIG.TITLE_MENU && (this.node.getComponent(cc.Label).enableBold = !0);
} else {
this.node.getComponent(cc.Label).font = BGUI.GameCoreManager.instance.listFontLanguage[t];
this.node.getComponent(cc.Label).enableBold = !0;
this._addLabelShadow();
switch (this.fontSizeActive) {
case _.LABEL_FONT_SIZE_CONFIG.TITLE_POPUP:
this._addLabelOutLine(cc.color(184, 74, 1, 255));
this.node.color = cc.color(255, 218, 45, 255);
break;

case _.LABEL_FONT_SIZE_CONFIG.BUTTON_POPUP:
this._addLabelOutLine(cc.color(106, 71, 3, 255));
this.node.color = cc.color(255, 204, 45, 255);
}
}
}
}
getSizeByKeyEnum(e) {
let t = 20;
switch (e) {
case _.LABEL_FONT_SIZE_CONFIG.TITLE_POPUP:
t = 40;
break;

case _.LABEL_FONT_SIZE_CONFIG.CONTENT_POPUP:
t = 28;
break;

case _.LABEL_FONT_SIZE_CONFIG.BUTTON_POPUP:
t = 30;
break;

case _.LABEL_FONT_SIZE_CONFIG.TITLE_MENU:
t = 26;
break;

case _.LABEL_FONT_SIZE_CONFIG.CONTENT_MENU:
t = 20;
break;

case _.LABEL_FONT_SIZE_CONFIG.NORMAL:
t = 22;
}
return t;
}
_addLabelShadow(e = 2, t = -3) {
let n = this.node.getComponent(cc.LabelShadow);
n || (n = this.node.addComponent(cc.LabelShadow));
n.color = cc.Color.BLACK;
n.blur = e;
n.offset.x = 0;
n.offset.y = t;
}
_addLabelOutLine(e = cc.Color.ORANGE, t = 2) {
let n = this.node.getComponent(cc.LabelOutline);
n || (n = this.node.addComponent(cc.LabelOutline));
n.color = e;
n.width = t;
}
onLoad() {
this._updateCustomFont();
this._updateText();
}
_updateText() {
BGUI.ZLog.log(this.localizedString);
this.localizedString && (this.upperCaseString ? this.node.getComponent(cc.Label).string = _.LanguageMgr.getString(this.textKey).toUpperCase() : this.node.getComponent(cc.Label).string = _.LanguageMgr.getString(this.textKey));
return this.node.getComponent(cc.Label).string;
}
};
o([ r ], l.prototype, "isUseCCFont", void 0);
o([ r({
type: cc.Enum(_.LABEL_FONT_SIZE_CONFIG),
visible: function() {
return !this.isCustomFontSize;
}
}) ], l.prototype, "fontSizeActive", void 0);
o([ r ], l.prototype, "isCustomFontSize", void 0);
o([ r({
multiline: !0,
tooltip: "Enter i18n key here"
}) ], l.prototype, "textKey", void 0);
o([ r ], l.prototype, "upperCaseString", void 0);
o([ r ], l.prototype, "notify", null);
o([ r({
override: !0,
tooltip: "Here shows the localized string of Text Key"
}) ], l.prototype, "_localizedString", void 0);
o([ r ], l.prototype, "localizedString", null);
o([ r({
type: a.default,
visible: function() {
return this.isCustomFontSize;
}
}) ], l.prototype, "lbFont", void 0);
l = o([ i, c("BGUI/Multi Language/Label"), s(cc.Label) ], l);
n.default = l;
cc._RF.pop();
}, {
"./LabelFontSet": "LabelFontSet",
"./LanguageMgr": "LanguageMgr"
} ],
LanguageMgr: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "a433bj2bmxMqITUnVb0d4OZ", "LanguageMgr");
Object.defineProperty(n, "__esModule", {
value: !0
});
n.LanguageMgr = n.LABEL_FONT_SIZE_CONFIG = n.LANGUAGE = n.COUNTRY = void 0;
n.COUNTRY = {
VIETNAM: "vn",
THAILAND: "tl",
ENGLAND: "en",
INDO: "id",
MALAYSIA: "my",
MYANMAR: "mm",
GOFA: "gofa",
INTERNATIONAL: "international"
};
n.LANGUAGE = {
VIETNAMESE: "vn",
ENGLISH: "en",
MYANMAR: "mm",
THAILAN: "tl",
CAMBODIA: "cam"
};
(function(e) {
e[e.TITLE_POPUP = 0] = "TITLE_POPUP";
e[e.CONTENT_POPUP = 1] = "CONTENT_POPUP";
e[e.BUTTON_POPUP = 2] = "BUTTON_POPUP";
e[e.TITLE_MENU = 3] = "TITLE_MENU";
e[e.CONTENT_MENU = 4] = "CONTENT_MENU";
e[e.NORMAL = 5] = "NORMAL";
})(n.LABEL_FONT_SIZE_CONFIG || (n.LABEL_FONT_SIZE_CONFIG = {}));
let o = new (e("polyglot"))({
phrases: e("en")
});
class a extends BGUI.LanguageMgr {
static init() {
BGUI.ZLog.log("BGUI.ClientDataKey.LANGUAGE", BGUI.ClientDataKey.LANGUAGE);
let e = BGUI.ClientData.getString(BGUI.ClientDataKey.LANGUAGE, "");
e || (e = a.instance.getCurrentLanguage());
o.replace(e);
}
static getString(e, t = {}) {
return o.t(e, t);
}
static updateLocalization(t) {
let n = e(t);
BGUI.ZLog.log("language =========" + t);
BGUI.ZLog.log("data =========" + JSON.stringify(n));
o.replace(n);
}
static updateLang(e = n.COUNTRY.VIETNAM) {
var t = BGUI.ClientData.getString(BGUI.ClientDataKey.LANGUAGE, "");
BGUI.ZLog.log("defaultLang ==------------------" + t);
if (!t) {
switch (e) {
case n.COUNTRY.VIETNAM:
t = n.LANGUAGE.VIETNAMESE;
break;

case n.COUNTRY.ENGLAND:
t = n.LANGUAGE.ENGLISH;
break;

case n.COUNTRY.MYANMAR:
t = n.LANGUAGE.MYANMAR;
break;

default:
t = n.LANGUAGE.ENGLISH;
}
BGUI.ClientData.setString(BGUI.ClientDataKey.LANGUAGE, t);
}
this.updateLocalization(t);
}
}
n.LanguageMgr = a;
cc._RF.pop();
}, {
en: "en",
polyglot: "polyglot"
} ],
ListGameCenter: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "c27a6G8jtZHJ6tz42WkF41X", "ListGameCenter");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const a = e("./ItemGameIconCtrl"), _ = e("./framework/ui/UITableView"), {ccclass: i, property: r} = cc._decorator;
let c = class extends cc.Component {
constructor() {
super(...arguments);
this._dataAllGames = [ "1", "2", "3", "4", "1", "2", "3", "4", "1", "2", "3", "4", "1", "2", "3", "4", "1", "2", "3", "4", "1", "2", "3", "4" ];
this.tableView = null;
}
numberOfCellsInTableView(e) {
return this._dataAllGames.length;
}
tableCellAtIndex(e, t) {
let n = e.dequeueCell(), o = n.getComponent(a.default);
var _ = this._dataAllGames[t];
o.setData(_, t);
return n;
}
onEnable() {
this.tableView.dataSource = this;
}
test() {
this.tableView.content.children.forEach((e, t) => {
if (e && 3 == t) {
console.log(e.getPosition());
e.position.x += 100;
console.log(e.getPosition());
}
});
this.tableView.reloadData();
}
};
o([ r(_.default) ], c.prototype, "tableView", void 0);
c = o([ i ], c);
n.default = c;
cc._RF.pop();
}, {
"./ItemGameIconCtrl": "ItemGameIconCtrl",
"./framework/ui/UITableView": "UITableView"
} ],
LoginFeature: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "8b7d1eQq4JHxbM+cgSIxjq3", "LoginFeature");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const {ccclass: a, property: _} = cc._decorator;
let i = class extends BGUI.LoginFeature {
constructor() {
super(...arguments);
this.tabIndex = 0;
this.guiType = BGUI.GUI_TYPE.POPUP;
this.featurePrefab = null;
this.isLoadFromUrl = !0;
this.featurePrefabUrl = "";
this.bundleName = "";
this.isNotLogin = !1;
}
};
o([ _ ], i.prototype, "tabIndex", void 0);
o([ _({
type: cc.Enum(BGUI.GUI_TYPE)
}) ], i.prototype, "guiType", void 0);
o([ _({
type: cc.Prefab,
visible: function() {
return !this.isLoadFromUrl;
}
}) ], i.prototype, "featurePrefab", void 0);
o([ _ ], i.prototype, "isLoadFromUrl", void 0);
o([ _({
visible: function() {
return this.isLoadFromUrl;
}
}) ], i.prototype, "featurePrefabUrl", void 0);
o([ _({
visible: function() {
return this.isLoadFromUrl;
}
}) ], i.prototype, "bundleName", void 0);
o([ _ ], i.prototype, "isNotLogin", void 0);
i = o([ a ], i);
n.default = i;
cc._RF.pop();
}, {} ],
PrefabEDefined: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "a9c77lq3AJF+rUbcC9M4FrY", "PrefabEDefined");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const {ccclass: a, property: _} = cc._decorator;
cc.Enum({
VN: 0,
EN: 1,
MM: 2
});
let i = class {
constructor() {
this.namePrefab = "";
this.prfDefined = null;
}
};
o([ _(cc.String) ], i.prototype, "namePrefab", void 0);
o([ _(cc.Prefab) ], i.prototype, "prfDefined", void 0);
i = o([ a("PrefabEDefined") ], i);
n.default = i;
cc._RF.pop();
}, {} ],
SpineAnimationSet: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "56bbdf7cCJAGqszWrJva9rh", "SpineAnimationSet");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const a = e("./LanguageMgr"), {ccclass: _, property: i} = cc._decorator, r = cc.Enum({
VN: 0,
EN: 1,
MM: 2
});
let c = class {
constructor() {
this.language = r.VN;
this.skeletonData = null;
}
setLang(e) {
this.language = e;
}
getLang() {
return this.language == r.VN ? a.LANGUAGE.VIETNAMESE : this.language == r.EN ? a.LANGUAGE.ENGLISH : this.language == r.MM ? a.LANGUAGE.MYANMAR : void 0;
}
};
o([ i({
type: r
}) ], c.prototype, "language", void 0);
o([ i(sp.SkeletonData) ], c.prototype, "skeletonData", void 0);
c = o([ _("SpineAnimationSet") ], c);
n.default = c;
cc._RF.pop();
}, {
"./LanguageMgr": "LanguageMgr"
} ],
SpineLocalized: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "a1db0O/7NpCZoiFCtjY05wg", "SpineLocalized");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const a = e("./LanguageMgr"), _ = e("./SpineAnimationSet"), {ccclass: i, property: r, menu: c} = cc._decorator;
let s = class extends BGUI.SpineLocalized {
constructor() {
super(...arguments);
this.isRunNew = !1;
this.isLoop = !0;
this.spineConfigs = this.loadLang();
}
loadLang() {
for (var e = [], t = 0; t < Object.keys(a.LANGUAGE).length; t++) {
var n = new _.default();
n.setLang(t);
e.push(n);
}
return e;
}
};
o([ r(cc.Boolean) ], s.prototype, "isRunNew", void 0);
o([ r(cc.Boolean) ], s.prototype, "isLoop", void 0);
o([ r({
type: [ _.default ],
visible: function() {
return !this.isRunNew;
}
}) ], s.prototype, "spineConfigs", void 0);
s = o([ i, c("BGUI/Multi Language/Spine") ], s);
n.default = s;
cc._RF.pop();
}, {
"./LanguageMgr": "LanguageMgr",
"./SpineAnimationSet": "SpineAnimationSet"
} ],
SpriteFrameSet: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "f2e59J/03NPSZUyVWWoJOuu", "SpriteFrameSet");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const a = e("./LanguageMgr"), {ccclass: _, property: i} = cc._decorator, r = cc.Enum({
VN: 0,
EN: 1,
MM: 2,
TL: 3,
CAM: 4
});
let c = class {
constructor() {
this.language = r.VN;
this.spriteFrame = null;
}
setLang(e) {
this.language = e;
}
getLang() {
return this.language == r.VN ? a.LANGUAGE.VIETNAMESE : this.language == r.EN ? a.LANGUAGE.ENGLISH : this.language == r.MM ? a.LANGUAGE.MYANMAR : this.language == r.TL ? a.LANGUAGE.THAILAN : this.language == r.CAM ? a.LANGUAGE.CAMBODIA : void 0;
}
};
o([ i({
type: r
}) ], c.prototype, "language", void 0);
o([ i(cc.SpriteFrame) ], c.prototype, "spriteFrame", void 0);
c = o([ _("SpriteFrameSet") ], c);
n.default = c;
cc._RF.pop();
}, {
"./LanguageMgr": "LanguageMgr"
} ],
SpriteLocalized: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "5289fxom5JMMZ9tY6WsMujG", "SpriteLocalized");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const a = e("./LanguageMgr"), _ = e("./SpriteFrameSet"), {ccclass: i, property: r, menu: c} = cc._decorator;
let s = class extends BGUI.SpriteLocalized {
constructor() {
super(...arguments);
this.spriteConfigs = this.loadLang();
}
loadLang() {
for (var e = [], t = 0; t < Object.keys(a.LANGUAGE).length; t++) {
var n = new _.default();
n.setLang(t);
e.push(n);
}
return e;
}
};
o([ r([ _.default ]) ], s.prototype, "spriteConfigs", void 0);
s = o([ i, c("BGUI/Multi Language/Sprite") ], s);
n.default = s;
cc._RF.pop();
}, {
"./LanguageMgr": "LanguageMgr",
"./SpriteFrameSet": "SpriteFrameSet"
} ],
UIAutoLayout: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "c6cda9lQuNPlLL7+cteSbei", "UIAutoLayout");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const {ccclass: a, property: _} = cc._decorator;
let i = class extends BGUI.UIAutoLayout {
constructor() {
super(...arguments);
this.type = BGUI.eAutoLayoutType.Raw;
}
};
o([ _(cc.Enum({
type: cc.Enum(BGUI.eAutoLayoutType)
})) ], i.prototype, "type", void 0);
i = o([ a ], i);
n.default = i;
cc._RF.pop();
}, {} ],
UIButtonCommon: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "58361a529dG1LTx1JYiJ4GA", "UIButtonCommon");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const a = e("../localize/LanguageMgr"), {ccclass: _, property: i} = cc._decorator;
let r = class extends BGUI.UIButtonCommon {
constructor() {
super(...arguments);
this.listSprite = [];
this.lbAction = null;
}
onLoad() {
var e = this.lbAction.string;
"" !== e && (e.toUpperCase() == a.LanguageMgr.getString("alert.ok").toUpperCase() ? this.node.getComponent(cc.Sprite).spriteFrame = this.listSprite[0] : e.toUpperCase() != a.LanguageMgr.getString("alert.no").toUpperCase() && e != a.LanguageMgr.getString("alert.close").toUpperCase() || (this.node.getComponent(cc.Sprite).spriteFrame = this.listSprite[1]));
}
};
o([ i(cc.SpriteFrame) ], r.prototype, "listSprite", void 0);
o([ i(cc.Label) ], r.prototype, "lbAction", void 0);
r = o([ _ ], r);
n.default = r;
cc._RF.pop();
}, {
"../localize/LanguageMgr": "LanguageMgr"
} ],
UIDragDrop: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "b7247PMzvRJu5hX8uUdEr2+", "UIDragDrop");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const {ccclass: a, property: _} = cc._decorator;
let i = class extends BGUI.UIDragDrop {
constructor() {
super(...arguments);
this.dragAlwaysCenter = !0;
this.backToStartPosition = !1;
this.stickyDrag = !1;
this.propagateTouchEvent = !0;
this.dragScale = 1;
this.disableScrollViewWhileDrag = !0;
}
};
o([ _ ], i.prototype, "dragAlwaysCenter", void 0);
o([ _ ], i.prototype, "backToStartPosition", void 0);
o([ _ ], i.prototype, "stickyDrag", void 0);
o([ _ ], i.prototype, "propagateTouchEvent", void 0);
o([ _ ], i.prototype, "dragScale", void 0);
o([ _ ], i.prototype, "disableScrollViewWhileDrag", void 0);
i = o([ a ], i);
n.default = i;
cc._RF.pop();
}, {} ],
UIDraggable: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "b338c6fXEFECb3+bljbGmPU", "UIDraggable");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const {ccclass: a, property: _} = cc._decorator;
let i = class extends BGUI.UIDraggable {
constructor() {
super(...arguments);
this.draggable = !0;
this.backToStartPosition = !1;
this.autoFitEdge = !1;
}
};
o([ _ ], i.prototype, "draggable", void 0);
o([ _ ], i.prototype, "backToStartPosition", void 0);
o([ _ ], i.prototype, "autoFitEdge", void 0);
i = o([ a ], i);
n.default = i;
cc._RF.pop();
}, {} ],
UIJoystick: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "1417dvOjyhG7qZIi1TJTTxC", "UIJoystick");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const {ccclass: a, property: _} = cc._decorator;
let i = class extends BGUI.UIJoystick {
constructor() {
super(...arguments);
this.analog = null;
this.background = null;
this.radius = 60;
this.touchAnyWhereToStart = !0;
this.followFinger = !0;
}
};
o([ _(cc.Node) ], i.prototype, "analog", void 0);
o([ _(cc.Node) ], i.prototype, "background", void 0);
o([ _ ], i.prototype, "radius", void 0);
o([ _ ], i.prototype, "touchAnyWhereToStart", void 0);
o([ _ ], i.prototype, "followFinger", void 0);
i = o([ a ], i);
n.default = i;
cc._RF.pop();
}, {} ],
UIPersitsNode: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "5cd3ew3VKdAh6L7xnu2XSSg", "UIPersitsNode");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const {ccclass: a, property: _} = cc._decorator;
let i = class extends cc.Component {
onLoad() {
cc.game.addPersistRootNode(this.node);
}
};
i = o([ a ], i);
n.default = i;
cc._RF.pop();
}, {} ],
UIPopupCommon: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "f08fe9yX5BCq4keohrUs7Wh", "UIPopupCommon");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const {ccclass: a, property: _} = cc._decorator;
let i = class extends BGUI.UIPopupCommon {
constructor() {
super(...arguments);
this.lbTitle = null;
this.lbContent = null;
this.nCustomView = null;
this.nActionContainer = null;
this.buttons = new Map();
this.nSmall = null;
this.nBig = null;
this.lbContent_Small = null;
this.nActionContainerSmall = null;
}
};
o([ _(cc.Label) ], i.prototype, "lbTitle", void 0);
o([ _(cc.Label) ], i.prototype, "lbContent", void 0);
o([ _(cc.Node) ], i.prototype, "nCustomView", void 0);
o([ _(cc.Node) ], i.prototype, "nActionContainer", void 0);
o([ _(cc.Node) ], i.prototype, "nSmall", void 0);
o([ _(cc.Node) ], i.prototype, "nBig", void 0);
o([ _(cc.Label) ], i.prototype, "lbContent_Small", void 0);
o([ _(cc.Node) ], i.prototype, "nActionContainerSmall", void 0);
i = o([ a ], i);
n.default = i;
cc._RF.pop();
}, {} ],
UIPopup: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "2558ehHVUhC1Y7abTC2mXc3", "UIPopup");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const {ccclass: a, property: _} = cc._decorator;
let i = class extends BGUI.UIPopup {};
i = o([ a ], i);
n.default = i;
cc._RF.pop();
}, {} ],
UIScreen: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "742e77TYztKOK9Af6WwIErB", "UIScreen");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const {ccclass: a, property: _} = cc._decorator;
let i = class extends BGUI.UIScreen {
constructor() {
super(...arguments);
this.hideCurScreenOnShow = !0;
}
};
o([ _(cc.Boolean) ], i.prototype, "hideCurScreenOnShow", void 0);
i = o([ a ], i);
n.default = i;
cc._RF.pop();
}, {} ],
UIScrollBar: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "eb2bf77+s1LKIARwbyQpinD", "UIScrollBar");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
n.UIScrollBarDirection = void 0;
const {ccclass: a, property: _} = cc._decorator;
var i;
(function(e) {
e[e.HORIZONTAL = 0] = "HORIZONTAL";
e[e.VERTICAL = 1] = "VERTICAL";
})(i = n.UIScrollBarDirection || (n.UIScrollBarDirection = {}));
let r = class extends BGUI.UIScrollBar {
constructor() {
super(...arguments);
this.handle = null;
this.direction = i.VERTICAL;
this.enableAutoHide = !0;
this.autoHideTime = 1;
}
};
o([ _(cc.Sprite) ], r.prototype, "handle", void 0);
o([ _({
type: cc.Enum(i)
}) ], r.prototype, "direction", void 0);
o([ _(cc.Boolean) ], r.prototype, "enableAutoHide", void 0);
o([ _(cc.Float) ], r.prototype, "autoHideTime", void 0);
r = o([ a ], r);
n.default = r;
cc._RF.pop();
}, {} ],
UIScrollContent: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "a2324boZkJFxpzNX6zz85gx", "UIScrollContent");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const {ccclass: a, property: _} = cc._decorator;
let i = class extends cc.Component {
constructor() {
super(...arguments);
this._scrollView = null;
}
get scrollView() {
return this._scrollView;
}
set scrollView(e) {
this._scrollView = e;
}
};
i = o([ a ], i);
n.default = i;
cc._RF.pop();
}, {} ],
UIScrollView: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "4d28aYP5v1NRJI1EFf152rw", "UIScrollView");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const a = e("./UIScrollBar"), {ccclass: _, property: i} = cc._decorator;
let r = class extends BGUI.UIScrollView {
constructor() {
super(...arguments);
this.direction = BGUI.UIScrollDirection.BOTH;
this.zoomScaleEnabled = !1;
this.maxScale = 1;
this.minScale = 1;
this.content = null;
this.scrollEnabled = !0;
this.touchEnabled = !0;
this.dragChildrenEnabled = !1;
this.easingAutoScroll = !0;
this.movementFactor = .64;
this.horizontalScrollBar = null;
this.verticalScrollBar = null;
this.autoClearAutoScroll = !1;
this.autoClearAutoZoomScale = !1;
}
};
o([ i({
type: cc.Enum(BGUI.UIScrollDirection)
}) ], r.prototype, "direction", void 0);
o([ i ], r.prototype, "zoomScaleEnabled", void 0);
o([ i ], r.prototype, "maxScale", void 0);
o([ i ], r.prototype, "minScale", void 0);
o([ i(cc.Node) ], r.prototype, "content", void 0);
o([ i ], r.prototype, "scrollEnabled", void 0);
o([ i ], r.prototype, "touchEnabled", void 0);
o([ i ], r.prototype, "dragChildrenEnabled", void 0);
o([ i ], r.prototype, "easingAutoScroll", void 0);
o([ i ], r.prototype, "movementFactor", void 0);
o([ i(a.default) ], r.prototype, "horizontalScrollBar", void 0);
o([ i(a.default) ], r.prototype, "verticalScrollBar", void 0);
o([ i ], r.prototype, "autoClearAutoScroll", void 0);
o([ i ], r.prototype, "autoClearAutoZoomScale", void 0);
r = o([ _ ], r);
n.default = r;
cc._RF.pop();
}, {
"./UIScrollBar": "UIScrollBar"
} ],
UITabbarController: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "f48e8Syq7FBnpz9MjThYlbS", "UITabbarController");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const a = e("./UITabbarItem"), {ccclass: _, property: i} = cc._decorator;
let r = class extends BGUI.UITabbarController {
constructor() {
super(...arguments);
this.items = [];
this.content = null;
this.titleLabel = null;
this.startIndex = 0;
}
};
o([ i([ a.default ]) ], r.prototype, "items", void 0);
o([ i(cc.Node) ], r.prototype, "content", void 0);
o([ i(cc.Label) ], r.prototype, "titleLabel", void 0);
o([ i(cc.Integer) ], r.prototype, "startIndex", void 0);
r = o([ _ ], r);
n.default = r;
cc._RF.pop();
}, {
"./UITabbarItem": "UITabbarItem"
} ],
UITabbarItem: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "b92a2UbPxROtq7hEHvw7+8y", "UITabbarItem");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const {ccclass: a, property: _} = cc._decorator;
let i = class extends BGUI.UITabbarItem {
constructor() {
super(...arguments);
this.title = "";
this.prefab = null;
this.nodeContent = null;
this.nodeOn = null;
this.nodeOff = null;
}
};
o([ _(cc.String) ], i.prototype, "title", void 0);
o([ _({
type: cc.Prefab,
visible: function() {
return !this.isLoadFromUrl;
}
}) ], i.prototype, "prefab", void 0);
o([ _(cc.Node) ], i.prototype, "nodeContent", void 0);
o([ _(cc.Node) ], i.prototype, "nodeOn", void 0);
o([ _(cc.Node) ], i.prototype, "nodeOff", void 0);
i = o([ a ], i);
n.default = i;
cc._RF.pop();
}, {} ],
UITableCell: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "62daaYiRPtH+pZrGfUKRZsO", "UITableCell");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const {ccclass: a, property: _} = cc._decorator;
let i = class extends BGUI.UITableCell {
constructor() {
super(...arguments);
this.nSelected = null;
this.nDeselected = null;
this.nHighlighted = null;
this.nUnhighlighted = null;
}
};
o([ _(cc.Node) ], i.prototype, "nSelected", void 0);
o([ _(cc.Node) ], i.prototype, "nDeselected", void 0);
o([ _(cc.Node) ], i.prototype, "nHighlighted", void 0);
o([ _(cc.Node) ], i.prototype, "nUnhighlighted", void 0);
i = o([ a ], i);
n.default = i;
cc._RF.pop();
}, {} ],
UITableView: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "a0e36R/pTtMt7lUY1yP/dOz", "UITableView");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const a = e("./UIScrollBar"), {ccclass: _, property: i} = cc._decorator;
let r = class extends BGUI.UITableView {
constructor() {
super(...arguments);
this.direction = BGUI.UIScrollDirection.BOTH;
this.zoomScaleEnabled = !1;
this.maxScale = 1;
this.minScale = 1;
this.content = null;
this.scrollEnabled = !0;
this.touchEnabled = !0;
this.dragChildrenEnabled = !1;
this.easingAutoScroll = !0;
this.movementFactor = .64;
this.horizontalScrollBar = null;
this.verticalScrollBar = null;
this.autoClearAutoScroll = !1;
this.autoClearAutoZoomScale = !1;
this.fillOrder = BGUI.UITableViewFillOrder.LEFT_TO_RIGHT__TOP_TO_BOTTOM;
this.interactionMode = BGUI.UITableViewInteractionMode.NONE;
this.cellPagingEnabled = !1;
this.numberOfPagingCell = 1;
this.tableCell = null;
this.nEmpty = null;
}
};
o([ i({
type: cc.Enum(BGUI.UIScrollDirection)
}) ], r.prototype, "direction", void 0);
o([ i ], r.prototype, "zoomScaleEnabled", void 0);
o([ i ], r.prototype, "maxScale", void 0);
o([ i ], r.prototype, "minScale", void 0);
o([ i(cc.Node) ], r.prototype, "content", void 0);
o([ i ], r.prototype, "scrollEnabled", void 0);
o([ i ], r.prototype, "touchEnabled", void 0);
o([ i ], r.prototype, "dragChildrenEnabled", void 0);
o([ i ], r.prototype, "easingAutoScroll", void 0);
o([ i ], r.prototype, "movementFactor", void 0);
o([ i(a.default) ], r.prototype, "horizontalScrollBar", void 0);
o([ i(a.default) ], r.prototype, "verticalScrollBar", void 0);
o([ i ], r.prototype, "autoClearAutoScroll", void 0);
o([ i ], r.prototype, "autoClearAutoZoomScale", void 0);
o([ i({
type: cc.Enum(BGUI.UITableViewFillOrder)
}) ], r.prototype, "fillOrder", void 0);
o([ i({
type: cc.Enum(BGUI.UITableViewInteractionMode)
}) ], r.prototype, "interactionMode", void 0);
o([ i(cc.Boolean) ], r.prototype, "cellPagingEnabled", void 0);
o([ i(cc.Integer) ], r.prototype, "numberOfPagingCell", void 0);
o([ i(cc.Prefab) ], r.prototype, "tableCell", void 0);
o([ i(cc.Node) ], r.prototype, "nEmpty", void 0);
r = o([ _ ], r);
n.default = r;
cc._RF.pop();
}, {
"./UIScrollBar": "UIScrollBar"
} ],
UITextManager: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "33835FdSiNMLbniOKoxQEKX", "UITextManager");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const {ccclass: a, property: _} = cc._decorator;
let i = class extends BGUI.UITextManager {};
i = o([ a ], i);
n.default = i;
cc._RF.pop();
}, {} ],
UITooltipHandler: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "a1d90/iSb9Ito7NsDnUV/fy", "UITooltipHandler");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
n.TooltipHideType = void 0;
const {ccclass: a, property: _} = cc._decorator;
var i;
(function(e) {
e[e.OnTouchDownOnScreen = 0] = "OnTouchDownOnScreen";
e[e.OnTouchUpOrMoveFromTarget = 1] = "OnTouchUpOrMoveFromTarget";
e[e.Invalid = 2] = "Invalid";
})(i = n.TooltipHideType || (n.TooltipHideType = {}));
let r = class extends BGUI.UITooltipHandler {
constructor() {
super(...arguments);
this.followTarget = !0;
this.showAtTarget = !1;
this.hideType = i.OnTouchDownOnScreen;
this.manager = null;
}
};
o([ _ ], r.prototype, "followTarget", void 0);
o([ _ ], r.prototype, "showAtTarget", void 0);
o([ _({
type: cc.Enum(i)
}) ], r.prototype, "hideType", void 0);
r = o([ a ], r);
n.default = r;
cc._RF.pop();
}, {} ],
UITooltipListener: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "d36170HNpZJ5YQK3y54ATqX", "UITooltipListener");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const {ccclass: a, property: _} = cc._decorator;
let i = class extends BGUI.UITooltipListener {
constructor() {
super(...arguments);
this.message = "";
this.prefab = null;
this.target = null;
this.showType = BGUI.TooltipShowType.OnLongClick;
}
};
o([ _ ], i.prototype, "message", void 0);
o([ _(cc.Prefab) ], i.prototype, "prefab", void 0);
o([ _(cc.Node) ], i.prototype, "target", void 0);
o([ _({
type: cc.Enum(BGUI.TooltipShowType)
}) ], i.prototype, "showType", void 0);
i = o([ a ], i);
n.default = i;
cc._RF.pop();
}, {} ],
UITooltipManager: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "2ff118MmC1KSZM8CtawreW6", "UITooltipManager");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const {ccclass: a, property: _} = cc._decorator;
let i = class extends BGUI.UITooltipManager {};
i = o([ a ], i);
n.default = i;
cc._RF.pop();
}, {} ],
UITooltipMessage: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "bd03bTob9tOAYQmoYOj377n", "UITooltipMessage");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const a = e("./UITooltipHandler"), {ccclass: _, property: i} = cc._decorator;
let r = class extends a.default {
constructor() {
super(...arguments);
this.spBubble = null;
this.lbMessage = null;
}
};
o([ i(cc.Sprite) ], r.prototype, "spBubble", void 0);
o([ i(cc.Label) ], r.prototype, "lbMessage", void 0);
r = o([ _ ], r);
n.default = r;
cc._RF.pop();
}, {
"./UITooltipHandler": "UITooltipHandler"
} ],
UITouchHandler: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "22b49OMdi9K87wllJuw5ca+", "UITouchHandler");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const {ccclass: a, property: _} = cc._decorator;
let i = class extends BGUI.UITouchHandler {
constructor() {
super(...arguments);
this.touchEvent = new cc.Component.EventHandler();
this.longClickEnabled = !1;
}
};
o([ _(cc.Component.EventHandler) ], i.prototype, "touchEvent", void 0);
o([ _ ], i.prototype, "longClickEnabled", void 0);
i = o([ a ], i);
n.default = i;
cc._RF.pop();
}, {} ],
UIWaitingLayout: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "eadffzSZzdO+KkgOXSaKZBe", "UIWaitingLayout");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const {ccclass: a, property: _} = cc._decorator;
let i = class extends BGUI.UIWaitingLayout {
constructor() {
super(...arguments);
this.nFaded = null;
this.nLoading = null;
}
onDisable() {
this.node.off(cc.Node.EventType.TOUCH_START, this._onTouchStart, this);
}
onEnable() {
this.node.on(cc.Node.EventType.TOUCH_START, this._onTouchStart, this);
this.nLoading && (this.nLoading.active = !1);
this.nFaded && (this.nFaded.active = !1);
let e = cc.sequence(cc.delayTime(0), cc.callFunc(this._showWaitingUI.bind(this)));
e.setTag(99);
this.node.stopActionByTag(99);
this.node.runAction(e);
}
_showWaitingUI() {
this.nLoading && (this.nLoading.active = !0);
this.nFaded && (this.nFaded.active = !0);
}
_onTouchStart(e) {
e.stopPropagation();
}
};
o([ _(cc.Node) ], i.prototype, "nFaded", void 0);
o([ _(cc.Node) ], i.prototype, "nLoading", void 0);
i = o([ a ], i);
n.default = i;
cc._RF.pop();
}, {} ],
UIWindow: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "5b513z6C69Kr4wF3siWJHY2", "UIWindow");
var o = this && this.__decorate || function(e, t, n, o) {
var a, _ = arguments.length, i = _ < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var r = e.length - 1; r >= 0; r--) (a = e[r]) && (i = (_ < 3 ? a(i) : _ > 3 ? a(t, n, i) : a(t, n)) || i);
return _ > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
const {ccclass: a, property: _} = cc._decorator;
let i = class extends BGUI.UIWindow {};
i = o([ a ], i);
n.default = i;
cc._RF.pop();
}, {} ],
cam: [ function(e, t) {
"use strict";
cc._RF.push(t, "56f46Y2P3xGcr8524KB0y9d", "cam");
var n, o;
t.exports = {
"": "",
alert: {
title_notification: "သတိပေးစာ",
ok: "အတည်ပြုပါ",
yes: "ရှိသည်",
no: "ခွင့်မပြု",
loaded: "တာဝန်ခံ",
close: "ပယ္ဖ်က္မည္",
refuse: "ငြင်းပယ်သည်",
veritify: "တိကျမှန်ကန်မှု",
fail: "မှားယွင်းချက်",
discard: "ပြန်လည်ရွေးချယ်ပါ",
confirm_logout: "မင်းထွက်ချင်တာသေချာလား?",
you_need_veritify_pin: "သင်၏ PIN နံပါတ် တိကျမှန်ကန်မှု လိုအပ်သည်",
you_need_veritify_phone_number: "သင်၏ ဖုန်းနံပါ်တ် တိကျမှန်ကန်မှု လိုအပ်သည်!",
you_need_veritify_loaded_card: "သင်၏ ကဒ်နံပါတ်လိုအပ်သည်",
coming_soon: "လုပ်ငန်းဖြစ်အံ့ဆဲဆဲ",
coming_soon_game: "Game မကြာမှီလာမည်",
game_maintian: "Game ပြုပြင်ဆဲ",
fucntion_maintian: "အချက်အလက်များ ပြုပြင်ထိန်းသိမ်းထားသည်",
fucntion_use_lobby: "The function can only be used outside the lobby!",
action_fast: "You act too fast. Please try again in a moment!",
error: {
not_enough_gold: "GOLD ေကြွ စေ့ မလုံ လောက်ပါ",
wrong_captcha: "Captcha မှားနေသည်",
wrong_syntax: "ဝါကျဖွဲ့ပုံဖွဲ့နည်းမှားနေသည်",
wrong_pin: "PIN နံပါတ် မဟုတ်ပါ , ကုဒ်နံပါတ်မှတ်ပုံတင်ထားခြင်း မရှိသေးပါ",
wrong_pin_or_not_reg_pin: "PIN နံပါတ် မှားနေသည် , ကုဒ်နံပါတ်မှတ်ပုံတင်ထားခြင်း မရှိသေးပါ",
account_undefined: "ကစားသမား မတည်ရှိပါ",
connector: {
fail: "အင်တာနက် ချိတ်ဆက်မထားပါ , ချိတ်ဆက်မှုကို ပြန်လည် စစ်ဆေးပါ",
a_2: "ကွန်ယက် ချိတ်ဆက်မှု ရှိရန် လိုအပ်သည်",
a_3: "စနစ်သို့ ဆက်သွယ်နေသည်",
a_4: "သင် လက်ဆောင်မရရှိသေးပါ.\n \n လက်ဆောင်များရရှိရန် အဖွဲ့ တစ်ခုသို့ ၀င်ရောက်ပါ!",
a_5: "‌ေကျးဇူးပြု၍ PIN ကုဒ် နံပါတ် ၀င်ရောက်ပါ",
a_6: "‌ေကျးဇူးပြု၍ Captcha ၀င်ရောက်ပါ!",
expired: "အ‌ကော့င်ထဲသို့လုပ်ငန်းဆောင်ရွက်မှုကုန်ဆုံးသွားသည် , ‌ေကျးဇူးပြု၍ ထပ်မံ၀င်ရောက်ပါ",
ban: "သင့်၏ Account (အကော့င်) ဖြစ်ပျက်နေသောသော့ခတ် (လော့ဂ်စ် / သော့ခတ်) ကသွားခဲ့သည်",
a_9: "စနစ်သို့ ပြုပြင်နေသည် \n ‌ေကျးဇူးပြု၍နောက်မှ ပြန်လာပါရန်!",
some_where: "The account is already logged in elsewhere"
},
services: {
a_10: "သုံးစွဲသူ၏ စာရင်း (သို့မဟုတ်) လျို့၀ှက်နံပါတ် မှားယွင်းနေပါသည်",
a_11: "Account (စာရင်း) သည် အသုံးပြုပြီး ဖြစ်သည်",
a_12: "Account (စာရင်း) သည် မတည်ရှိသေးပါ",
a_13: "လျို့၀ှက်နံပါတ် မှားယွင်းနေပါသည်",
a_14: "သင်သည် အလွန်များပြားသော Account (စာရင်း ) များ မှတ်ပုံတင် ထားသည်.",
a_15: "သင်၏ Account (စာရင်း) ဖန်တီးနေခြင်းကို ဆက်လက်ရန် ေကျးဇူးပြု၍ မိနစ် အနည်းငယ်စော့င်ပါ.",
a_16: "သင်သည် အလွန်များပြားသော Account (စာရင်း ) များ ဖန်တီး ထားသည် \n  ေကျးဇူးပြု၍ မနက်ဖြန်မှ ပြန်လာပါရန်."
},
defined: {
fail: "မသိနိုငိသော ချို့ယွင်းချက်",
param_invalid: "အချက်အလက်ကမမှန်ကန်ပါ",
maintain_system: "စနစ်သို့ ပြုပြင်နေသည် , ‌ေကျးဇူးပြု၍နောက်မှ ပြန်လာပါရန်",
session_key_invalid: "Session key မတည်ရှိပါဘူး",
session_expired: "Session key ကုန်သွားပြီ",
session_room_not_exist: "ကစားကွင်းမရှိပါ",
session_not_enough_min_buy_in: "အနည်းဆုံးအလောင်းအစားမလုံလောက်ပါ",
out_buy_in_range: "အကွာအဝေးထဲက",
game_structure_invalid: "Game structure မတည်ရှိပါဘူး",
already_in_game: "သင်ဂိမ်းထဲမှာရှိနေပြီးဖြစ်သည်",
entering_game: "ဂိမ်းထဲဝင်ပါ",
gift_code_invalid: "Giftcode မတည်ရှိပါဘူး",
gift_code_is_used: "Giftcode အသုံးပြုခဲ့သည်",
gift_code_is_expired: "Giftcode ခေတ်ကုန်ပြီ",
login_banned_ip: "င့် IP သည်သော့ခတ်ထားသည်.\n ကျေးဇူးပြုပြီးဆက်သွယ်ပါ ",
login_banned_user: "သင့်အကောင့်ကိုသော့ခတ်ထားသည်.\n ကျေးဇူးပြုပြီးဆက်သွယ်ပါ ",
player_action_invalid: "မမှန်ကန်သောစစ်ဆင်ရေ",
player_action_fail: "ကြိုးကိုင်ခြယ်လှယ်မှုအမှား",
not_enough_gold: "မလုံလောက်  GOLD",
default: "အမှား",
not_bet_too_long: "သင့်အနေဖြင့်ကြာရှည်စွာမဆက်ဆံခြင်းအားဖြင့်သင့်စနစ်မှဖိတ်ကြားခြင်းခံရသည်"
},
luckywheel: (n = {
system_error: "Lỗi hệ thống.",
received_code: "Tài khoản đã nhận giftcode bảo mật",
system_error_cache: "Lỗi hệ thống. Lưu cache redis lỗi!"
}, n.system_error_cache = "Lỗi hệ thống. Lưu database lỗi!", n.success = "Bạn vừa quay được Giftcode 100K.\n Kiểm tra hòm thư để nhận thưởng", 
n)
}
},
loading: {
check_server: "Checking server information",
update: "Update",
update_success: "Update successful",
update_fail: "Update failed",
please_wait_update_version: "Please update to the latest version",
check_version: "Checking version",
progress_loading_new: "Updating the new version.",
not_loading_manifest: "Could not load manifest",
latest_current_version: "Latest current version",
load: "Loading"
},
login: {
title_quick_play: "ယခုကစားမည္",
login: {
title: "အေကာင့္ဝင္မည္",
placeholder: {
username: "Account Name (စာရင်းနာမည်ဖြ့င်) ၀င်ရောက်ပါ",
pass: "လျို့၀ှက်နံပါတ် ၀င်ရောက်ပါ"
},
save_pass: "အေကာင့္ကို သိမ္းမည္။",
forget: "မေ့ နေသည်",
error: {
login_fail: "Facebook အကော့င်၀င်ရောက်ရန် ကျရှုံးသည်",
please_enter_account_pass: "ေကျးဇူးပြု၍ သင်၏ Account (စာရင်း) နှ့င် Password (လျို့၀ှက်နံပါတ်) ၀င်ရောက်ပါ",
account_pass_than_six_charater: "Account (စာရင်း) သည် ပြီးဆုံးခဲ့ သည့် အချိန် ၆ ပတ်ထက် အနည်းငယ် ရှိမှု ဖြစ်ရမည်"
}
},
registry: {
title: "မွတ္ပံုတင္ပါ",
placeholder: {
username: "Account Name (စာရင်းနာမည်ဖြ့င်) ၀င်ရောက်ပါ",
pass: " လျို့၀ှက်နံပါတ် ၀င်ရောက်ပါ",
pass_confirm: "လျို့၀ှက်နံပါတ် အတည်ပြုပါ",
captcha: "Captcha တင်သွင်းပါ"
},
error: {
facebook_fail: "Login fail",
fail_1: "Username (သုံးစွဲသူ၏နာမည်) သည် အနည်းဆုံး ၆ လုံး ဖြစ်မှ မှတ်ပုံတင်၍ ရမည် , အထူးသီးသ့န် စာလုံးများ မရှိရပါ",
fail_2: "လျို့၀ှက်နံပါတ်သည် အနည်းဆုံး စာလုံး ၈လုံး ရှိရမည်",
fail_3: "လျို့၀ှက်နံပါတ် မှားယွင်းစွာ ၀င်ရောက်နေသည်",
fail_4: "သင်၏ Captcha သို့ ၀င်ရောက်မှု မရှိသေးပါ"
}
},
forget: {
title: "လျို့၀ှက်နံပါတ်  မေ့နေသည်",
placeholder: {
username: "Account Name (စာရင်းနာမည်ဖြ့င်) ၀င်ရောက်ပါ",
pin: "PIN ကုဒ်နံပါတ်် ထည့်ပါ",
pass: " လျို့၀ှက်နံပါတ် ၀င်ရောက်ပါ",
pass_confirm: "လျို့၀ှက်နံပါတ် အတည်ပြုပါ",
captcha: "Captcha တင်သွင်းပါ"
},
error: {
username_please: "ေကျးဇူးပြု၍ သင်၏ Username (သုံးစွဲသူ၏နာမည်) ၀င်ရောက်ပါ",
enter_code_pin_please: "‌ေကျးဇူးပြု၍ PIN ကုဒ် နံပါတ် ၀င်ရောက်ပါ",
enter_new_password_please: "ေကျးဇူးပြု၍ သင်၏ New Password (လျို့၀ှက်နံပါတ်အသစ်) ၀င်ရောက်ပါ",
note_create_new_password: "လျို့၀ှက်နံပါတ်အသစ်သည် စာလုံး ၈ လုံး အထက် ဖြစ်ရမည်",
wrong_enter_password: "လျို့၀ှက်နံပါတ် မှားယွင်းစွာ ၀င်ရောက်နေသည်",
enter_captcha_please: "‌ေကျးဇူးပြု၍  Captcha ၀င်ရောက်ပါ",
note_create_new_password_success: "Password was successfully changed",
wrong_syntax: "Incorrect Syntax",
error_invalid_account_pin: "Username does not exist or the PIN is incorrect",
wrong_captcha: "Incorrect captcha"
}
}
},
lobby: {
lobby_notify_no_talk: "Currently not broadcasting Live\n Please come back later.",
not_have_account: "သင့်တွင်အကောင့်တစ်ခုမရှိပါ။",
profile: "ကိုယ်ရေးအကျဉ်း",
join_time: "ပါဝင်သည့်ရက်စွဲ",
birth_date: "မွေးနေ့",
ip_address: "IP လိပ်စာ",
invite_code: "ရည်ညွှန်းကုဒ်",
change_password: "စကားဝှက်ကိုပြောင်းရန်",
change_avatar: "ကိုယ်ပွားကို ပြောင်းပါ။",
back: "ကျော",
change: "ပြောင်းလဲပါ။",
current_password: "လက်ရှိစကားဝှက်",
new_password: "စကားဝှက်အသစ်",
confirm_new_password: "သင့်စကားဝှက်အသစ်ကို ပြန်လည်ထည့်သွင်းပါ။",
update: "မွမ်းမံ",
deposit_gold: "ရွှေငွေဖြည့်ပါ။",
deposit_history: "ငွေဖြည့်မှတ်တမ်း",
sell_gold: "ရွှေရောင်း",
sell_history: "သမိုင်းရောင်း",
current_credit: "လက်ကျန်ငွေ",
agency: "အေဂျင်စီ",
deposit_money: "သိုက်",
receive_gold: "ရွှေလက်ခံသည်။",
agency_note: "မှတ်ချက်- မလွှဲပြောင်းမီ အေးဂျင့်၏ အချက်အလက်ကို သေချာစစ်ဆေးပါ၊ မပံ့ပိုးသော မှားယွင်းသောထုတ်ဝေသူထံ လွှဲပြောင်းပါ။ ၅ မိနစ်ကြာပြီးနောက် ရွှေအဆက်အသွယ် မရခဲ့ပါ။",
or_call_to: "သို့ ဖုန်းဆက်ပါ။",
note: "မှတ်စုများ",
minimum_trade: "အနိမ့်ဆုံးငွေပေးငွေယူ",
exchange_rate: "ကူးပြောင်းနှုန်း",
account_number: "အကောင့်နံပါတ်",
account_name: "အကောင့်နာမည်",
area: "ဧရိယာ",
confirm: "အတည်ပြုပါ။",
deposit_note: "ငွေသွင်းအမှာစာကို သင် အောင်မြင်စွာ ဖန်တီးပြီးပါပြီ။ ထို့နောက် ငွေသွင်းခြင်းလုပ်ငန်းစဉ်ကို အပြီးသတ်ရန်။ ငွေလွှဲပြေစာပေးပို့ရန် ဖောက်သည်ဝန်ဆောင်မှုကို ဆက်သွယ်ပါ။",
branch: "ကိုင်း",
transfer_code_short: "ငွေပေးငွေယူကုဒ်",
num_transfer_money: "လွှဲပြောင်းပမာဏ",
account_owner_name: "ကိုင်ဆောင်သူအမည်",
status: "အဆင့်အတန်း",
korea: "ကိုရီးယား",
japan: "ဂျပန်",
taiwan: "ထိုင်ဝမ်",
lao: "လာအို",
campuchia: "ကမ္ဘောဒီးယား",
no: "ဂဏန်းအလို့ငှာ",
nickname: "အမည်ပြောင်",
phone_number: "ဖုန်းနံပါတ်",
contact: "ဆက်သွယ်ပါ။",
action: "အက်ရှင်",
buy: "ဝယ်ပါ။",
sell: "ရောင်း",
attendance: "ကျောင်းခေါ်ချိန်",
day: "နေ့",
day1: "နေ့ ၁",
day2: "နေ့ ၂",
day3: "နေ့ ၃",
day4: "နေ့ 4",
day5: "နေ့ ၅",
day6: "၆ ရက်",
day7: "၇ ရက်",
attendance_note: "စနေ၊",
open_egg: "ကြက်ဥကိုဖွင့်ပါ။",
gold_egg: "ရွှေဥ",
white_egg: "ကြက်ဥအဖြူ",
game_download: "ဂိမ်းဒေါင်းလုဒ်လုပ်ပါ။",
download: "ဒေါင်းလုဒ်လုပ်ပါ။",
list_giftcode: "လက်ဆောင်ကုဒ်စာရင်း",
received: "ရရှိခဲ့သည်။",
title_events: "အဲ့ဒါနဲ့",
event: "အဲ့ဒါနဲ့",
event_top_bet: "ထိပ်တန်းလောင်းကစားပွဲ",
event_attendace: "ပွဲတက်ရောက်သူ",
event_receive_bet: "လောင်းကစားပွဲကို ရယူပါ။",
event_find_million: "သန်းကြွယ်သူဌေးဖစ်ရှာပါ။",
event_sicbo: "Sicbo ပွဲ",
event_jackpot_sicbo: "Sicbo Jackpot",
trade_history: "ငွေလွှဲမှတ်တမ်း",
play_gold: "ရွှေကစားပါ။",
play_chip: "ဒင်္ဂါးပြားများကို ကစားပါ။",
deposit_chip: "ငွေဖြည့်ဒင်္ဂါးများ",
expense_gold: "ရွှေဖြုန်း",
trade_code: "ငွေပေးငွေယူကုဒ်",
time: "အချိန်",
service: "ဝန်ဆောင်မှု",
incurred: "ကြုံမည်။",
credit: "လက်ကျန်",
description: "ဖော်ပြချက်",
detail: "အသေးစိတ်",
view: "အမြင်",
account: "အကောင့်",
account_note_full_info: "အထောက်အပံ့ရဖို့။ ကျေးဇူးပြု၍ အောက်ပါအချက်အလက်များကိုဖြည့်ပါ။",
account_note_username: "ဇာတ်ကောင်အမည်သည် အချက်အလက် လိုအပ်သည်။",
type_login_name: "အသုံးပြုသူအမည်ထည့်ပါ။",
authentication_code: "အတည်ပြုရန်ကုတ်",
send: "ပို့ပါ။",
forgot_password: "စကားဝှက်ကိုမေ့နေပါသလား",
telegram_authentication_code: "ကြေးနန်းအထောက်အထားစိစစ်ခြင်းကုဒ်...",
username: "ဇာတ်ကောင်နာမည်",
account_note_username1: "စာလုံး 6 လုံးမှ 16 လုံးကြားရှိ ဇာတ်ကောင်အမည်၊ ထိလွယ်ရှလွယ် စာလုံးများမရှိ၊ အထူးဇာတ်ကောင်များနှင့် နေရာလွတ်များမရှိပါ။",
create_new: "အသစ်ဖန်တီးပါ။",
login_name: "အသုံးပြုသူအမည်",
password: "စကားဝှက်",
save_password: "စကားဝှက်ကိုသိမ်းဆည်းပါ။",
login: "လော့ဂ်အင်",
register: "မှတ်ပုံတင်ပါ။",
confirm_password: "စကားဝှက်အတည်ပြုခြင်း",
invite_code_note: "ရည်ညွှန်းကုဒ် (ချန်လှပ်ထားနိုင်သည်)",
captcha: "Captcha",
sender: "ပေးပို့သူ",
content: "အကြောင်းအရာ",
notify: "အကြောင်းကြားပါ။",
agency_account: "အေဂျင်စီအကောင့်",
notify_note_cheat: "လိမ်လည်မှုများကို ရှောင်ရှားရန် အေးဂျင့်များနှင့်သာ ဆက်ဆံပါ။",
you_sure_send: "သေချာပေါက် လွှဲပြောင်းချင်ပါသည်။",
amount_money: "ငွေပမာဏ",
reason: "အကြောင်းပြချက်",
reject: "မလုပ်တော့",
accept: "လက်ခံပါတယ်။",
buy_gold: "ရွှေဝယ်ပါ။",
gold: "ရွှေ",
type_amount_money: "ငွေဖြည့်သွင်းသည့်ပမာဏကို ထည့်ပါ...",
receive_money: "ရရှိသည့်ပမာဏ",
received_money: "လက်ခံရရှိသည့်ပမာဏ",
num_receive_gold: "ရွှေလက်ခံသည်။",
other_agency: "အခြားအေးဂျင့်များ",
buy_gold_rule: "ရွှေဝယ်ရန်စည်းကမ်းများ",
minimum_trade_value: "အနိမ့်ဆုံး ငွေပေးငွေယူတန်ဖိုး",
trade_fee: "ငွေလွှဲကြေး",
buy_gold_rule_note: "",
buy_gold_rule_note_check_nickname: "ငွေပေးငွေယူမပြုလုပ်မီ လက်ခံရရှိသော အမည်ဝှက်ကို နှစ်ဆစစ်ဆေးပါ။",
type_nickname: "အမည်ပြောင်ထည့်ပါ။",
type_nickname_again: "အမည်ပြောင်ကို ပြန်ထည့်ပါ။",
type_amount_sell_money: "လွှဲပြောင်းရန် ပမာဏကို ထည့်သွင်းပါ။",
type_num_gold: "ရွှေနံပါတ်ထည့်ပါ။",
transfer_reason: "ပြောင်းရွှေ့ရခြင်း အကြောင်းအရင်း",
transfer_note_nickname: 'ရရှိထားသောအမည်ပြောင်သည် လော့ဂ်အင်အကောင့်အမည်မဟုတ်ဘဲ "ဂိမ်းတွင်းပြသမှုအမည်" ဇာတ်ကောင်အမည်ဖြစ်သည်။ ',
transfer_note_wrong_transfer: "*မှားယွင်းသော အကောင့်အမည်သို့ လွှဲပြောင်းလိုက်သော ငွေလွှဲမှုများကို စနစ်က တရားဝင်သော လွှဲပြောင်းမှုများအဖြစ် အလိုအလျောက် သတ်မှတ်ပြီး ပြန်အမ်း၍မရပါ။",
continue: "ဆက်လက်",
transfer_rule: "အပြောင်းအရွှေ့စည်းမျဉ်းများ",
transfer: "အပြောင်းအရွှေ့",
choose_nation: "နိုင်ငံကိုရွေးချယ်ပါ",
transfer_withdraw: "လွှဲပြောင်း/ငွေထုတ်ခြင်း။",
num_transfer_gold: "ရွှေနံပါတ်ပြောင်းပါ။",
current_money: "လက်ရှိငွေ",
transfer_fund: "ရန်ပုံငွေလွှဲပြောင်း",
play_now: "ယခုကစားပါ။",
withdraw_fund: "ရန်ပုံငွေထုတ်ယူ",
withdraw_money: "ထုတ်ယူရမည့်ပမာဏ",
notify_common_noti: " ထုတ်ဝေသူအား ဝမ်းမြောက်စွာ ကြေငြာအပ်ပါသည်။",
notify_common_admin: "BOSS79 စီမံခန့်ခွဲမှုဘုတ်အဖွဲ့မှ လေးစားစွာဖြင့် အသိပေးကြေငြာအပ်ပါသည်။",
notify_common_content: 'To meet the needs of agents and customers,\nwe officially open another site:                                 \nWith a variety of games, "North, Central and South Lottery with extremely\nattractive payout rates compared to the market" and a variety of\nCasino games, Sports bets, Baccarat with extremely high return rates,\nbringing an extremely attractive experience with a 1:1\ndeposit/withdrawal ratio.',
term_of_use: "သတ်မှတ်ချက်များ",
cmtnd: "ID နံပါတ်များ",
active: "လှုပ်လှုပ်ရှားရှား",
email: "အီးမေးလ်",
phone_number_long: "ဖုန်းနံပါတ်",
profile_note_scuriry: "လျှို့ဝှက်အချက်အလက်များအကြောင်း မှတ်သားထားပါ။",
profile_note_update: "အကျိုးခံစားခွင့်များသေချာစေရန် အချက်အလက်ကို အပ်ဒိတ်လုပ်ပါ။",
music: "ဂီတ",
feedBack: "တုံ့ပြန်ချက်",
shop: "ဆိုင်",
gift_code: "GIFTCODE",
type_gift_code: "GiftCode ရိုက်ထည့်ပါ။",
receive: "လက်ခံတယ်။",
mailbox: "စာတိုက်ပုံး",
setting: "ဆက်တင်",
logout: "ထွက်လိုက်ပါ။",
get_otp: "OTP ရယူပါ။",
title_sold_gold: "ရွှေရောင်း",
title_tranfers_gold: "အပြောင်းအရွှေ့",
warning: {
error_try_gain: "အမှားအယွင်းတစ်ခု ဖြစ်ပွားခဲ့သည်။ ကျေးဇူးပြု၍ နောက်မှ ထပ်စမ်းကြည့်ပါ။",
minimum_transfer_500k: "အနိမ့်ဆုံးပမာဏမှာ ရွှေ 500k ဖြစ်သည်။",
not_enough_gold: "လက်ကျန်ငွေ မရရှိနိုင်ပါ။",
maximum_bet_10M: "အားကစားလောင်းကစားအကောင့် 10M ထက်မပိုရပါ။",
transfer_success: "ဂုဏ်ယူပါသည်။ သင်သည် ယခုလေးတင် အောင်မြင်စွာ လွှဲပြောင်းပြီးပါပြီ- ",
error_in_processing: "လုပ်ဆောင်ရာတွင် အမှားအယွင်းရှိခဲ့သည်။",
you_need_type_withdraw_money: "ငွေထုတ်သည့်ပမာဏကို ထည့်သွင်းရန် လိုအပ်ပါသည်။",
wrong_money: "ပမာဏ မမှန်ပါ။",
cant_get_credit_try_again: "လက်ကျန်ကို မရနိုင်ပါ။ ထပ်စမ်းကြည့်ပါ။",
withdraw_success: "ဂုဏ်ယူပါသည်။ သင် အောင်မြင်စွာ ရုပ်သိမ်းလိုက်ပါပြီ။",
delete_mail_success: "မေးလ်ကို အောင်မြင်စွာ ဖျက်လိုက်ပါ။",
you_sure_delete_mail: "သေချာပေါက် မေးလ်ကို ဖျက်ချင်နေပီ",
error: "အမှားအယွင်းတစ်ခု ဖြစ်ပွားခဲ့သည်။",
developing_feature: "အင်္ဂါရပ်သည် ဖွံ့ဖြိုးဆဲဖြစ်သည်။",
wrong_giftcode_check_again: "လက်ဆောင်ကုဒ် မမှန်ပါ။ ထပ်မံစစ်ဆေးပါ။",
gift_code_is_used: "လက်ဆောင်ကုဒ်ကို အသုံးပြုပြီးပါပြီ။",
congluratulation: "ဂုဏ်ယူပါသည်။ သင်လက်ခံရရှိပြီးပါပြီ။",
invalid_giftcode: "ထည့်သွင်းထားသော လက်ဆောင်ကုဒ်သည် မမှန်ကန်ပါ။",
over_exp_giftcode: "လက်ဆောင်ကုဒ် သက်တမ်းကုန်သွားပါပြီ။",
unsecury_account: "စာရင်းမသွင်းရသေးသော အကောင့်လုံခြုံရေး။",
giftcode_cant_use_phone_number: "လက်ဆောင်ကုဒ်သည် ဗီယက်နမ်ဖုန်းနံပါတ်များဖြင့် လုံခြုံသောအကောင့်များနှင့် သက်ဆိုင်ခြင်းမရှိပါ။",
giftcode_cant_use_this_account: "လက်ဆောင်ကုဒ်ကို ဤအကောင့်အတွက် အသုံးမပြုနိုင်ပါ။",
please_type_num_money: "ကျေးဇူးပြု၍ ပမာဏကို ထည့်ပါ။",
minimum_trade: "အနိမ့်ဆုံးငွေပေးငွေယူ",
gold_up: "ရွှေ",
gold_n: "ရွှေ",
not_enough_gold1: "အကောင့်လက်ကျန် မလုံလောက်ပါ။",
username_must_same: "အကောင့်အမည်သည် တူညီရပါမည်။",
please_type_full_info: "အချက်အလက်အပြည့်အစုံကို ထည့်သွင်းပါ။ (ကိုယ်စားလှယ်အမည်၊ အမည်ပြောင်၊ ပမာဏ)",
un_phone_number_verify_account: "အထောက်အထားမခိုင်လုံသောအကောင့် လုံခြုံသောဖုန်းနံပါတ်",
cant_transfer_yourselft: "သင်ကိုယ်တိုင် လွှဲပြောင်းလို့ မရပါဘူး။",
change_avatar_success: "ကိုယ်ပွားကို အောင်မြင်စွာပြောင်းလဲပါ။",
please_type_full_info1: "အချက်အလက်အားလုံးကို ဖြည့်ပါ။",
password_confirm_password_must_same: "စကားဝှက်အသစ်နှင့် အသစ်ပြန်ထည့်သည့် စကားဝှက်သည် အတူတူဖြစ်ရပါမည်။",
old_password_wrong: "စကားဝှက်ဟောင်း မမှန်ပါ။",
you_sure_withdraw: "VND ထုတ်ယူလိုသည်မှာ သေချာသည်။ ရွှေနံပါတ် ",
unexist_account: "အကောင့် မရှိပါ။",
untype_username: "အသုံးပြုသူအမည်ကို သင်မထည့်ရသေးပါ။",
untype_password: "စကားဝှက်မထည့်ရသေးပါ။",
server_lost_connect: "ဆာဗာချိတ်ဆက်မှု ပြတ်တောက်သွားသည်။",
account_logining_please_logout: "သင့်အကောင့်ကို အခြားနေရာတွင် ဝင်ရောက်နေပါသည်။ အကောင့်မဝင်ခင် အကောင့်ထွက်ပါ။",
account_banning: "အကောင့်ကို ပိတ်ပင်ထားသည်။",
invalid_authentication_code: "အထောက်အထားစိစစ်ခြင်းကုဒ် မမှန်ပါ။",
overtime_authentication: "အတည်ပြုကုဒ် သက်တမ်းကုန်သွားပါပြီ။",
server_maintain_go_later: "စနစ်က ပြုပြင်ထိန်းသိမ်းမှုပါ။ ကျေးဇူးပြုပြီး နောက်မှပြန်လာပါ။",
password_wrong: "စကားဝှက်မှား",
login_banned: "ဝင်ရောက်ရန် တားမြစ်ထားသည်။",
unexist_user: "အသုံးပြုသူမရှိပါ။",
you_not_create_username: "အကောင့်အတွက် နာမည်ပြောင်တစ်ခု မဖန်တီးရသေးပါ။",
username_warning: "အသုံးပြုသူအမည်သည် အက္ခရာ 6 လုံးမှ 18 လုံးအထိရှိရမည်ဖြစ်ပြီး အသံထွက်မပါဘဲ ချက်ချင်းရေးပါ၊ အထူးစာလုံးများမရှိပါ။",
password_same_warning: "ပြန်လည်ထည့်သွင်းထားသော စကားဝှက်သည် ထည့်သွင်းထားသော စကားဝှက်နှင့် မကိုက်ညီပါ။",
verify_code_wrong: "ကုဒ်မမှန်ပါ။",
internet_unstable: "ကွန်ရက်ချိတ်ဆက်မှု မတည်ငြိမ်ပါ။ wifi/3g ချိတ်ဆက်မှုကို စစ်ဆေးပါ။",
invalid_username: "အသုံးပြုသူအမည် မမှန်ကန်ပါ။",
username_exist: "အသုံးပြုသူအမည် ရှိနှင့်ပြီးဖြစ်သည်။",
invite_code_unexist: "ရည်ညွှန်းကုဒ်မရှိပါ။",
invite_code_wrong_type: "မမှန်ကန်သော ရည်ညွှန်းကုဒ် (ဥပမာ-K1234567)",
captcha_wrong: "captcha ကုဒ် မမှန်ပါ။",
captcha_error: "Captcha အမှား",
nickname_invalid: "မမှန်ကန်သော အမည်ပြောင်",
nickname_exist: "နာမည်ပြောင် ရှိပြီးသားပါ။",
nickname_not_same_username: "အမည်ပြောင်သည် အသုံးပြုသူအမည်နှင့် တူညီနိုင်မည်မဟုတ်ပေ။",
nickname_had: "နာမည်ပြောင်ရှိပြီးသား။",
nickname_not_sentitive: "ထိလွယ်ရှလွယ် နာမည်ပြောင်များကို မရွေးချယ်ပါနှင့်။",
check_network: "ကွန်ရက်ချိတ်ဆက်မှု မတည်ငြိမ်ပါ။",
logined_other_device: "သင်သည် အခြားစက်ပစ္စည်းတွင် အကောင့်ဝင်ထားသည်။",
giftcode_please_enter_full: "လက်ဆောင်ကုဒ်ကိုဖြည့်ပါ။",
info_update_success_contact_to_complete: "အောင်မြင်စွာ မွမ်းမံပြီးပါပြီ။ လုံခြုံရေးအဆင့်ကို အပြီးသတ်ရန် တယ်လီဘော့တ်နှင့် စကားပြောပါ။",
info_error_update: "အချက်အလက်ကို အပ်ဒိတ်လုပ်နေစဉ် အမှားအယွင်းတစ်ခု ဖြစ်ပေါ်ခဲ့သည်။",
info_email_wrong_type: "အီးမေးလ်ဖော်မတ် မမှန်ပါ။",
info_phone_number_wrong_type: "ဖုန်းနံပါတ်ဖော်မတ် မမှန်ပါ။",
info_email_registered_other_account: "အီးမေးလ်ကို အခြားအကောင့်ဖြင့် မှတ်ပုံတင်ပြီးဖြစ်သည်။",
info_not_need_otp_unsecure_account: "လုံခြုံမှုမရှိသောအကောင့်များအတွက် OTP မလိုအပ်ပါ။",
info_phone_number_registered_try_other: "မှတ်ပုံတင်ထားသော ဖုန်းနံပါတ်။ ကျေးဇူးပြု၍ အခြားဖုန်းနံပါတ်ကို အသုံးပြုပါ။",
phone_number_warning: "ဖုန်းနံပါတ်များသည် 10-15 နံပါတ်များရှည်ရပါမည်။",
otp_required: "OTP ကုဒ်သည် အချက်အလက် လိုအပ်ပါသည်။",
otp_tele_wrong: "Tele OTP ကုဒ်မှားရိုက်ထည့်ပါ။ ထပ်စမ်းကြည့်ပါ။",
otp_wrong: "OTP ကုဒ် မမှန်ပါ။",
otp_unexist: "OTP ကုဒ်မရှိပါ။",
otp_overtime_use: "OTP ကုဒ် သက်တမ်းကုန်သွားပါပြီ။",
you_sure_out_game: "ဂိမ်းမှ ထွက်လိုသည်မှာ သေချာပါသလား။",
password_change_success: "စကားဝှက်ပြောင်းလဲခြင်း အောင်မြင်ပါသည်။",
password_required: "စကားဝှက်အသစ်သည် အချက်အလက်လိုအပ်သည်။",
password_confirm_required: "ပြန်လည်ထည့်သွင်းရန် လိုအပ်သော အချက်အလက်",
password_confirm_wrong: "မမှန်သော စကားဝှက်အသစ်ကို ပြန်ထည့်ပါ။",
password_current_wrong: "လက်ရှိ စကားဝှက် မမှန်ပါ။",
account_login_fb_gg_cant_use_feature: "Facebook သို့မဟုတ် Google+ ဖြင့် ဝင်ရောက်ထားသည့် အကောင့်များသည် ဤလုပ်ဆောင်ချက်ကို အသုံးမပြုနိုင်ပါ။",
feature_for_register_secury_account: "ဤအင်္ဂါရပ်သည် မှတ်ပုံတင်ထားသော လုံခြုံရေးအကောင့်များအတွက်ဖြစ်သည်။",
account_warning_nickname: "အမည်ပြောင်များကို မွမ်းမံမွမ်းမံထားသော အကောင့်များကို စနစ်က မပံ့ပိုးပါ။",
you_need_enter_money: "ပမာဏကို ထည့်သွင်းရန် လိုအပ်ပါသည်။",
deposit_order_double: "သင်သည် ငွေဖြည့်သွင်းခြင်း 2 ခုကို နီးကပ်လွန်းစွာ ဖန်တီးထားသည်။",
deposit_order_limit_per_day: "တစ်ရက်အတွင်း အပ်ငွေ အော်ဒါများ ပြုလုပ်ရန် ကန့်သတ်ချက်ကို ကျော်လွန်သွားပါပြီ။ နောက်အမှာစာ မဖန်တီးမီ အပ်ငွေကို အပြီးသတ်ရန် လွှဲပြောင်းရန် လိုအပ်ပါသည်။",
buy_gold_faild: "ရွှေဝယ်ရန် မအောင်မြင်ပါ။",
withdraw_money_faild: "ငွေထုတ်ခြင်း မအောင်မြင်ပါ။",
withdraw_fail: "ငွေထုတ်ခြင်း မအောင်မြင်ပါ။",
success: "အောင်မြင်သည်!",
bank_id_required: "ဘဏ် ID လိုအပ်ပါသည်။",
account_number_required: "အကောင့်နံပါတ် လိုအပ်ပါသည်။",
username_required: "အသုံးပြုသူအမည် လိုအပ်ပါသည်။",
nickname_required: "အမည်ပြောင် လိုအပ်ပါသည်။",
num_gold_required: "ရွှေနံပါတ် လိုအပ်ပါသည်။",
account_number_wrong_type: "အကောင့်နံပါတ် မမှန်ပါ။",
num_gold_wrong_type: "ရွှေနံပါတ် မမှန်ပါ။",
account_banned_transfer: "လွှဲပြောင်းခြင်းလုပ်ဆောင်ချက်မှ အကောင့်ကို လော့ခ်ချထားသည်။",
withdraw_money_minimum: "ငွေထုတ်သည့်ပမာဏသည် ထက်ကြီးသည် သို့မဟုတ် ညီမျှရပါမည်။",
error_undetermine: "အမည်မသိ အမှားတစ်ခု",
not_enough_transfer_require_contact_service: "သင်သည် အရောင်းအ၀ယ်ပြုလုပ်ရန် အရည်အချင်းမပြည့်မီပါ။ အသေးစိတ်အချက်အလက်များကို ဖောက်သည်ဝန်ဆောင်မှုကို ဆက်သွယ်ပါ။",
attendance_success: "အောင်မြင်စွာတက်ရောက်ခြင်း။",
attendance_fail: "တက်ရောက်မှု မအောင်မြင်ပါ။",
account_unregister_secure: "လုံခြုံရေး မှတ်ပုံတင်မထားသည့် အကောင့်",
account_unregister_secure_contact_service: "အကောင့်သည် လုံခြုံရေးလုပ်ဆောင်ချက်ကို စာရင်းမသွင်းရသေးပါ။ အကူအညီအတွက် Telegram:@cskhboss79 သို့မဟုတ် call center 19006896 သို့ ဆက်သွယ်ပါ၊ စကားဝှက်ရယူရန် အကောင့်အချက်အလက်ကို အတည်ပြုပါ။ ကျေးဇူးတင်ပါတယ်!",
account_unexist: "အကောင့်မရှိပါ။",
support: "ကျေးဇူးပြုပြီးဆက်သွယ်ပါ ",
server_unconnect: "ဆာဗာသို့ မချိတ်ဆက်ပါ။",
server_terminate_interupt: "ဆာဗာ ခေတ္တပိတ်ထားသည်။",
account_not_enter: "အသုံးပြုသူအမည်ကို သင်မထည့်ရသေးပါ။",
password_not_enter: "စကားဝှက်မထည့်ရသေးပါ။",
play_game_fun: "ဂိမ်းကို ပျော်ရွှင်စွာ ကစားပါ။",
good_luck_later: "နောက်တစ်ကြိမ် ကံကောင်းပါစေလို့ ဆုတောင်းပါတယ်။",
transfer_account_receive_unexist: "လက်ခံသည့်အကောင့် မရှိပါ။",
transfer_minimum_money: "လွှဲပြောင်းသည့်ပမာဏသည် အနည်းဆုံး ငွေပေးငွေယူတန်ဖိုးထက် နည်းပါသည်။",
account_not_enought_transfer_condition: "အကောင့်သည် ကုန်သွယ်မှုအတွက် အရည်အချင်းမပြည့်မီပါ။ ထုတ်ဝေသူကို ဆက်သွယ်ပါ။",
sercure_feature_auto_active: "မှတ်ပုံတင်ခြင်းအောင်မြင်သည့်အချိန်မှ ၂၄ နာရီအကြာတွင် လုံခြုံရေးလုပ်ဆောင်ချက်ကို အလိုအလျောက် စတင်အသုံးပြုနိုင်မည်ဖြစ်သည်။",
transfer_limit: "ငွေပမာဏအချို့ကို အထွေထွေကိုယ်စားလှယ်ထံသို့သာ လွှဲပေးနိုင်ပါသည်။",
transfer_over_credit: "လွှဲပြောင်းသည့်ပမာဏသည် ကန့်သတ်ချက်ထက်ကျော်လွန်သွားပြီ။",
transfer_account_send_unexist: "ငွေလွှဲအကောင့် မရှိပါ။",
transfer_enter_content: "လိုအပ်သော လွှဲပြောင်းအကြောင်းအရာကို ထည့်သွင်းပါ။",
tranfer_same_account: "ငွေလွှဲအကောင့်သည် လက်ခံအကောင့်နှင့် အတူတူပင်ဖြစ်ပါသည်။",
transfer_local_feature_terminated_contact_service: "အတွင်းပိုင်းလွှဲပြောင်းခြင်းလုပ်ဆောင်ချက်ကို ယာယီဆိုင်းငံ့ထားသည်။ အကူအညီအတွက် ဖောက်သည်ဝန်ဆောင်မှုကို ဆက်သွယ်ပါ။",
transfer_local_feature_terminated_contact_service1: "အတွင်းပိုင်း လွှဲပြောင်းခြင်း လုပ်ဆောင်ချက်ကို ယာယီ ပိတ်ထားသည်။ အသေးစိတ်အချက်အလက်များအတွက် ဖောက်သည်ဝန်ဆောင်မှုကို ဆက်သွယ်ပါ။"
},
gui_profile: {
profile_title: "ကိုယ်ရေးအကျဉ်း",
join_time: "ပါဝင်သည့်ရက်စွဲ",
birth_date: "မွေးနေ့",
ip_address: "IP လိပ်စာ",
invite_code: "ရည်ညွှန်းကုဒ်",
change_password: "စကားဝှက်ကိုပြောင်းရန်",
change_password1: "Change password",
change_avatar: "ကိုယ်ပွားကို ပြောင်းပါ။",
back: "ကျော",
change: "ပြောင်းလဲပါ။",
current_password: "လက်ရှိစကားဝှက်",
new_password: "စကားဝှက်အသစ်",
confirm_new_password: "စကားဝှက်အသစ်ထည့်ပါ။",
update: "အပ်ဒိတ်",
alert: {
warning_1: "သင့်ကိုယ်ပွားသည် ယခင်ရုပ်ပွားတော်နှင့် မတူပါ။",
warning_2: "သင်ပြောင်းလိုသော Avatar ကို ရွေးပါ။"
}
},
gui_agency: {
deposit_title: "ရွှေငွေဖြည့်ပါ။",
deposit_gold: "ရွှေငွေဖြည့်ပါ။",
deposit_history: "ငွေဖြည့်မှတ်တမ်း",
sell_title: "ရွှေရောင်း",
sell_gold: "ရွှေရောင်း",
sell_history: "သမိုင်းကိုရောင်း",
current_credit: "လက်ကျန်ငွေ",
agency: "အေဂျင်စီ",
deposit_money: "အပ်ငွေ",
receive_gold: "ရွှေလက်ခံ",
agency_note: "မှတ်ချက်- မလွှဲပြောင်းမီ အေးဂျင့်၏အချက်အလက်များကို သေချာစစ်ဆေးပါ၊ မပံ့ပိုးသော ထုတ်ဝေသူမှားသို့ လွှဲပြောင်းပါ။ ၅ မိနစ်ကြာပြီးနောက် ရွှေအဆက်အသွယ် မရခဲ့ပါ။",
or_call_to: "ဆက်သွယ်ရန်",
note: "မှတ်ချက်",
minimum_trade: "အနိမ့်ဆုံးငွေပေးငွေယူ",
exchange_rate: "ကူးပြောင်းနှုန်း",
account_number: "အကောင့်နံပါတ်",
account_name: "အကောင့်နာမည်",
area: "ဧရိယာ",
confirm: "အတည်ပြုပါ။",
deposit_note: "ငွေသွင်းအမှာစာကို သင်အောင်မြင်စွာ ဖန်တီးပြီးဖြစ်သည်။ ထို့နောက် ငွေသွင်းခြင်းလုပ်ငန်းစဉ်ကို အပြီးသတ်ရန်။ ငွေလွှဲပြေစာပေးပို့ရန် ဖောက်သည်ဝန်ဆောင်မှုကို ဆက်သွယ်ပါ။",
notify_title: "အကြောင်းကြားပါ။",
num_transfer_gold: "ရွှေနံပါတ်ကို လွှဲပြောင်းပါ။",
receive_money: "လက်ခံရရှိသည့်ပမာဏ",
branch: "ကိုင်း",
account_owner_name: "အကောင့်ပိုင်ရှင်အမည်",
continue: "ဆက်လက်",
status: "အဆင့်အတန်း",
time: "အချိန်",
transfer_code_short: "ငွေပေးငွေယူကုဒ်",
num_transfer_money: "လွှဲပြောင်းပမာဏ"
},
gui_list_agency: {
agency_title: "အေဂျင်စီ",
korea: "ကိုရီးယား",
japan: "ဂျပန်",
taiwan: "ထိုင်ဝမ်",
lao: "လာအို",
campuchia: "ကမ္ဘောဒီးယား",
no: "ဂဏန်းအလို့ငှာ",
agency: "အေဂျင်စီ",
nickname: "အမည်ပြောင်",
phone_number: "ဖုန်းနံပါတ်",
contact: "ဆက်သွယ်ပါ။",
area: "ဧရိယာ",
action: "အက်ရှင်",
buy: "ဝယ်ပါ။",
sell: "ရောင်း"
},
gui_attendance: {
attendance: "ကျောင်းခေါ်ချိန်",
attendance_title: "ကျောင်းခေါ်ချိန်",
day: "နေ့",
day1: "နေ့ ၁",
day2: "နေ့ ၂",
day3: "နေ့ ၃",
day4: "နေ့ ၄",
day5: "နေ့ ၅",
day6: "၆ ရက်",
day7: "၇ ရက်",
attendance_note: "စနေ၊"
},
gui_open_egg: {
open_egg: "ကြက်ဥကိုဖွင့်ပါ။",
gold_egg: "ရွှေဥ",
white_egg: "ရွှေဥ"
},
gui_bundle_download: {
download_game: "ဂိမ်းဒေါင်းလုဒ်လုပ်ပါ။",
download: "ဒေါင်းလုဒ်လုပ်ပါ။"
},
gui_event_list_giftcode: {
list_giftcode_title: "လက်ဆောင်ကုဒ်စာရင်း"
},
gui_events: {
event_title: "ပွဲ",
event: "ပွဲ",
event_top_bet: "ထိပ်တန်းလောင်းကစားပွဲ",
event_attendace: "ပွဲတက်ရောက်သူ",
event_receive_bet: "အလောင်းအစားပွဲကို လက်ခံပါ။",
event_find_million: "သန်းကြွယ်သူဌေးဖစ်ရှာပါ။",
event_sicbo: "Sicbo ပွဲ",
event_jackpot_sicbo: "Sicbo Jackpot"
},
gui_trade_history: {
trade_history_title: "ငွေလွှဲမှတ်တမ်း",
trade_history: "ငွေလွှဲမှတ်တမ်း",
play_gold: "ရွှေကစားပါ။",
play_chip: "အကြွေစေ့ကစားပါ။",
deposit_chip: "ငွေဖြည့်ဒင်္ဂါးများ",
deposit_gold: "ရွှေငွေဖြည့်ပါ။",
expense_gold: "ရွှေဖြုန်း",
trade_code: "ငွေပေးငွေယူကုဒ်",
time: "အချိန်",
service: "ဝန်ဆောင်မှု",
incurred: "ကြုံမည်။",
credit: "လက်ကျန်",
description: "ဖော်ပြချက်",
detail: "အသေးစိတ်",
view: "အမြင်"
},
gui_forgot_password: (o = {
account: "အကောင့်",
account_title: "အကောင့်",
account_note_full_info: "အထောက်အပံ့ရဖို့။ ကျေးဇူးပြု၍ အောက်ပါအချက်အလက်များကိုဖြည့်ပါ။",
account_note_username: "ဇာတ်ကောင်အမည်သည် အချက်အလက် လိုအပ်သည်။",
type_login_name: "အသုံးပြုသူအမည်ထည့်ပါ။",
authentication_code: "အတည်ပြုရန်ကုတ်",
send: "ပို့ပါ။",
forgot_password: "စကားဝှက်ကိုမေ့နေပါသလား",
forgot_password_title: "စကားဝှက်ကိုမေ့နေပါသလား",
telegram_authentication_code: "ကြေးနန်းအထောက်အထားစိစစ်ခြင်းကုဒ်..."
}, o.send = "ပါ", o.new_password = "စကားဝှက်အသစ်", o.confirm_new_password = "သင့်စကားဝှက်အသစ်ကို ပြန်လည်ထည့်သွင်းပါ။", 
o),
gui_display_name: {
account_title: "အကောင့်",
account_note_username: "ဇာတ်ကောင်အမည်သည် အချက်အလက် လိုအပ်သည်။",
username: "အသုံးပြုသူအမည်",
account_note_username1: "စာလုံး 6 လုံးမှ 16 လုံးကြားရှိ ဇာတ်ကောင်အမည်၊ ထိလွယ်ရှလွယ် စာလုံးများမရှိ၊ အထူးဇာတ်ကောင်များနှင့် နေရာလွတ်များမရှိပါ။",
create_new: "အသစ်ဖန်တီးပါ။"
},
gui_login: {
login_title: "အကောင့်",
login_name: "အသုံးပြုသူအမည်",
password: "စကားဝှက်",
save_password: "စကားဝှက်ကိုသိမ်းဆည်းပါ။",
login: "လော့ဂ်အင်",
forgot_password: "စကားဝှက်ကိုမေ့နေပါသလား"
},
gui_registry: {
register_title: "မှတ်ပုံတင်ပါ။",
register: "မှတ်ပုံတင်ပါ။",
login_name: "အသုံးပြုသူအမည်",
password: "စကားဝှက်",
confirm_password: "စကားဝှက်ကိုပြန်လည်ထည့်ပါ",
invite_code_note: "ရည်ညွှန်းကုဒ် (ချန်လှပ်ထားနိုင်သည်)",
captcha: "Captcha"
},
gui_mailbox: {
title: "ခေါင်းစဥ်:",
content: "အကြောင်းအရာ-",
sender: "ပေးပို့သူ-"
},
gui_minigame: {
game_download: "ဂိမ်းဒေါင်းလုဒ်လုပ်ပါ။"
},
gui_confirm_transfer: {
notify: "အကြောင်းကြားပါ။",
agency_account: "အေဂျင်စီအကောင့်",
notify_note_cheat: "လိမ်လည်မှုများကို ရှောင်ရှားရန် အေးဂျင့်များနှင့်သာ ဆက်ဆံပါ။",
you_sure_send: "သင် သေချာပေါက် လွှဲပြောင်းချင်ပါသည်။",
amount_money: "ငွေပမာဏ",
reason: "အကြောင်းပြချက်",
reject: "မလုပ်တော့",
accept: "လက်ခံပါတယ်။",
account: "အကောင့်",
confirm_transfer_title: "အကြောင်းကြားပါ။"
},
gui_buy_gold: {
buy_gold: "ရွှေဝယ်ပါ။",
buy_gold_title: "ရွှေဝယ်ပါ။"
},
gui_sell_gold: {
sell_gold: "Sell Gold",
sell_gold_title: "Sell GOld",
current_credit: "Current Credit",
agency: "Agency",
enter_agency: "Enter agency",
nickname: "NickName",
enter_nickname: "Enter Nickname",
buy_money: "Amout money",
number_sell_gold: "Amount money...",
gold: "Gold",
receive_money: "Receive money...",
other_agency: "Other agency",
continue: "Continue",
transfer_reason: "Transfer reason",
lao: "Laos",
cam: "Cambodia",
vn: "Vietnam",
kor: "Korea",
jp: "Japan",
tw: "Taiwan"
},
gui_notify: {
title_notify: "Notify",
notify_common_admin: "BOSS79 Management Board Sincerely Announcement",
notify_common_noti: " Publisher is pleased to announce"
},
safetybox: {
safetybox_title: "Safety Box",
lb_goldin: "Gold in Safety Box",
note: "Create password to use safe box!",
lb_btn: {
chuyen: "DEPOSIT",
rut: "WITHDRAW",
doimk: "CHANGE PWD",
dongy: "ACCEPT",
back: "BACK"
},
lb_editbox: {
lb_chuyen: "Deposit Gold",
lb_rut: "Withdraw Gold",
placeholder_password_rut: "Enter Safety Box password to withdraw",
placeholder_password_create: "Create password",
placeholder_re_password_create: "Re-enter Password",
placeholder_password_old: "Old pasword",
placeholder_new_password_update: "New password",
placeholder_re_new_password_update: "Re-enter new password"
},
message: {
wrong_password: "Wrong password. Please type again!",
wrong_password_retype: "Re-enter wrong passwrod. Please type again!",
wrong_old_pass: "Old password is incorrect. Please type again!",
withdraw_success: "Withdraw success!",
transfer_success: "Deposit success!",
transfer_failed: "Deposit fail!",
create_password_success: "Create password success!",
update_password_success: "Update password success!",
please_type_money_withdraw: "Enter withdraw amount",
please_type_money_transfer: "Enter deposit amount",
error_create: "Creat fail. Please try again!",
error_update: "Update fail. Please try again!",
error_network: "Network unstable. Please try again later!"
}
},
gui_setting: {
music: "Music",
music_on: "Music (On)",
music_off: "Music (Off)",
term_of_use: "Terms of use",
feedBack: "Feedback"
},
gui_chuyen_quy: {
transfer_withdraw_title: "Deposit/Withdraw",
num_transfer_gold: "Transfer Gold number",
receive_money: "Amount receive",
transfer_fund: "Transfer fund",
play_now: "Play now",
withdraw_fund: "Withdraw fund",
withdraw_money: "Amount to withdraw",
num_receive_gold: "Amount receive",
type_num_gold: "Enter gold number",
type_num_money: "Enter the amount",
receive_gold: "Amount receive",
current_money: "Current credit"
},
gui_transfer: {
transfer: "Transfer",
transfer_title: "Transfer",
current_credit: "Current Credit",
enter_nickname: "Enter Nickname",
re_enter_nickname: "Re-Enter Nickname",
enter_sell_money: "Enter the amount to transfer",
receive_gold: "Receive Gold",
reason: "Transfer reason",
continue: "Continue",
agency: "Agency",
gold: "Gold",
amount_less_than_minimum: "Transfer amount is less than minimum transaction value!",
unregister_security: "Security unregistered account! Please contact Customer Service!",
otp_expired: "OTP code has expired!",
otp_not_correct: "OTP code is not correct!",
otp_error: "OTP code error!",
una_balance: "Unavailable balance!",
lock_transfer: "The nickname is locked from the transfer function!",
acc_not_exist: "Nickname does not exist!",
enter_details: "Please enter transfer details!",
not_transfer_yourself: "Unable to transfer to yourself",
not_transfer_agency: "Agent cannot transfer to agent",
not_transfer_agency2: "Level 2 agents cannot transfer to level 2 agents",
not_transfer_not_your_agency2: "You cannot transfer money to a level 2 agent that is not yours!",
amount_maximum: "\n\nThe maximum amount that can be transferred is %{money} according to GIFTCODE mechanism. For more details, please contact Customer Service!",
transfer_fail: "Transfer failed!",
transfer_success: "Transfer success ",
sell_gold: "Sell Gold to "
},
gui_logout: {
logout_title: "Log Out",
warning: "Are you sure you want to exit the game?",
no: "Cancel",
yes: "Ok"
},
gui_policy: {
policy_title: "Terms of Use"
},
gui_security: {
security_title: "Profile",
account_name: "Account name",
username: "Character name",
cmtnd: "ID Number",
email: "Email",
phone_number: "Phone number",
update: "Update",
active: "Active",
get_otp: "Get OTP"
},
gui_buy_and_sold: {
buy_and_sold_title: "Shop",
transfer: "Transfer",
sell_gold: "Sell Gold",
input_otp: "Input OTP"
},
gui_gift_code: {
notice: "* Please enter the correct to receive the gift and notice the receiving time.\n* Each giftcode is only applicable for 1 account.",
gift_code_title: "Gift Code",
enter_gift_code: "Enter Gift Code",
receive: "Receive"
},
gui_header: {
logout: "Log Out",
safetybox: "Safety Box",
history: "History",
language: "Language",
shop: "Shop",
setting: "Setting",
confirm_change_language: "Are you want to change\nlanguage to %{language} ?",
ok: "Yes",
cancel: "No"
},
gui_choose_nation: {
choose_nation_title: "Choose nation"
},
gui_language: {
language_title: "Language"
},
mergeWord: {
transaction_failed: "Transaction failed. Please try again later!",
transaction_success: "Successful transaction",
seller_not_online: "The seller is currently not online",
insufficient_balance: "Insufficient balance!",
letter_not_exist: "Letters/Numbers do not exist!",
sys_err: "System error. Please try again later!",
price_greater: "The price of letters/numbers must be greater than the floor price!",
wants_to_sell: " wants to sell you the letter/number",
price: "Price: ",
please_choose_letters: "Please choose the letters from the inventory on the left to combine them!",
pairing_fail: "Pairing letters failed.",
pairing_success: "Pairing letters successfully. You receive ",
empty_data: "Empty data",
word_incorrect: "The word set is incorrect!",
not_enough_letters: "You don't have enough letters/numbers!",
account_not_exist: "Account does not exist!",
selling_failed: "Selling words failed. Please try again later!",
selling_success: "Selling words successfully. Please wait for the buyer to confirm!",
buyer_not_online: "The buyer is not online. Please try again later!",
action_fast: "You act too fast. Please try again in a moment!",
greater_minimum: "The transaction amount must be greater than the specified minimum transaction amount",
minimum_selling: "Minimum selling price is 10,000 Gold.",
transaction_fee: "Transaction fee is 5% (Minimum is 10,000 Gold)",
transaction_note: "You want to trade this word with someone else. Please carefully check the sender information and denomination, if the operation is wrong, no refund will be given!",
selling_err: " An error occurred when selling %s for %s to %s",
acepted_buy: "%s agrees to buy letter %s for %s Gold",
not_acepted_buy: "%s doesn't agree to buy letter %s for %s Gold",
please_choose_word: "Please select letter to sell",
please_type_nickname: "Please enter a nickname!",
please_type_price: "Please enter selling price!",
buy: "Buy",
sell: "Sell",
history_buy_sell: "Transaction History",
history_trade_word: "History of letter exchange",
nickname: "Nickname"
}
},
SlotTreeOfFortune: {
main: {
total_bet: "စုစုပေါင်းလောင်းကြေး:",
total_win: "ဝင်:",
music: "ဂီတ",
sound: "အသံ"
},
choose_line: {
title: "လိုင်းရွေးပါ။",
even_line: "လိုင်းမတတ်",
odd_line: "မျဉ်းကြောင်းများ",
all_line: "အားလုံး",
re_line: "ပြန်ရွေးပါ။"
},
mini_game: {
notice: "တုန်ခါရန် သစ်ပင်ကို ကလစ်/နှိပ်ပါ။",
close: "ပိတ်လိုက",
you_get: "မင်းလက်ခံတယ်။",
time_left: "ကျန်ရှိသောအချိန်:",
score: "ငွေသွင်းရန်အချက်များ-"
},
history: {
title: "မှတ်တမ်း",
phien: "အပိုင်း",
time: "အချိန်",
muc: "အဆင့်",
line_bet: "လောင်းကြေးလိုင်း",
line_win: "ဝင်းလိုင်း",
gold_receive: "ရွှေလက်ခံသည်။"
},
top: {
title: "ထိပ်တန်း",
time: "အချိန်",
muc: "အဆင့်",
jackpot: "Jackpot",
account: "အကောင့်",
result: "ရလဒ်",
nohu: "Jackpot"
},
guide: "လမ်းညွှန်",
message: {
message1: "ဤအင်္ဂါရပ်သည် အစမ်းသုံးမုဒ်တွင် အလုပ်မလုပ်ပါ။",
message2: "နေ့စဥ်လှည့်ခြင်းသည် အလိုအလျောက် မှတ်တမ်းကို အသုံးမပြုနိုင်ပါ",
message3: "မင်းအခန်းပြောင်းနေတယ်၊ ​​ခဏစောင့်",
message4: "မင်းရိုက်ကူးနေတာပါ၊ အသံသွင်းပြီးအောင်စောင့်ပါ",
message5: "စနစ်က လုပ်ဆောင်နေပါတယ်၊ ခဏစောင့်ပါ",
message6: "သင်သည် အစမ်းသုံးမုဒ်တွင် ရှိနေသည်၊ လိုင်းမရွေး",
message7: "မင်းမှာ အလကား ဝင်ထွက်သွားတယ်",
message8: "မင်း အလိုအလျောက် မှတ်တမ်းတင်နေတယ်",
message9: "မှတ်တမ်းတင်ခြင်း မအောင်မြင်ပါ",
message10: "မမှန်ကန်သောလောင်းကြေး",
message11: "မင်းမှာ ပိုက်ဆံမလောက်ဘူး",
message12: "မမှန်ကန်သောလှည့်ဖျားမှု",
message13: "နောက်တစ်ခါ ကံကောင်းပါစေ!",
message14: "သင်သည် အနည်းဆုံး 1 လိုင်းကို ရွေးရပါမည်။"
}
},
card_game_52: {
sort_card: "Sort",
hit_card: "Submit",
next_turn: "Cancel",
bao_sam: "Report Card",
huy_sam: "Cancel Report Card",
watting_for_start_game: "Waiting for a new game to start: ",
table: "Table: ",
bet_money: "Bet Money: ",
viewing: "Watching",
chat_place_holder: "Type",
invite_game: "Invite to play",
no_one_invite: "No suitable players",
not_open: "Function temporarily not open",
create_room: "CREAT TABLE",
create_room_place_holder: "Name the room",
play_now: "PLAY NOW",
refresh_room: "REFRESH",
choose_bet_value: "CHOOSE",
player: "Player",
password_room: "Room Password",
buy_in: "BUY IN",
auto_buy_in: "Automatically buy in when running out of chips",
result: "Result",
confirm: "Confirm",
tlmn: {
chat_1: "You can't do it!",
chat_2: "Give me a like !",
chat_3: "Thanks!",
chat_4: "Lucky!",
chat_5: "Cool~",
chat_6: "Unlucky!",
chat_7: "So close!!",
chat_8: "Oops, Sorry!",
chat_9: "Oh, no…",
chat_10: "I got this!",
chat_11: "You're gonna lose!",
chat_12: "Hurry up!"
},
sam: {
chat_1: "You can't do it!",
chat_2: "Give me a like !",
chat_3: "Thanks!",
chat_4: "Lucky!",
chat_5: "Cool~",
chat_6: "Unlucky!",
chat_7: "So close!!",
chat_8: "Oops, Sorry!",
chat_9: "Oh, no…",
chat_10: "I got this!",
chat_11: "You're gonna lose!",
chat_12: "Hurry up!"
}
},
MiniHoaQua: {
big_win: "ဝင်းကြီး",
jackpot: "Jackpot",
line: "လိုင်း",
spin: "လှည့်ဖျားသည်။",
autoSpin: "အလိုအလျောက်လှည့်ခြင်း။",
stop: "ရပ်",
popup: {
detail_title: "အလောင်းအစားအသေးစိတ်",
guide_title: "လမ်းညွှန်",
history_title: "ကစားမှတ်တမ်း",
honor_title: "ဂုဏ်ထူးများ",
select_line_title: "လိုင်းကိုရွေးပါ။",
session: "အပိုင်း",
time: "အချိန်",
bet_level: "အလောင်းအစားအဆင့်",
bet_line: "လောင်းကြေးလိုင်း",
bet: "လောင်းကစား",
gain_gift: "ဆုလာဘ်တစ်ခုရယူပါ။",
room: "အခန်း",
detail: " အသေးစိတ်",
account: "အကောင့်",
status: "အဆင့်အတန်း",
win: "ဝင်း",
unselect: "ရွေးဖြုတ်ပါ။",
even_line: "တစ်ကြောင်းတည်းပင်",
odd_line: "မျဉ်းကြောင်းများ",
all_line: "အားလုံး",
line_win: "အနိုင်ရတဲ့လိုင်း"
},
toast: {
action_too_quick: "မင်းလုပ်ရပ်က မြန်လွန်းတယ်။",
not_enough_gold: "ဒင်္ဂါးများ မလုံလောက်ပါ၊ ကျေးဇူးပြု၍ ငွေဖြည့်ပါ။",
error_try_again: "အမှားဖြစ်သွားသည်၊ ကျေးဇူးပြု၍ နောက်မှ ထပ်ကြိုးစားပါ။",
connecting_server: "ဆာဗာသို့ ချိတ်ဆက်နေသည်။",
you_need_choose_at_least_1_line: "သင်သည် အနည်းဆုံး 1 လိုင်းကို ရွေးရပါမည်။"
}
},
keno: {
door: {
tai: "Big",
xiu: "Small",
chan: "Even",
le: "Odd",
kim: "Metal",
moc: "Wood",
thuy: "Water",
hoa: "Fire",
tho: "Earth"
},
type_bet: {
number: "Number",
xien: "Xien",
truotxien: "Not Appear",
tx: "Big Small",
cl: "Odd Even",
xien2: "Xien 2",
xien3: "Xien 3",
xien4: "Xien 4",
xien5: "Xien 5",
truotxien4: "N-A Xien 4",
truotxien5: "N-A Xien 5",
truotxien6: "N-A Xien 6",
truotxien7: "N-A Xien 7",
truotxien8: "N-A Xien 8",
truotxien9: "N-A Xien 9",
truotxien10: "N-A Xien 10"
},
btn: {
chat: "CHAT",
vecuoc: "BET TICKET",
statistic: "STATISTICS",
number_bet: "NUMBER BET",
base_bet: "BASE BET",
guide: "GUIDE",
most: "MOST",
at_least: "AT LEAST",
consecutive: "CONSECUTIVE",
no_result: "NO RESULT",
bet: "BET",
cancel: "CANCEL",
off: "OFF",
dont_show_again: "Don't show again",
transaction: "Transaction"
},
statistic: {
number_kytai: "Total Big:",
number_kyxiu: "Total Small:",
number_kychan: "Total Odd:",
number_kyle: "Total Even:",
ratio: "Rate:",
explain: "Explain",
tai: "=BIG",
xiu: "=SMALL",
chan: "=ODD",
le: "=EVEN",
today: "Today",
yesterday: "Yesterday",
number: "Number",
session50: "50 session",
session100: "100 session",
session200: "200 session",
session400: "400 session",
frequency: "Frequency",
tx: "Big Small",
cl: "Odd Even"
},
popup_title: {
confirm_ticket: "Confirm ticket",
you_know: "Do you know",
history_transfer: "History transfer",
result: "Result"
},
popup_confirm: {
selected: "Selected",
money_bet: "Money bet",
total_bet: "Total bet:",
total_prize: "Total prize:"
},
editbox: {
placeholder_session: "Type session number"
},
message: {
times: "fre",
rounding: "ROUNDING",
total: "TOTAL: ",
result_session: "RESULT SESSION #",
get: "1 GET",
error_number: "number!",
error_enough_number: "You must choose enough",
error_choose_maximum: "You only choose maximum",
selected: "Selected:  ",
success_bet: "Successful bet!",
error_bet1: "The system is being interrupted.\n Please try again later!",
error_bet2: "Currently the system is stopping \n the drawing of prizes.\n Please contact hotline!",
error_bet3: "The betting session has ended.\n Please bet next session!",
error_bet4: "Login error!",
error_bet5: "Please select bet type,\n number and money to complete the bet!",
error_bet6: "Please deposit to bet!",
error_bet7: "There is no bet type.\n Please bet again!",
error_bet8: "Money too small/bet!",
error_bet9: "Money is too big/bet!",
error_bet10: "The amount has exceeded the stake threshold/number.\n Please bet smaller amount\n or try again with another number\n or try again later session.",
error_bet11: "Not enough balance.\n Please try again!",
error_bet12: "Params is the wrong format!",
error_bet13: "Bet time out!",
error_bet14: "Unavailable balance!",
error_bet15: "Invalid amount!"
},
popup: {
rlt_number: "No",
rlt_session: "Session",
rlt_result: "Result",
rlt_total: "Total",
rlt_tx: "Big/Small",
rlt_cl: "Odd/even",
rlt_ngu_hanh: "5 Ele",
rlh_session: "Session",
rlh_bet_type: "Bet Type",
rlh_bet_money: "Money",
rlh_prize: "Prize",
rlh_time: "Time"
}
},
lode79: {
ld_txt_dat: "Bet",
ld_txt_tai: "BIG",
ld_txt_xiu: "SMALL",
ld_txt_le: "EVEN",
ld_txt_chan: "ODD",
ld_tit_chuyen_rut: "TRANSFER/WITHDRAWAL",
ld_xo_so: "Lottery",
ld_phien: "V: ",
ld_so_du: "Balance",
ld_so_tien: "Money",
ld_so_diem: "Score",
ld_tong_diem: "Total Score",
ld_thanh_tien: "Total money",
ld_tong_tien: "Total amount",
bet_success: "Successful bet",
bet_fail: "Bet failed",
mien_bac: "NORTHERN",
mien_trung: "CENTRAL",
mien_nam: "SOUTH",
dat_cuoc: "BET",
ltr_huy: "CANCEL",
result: {
txt_giai_db: "Special",
txt_giai_1: "1st Prize",
txt_giai_2: "2nd Prize",
txt_giai_3: "3rd Prize",
txt_giai_4: "4th Prize",
txt_giai_5: "5th Prize",
txt_giai_6: "6th Prize",
txt_giai_7: "7th Prize",
txt_giai_8: "8th Prize"
},
lib: {
re_mien_bac: "NORTHERN",
re_mien_trung: "CENTRAL",
re_mien_nam: "SOUTH",
re_short_mien_bac: "NORTHERN",
re_short_mien_trung: "CENTRAL",
re_short_mien_nam: "SOUTH",
qs_con_giap: "12 ANIMAL",
cg_ty_9: "Rat (9)",
cg_suu_9: "Ox (9)",
cg_dan_9: "Tiger (9)",
cg_mao_9: "Cat (9)",
cg_thin_8: "Dragon (8)",
cg_ti_8: "Snake (8)",
cg_ngo_8: "Horse (8)",
cg_mui_8: "Goat (8)",
cg_than_8: "Monkey (8)",
cg_dau_8: "Rooster (8)",
cg_tuat_8: "Dog (8)",
cg_hoi_8: "Pig (8)",
qs_bo_so: "GROUP",
bo_so_01: "Group 01",
bo_so_02: "Group 02",
bo_so_03: "Group 03",
bo_so_04: "Group 04",
bo_so_12: "Group 12",
bo_so_13: "Group 13",
bo_so_14: "Group 14",
bo_so_23: "Group 23",
bo_so_24: "Group 24",
bo_so_34: "Group 34",
qs_so_kep: "DUAL",
kep_bang: "Similar",
bo_00: "Set of 00",
bo_11: "Set of 11",
bo_22: "Set of 22",
bo_33: "Set of 33",
bo_44: "Set of 44",
qs_de_tong: "TOTAL",
tong_0: "Total 0",
tong_1: "Total 1",
tong_2: "Total 2",
tong_3: "Total 3",
tong_4: "Total 4",
tong_5: "Total 5",
tong_6: "Total 6",
tong_7: "Total 7",
tong_8: "Total 8",
tong_9: "Total 9",
type_de: "2D-L SPECIAL",
type_de_dau: "2D-F SPECIAL",
type_de_duoi: "2D-L 8th-S",
type_de_giai_8: "2D-F 8th",
type_de_giai_nhat: "2D-L 1st",
type_de_giai_7: "2D-L 7th",
type_de_dau_db: "1D-F SPECIAL",
type_de_duoi_db: "1D-L SPECIAL",
type_de_3_cang: "3D-L SPECIAL",
type_3d_dac_biet: "3D-L SPECIAL",
type_3d_giai_7: "3D-L 7th",
type_3d_duoi: "3D-L 7th-S",
type_lo: "LO",
type_lo_xien_2: "PARLAY LO 2",
type_lo_xien_3: "PARLAY LO 3",
type_lo_xien_4: "PARLAY LO 4",
type_lo_truot_4: "LO FAIL 4",
type_lo_truot_8: "LO FAIL 8",
type_lo_truot_10: "LO FAIL 10",
type_tai_xiu: "BIG SMALL",
type_chan_le: "ODD EVEN",
type_s_de: "2D-L SPECIAL",
type_s_de_dau: "2D-F SPECIAL",
type_s_de_duoi: "2D-L 8th-S",
type_s_de_giai_8: "2D-F 8th",
type_s_de_giai_nhat: "2D-L 1st",
type_s_de_giai_7: "2D-L 7th",
type_s_de_dau_db: "1D-F SPECIAL",
type_s_de_duoi_db: "1D-L SPECIAL",
type_s_de_3_cang: "3D-L SPECIAL",
type_s_3d_dac_biet: "3D-L SPECIAL",
type_s_3d_giai_7: "3D-L 7th",
type_s_3d_duoi: "3D-L 7th-S",
type_s_lo: "LO",
type_s_lo_xien_2: "PARLAY LO 2",
type_s_lo_xien_3: "PARLAY LO 3",
type_s_lo_xien_4: "PARLAY LO 4",
type_s_lo_truot_4: "LO FAIL 4",
type_s_lo_truot_8: "LO FAIL 8",
type_s_lo_truot_10: "LO FAIL 10",
type_s_tai_xiu: "BIG SMALL",
type_s_chan_le: "ODD EVEN"
},
responseWs: {
bet_success: "Successful bet.",
bet_fail: "Bet failed.",
resNotifyLivestream1: "Please invite you to bet\n on Lottery LiveStream\n  XXXX - YYYY session!",
resNotifyLivestream2: "Currently in the spinning.\n Please wait a few minutes \nto open the next session!",
resNotifyLivestream3: "Please stop betting.\n The system will start spinning\n the current session!",
resNotifyLivestream4: "Open bets on the next session\n XS XXXX Session YYYY.\n Please place your bets!",
resBet_am_1: "The token is in the wrong format!",
resBet_0: "Successful bet!",
resBet_1: "The system is busy.\n Please try again in a few minutes!",
resBet_2: "Configuration does not exist!",
resBet_3: "The prize draw is paused today!",
resBet_4: "Failed to load Lotery time bet",
resBet_5: "It's not time to open bets yet!",
resBet_6: "Account does not exist!",
resBet_7: "Nothing",
resBet_8: "Bets are required information!",
resBet_9: "The system is busy.\n Please try again in a few minutes!",
resBet_10: "The bet amount is too small!",
resBet_11: "The bet is too big!",
resBet_12: "Lotery type does not exist!",
resBet_13: "The bet is too big!",
resBet_14: "The bet amount is too small!",
resBet_15: "The bets are not in the correct format!",
resBet_16: "The bet number is not in the correct format!",
resBet_17: "The bet amount is too large!",
resBet_18: "Your account is not enough!",
resBet_19: "The province does not exist!",
resBet_20: "The system is busy.\n Please try again in a few minutes!",
resBet_21: "There is no prize draw at this location today!",
resBet_22: "The system is busy.\n Please try again in a few minutes!",
resBet_23: "Respose bet!",
resBet_24: "Respose bet!",
resBet_25: "Respose bet!",
resBet_26: "Respose bet!",
resBet_27: "Respose bet!",
resBet_28: "The system is busy.\n Please try again in a few minutes!",
resBet_29: "Bet amount is too big!",
resBet_30: "The system is busy.\n Please try again in a few minutes!",
resBet_31: "The system is busy.\n Please try again in a few minutes!",
resBet_32: "The system is busy.\n Please try again in a few minutes!",
resBet_33: "The account session has expired.\n Please login and action again!",
resBet_34: "Required minimum deposit to be eligible to bet!"
},
popup: {
title_huong_dan: "GUIDE",
title_thong_so: "PARAMETER",
title_thong_so_tra: "Traditional parameters",
title_thong_so_liv: "Livestream specs",
thong_so_header_gia_ban: "Price",
thong_so_header_tra_thuong: "Reward",
thong_so_header_toi_da_lan_cuoc: "Max/number of bets",
thong_so_header_toi_da_so: "Max/number",
title_sao_ke: "STATEMENT",
title_sao_ke_tra: "Traditional statement",
title_sao_ke_liv: "Livestream statement",
sao_ke_loai_phien: "Session Type",
sao_ke_thoi_gian: "Time",
sao_ke_de_lo: "De/Lo",
sao_ke_tien_cuoc: "Bets",
sao_ke_nhan_thuong: "Get rewarded",
title_bang_cuoc: "BET TABLE",
title_bang_cuoc_tra: "Traditional betting table",
title_bang_cuoc_liv: "Live betting table",
bang_cuoc_loai_phien: "Session Type",
bang_cuoc_thoi_gian: "Time",
bang_cuoc_de_lo: "De/Lo",
bang_cuoc_tien_cuoc: "Bets",
quy_tit_chuyen_quy: "FUND TRANSFER",
quy_tit_rut_quy: "WITHDRAWAL",
quy_lbcq_gold_c: "Gold transfer:",
quy_lbcq_gold_n: "Gold received:",
quy_lbrq_gold_r: "Gold withdrawn:",
quy_lbrq_gold_n: "Gold received:",
quy_tit_ti_le: "Ratio:",
quy_tit_so_du: "Balance:",
quy_btn_chuyen_quy: "OK",
quy_btn_rut_quy: "OK",
quy_btn_choi_ngay: "PLAY NOW"
},
validate: {
vli_1: "Unavailable balance.",
vli_2: "You have not selected a number.",
vli_3: "Please enter the amount.",
vli_4: "Please enter the score.",
vli_5: "Please choose enough XXXX number/lo.",
vli_6: "The next session is currently\n yet open. Please wait!",
vli_7: "Please choose enough 10 number/bet."
},
resChuyenRutQuy: {
res_01: "Invalid amount",
res_02: "The amount to withdraw exceeds the balance",
res_03: "Unavailable balance.",
res_cp_0: "Fund transfer successful.",
res_rq_0: "Successful withdrawal."
}
},
lodenormal: {
betted: "Betted",
betting: "Betting",
bet: "Bet",
winned: "Won",
eat: "Win",
de: "De",
lo: "Lo",
de_3_num: "De 3 number",
de_first: "De first",
de_last: "De last",
lo_through_2: "2 Lo parlay",
lo_through_3: "3 Lo parlay",
lo_through_4: "4 Lo parlay",
lo_fail_10: "Lo fail 10",
de_group: "De group",
no_group: "Number group",
couple_number: "Couple number",
rate_number: "De coefficient",
group: "Group",
double_group: "Double group",
double_type: "Double type group",
type_double: "Double type",
type_double1: "Type double",
num_lo_de_group: "Lo de number group",
animal_designation_12: "Animal Signs",
double_similar: "Double similar",
double_dif: "Double diff",
de_sum: "De sum",
special: "Special",
first_prize: "1st prize",
second_prize: "2nd prize",
third_prize: "3rd prize",
fourth_prize: "4th Prize",
fifth_prize: "5th prize",
sixth_prize: "6th prize",
seventh_prize: "7th prize",
north_lottery: "Northern Lotery",
last_second: "Seconds ago",
last_minute: "Minute ago",
last_hour: "Hours ago",
last_day: "Yesterday",
last_month: "Last month",
last_year: "Last year",
rat: "The Rat",
ox: "The Ox",
tiger: "The Tiger",
cat: "The Cat",
dragon: "The Dragon",
snake: "The Snake",
horse: "The Horse",
goat: "The Goat",
monkey: "The Monkey",
rooster: "The Rooster",
dog: "The Dog",
pig: "The Pig",
popup: {
month: "Month",
year: "Year",
end_bet_title: "Information",
inputbet_title: "Enter Money",
choose_de_num_title: "Choose De number",
choose_lo_num_title: "Choose Lo number",
de_3_num_title: "De 3 number",
choose_de_group_title: "Choose De group",
choose_lo_through_2: "Choose 2 Lo parlay",
choose_lo_through_3: "Choose 3 Lo parlay",
choose_lo_through_4: "Choose 4 Lo parlay",
choose_lo_fail_10: "Choose Lo fail 10",
choose_num_group_12: "Choose number group 12 animal signs",
choose_double_similar: "De double similar",
double_similar_detail: "Set of numbers: 00, 11, 22, 33, 44, 55, 66, 77, 88, 99",
choose_double_dif: "Choose De group double diff",
choose_de_sum_title: "Choose De group sum",
confirm: "Confirm",
reject: "Cancel",
bet: "Bet",
bet_num: "Bet",
bet_money: "Bet money",
bet_money_total: "Total bet money",
win_total: "Total win",
de: "De",
lo: "Lo",
end_bet_warning: "Please confirm your bet information",
bet_money_total1: "Total amount set",
input_bet_placeholder: "Enter the amount",
input_num_placeholder: "Enter the number",
gold: "Gold",
bet_total: "Total bet",
time_warning: "Time from 18:10 to 18:45 (Vietnam time) is the time of prize drawing and payout, we do not accept bets during this period."
},
warning: {
bet_success: "Successful bet!",
invalid_bet: "Invalid bet amount",
error_in_betting: "There was an error while placing the bet",
cant_bet_this_time: "Can't place bets during this time",
not_enough_gold: "You don't have enough balance",
please_choose_bet: "Please choose your bet level",
server_stop_spin_and_return_reward: "Today the system stops spinning and pays out",
please_cash_in_before_bet: "Please make a deposit before placing a bet",
please_choose_no_bet: "Please select the bet number",
please_choose_bet_money: "Please choose your bet amount",
over_bet_bound: "Set limit exceeded",
only_can_bet: "You can the bet",
gold: "Gold",
no: "Number",
error_in_betting_door: "Error in the process of placing the bet"
}
},
shankoemee: {
cannot_out_room: "You are a banker can not make out room",
cancel_leave_room: "Cancel leave",
refresh_room: "REFRESH",
skm_card_score: "Score",
skm_nguoi_choi: "Player",
skm_muc_cuoc: "Bet Levels",
draw_card: "Draw card",
do_not_draw_card: "Not draw",
bet: "Bet",
quick_chat_1: "Are you cold yet?",
quick_chat_2: "What age are you?",
quick_chat_3: "Life is not a dream",
quick_chat_4: "Lucky",
quick_chat_5: "Very good",
quick_chat_6: "Unlucky",
quick_chat_7: "But still demanding",
quick_chat_8: "This is dead",
quick_chat_9: "The card is not good",
quick_chat_10: "Have you broken your mouth?",
quick_chat_11: "Lose, friend",
quick_chat_12: "Hurry up",
enter_chat_content: "Enter chat content ...",
do_not: "No",
accept: "Accept",
invite: "INVITE",
double_banker: "Do you want to add double the amount to the bank to continue being a banker?",
play_now: "Playnow",
choose_room: "Choose room",
bank: "Bank",
enter_table_id: "Enter table id ...",
hidden_table_full: "Hidden table full",
table_id: "Table: %{table}#%{game}",
bet_value: "BET",
bet_value_num: "Bet:",
watching: "Watching",
empty_list: "Empty list",
not_enough_money_to_join_the_table: "Not enough money to join the room!",
value_slot: "%{value} slot",
pot_bank: "Pot: %{value}",
banker_turn: "Banker turn: %{turn}",
banker_turn2: "Continue to be the banker round 2",
banker_turn3: "Continue to be the banker round %{turn}",
waiting_new_game: "Waiting for the new game to start",
waiting_banker: "Waiting banker",
change_banker: "Change banker",
banker_win_title: "Banker win",
not_open_yet: "Function not open",
can_not_find_table_selected: "The selected room could not be found",
enter_the_table_you_want_to_search: "Please enter the table you want to search for",
can_not_create_table: "This game does not allow creating tables!",
no_valid_table_found: "No valid table found",
invite_user: "%{name} invites you to play, do you want to join?",
error_not_defined: "Error %{id}, undefined.",
error_check_infomation: "Error checking information!",
error_can_not_find_table_try_again: "The appropriate room could not be found. Please try again later!",
error_not_enough_money_to_join_table: "You don't have enough money to enter this room!",
error_join_room_too_fast: "Join the room too fast",
error_server_maintenance: "Maintenance system!",
error_can_not_find_table: "Playroom not found!",
error_password_table_not_correct: "The game room password is incorrect!",
error_room_full: "The playroom is full!",
error_has_been_kick: "You are not allowed to enter the table by the owner of the room!",
register_leave_table_success: "You have registered to leave the room!",
place_bet: "Place bets",
error_bet_already: "Bet already",
error_not_enough_money: "Not enough money",
error_bet_not_correct: "Incorrect bet value",
not_enough_gold_please_deposit: "The balance is not enough, please top up",
cancel_register_leave_table: "You unsubscribed to leave the room",
open_card: "Open card",
id: "ID",
table_name: "Name:",
table_require: "Require",
table_min_bet: "Min bet",
table_num_user: "User",
leave_room_title: "Leave",
leave_room_contect: "Are you sure to leave the table?",
on_sound: "On",
off_sound: "Off",
send_chat: "Send"
},
boogyi: {
cannot_out_room: "You are a banker can not make out room",
cancel_leave_room: "Cancel leave",
boo_tong_diem: "Total Score",
refresh_room: "REFRESH",
skm_card_score: "Score",
skm_nguoi_choi: "Player",
skm_muc_cuoc: "Bet Levels",
draw_card: "Draw card",
do_not_draw_card: "Not draw",
bet: "Bet",
quick_chat_1: "Are you cold yet?",
quick_chat_2: "What age are you?",
quick_chat_3: "Life is not a dream",
quick_chat_4: "Lucky",
quick_chat_5: "Very good",
quick_chat_6: "Unlucky",
quick_chat_7: "But still demanding",
quick_chat_8: "This is dead",
quick_chat_9: "The card is not good",
quick_chat_10: "Have you broken your mouth?",
quick_chat_11: "Lose, friend",
quick_chat_12: "Hurry up",
enter_chat_content: "Enter chat content ...",
do_not: "No",
accept: "Accept",
invite: "INVITE",
double_banker: "Do you want to add double the amount to the bank to continue being a banker?",
play_now: "Playnow",
choose_room: "Choose room",
bank: "Bank",
enter_table_id: "Enter table id ...",
hidden_table_full: "Hidden table full",
table_id: "Table: %{table}#%{game}",
bet_value: "BET",
bet_value_num: "Bet:",
watching: "Watching",
empty_list: "Empty list",
not_enough_money_to_join_the_table: "Not enough money to join the room!",
value_slot: "%{value} slot",
pot_bank: "Pot: %{value}",
banker_turn: "Banker turn: %{turn}",
banker_turn2: "Continue to be the banker round 2",
banker_turn3: "Continue to be the banker round %{turn}",
waiting_new_game: "Waiting for the new game to start",
waiting_banker: "Waiting banker",
change_banker: "Change banker",
banker_win_title: "Banker win",
not_open_yet: "Function not open",
can_not_find_table_selected: "The selected room could not be found",
enter_the_table_you_want_to_search: "Please enter the table you want to search for",
can_not_create_table: "This game does not allow creating tables!",
no_valid_table_found: "No valid table found",
invite_user: "%{name} invites you to play, do you want to join?",
error_not_defined: "Error %{id}, undefined.",
error_check_infomation: "Error checking information!",
error_can_not_find_table_try_again: "The appropriate room could not be found. Please try again later!",
error_not_enough_money_to_join_table: "You don't have enough money to enter this room!",
error_join_room_too_fast: "Join the room too fast",
error_server_maintenance: "Maintenance system!",
error_can_not_find_table: "Playroom not found!",
error_password_table_not_correct: "The game room password is incorrect!",
error_room_full: "The playroom is full!",
error_has_been_kick: "You are not allowed to enter the table by the owner of the room!",
register_leave_table_success: "You have registered to leave the room!",
place_bet: "Place bets",
error_bet_already: "Bet already",
error_not_enough_money: "Not enough money",
error_bet_not_correct: "Incorrect bet value",
not_enough_gold_please_deposit: "The balance is not enough, please top up",
cancel_register_leave_table: "You unsubscribed to leave the room",
open_card: "Open card",
id: "ID",
table_name: "Name",
table_require: "Require",
table_min_bet: "Min bet",
table_num_user: "User",
leave_room_title: "Leave",
leave_room_contect: "Are you sure to leave the table?",
on_sound: "On",
off_sound: "Off",
send_chat: "Send",
test: "test",
zero_slot: "Leaks",
confirm: "Xác nhận",
not_bid: "Không bid",
place_bid: "Mời đấu giá",
bid_value: "bid x%{value}",
bid_error_1: "Mức bid không đúng",
bid_error_2: "Không đủ tiền",
start_compare: "So bài"
},
shweshan: {
cannot_out_room: "You are a banker can not make out room",
cancel_leave_room: "Cancel leave",
shw_resort: "Rearrange",
game_name: "Shweshan",
zero_slot: "Leaks",
arranage_done: "Arrange done",
shweshan_nguoi_choi: "Player",
shweshan_muc_cuoc: "Bet Levels",
watching: "Watching",
do_not: "No",
accept: "Accept",
invite: "INVITE",
refresh_room: "REFRESH",
empty_list: "Empty list",
play_now: "Play now",
confirm: "Confirm",
start_compare: "Compare",
skm_card_score: "Score",
skm_nguoi_choi: "Player",
skm_muc_cuoc: "Bet Levels",
draw_card: "Draw card",
do_not_draw_card: "Not draw",
bet: "Bet",
quick_chat_1: "Are you cold yet?",
quick_chat_2: "What age are you?",
quick_chat_3: "Life is not a dream",
quick_chat_4: "Lucky",
quick_chat_5: "Very good",
quick_chat_6: "Unlucky",
quick_chat_7: "But still demanding",
quick_chat_8: "This is dead",
quick_chat_9: "The card is not good",
quick_chat_10: "Have you broken your mouth?",
quick_chat_11: "Lose, friend",
quick_chat_12: "Hurry up",
enter_chat_content: "Enter chat content ...",
double_banker: "Do you want to add double the amount to the bank to continue being a banker?",
choose_room: "Choose room",
bank: "Bank",
enter_table_id: "Enter table id ...",
hidden_table_full: "Hidden table full",
table_id: "Table: %{table}#%{game}",
bet_value: "BET",
bet_value_num: "Bet:",
not_enough_money_to_join_the_table: "Not enough money to join the room!",
value_slot: "slot:%{value}",
pot_bank: "Pot: %{value}",
banker_turn: "Banker turn: %{turn}",
banker_turn2: "Continue to be the banker round 2",
banker_turn3: "Continue to be the banker round %{turn}",
waiting_new_game: "Waiting for the new game to start",
waiting_banker: "Waiting banker",
change_banker: "Change banker",
banker_win_title: "Banker win",
not_open_yet: "Function not open",
can_not_find_table_selected: "The selected room could not be found",
enter_the_table_you_want_to_search: "Please enter the table you want to search for",
can_not_create_table: "This game does not allow creating tables!",
no_valid_table_found: "No valid table found",
invite_user: "%{name} invites you to play, do you want to join?",
error_not_defined: "Error %{id}, undefined.",
error_check_infomation: "Error checking information!",
error_can_not_find_table_try_again: "The appropriate room could not be found. Please try again later!",
error_not_enough_money_to_join_table: "You don't have enough money to enter this room!",
error_join_room_too_fast: "Join the room too fast",
error_server_maintenance: "Maintenance system!",
error_can_not_find_table: "Playroom not found!",
error_password_table_not_correct: "The game room password is incorrect!",
error_room_full: "The playroom is full!",
error_has_been_kick: "You are not allowed to enter the table by the owner of the room!",
register_leave_table_success: "You have registered to leave the room!",
place_bet: "Place bets",
error_bet_already: "Bet already",
error_not_enough_money: "Not enough money",
error_bet_not_correct: "Incorrect bet value",
not_enough_gold_please_deposit: "The balance is not enough, please top up",
cancel_register_leave_table: "You unsubscribed to leave the room",
open_card: "Open card",
id: "ID",
table_name: "Name",
table_require: "Require",
table_min_bet: "Min bet",
table_num_user: "User",
leave_room_title: "Leave",
leave_room_contect: "Are you sure to leave the table?",
on_sound: "On",
off_sound: "Off",
send_chat: "Send"
}
};
cc._RF.pop();
}, {} ],
en: [ function(e, t) {
"use strict";
cc._RF.push(t, "f5810uH+rpFoKmwuMENExH7", "en");
var n, o, a, _, i, r;
t.exports = {
"": "",
alert: {
title_notification: "Notification",
ok: "OK",
yes: "Yes",
no: "No",
loaded: "CHARGE",
close: "Cancel",
refuse: "REJECT",
veritify: "Verify",
fail: "Error",
discard: "Reselect",
confirm_logout: "Are you sure you want to log out??",
you_need_veritify_pin: "You need to verify your PIN",
you_need_veritify_phone_number: "You need to verify your phone number!",
you_need_veritify_loaded_card: "You need to charge!",
coming_soon: "New feature is coming soon",
coming_soon_game: "Game is coming soon",
game_maintian: "The game is under maintenance now!",
require_login: "You need to login!",
fucntion_maintian: "The feature is under maintenance now!",
fucntion_use_lobby: "The function can only be used outside the lobby!",
action_fast: "You act too fast. Please try again in a moment!",
error: {
not_enough_gold: "InsufficientGOLD",
wrong_captcha: "Incorrect captcha",
wrong_syntax: "Incorrect syntax",
wrong_pin: "Your PIN is invalid, or your PIN is unregistered",
wrong_pin_or_not_reg_pin: "Your PIN is invalid, or your PIN is unregistered",
account_undefined: "Invalid user",
connector: {
fail: "No Internet connection\n Please check your connection again!",
a_2: "Internet required!!!",
a_3: "Connecting to system",
a_4: "You don't have gifts.\n \n Join Event to get your gifts!",
a_5: "Please enter the PIN",
a_6: "Please enter the Captcha!",
expired: "Your login session has expired, please login again",
ban: "This account has been locked by the system",
a_9: "The system is under maintenance\nPlease come back later!",
some_where: "The account is already logged in elsewhere"
},
services: {
a_10: "The account or password is incorrect",
a_11: "Account already in use",
a_12: "Account does not exist",
a_13: "Wrong password",
a_14: "You have registered too many accounts.",
a_15: "Please wait a few minutes then create your account.",
a_16: "You have created too many accounts \n please come back tomorrow."
},
defined: {
fail: "Unknown error",
param_invalid: "Parameter is incorrect",
maintain_system: "The system is under maintenance\nPlease come back later!",
session_key_invalid: "Session key does not exist",
session_expired: "Session key expired",
session_room_not_exist: "Playroom does not exist",
session_not_enough_min_buy_in: "Not enough minimum bet",
out_buy_in_range: "Out of bet",
game_structure_invalid: "Game structure does not exist",
already_in_game: "You are already in the game",
entering_game: "Entering the game",
gift_code_invalid: "Giftcode does not exist",
gift_code_is_used: "Giftcode has been used",
gift_code_is_expired: "Giftcode expired",
login_banned_ip: "Your IP has been locked. \n Please contact Customer Service for more information!",
login_banned_user: "Your account has been locked. \n Please contact Customer Service for more information!",
player_action_invalid: "Operation not valid",
player_action_fail: "Error manipulation",
not_enough_gold: "Not enough GOLD",
default: "Error",
not_bet_too_long: "You have been invited to the system  n for not interacting for too long"
}
}
},
LuckyWheel: {
system_error: "System error.",
received_code: "The account has received a secure giftcode",
system_error_cache: "System error. Caching redis error!",
system_error_database: "System error. Save database error!",
success: "Congratulations, you have just won the %{XXX} GOLD gift. Please contact customer service to receive your reward",
contact: "Contact customer service to receive the gift"
},
loading: {
check_server: "Checking server information",
update: "Update",
update_success: "Update successful",
update_fail: "Update failed",
please_wait_update_version: "Please update to the latest version",
check_version: "Checking version",
progress_loading_new: "Updating the new version.",
not_loading_manifest: "Could not load manifest",
latest_current_version: "Latest current version",
load: "Loading"
},
login: {
title_quick_play: "Play now",
login: {
title: "Login",
placeholder: {
username: "Enter account name",
pass: "Enter password"
},
save_pass: "Save password",
forget: "forget",
error: {
login_fail: "Facebook login failed!",
please_enter_account_pass: "Please enter your account and password",
account_pass_than_six_charater: "Account and password must be more than 6 characters"
}
},
registry: {
title: "Register",
placeholder: {
username: "Enter account name",
pass: "Enter password",
pass_confirm: "Confirm password",
captcha: "Enter captcha"
},
error: {
facebook_fail: "Login fail",
fail_1: "The username must be at least 6 characters \n without special symbols",
fail_2: "Password must be at least 8 characters",
fail_3: "Retype password incorrect",
fail_4: "The captcha wasn't entered"
}
},
forget: {
title: "Forgot password",
placeholder: {
username: "Enter account name",
pin: "Enter PIN",
pass: "Enter password",
pass_confirm: "Confirm password",
captcha: "Enter captcha"
},
error: {
username_please: "Please enter your username",
enter_code_pin_please: "Please enter the PIN",
enter_new_password_please: "Please enter a new password",
note_create_new_password: "New password must be more than 8 characters",
wrong_enter_password: "Retype password incorrect",
enter_captcha_please: "Please enter the Captcha!",
note_create_new_password_success: "Password was successfully changed",
wrong_syntax: "Incorrect Syntax",
error_invalid_account_pin: "Username does not exist or the PIN is incorrect",
wrong_captcha: "Incorrect captcha"
}
}
},
lobby: {
lobby_notify_no_talk: "Currently not broadcasting Live\n Please come back later.",
not_have_account: "You do not have an account",
profile: "Profile",
join_time: "Date of participation",
birth_date: "Birthday",
ip_address: "IP address",
invite_code: "Referral code",
change_password: "Change Pwd",
change_avatar: "Change avt",
back: "Back",
change: "Change",
current_password: "Current password",
new_password: "New password",
confirm_new_password: "Re - enter your new password",
update: "Update",
deposit_gold: "Top up Gold",
deposit_history: "Top up History",
sell_gold: "Sell Gold",
sell_history: "Sell History",
current_credit: "Current balance",
agency: "Agency",
deposit_money: "Deposits",
receive_gold: "Gold receive",
agency_note: "Note: Please check the agent's information carefully before transferring, transfer to the wrong publisher that does not support. After 5 minutes have not received the gold contact:",
or_call_to: "Or call to",
note: "Notes",
minimum_trade: "Minimum transaction",
exchange_rate: "Conversion rate",
account_number: "Account number",
account_name: "Account name",
area: "Area",
confirm: "Confirm",
deposit_note: "You have successfully created the deposit order. \nNext, to complete the deposit process. \nPlease contact customer service to send the transfer invoice.",
branch: "Branch",
transfer_code_short: "Transaction code",
num_transfer_money: "Transfer amount",
account_owner_name: "Holder name",
status: "Status",
korea: "Korea",
japan: "Japan",
taiwan: "Taiwan",
lao: "Laos",
campuchia: "Cambodia",
no: "Numerical order",
nickname: "NICKNAME",
phone_number: "Phone number",
contact: "Contact",
action: "Action",
buy: "Buy",
sell: "Sell",
attendance: "Attendance",
day: "Day",
day1: "Day 1",
day2: "Day 2",
day3: "Day 3",
day4: "Day 4",
day5: "Day 5",
day6: "Day 6",
day7: "Day 7",
attendance_note: "Please take full attendance to receive attractive rewards at the weekend",
open_egg: "Open Egg",
gold_egg: "Golden Egg",
white_egg: "White Egg",
game_download: "Game Download",
download: "Download",
list_giftcode: "Giftcode List",
received: "Received",
title_events: "Events",
event: "Events",
event_top_bet: "Top Bet Event",
event_attendace: "Attendance Event",
event_receive_bet: "Get Bets Event",
event_find_million: "Find a millionaire Event",
event_sicbo: "Sicbo Event",
event_jackpot_sicbo: "Sicbo Jackpot",
trade_history: "Transaction history",
play_gold: "Play Gold",
play_chip: "Play Coins",
deposit_chip: "Top up Coins",
expense_gold: "Spend Gold",
trade_code: "Transaction Code",
time: "Time",
service: "Service",
incurred: "Incurred",
credit: "Balance",
description: "Description",
detail: "Detail",
view: "View",
account: "Account",
account_note_full_info: "To get support. Please fill in the information below",
account_note_username: "Character name is required information",
type_login_name: "Enter Username",
authentication_code: "Verification Code",
send: "Send",
forgot_password: "Forgot Password",
telegram_authentication_code: "Telegram authentication code...",
username: "Character's name",
account_note_username1: "Character name between 6-16 characters, no sensitive characters, special characters and no spaces",
create_new: "Creat New",
login_name: "Username",
password: "Password",
save_password: "Save Password",
login: "Login",
register: "Register",
confirm_password: "Confirm Password",
invite_code_note: "Referral Code (Optional)",
captcha: "Capcha",
sender: "Sender",
content: "Content",
notify: "Notify",
agency_account: "Agency account",
notify_note_cheat: "Only deal with agents to avoid fraud",
you_sure_send: "You definitely want to transfer to",
amount_money: "Amount of money",
reason: "Reason",
reject: "Cancel",
accept: "Accept",
buy_gold: "Buy Gold",
gold: "Gold",
type_amount_money: "Enter top up amount...",
receive_money: "Amount receive",
received_money: "Amount received",
num_receive_gold: "Gold receive",
other_agency: "Other agents",
buy_gold_rule: "Rules for buying gold",
minimum_trade_value: "Minimum transaction value",
trade_fee: "Transaction fee",
buy_gold_rule_note: "",
buy_gold_rule_note_check_nickname: "Please double check the nickname received before making the transaction",
type_nickname: "Enter nickname",
type_nickname_again: "Re - enter nickname",
type_amount_sell_money: "Enter the amount to transfer",
type_num_gold: "Enter gold number",
transfer_reason: "Transfer reason",
transfer_note_nickname: 'Nickname received is the character name "In-game display name" not the login account name ',
transfer_note_wrong_transfer: "*Transactions that are transferred to the wrong account name are automatically identified by the system as valid transactions and are non-refundable",
continue: "Continue",
transfer_rule: "Transfer regulations",
transfer: "Transfer",
choose_nation: "Select country",
transfer_withdraw: "Transfer/Withdraw",
num_transfer_gold: "Transfer Gold number",
current_money: "Current money",
transfer_fund: "Transfer fund",
play_now: "Play now",
withdraw_fund: "Withdraw fund",
withdraw_money: "Amount to withdraw",
notify_common_noti: " Publisher is pleased to announce",
notify_common_admin: "BOSS79 Management Board Sincerely Announcement",
term_of_use: "Terms of use",
cmtnd: "ID numbers",
active: "Active",
email: "Email",
phone_number_long: "Phone number",
profile_note_scuriry: "Note about confidential information",
profile_note_update: "Update information to ensure benefits",
music: "Music",
feedBack: "Feedback",
shop: "Shop",
gift_code: "GIFTCODE",
type_gift_code: "Enter GiftCode",
receive: "Receive",
mailbox: "Mailbox",
setting: "Setting",
get_otp: "Get OTP",
title_sold_gold: "Sell Gold",
title_tranfers_gold: "Transfer",
title_language: "Ngôn ngữ",
title_safe: "Két Sắt",
title_shop: "Cửa Hàng",
title_history: "Lịch Sử",
title_naprut: "Deposit / Withdraw",
title_support: "Support",
title_security: "Security",
title_mail: "Mail",
title_fanpage: "Fanpage",
title_giftcode: "Gift Code",
title_group: "Group",
logout: "Log out",
jackpot: {
jungle_spirit: "Jungle Spirit",
captians: "Captian's",
agent_royale: "Agent Royale",
sexy_girl: "Dance Girl",
avangers: "Avangers",
fortune: "Fortune"
},
tab_game: {
all_game: "All Game",
mini_game: "Mini Game",
betting: "Betting",
live_game: "Live Game",
slot: "Slot Game",
casino: "Casino"
},
warning: {
error_try_gain: "An error occurred. Please try again later!",
minimum_transfer_500k: "Minimum amount is 500k Gold!",
not_enough_gold: "Unavailable balance",
maximum_bet_10M: "Sports betting account must not exceed 10M",
transfer_success: "Congratulations! \nYou have just successfully transferred: ",
error_in_processing: "There was an error in processing!",
you_need_type_withdraw_money: "You need to enter the withdrawal amount!",
wrong_money: "The amount is not correct!",
cant_get_credit_try_again: "The balance cannot be obtained. Please try again!",
withdraw_success: "Congratulations!\nYou have successfully withdrawn",
delete_mail_success: "Delete mail successfully!",
you_sure_delete_mail: "You definitely want to delete the mail",
error: "An error occurred",
developing_feature: "The feature are developing!",
wrong_giftcode_check_again: "Giftcode is incorrect. Please check again!",
gift_code_is_used: "Giftcode has been used!",
congluratulation: "Congratulations! You have received!",
invalid_giftcode: "Giftcode entered is invalid!",
over_exp_giftcode: "Giftcode has expired!",
unsecury_account: "Unregistered account security!",
giftcode_cant_use_phone_number: "Giftcode does not apply to secure accounts by Vietnamese phone numbers",
giftcode_cant_use_this_account: "Giftcode cannot be used for this account!",
please_type_num_money: "Please enter the amount!",
minimum_trade: "Minimum transaction",
gold_up: "Gold",
gold_n: "Gold",
not_enough_gold1: "Insufficient account balance",
username_must_same: "The account name must be the same!!",
please_type_full_info: "Please enter full information! (Agent name, Nickname, Amount)",
un_phone_number_verify_account: "Unauthenticated account secure phone number",
cant_transfer_yourselft: "You cannot transfer to yourself",
change_avatar_success: "Change avatar successfully!!",
please_type_full_info1: "Please fill in all the information!",
password_confirm_password_must_same: "The new password and the newly re-entered password must be the same!",
old_password_wrong: "Old password is incorrect",
you_sure_withdraw: "Are you sure you want to withdraw VND. \nGOLD number ",
unexist_account: "Account does not exist!",
untype_username: "You have not entered username",
untype_password: "You have not entered password",
server_lost_connect: "Lost server connection",
account_logining_please_logout: "Your account is being logged in elsewhere. Please log out before logging in.",
account_banning: "Account is banning.",
invalid_authentication_code: "The authentication code is incorrect.",
overtime_authentication: "The verification code has expired.",
server_maintain_go_later: "The system is maintenance. Please come back later.",
password_wrong: "Wrong password",
login_banned: "Forbidden to login",
unexist_user: "User does not exist.",
you_not_create_username: "You have not created a nickname for the account.",
username_warning: "User name must be from 6 - 18 characters, write immediately without accents, no special characters!",
password_same_warning: "The re-entered password does not match the entered password.",
verify_code_wrong: "Incorrect code",
internet_unstable: "The network connection is not stable. \nPlease check wifi/3g connection",
invalid_username: "Invalid username",
username_exist: "Username already exists",
invite_code_unexist: "Referral code does not exist",
invite_code_wrong_type: "Invalid Referral Code (eg:K1234567)",
captcha_wrong: "Incorrect captcha code",
captcha_error: "Captcha error",
nickname_invalid: "Invalid Nickname",
nickname_exist: "Nickname already exists",
nickname_not_same_username: "Nickname cannot be the same as Username",
nickname_had: "Already have a Nickname.",
nickname_not_sentitive: "Do not choose sensitive Nicknames.",
check_network: "The network connection is not stable",
logined_other_device: "You are logged in on another device",
giftcode_please_enter_full: "Please complete the Gift Code",
info_update_success_contact_to_complete: "Successfully updated! Please chat with the tele bot to complete the security step.",
info_error_update: "An error occurred while updating information!",
info_email_wrong_type: "Email format incorrect!",
info_phone_number_wrong_type: "Phone number format incorrect!",
info_email_registered_other_account: "Email already registered by another account!",
info_not_need_otp_unsecure_account: "No OTP required for unsecured accounts!",
info_phone_number_registered_try_other: "Registered phone number. Please use another phone number!",
phone_number_warning: "Phone numbers must be 10-15 numbers long!",
otp_required: "OTP code is required information",
otp_tele_wrong: "Enter the wrong Tele OTP code. Please try again",
otp_wrong: "OTP code is not correct!",
otp_unexist: "OTP code does not exist",
otp_overtime_use: "OTP code has expired",
you_sure_out_game: "Are you sure you want to exit the game?",
password_change_success: "Password change successful!",
password_required: "New password is required information",
password_confirm_required: "Re-entering is required information",
password_confirm_wrong: "Re-enter the new incorrect password.",
password_current_wrong: "Current password is incorrect",
account_login_fb_gg_cant_use_feature: "Accounts logged in with Facebook or Google+ cannot use this function!",
feature_for_register_secury_account: "This feature is for registered security accounts!",
account_warning_nickname: "The system does not support accounts that have not updated Nicknames",
you_need_enter_money: "You need to enter the amount!",
deposit_order_double: "You created 2 top up too close together",
deposit_order_limit_per_day: "Exceeded the limit to create deposit orders in a day! Transfer is required to complete the deposit before creating the next order",
buy_gold_faild: "Buy GOLD failed!",
withdraw_money_faild: "Withdraw money failed",
withdraw_fail: "Withdrawal failed!",
success: "Successful!",
bank_id_required: "Bank ID is required!",
account_number_required: "Account number is required!",
username_required: "Username is required!",
nickname_required: "Nickname is required!",
num_gold_required: "Gold number is required!",
account_number_wrong_type: "Incorrect account number!",
num_gold_wrong_type: "Incorrect Gold number!",
account_banned_transfer: "The account is locked from the transfer function!",
withdraw_money_minimum: "Withdrawal amount must be greater than or equal to",
error_undetermine: "An unknown error",
not_enough_transfer_require_contact_service: "You are not eligible to trade. Details please contact customer service!",
attendance_success: "Successful attendance!",
attendance_fail: "Attendance failed",
account_unregister_secure: "Security unregistered account",
account_unregister_secure_contact_service: "The account has not registered the security function. Please contact Telegram:@cskhboss79 or call center 19006896 for support, verify account information to retrieve password. Thank you!",
account_unexist: "Account does not exist",
support: "Please contact Customer Service for more information!",
server_unconnect: "Not connected to the server",
server_terminate_interupt: "Server is temporarily down",
account_not_enter: "You have not entered username",
password_not_enter: "You have not entered password",
play_game_fun: "Have fun playing the game",
good_luck_later: "Wish you luck next time",
transfer_account_receive_unexist: "Receiving account does not exist!",
transfer_minimum_money: "Transfer amount is less than minimum transaction value!",
account_not_enought_transfer_condition: "The account is not eligible for trading. Please contact the publisher!",
sercure_feature_auto_active: "The security function will automatically activate after 24 hours from the time of successful registration!",
transfer_limit: "You can only transfer to the General Agent a certain amount of money",
transfer_over_credit: "Transfer amount exceeded limit!",
transfer_account_send_unexist: "Transfer account does not exist!",
transfer_enter_content: "Required enter transfer content!",
tranfer_same_account: "Transfer account is the same as the receiving account",
transfer_local_feature_terminated_contact_service: "The internal transfer function is temporarily suspended. Please contact customer service for assistance!",
transfer_local_feature_terminated_contact_service1: "The internal transfer function is temporarily disabled. Please contact customer service for more details!"
},
gui_profile: {
profile_title: "Profile",
join_time: "Date of participation",
birth_date: "Birthday",
ip_address: "IP address",
invite_code: "Referral code",
change_password: "Change Pwd",
change_password1: "Change password",
change_avatar: "Change avt",
back: "Back",
change: "Change",
current_password: "Current password",
new_password: "New password",
confirm_new_password: "Enter a new password",
update: "Update",
alert: {
warning_1: "Your avatar is no different from the previous avatar.",
warning_2: "Select the Avatar you want to change."
}
},
gui_agency: {
deposit_title: "Top up Gold",
deposit_gold: "Top up Gold",
deposit_history: "Top up history",
sell_title: "Sell gold",
sell_gold: "Sell gold",
sell_history: "Sell history",
current_credit: "Current balance",
agency: "Agency",
deposit_money: "Deposits money",
receive_gold: "Gold Receive",
agency_note: "Note: Check the agent's information carefully before transferring, transfer to the wrong publisher that does not support. After 5 minutes have not received the gold contact:",
or_call_to: "Or call to",
note: "Note",
minimum_trade: "Minimum transaction",
rate_trade: "Transaction Fee",
exchange_rate: "Conversion rate",
account_number: "Account number",
account_name: "Account name",
area: "Area",
confirm: "Confirm",
deposit_note: "You have successfully created a deposit order. Next, to complete the deposit process. Please contact customer service to send the transfer invoice.",
notify_title: "Notify",
num_transfer_gold: "Transfer GOLD Number",
receive_money: "Amount received",
branch: "Branch",
account_owner_name: "Account holder name",
continue: "Continue",
status: "Status",
time: "Time",
transfer_code_short: "Code",
num_transfer_money: "Transfer amount",
title_new_bank: "Input new bank",
title_bank_other: "Bank Other",
title_new_bank_message: "Input bank with draw",
lao: "Laos",
taiwan: "Taiwan",
vietnam: "Vietnam",
thailan: "Thailand",
pending: "Pending",
accepted: "Accepted",
rejected: "Rejected",
huy: "Canceled"
},
gui_list_agency: {
country_code: {
VN: "Vietnamese",
JP: "Japan",
KR: "Korea",
TW: "Taiwan",
LA: "Laos",
KH: "Cambodia",
US: "United States",
MM: "Myanmar",
TH: "Thailand",
LD: "LD",
WB: "WB",
JL: "JL"
},
agency_title: "Agency",
korea: "Korea",
japan: "Japan",
taiwan: "Taiwan",
lao: "Laos",
campuchia: "Cambodia",
singapore: "Singapore",
thailand: "Thailand",
myanmar: "Myanmar",
no: "No.",
agency: "Agency",
nickname: "NICKNAME",
phone_number: "Phone number",
contact: "Contact",
area: "Area",
action: "Action",
buy: "Buy",
sell: "Sell",
rate: "Rate",
people_rate: " people rated it",
action_rate: "Click to rate the agent",
title_rate: "Evaluate feedback about the agent ",
feedback_rate: "Feedback from others",
enter_content: "Enter chat content ...",
rate_success: "Rating success",
rate_fail: "Rating fail",
dk_rate: "You need to trade a minimum of 100,000 GOLD with the agent to get a review. Thank you!",
dk_rate_1: "Please enter comment content to complete the review (minimum 12 characters).",
dk_rate_2: "Successful transaction. Please take some time to rate the agent so we can improve our service better.",
dk_rate_content_0: "Trusted trading agent",
dk_rate_content_1: "Fast transaction agent",
dk_rate_content_2: "OK",
dk_rate_content_3: "Support Agent",
dk_rate_content_4: "Wishing the agent good fortune and prosperity"
},
gui_attendance: {
attendance: "Attendance",
attendance_title: "Attendance",
day: "Day",
day1: "Day 1",
day2: "Day 2",
day3: "Day 3",
day4: "Day 4",
day5: "Day 5",
day6: "Day 6",
day7: "Day 7",
attendance_note: "Please take full attendance to receive attractive rewards at the weekend"
},
gui_open_egg: {
open_egg: "Open Egg",
gold_egg: "Golden Egg",
white_egg: "White Egg",
no_egg: "There is no egg"
},
gui_bundle_download: {
download_game: "Download game",
download: "Download"
},
gui_event_list_giftcode: {
list_giftcode_title: "Gift code list"
},
gui_events: {
event_title: "Event",
event: "Event",
event_top_bet: "Top bet event",
event_attendace: "Attendance event",
event_receive_bet: "Receive bet event",
event_find_million: "Find a millionaire Event",
event_sicbo: "Sicbo Event",
event_jackpot_sicbo: "Sicbo Jackpot",
rules: "Rules",
daily_top: "Daily TOP",
top_bet: "TOP Bet",
attendace_again: "Attendace again",
rank: "Rank",
user: "User",
bet: "Bet",
refund: "Refund",
money: "Money"
},
gui_trade_history: {
trade_history_title: "Transaction history",
trade_history: "Transaction history",
play_gold: "Play Gold",
play_chip: "Play coins",
deposit_chip: "Top up coins",
deposit_gold: "Top up Gold",
expense_gold: "Spend Gold",
trade_code: "Code",
time: "Time",
service: "Service",
incurred: "Incurred",
credit: "Balance",
description: "Description",
detail: "Detail",
view: "View"
},
gui_forgot_password: (n = {
account: "Account",
account_title: "Account",
account_note_full_info: "To get support. Please fill in the information below",
account_note_username: "Character name is required information",
type_login_name: "Enter Username",
authentication_code: "Verification Code",
send: "Send",
forgot_password: "Forgot password",
forgot_password_title: "Forgot password",
telegram_authentication_code: "Telegram authentication code..."
}, n.send = "Send", n.new_password = "New password", n.confirm_new_password = "Re - enter your new password", 
n),
gui_display_name: {
account_title: "Account",
account_note_username: "Character name is required information",
username: "Username",
account_note_username1: "Character name between 6-16 characters, no sensitive characters, special characters and no spaces",
create_new: "Creat new"
},
gui_login: {
login_title: "Account",
login_name: "Username",
password: "Password",
save_password: "Save Password",
login: "Login",
forgot_password: "Forgot password"
},
gui_registry: {
register_title: "Register",
register: "Register",
login_name: "Username",
password: "Password",
confirm_password: "Re - enter password",
invite_code_note: "Referral Code (Optional)",
captcha: "Captcha"
},
gui_mailbox: {
title: "Title:",
content: "Content:",
sender: "Sender:",
unread: "Unread",
read: "Read",
mailbox_title: "Mail box",
mess_delete_mail: "You want to delete the message?"
},
gui_minigame: {
game_download: "Download game",
taixiu: "Big-Small",
caothap: "Hi-Lo",
chanle: "Odd-Even",
xocdia: "SeDie",
pokego: "Poke Go",
baucua: "Kla Klouk"
},
gui_confirm_transfer: {
notify: "Notify",
agency_account: "Agency account",
notify_note_cheat: "Only deal with agents to avoid fraud",
you_sure_send: "You definitely want to transfer to",
amount_money: "Amount of money",
reason: "Reason",
reject: "Cancel",
accept: "Accept",
account: "Account",
confirm_transfer_title: "Notify"
},
gui_buy_gold: {
buy_gold: "Buy Gold",
buy_gold_title: "Buy Gold",
current_credit: "Current Credit",
agency: "Agency",
enter_agency: "Enter agency",
nickname: "NickName",
enter_nickname: "Enter Nickname",
buy_money: "Buy Money",
number_buy_money: "Buy Money...",
gold: "Gold",
receive_gold: "Receive Gold...",
other_agency: "Other Agency",
lb_warning_1: "Contact agency to exchange directly",
lb_warning_2: "Agency phone number:",
lb_warning_3: "or access link: ",
lao: "Laos",
cam: "Cambodia",
vn: "Vietnam",
kor: "Korea",
jp: "Japan",
tw: "Taiwan"
},
gui_sell_gold: {
sell_gold: "Sell Gold",
sell_gold_title: "Sell GOld",
current_credit: "Current Credit",
agency: "Agency",
enter_agency: "Enter agency",
nickname: "NickName",
enter_nickname: "Enter Nickname",
buy_money: "Amout money",
number_sell_gold: "Amount money...",
gold: "Gold",
receive_money: "Receive money...",
other_agency: "Other agency",
continue: "Continue",
transfer_reason: "Transfer reason",
lao: "Laos",
cam: "Cambodia",
vn: "Vietnam",
kor: "Korea",
jp: "Japan",
tw: "Taiwan"
},
gui_notify: {
title_notify: "Notify",
notify_common_admin: "BOSS79 Management Board Sincerely Announcement",
notify_common_noti: " Publisher is pleased to announce",
notify_common_content: 'To meet the needs of agents and customers,\nwe officially open another site:                                 \nWith a variety of games, "North, Central and South Lottery with extremely\nattractive payout rates compared to the market" and a variety of\nCasino games, Sports bets, Baccarat with extremely high return rates,\nbringing an extremely attractive experience with a 1:1\ndeposit/withdrawal ratio.'
},
safetybox: {
safetybox_title: "Safety Box",
lb_goldin: "Gold in Safety Box",
note: "Create password to use safe box!",
lb_btn: {
chuyen: "DEPOSIT",
rut: "WITHDRAW",
doimk: "CHANGE PWD",
dongy: "ACCEPT",
back: "BACK"
},
lb_editbox: {
lb_chuyen: "Deposit Gold",
lb_rut: "Withdraw Gold",
placeholder_password_rut: "Enter Safety Box password to withdraw",
placeholder_password_create: "Create password",
placeholder_re_password_create: "Re-enter Password",
placeholder_password_old: "Old pasword",
placeholder_new_password_update: "New password",
placeholder_re_new_password_update: "Re-enter new password"
},
message: {
wrong_password: "Wrong password. Please type again!",
wrong_password_retype: "Re-enter wrong passwrod. Please type again!",
wrong_old_pass: "Old password is incorrect. Please type again!",
withdraw_success: "Withdraw success!",
transfer_success: "Deposit success!",
transfer_failed: "Deposit fail!",
create_password_success: "Create password success!",
update_password_success: "Update password success!",
please_type_money_withdraw: "Enter withdraw amount",
please_type_money_transfer: "Enter deposit amount",
error_create: "Creat fail. Please try again!",
error_update: "Update fail. Please try again!",
error_network: "Network unstable. Please try again later!"
}
},
gui_setting: {
music: "Music",
music_on: "Music (On)",
music_off: "Music (Off)",
term_of_use: "Terms of use",
feedBack: "Feedback"
},
gui_chuyen_quy: {
transfer_withdraw_title: "Deposit/Withdraw",
num_transfer_gold: "Transfer Gold number",
receive_money: "Withdraw Gold",
transfer_fund: "Transfer fund",
play_now: "Play now",
withdraw_fund: "Withdraw fund",
withdraw_money: "Amount to withdraw",
num_receive_gold: "Amount receive",
type_num_gold: "Enter gold number",
type_num_money: "Enter the amount",
receive_gold: "Amount receive",
current_money: "Current credit"
},
gui_transfer: {
transfer: "Transfer",
transfer_title: "Transfer",
current_credit: "Current Credit",
enter_nickname: "Enter Nickname",
re_enter_nickname: "Re-Enter Nickname",
enter_sell_money: "Enter the amount to transfer",
receive_gold: "Receive Gold",
reason: "Transfer reason",
continue: "Continue",
agency: "Agency",
gold: "Gold",
amount_less_than_minimum: "Transfer amount is less than minimum transaction value!",
unregister_security: "Security unregistered account! Please contact Customer Service!",
otp_expired: "OTP code has expired!",
otp_not_correct: "OTP code is not correct!",
otp_error: "OTP code error!",
una_balance: "Unavailable balance!",
lock_transfer: "The nickname is locked from the transfer function!",
acc_not_exist: "Nickname does not exist!",
enter_details: "Please enter transfer details!",
not_transfer_yourself: "Unable to transfer to yourself",
not_transfer_agency: "Agent cannot transfer to agent",
not_transfer_agency2: "Level 2 agents cannot transfer to level 2 agents",
not_transfer_not_your_agency2: "You cannot transfer money to a level 2 agent that is not yours!",
amount_maximum: "\n\nThe maximum amount that can be transferred is %{money} according to GIFTCODE mechanism. For more details, please contact Customer Service!",
transfer_fail: "Transfer failed!",
transfer_success: "Transfer success ",
sell_gold: "Sell Gold to ",
sell_gold_user_text_0: " Lucky Lucky",
sell_gold_user_text_1: "Confident victory ",
sell_gold_user_text_2: "%{myNickName} transfer GOLD to %{otherNickName} ",
sell_gold_user_text_3: "Lucky Money "
},
gui_logout: {
logout_title: "Log Out",
warning: "Are you sure you want to exit the game?",
no: "Cancel",
yes: "Ok"
},
gui_policy: {
policy_title: "Terms of Use"
},
gui_security: {
security_title: "Security",
account_name: "Account name",
username: "Character name",
cmtnd: "ID Number",
email: "Email",
phone_number: "Phone number",
update: "Update",
active: "Active",
get_otp: "Get OTP"
},
gui_buy_and_sold: {
buy_and_sold_title: "Shop",
transfer: "Transfer",
sell_gold: "Sell Gold",
input_otp: "Input OTP"
},
gui_gift_code: {
notice: "* Please enter the correct to receive the gift and notice the receiving time.\n* Each giftcode is only applicable for 1 account.",
gift_code_title: "Gift Code",
enter_gift_code: "Enter Gift Code",
receive: "Receive",
price: "Price: ",
code: "Code: "
},
gui_header: {
logout: "Log Out",
safetybox: "Safety Box",
history: "History",
language: "Language",
shop: "Shop",
setting: "Setting",
confirm_change_language: "Are you want to changelanguage\nto %{language} ?",
ok: "Yes",
cancel: "No",
win: "Win",
day: "day"
},
gui_choose_nation: {
choose_nation_title: "Choose nation"
},
gui_language: {
language_title: "Language"
},
mergeWord: {
transaction_failed: "Transaction failed. Please try again later!",
transaction_success: "Successful transaction",
seller_not_online: "The seller is currently not online",
insufficient_balance: "Insufficient balance!",
letter_not_exist: "Letters/Numbers do not exist!",
sys_err: "System error. Please try again later!",
price_greater: "The price of letters/numbers must be greater than the floor price!",
wants_to_sell: " wants to sell you the letter/number",
price: "Price: ",
please_choose_letters: "Please choose the letters from the inventory on the left to combine them!",
pairing_fail: "Pairing letters failed.",
pairing_success: "Pairing letters successfully. You receive ",
empty_data: "Empty data",
word_incorrect: "The word set is incorrect!",
not_enough_letters: "You don't have enough letters/numbers!",
account_not_exist: "Account does not exist!",
selling_failed: "Selling words failed. Please try again later!",
selling_success: "Selling words successfully. Please wait for the buyer to confirm!",
buyer_not_online: "The buyer is not online. Please try again later!",
action_fast: "You act too fast.\nPlease try again in a moment!",
greater_minimum: "The transaction amount must be greater than the specified minimum transaction amount",
minimum_selling: "Minimum selling price is 10,000 Gold.",
transaction_fee: "Transaction fee is 5% (Minimum is 10,000 Gold)",
transaction_note: "You want to trade this word with someone else. Please carefully check the sender information and denomination, if the operation is wrong, no refund will be given!",
selling_err: " An error occurred when selling %s for %s to %s",
acepted_buy: "%s agrees to buy letter %s for %s Gold",
not_acepted_buy: "%s doesn't agree to buy letter %s for %s Gold",
please_choose_word: "Please select letter to sell",
please_type_nickname: "Please enter a nickname!",
please_type_price: "Please enter selling price!",
buy: "Buy",
sell: "Sell",
history_buy_sell: "Transaction History",
history_trade_word: "History of letter exchange",
nickname: "Nickname"
}
},
minigame: {
chat: {
input_chat: "Click to chat",
send: "Send",
error: "Error",
greeting: "Goodluck for you!",
banned: "*** You do not have permission to Chat!",
temp_banned: "*** You are temporarily banned from Chat!",
limited_length: "*** Chat content is too long!",
not_enough_gold: "*** Balance is not enough for Chat.",
ban_forever: "*** You are banned from chatting forever.",
action_quickly: "*** You chat too fast.",
require_length: "Please enter more than 1 character",
require_topup: "Requires you to top up to open the chat feature"
},
common: {
rebet: "Rebet",
accept: "Accept",
destroy: "Cancel",
select: "select",
all_in: "All in",
dice_1: "Dice 1",
dice_2: "Dice 2",
dice_3: "Dice 3",
top_day: "Day",
top_month: "Month",
top_year: "Year",
top_round: "Round",
top_round1: "Round 1",
top_round2: "Round 2",
title_help: "Guide",
title_session_detail: "Session details",
title_session: "Session",
title_nickname: "Nickname",
title_name: "Name",
title_time: "Time",
title_side: "Door",
title_bet: "Bet",
title_refund: "Refund",
title_reward: "Received",
title_result: "Result",
title_total_bet_refund: "Total bet/refund",
title_transaction_history: "Transaction history",
title_top_bet: "Top Rich",
title_top_daily: "Top daily",
title_top_monthly: "Top Monthly",
title_top_rule: "Rules",
title_top_number: "RANK",
title_account: "Account",
title_top_money: "Bet money",
title_top_reward: "Reward",
title_top_refund: "Refund",
xiu: "Small",
tai: "Big",
chan: "Even",
le: "Odd",
bet_success: "Bet success!",
bet_fail: "Bet fail!",
bet_system_error: "System error",
bet_timeout: "Bet time out",
bet_not_enough_chip: "Not enough chip",
bet_money_invalid: "Bet money invalid",
bet_money_invalid_tour: "Bet money invalid",
bet_min_100: "Amount must be more than 100",
bet_min_1000: "The fortune must be greater than 1,000 GOLD!",
bet_only_1_side: "Already bet at another",
bet_invalid_side: "Bet invalid side",
bet_side_other: "Bet only 1 side",
bet_invalid: "You haven't chosen the bet yet!",
prestart_phase: "Wait for the new game!",
start_phase: "Start a new game!",
bet_phase: "Please bet",
result_phase: "Stop bet",
reward_phase: "Pay the reward!",
win_streak: "WIN STREAK",
lose_streak: "LOSE STREAK",
nan: "SLIDE",
bo_nan: "OPEN",
no_data: "This session has no data"
},
sicbo: {
gate: {
0: "Even 4 red",
1: "Odd 1 black",
2: "Even",
3: "Odd 1 red",
4: "Even 4 black",
5: "Odd",
6: "Sicbo even",
7: "Sicbo odd",
14: "Total 4",
15: "Total 5",
16: "Total 6",
17: "Total 7",
18: "Total 8",
19: "Total 9",
20: "Total 10",
21: "Total 11",
22: "Total 12",
23: "Total 13",
24: "Total 14",
25: "Total 15",
26: "Total 16",
27: "Total 17",
31: "Number 1",
32: "Number 2",
33: "Number 3",
34: "Number 4",
35: "Number 5",
36: "Number 6",
40: "Any storm",
41: "Storm 1",
42: "Storm 2",
43: "Storm 3",
44: "Storm 4",
45: "Storm 5",
46: "Storm 6"
},
bao: "STORM",
bet_side_other: "Only place 1 of 2 doors Big or Small"
},
taixiu: {
bet_tai: "BET BIG",
bet_xiu: "BET SMALL",
open: "Open",
chitietbangdau: {
group_A: "Group A",
group_B: "Group B",
group_C: "Group C",
group_D: "Group D",
group_E: "Group E",
group_F: "Group F",
group_G: "Group G",
group_H: "Group H",
nickname: "NICKNAME",
gold: "GOLD",
time: "TIME",
small_gate: "SMALL",
big_gate: "BIG",
group: "GROUP",
rank: "RANK",
finnal: "Final"
},
jackpot: {
Tai: "The jackpot amount you win at Big side is ",
Xiu: "The jackpot amount you win at Small side is "
}
},
xocdia: {
gate: {
0: "Even 4 red",
1: "Odd 1 black",
2: "Even",
3: "Odd 1 red",
4: "Even 4 black"
}
},
chanle: {
bet_chan: "BET EVEN",
bet_le: "BET ODD",
open: "Open"
},
rutloc: {
quy_loc: "FORTUNE FUND",
tan_loc: "SHARE FORTUNE",
rut_loc: "WITHDRAWL FORTUNE",
bet_success: "Successful fortune. Good luck to you!",
bet_fail: "Fail fortune!",
bet_min_1000: "The fortune must be greater than 1,000 GOLD!",
bet_outtime: "Withdrawal failed! Wait for the last 30 seconds!",
bet_nexttime: "Wish you luck next time!!",
reward: "You can withdraw fortune",
not_money: "Not enough fortune",
out: "You have run out of draws!"
},
tournament: {
title_user: "User",
no: "No.",
title_user_history: "User history",
phien: "Session",
time: "Time",
bet_1: "Door",
result: "Result",
bet_2: "Bet",
rev: "Received",
nickname: "Nickname",
gold: "Balance",
day: "day",
tour_status_1: "Tournament coming soon!",
tour_status_2: "Tournament ready!",
tour_status_3: "The tournament is about to start!",
tour_status_4: "Tournament in progress",
tour_status_5: "End of round",
tour_status_6: "End of the tournament",
tit_players: "Players",
tit_tour_info: "Infomations",
tit_join_tour: "Join Tour",
tit_num_players: "Players:",
tit_num_rounds: "Rounds:",
tit_min_bet: "Min bet:",
tit_ticket_prize: "Ticket prize:",
tit_nph_prize: "Discount:",
tit_reg: "REGISTER FOR TEAM",
err_reg_0: "Registration successful",
err_reg_1: "Invalid code",
err_reg_2: "Duplicate code",
err_reg_4: "User not found",
err_reg_5: "No code found",
err_reg_6: "Code is already in use",
err_reg_7: "Code expired",
err_reg_8: "No tour found",
err_reg_9: "Tour without code",
err_reg_10: "User was on tour",
err_reg_11: "No team found",
err_reg_12: "The tournament has started. Unable to register",
err_reg_14: "The tournament has reached its maximum number of players",
tit_ticket: "Ticket fare",
tit_top_tour_0: "TOP OF WEEK",
tit_top_tour_1: "TOP OF MONTH",
tit_top_tour_2: "TOP RANK COMPETITION",
tit_top_tour_3: "TOP RANK COMPETITION",
thele: {
week: {
text_1: "- Weekly Tournament\nHappening every Saturday",
text_2: "* Weekly Tournament\nCompetition format: Participate in the knockout of 32 players, divided into 8 groups, 4 players each, choose 2 players with the best performance in each group to the next round. A total of 8 finalists of the week to compete and find out the top 3 ranked people of the week to compete in the Monthly Tournament.",
prize_0: "+ First Prize: %{money} Gold “to participate in the monthly final competition”  ",
prize_1: "+ Second Prize: %{money} Gold “to participate in the monthly final competition”  ",
prize_2: "+ Third Prize: %{money} Gold “to participate in the monthly final competition”  ",
prize_3: "+ 4th Prize: %{money} Gold ",
prize_4: "+ 5th Prize: %{money} Gold ",
prize_5: "+ 6th Prizen: %{money} Gold ",
prize_6: "+ 7th Prize: %{money} Gold ",
prize_7: "+ 8th Prize: %{money} Gold ",
text_3: "* For the Audience",
text_4: "+ 3 prizes: 1,000,000 Gold - 500,000 Gold - 200,000 Gold for those who guess correctly or closest to 4 character names of the semi-finals",
text_5: "+ 30 consolation prizes: code 50,000 for participants to predict + tag 5 friends “not counting clone nick, virtual FB. Only real Facebook with 200 friends or more”"
},
month: {
text_1: "- Monthly Tournament\nHappening every Sunday night at the end of the month",
text_2: "* Monthly Tournament\nCompetition format: Monthly tournament with 16 people. Divided into 4 groups, each group 4 players against each other\nSelect 8 people with the best results to the final of the Month.",
prize_0: "+ First Prize: %{money} Gold ",
prize_1: "+ Second Prize: %{money} Gold ",
prize_2: "+ Third Prize: %{money} Gold ",
prize_3: "+ 4th Prize: %{money} Gold ",
prize_4: "+ 5th Prize: %{money} Gold ",
prize_5: "+ 6th Prize: %{money} Gold ",
prize_6: "+ 7th Prize: %{money} Gold ",
prize_7: "+ 8th Prize: %{money} Gold ",
text_3: "* For the Audience",
text_4: "+ 3 prizes: 1,000,000 Gold - 500,000 Gold - 200,000 Gold for those who guess correctly or closest to 4 character names of the semi-finals",
text_5: "+ 30 consolation prizes: code 50,000 for participants to predict + tag 5 friends “not counting clone nick, virtual FB. Only real Facebook with 200 friends or more”"
}
}
}
},
minibaucua: {
check_ball: "CHECK BALL",
rebet: "BET AGAIN",
accept: "ACCEPT",
destroy: "CANCEL",
popup: {
guide_title: "GUIDE",
history_title: "TRANSACTION HISTORY",
honor_title: "Top bets",
session: "SESSION",
time: "TIME",
bet_position: "BET PLACE",
result: "RESULT",
bet: "BET",
return: "RETURN",
gain: "TAKE",
detail: "DETAIL",
rank: "RANK",
account: "Account",
win: "Win"
},
his_detail: {
session: "Session:",
day: "Day:",
result: "Result:",
bau: "Gourd",
cua: "Crab",
tom: "Prawn",
ca: "Fish",
ga: "Chicken",
huou: "Deer"
},
toast: {
bet_fail: "Bet fail.",
unreach_bet_time: "It's not time to bet yet.",
over_bet_time: "Bet timeout.",
not_enough_gold: "Insufficient coins.",
bet_success: "Bet success.",
action_too_quick: "Action too quick.",
bet_no_position: "You have not set the bet.",
no_bet_last_session: "You haven't bet the previous session",
no_bet_before: "You have not placed a bet before.",
only_rebet_in_first_time: "You can only reset for the first bet."
}
},
caothap: {
play: "PLAY",
stop: "STOP",
popup: {
guide_title: "GUIDE",
history_title: "HISTORY",
honor_title: "HONORS",
session: "Session",
time: "Time",
bet: "Bet",
step: "Step",
result: "Result",
bet_door: "Bet Place",
win: "Win",
account: "Account",
bet_level: "Bet level",
status: "Status",
jackpot: "Jackpot",
big_win: "Big win",
high: "High",
low: "Low"
},
toast: {
not_enough_gold: "The coin is not enough, please top up",
you_loose: "You lose! Good luck next time!",
congratulations: "Congratulations! You won ",
gold: "gold",
click_to_start_game: 'Click "Play" to start the game',
action_too_quick: "You act too quick",
not_enough_gold_at_bet_level: "You do not have enough money to play this bet."
}
},
minilongho: {
accept: "Accept",
destroy: "Cancel",
bet_dragon: "Bet Dragon",
bet_draw: "Bet Draw",
bet_tiger: "Bet Tiger",
dragon: "Dragon",
tiger: "Tiger",
draw: "Draw",
big_road: "Big road",
disk_road: "Disk road",
top_bet: "Top Bet",
total_game: "Total game",
popup: {
guide_title: "Guide",
history_title: "History",
honor_title: "Top Daily",
session: "Session",
bet_door: "Bet place",
bet: "Bet money",
time: "Time",
win: "Win",
result: "Result",
no: "No",
account: "Account",
bet_money: "Bet money",
win_money: "Win money"
},
toast: {
start_new_game: "Start a new game!",
start_return_reward: "Start paying",
have_err_betting: "There was an error during the betting process",
minimum_bet: "Bet amount must be more than 1,000",
not_enough_gold: "Not enough balance",
over_bet_time: "Over bet time",
not_in_bet_time: "It's not time to bet yet!"
}
},
pokemon: {
line: "Line",
spin: "Spin",
autoSpin: "Auto Spin",
stop: "Stop",
popup: {
detail_title: "Bet Detail",
guide_title: "Guide",
history_title: "Play History",
honor_title: "Honors",
select_line_title: "Select line",
session: "Session",
time: "Time",
bet_level: "Bet level",
bet_line: "Bet line",
bet: "Bet",
gain_gift: "Get a rewards",
room: "Room",
detail: " Detail",
account: "Account",
status: "Status",
win: "Win",
unselect: "Unselect",
even_line: "Even line",
odd_line: "Odd line",
all_line: "All",
line_win: "Win Line",
jackpot: "Jackpot",
big_win: "Big Win"
},
toast: {
action_too_quick: "You act too quickly.",
not_enough_gold: "The coins is not enough, please top up",
error_try_again: "An error occurred, please try again later",
connecting_server: "Connecting to the server"
}
},
minipoker: {
auto_spin: "Auto Spin",
play_gold: "Play Gold",
play_chip: "Play Coins",
popup: {
guide_title: "Guide",
history_title: "Transaction history",
honor_title: "Leaderboard",
time: "Time",
bet: "Level",
type: "Card group",
win: "Win",
account: "Account",
straight: "Straight",
pair_j: "Pair of J++",
full_house: "Full House",
two_pair: "Two Pair",
flush: "Flush",
three_of_a_kind: "Three of a kind",
straight_flush: "Straight Flush",
jackpot: "Jackpot",
four_of_a_kind: "Four of a kind"
},
toast: {
action_too_quick: "You act too quickly.",
not_enough_gold: "The balance is not enough, please top up.",
error_try_later: "An error occurred, please try again later.",
game_in_auto_spin: "The game is in auto spin mode"
}
},
xeng: {
day: "Day",
month: "Month",
year: "Year",
title_help: "Guide",
title_transaction: "Transaction history",
title_top: "TOP Bet",
title_session: "Session",
title_time: "Time",
title_side: "Bet door",
title_result: "Result",
title_bet: "Bet",
title_reward: "Receive",
title_stt: "No",
title_account: "Account",
title_gold: "Gold",
bet_phase: "Start betting!",
result_phase: "Bet time out!!",
bet_success: "Successful bet!!",
bet_invalid_money: "Invalid bet",
bet_not_enough_money: "Not enough money",
bet_fail: "Bet failed"
},
lodenormal: {
betted: "Betted",
betting: "Betting",
bet: "Bet",
winned: "Won",
eat: "Win",
de: "De",
lo: "Lo",
de_3_num: "De 3 number",
de_first: "De first",
de_last: "De last",
lo_through_2: "2 Lo parlay",
lo_through_3: "3 Lo parlay",
lo_through_4: "4 Lo parlay",
lo_fail_10: "Lo fail 10",
de_group: "De group",
no_group: "Number group",
couple_number: "Couple number",
rate_number: "De coefficient",
group: "Group",
double_group: "Double group",
double_type: "Double type group",
type_double: "Double type",
type_double1: "Type double",
num_lo_de_group: "Lo de number group",
animal_designation_12: "Animal Signs",
double_similar: "Double similar",
double_dif: "Double diff",
de_sum: "De sum",
special: "Special",
first_prize: "1st prize",
second_prize: "2nd prize",
third_prize: "3rd prize",
fourth_prize: "4th Prize",
fifth_prize: "5th prize",
sixth_prize: "6th prize",
seventh_prize: "7th prize",
north_lottery: "Northern Lotery",
last_second: "Seconds ago",
last_minute: "Minute ago",
last_hour: "Hours ago",
last_day: "Yesterday",
last_month: "Last month",
last_year: "Last year",
rat: "The Rat",
ox: "The Ox",
tiger: "The Tiger",
cat: "The Cat",
dragon: "The Dragon",
snake: "The Snake",
horse: "The Horse",
goat: "The Goat",
monkey: "The Monkey",
rooster: "The Rooster",
dog: "The Dog",
pig: "The Pig",
popup: {
month: "Month",
year: "Year",
end_bet_title: "Information",
inputbet_title: "Enter Money",
choose_de_num_title: "Choose De number",
choose_lo_num_title: "Choose Lo number",
de_3_num_title: "De 3 number",
choose_de_group_title: "Choose De group",
choose_lo_through_2: "Choose 2 Lo parlay",
choose_lo_through_3: "Choose 3 Lo parlay",
choose_lo_through_4: "Choose 4 Lo parlay",
choose_lo_fail_10: "Choose Lo fail 10",
choose_num_group_12: "Choose number group 12 animal signs",
choose_double_similar: "De double similar",
double_similar_detail: "Set of numbers: 00, 11, 22, 33, 44, 55, 66, 77, 88, 99",
choose_double_dif: "Choose De group double diff",
choose_de_sum_title: "Choose De group sum",
confirm: "Confirm",
reject: "Cancel",
bet: "Bet",
bet_num: "Bet",
bet_money: "Bet money",
bet_money_total: "Total bet money",
win_total: "Total win",
de: "De",
lo: "Lo",
end_bet_warning: "Please confirm your bet information",
bet_money_total1: "Total amount set",
input_bet_placeholder: "Enter the amount",
input_num_placeholder: "Enter the number",
gold: "Gold",
bet_total: "Total bet",
time_warning: "Time from 18:10 to 18:45 (Vietnam time) is the time of prize drawing and payout, we do not accept bets during this period."
},
warning: {
bet_success: "Successful bet!",
invalid_bet: "Invalid bet amount",
error_in_betting: "There was an error while placing the bet",
cant_bet_this_time: "Can't place bets during this time",
not_enough_gold: "You don't have enough balance",
please_choose_bet: "Please choose your bet level",
server_stop_spin_and_return_reward: "Today the system stops spinning and pays out",
please_cash_in_before_bet: "Please make a deposit before placing a bet",
please_choose_no_bet: "Please select the bet number",
please_choose_bet_money: "Please choose your bet amount",
over_bet_bound: "Set limit exceeded",
only_can_bet: "You can the bet",
gold: "Gold",
no: "Number",
error_in_betting_door: "Error in the process of placing the bet"
}
},
longho: {
dragon: "Dragon",
tiger: "Tiger",
draw: "Tie",
tai: "Big",
xiu: "Small",
black: "Black",
red: "Red",
session: "Session",
menu: {
exit: "Exit",
rule: "Rule",
history: "History",
rank: "Rank"
},
popup: {
chat_title: "Chat",
playing_people_title: "People who play together",
check_ball_title: "Current session details",
guide_title: "Guide",
history_title: "Transaction history",
rank_title: "Top winner",
chat_placeholder: "Chat",
exit_table: "Exit table",
history: "History",
rule: "Rule",
rank: "Rank",
title_statitics: "statitics",
title_count_statitics: "Count statitics",
title_dishroad: "Dish road",
title_bigroad: "Big road",
nick_name: "Nick Name",
bet_door: "Bet",
money: "Money",
time: "Time",
session: "Session",
bet_money: "Bet money",
win_money: "Win money",
result: "Result",
dragon: "Dragon",
tiger: "Tiger",
no: "No",
user_name: "User name",
play_together: "User play together"
},
toast: {
no_chat_permission: "*** You do not have permission to Chat!",
banned_chat: "*** Temporarily banned from Chat!",
too_long_chat_content: "*** Chat content is too long!",
banned_chat_to: "You are banned chat to",
serverr_busy_try_later: "The system is busy, please try again later",
not_enough_gold: "Account balance is not enough to bet",
bet_too_small: "Bet amount is too small",
only_allow_bet_dragon_or_tiger: "You only place to bet on either Dragon or Tiger",
only_alow_bet_red_or_black_dragon: "You can only bet on one of 2 doors Dragon-Red or Dragon-Black",
only_alow_bet_tai_or_xiu_dragon: "You can only bet on one of 2 doors Dragon-Big or Dragon-Small",
only_alow_bet_red_or_black_tiger: "You can only bet on one of 2 doors Tiger-Red or Tiger-Black",
only_alow_bet_tai_or_xiu_tiger: "You can only bet on one of 2 doors Tiger-Big or Tiger-Small",
start_return_reward: "START PAYING",
start_bet_door: "START BETTING",
not_in_bet_time: "Now is not the time to bet",
please_choose_bet: "Please choose a bet",
over_time_bet: "Betting time is over",
not_enough_gold1: "Insufficient coins"
}
},
slot_avengers: {
unhappen: "Not happen yet",
music: "Music",
sound: "Sound",
win: "Win:",
total_bet: "Total Bet:",
autoSpin: "Auto Spin",
line: "Line",
bet: "Bet",
play_trial: "Play Trial",
play_real: "Play Real",
popup: {
jackpot_history_title: "Jackpot history",
choose_line_title: "Choose line",
trade_history_title: "Transaction history",
x2_win_title: "X2 bonus",
time: "Time",
level: "Level",
jackpot: "Jackpot",
account: "Account",
result: "Result",
session: "Session",
line_bet: "Bet Line",
line_win: "Win Line",
receive_gold: "Receive gold",
even_line: "Even Line",
odd_line: "Odd Line",
all_line: "All Line",
re_select: "Reset",
big_win: "Big Win",
choose_pearl: "Choose Pearl",
congratulations: "You Win",
jackpotx2: "Jackpot x2"
},
toast: {
need_choose_minimum_1_line: "You need to select at least 1 Line",
function_dont_work_in_trial: "This function does not work in trial mode.",
off_auto_spin_to_leave: "Turn off the AUTO spin to exit the table",
function_in_develop: "The function are developing",
not_enough_gold: "The coins is not enough, please top up",
error_try_again: "An error occurred, please try again"
}
},
slot_dancing_girls: {
holdToSpin: "HOLD TO AUTO-SPIN",
unhappen: "Not happen yet",
music: "Music",
sound: "Sound",
win: "Win:",
total_bet: "Total Bet:",
autoSpin: "Auto Spin",
line: "Line",
bet: "Bet",
play_trial: "Play Trial",
play_real: "Play Real",
popup: {
jackpot_history_title: "Jackpot history",
guide_title: "Rewards table",
choose_line_title: "Choose line",
trade_history_title: "Transaction history",
x2_win_title: "X2 bonus",
time: "Time",
level: "Level",
jackpot: "Jackpot",
account: "Account",
result: "Result",
session: "Session",
line_bet: "Bet Line",
line_win: "Win Line",
receive_gold: "Receive gold",
even_line: "Even Line",
odd_line: "Odd Line",
all_line: "All Line",
re_select: "Reset",
big_win: "Big Win",
choose_pearl: "Choose Pearl",
congratulations: "You Win",
jackpotx2: "Jackpot x2"
},
toast: {
need_choose_minimum_1_line: "You need to select at least 1 Line",
function_dont_work_in_trial: "This function does not work in trial mode.",
off_auto_spin_to_leave: "Turn off the AUTO spin to exit the table",
function_in_develop: "The function are developing",
not_enough_gold: "The coins is not enough, please top up",
error_try_again: "An error occurred, please try again"
}
},
slotkhobau: {
unhappen: "Not happened yet",
music: "Music",
sound: "Sound",
bet: "Bet",
total_bet: "Total Bet",
last_win: "Last Win",
hide: "Hide",
autoSpin: "Auto Spin",
line: "Line",
popup: {
choose_line_title: "Choose line",
x2_win_title: "X2 bonus",
guide_title: "Rewards table",
jackpot_history_title: "Jackpot history",
trade_history_title: "Transaction history",
time: "Time",
level: "Level",
jackpot: "Jackpot",
account: "Account",
result: "Result",
session: "Session",
line_bet: "Line bet",
line_win: "Line win",
receive_gold: "Receive gold",
even_line: "Even Line",
odd_line: "Odd Line",
all_line: "All Line",
re_select: "Reset",
big_win: "Big Win",
choose_pearl: "Choose Pearl",
you_win: "You Win",
remain_turn: "Remain Turn",
total_score: "Total Score",
click_to_exit: "Click to Exit",
minigame_title: "Mini game Treasure"
},
toast: {
function_dont_work_on_trial: "This function does not work in trial mode.",
off_auto_spin_to_leave: "Turn off the AUTO spin to exit the table",
funtion_in_develop: "The function are developing",
not_enough_gold: "The balance is not enough, please top up",
spin_unsuccess: "Spin unsuccess",
unvalid_bet: "Invalid bet",
unvalid_spin: "Invalid spin",
error_try_again: "An error occurred, please try again",
atleast_1_line: "You need to select at least 1 Line"
}
},
SlotTreeOfFortune: {
main: {
total_bet: "Total bet:",
total_win: "Win:",
music: "Music",
sound: "Sound"
},
choose_line: {
title: "SELECT LINE",
even_line: "EVEN LINE",
odd_line: "ODD LINE",
all_line: "ALL",
re_line: "RESELECT"
},
mini_game: {
notice: "Click/Tap the tree to vibrate",
close: "Close",
you_get: "You receive",
time_left: "Time left:",
score: "CHARGE POINTS:"
},
history: {
title: "HISTORY",
phien: "SESSION",
time: "TIME",
muc: "LEVEL",
line_bet: "LINE BET",
line_win: "LINE WIN",
gold_receive: "GOLD"
},
top: {
title: "TOP",
time: "TIME",
muc: "LEVEL",
jackpot: "JACKPOT",
account: "ACCOUNT",
result: "RESULT",
nohu: "JACKPOT"
},
guide: "GUIDE",
message: {
message1: "This feature does not work in trial mode.",
message2: "Daily rotation cannot use auto-record",
message3: "You are moving room, please wait",
message4: "You are recording, please wait for the recording to finish",
message5: "The system is processing, please wait",
message6: "You are in trial mode, no line selected",
message7: "You have free spins left",
message8: "You are recording automatically",
message9: "Recording failed",
message10: "Invalid bet",
message11: "You don't have enough money",
message12: "Invalid spin",
message13: "Good luck next time!",
message14: "You must select at least 1 line"
}
},
tlmn: (o = {
tlmn_title: "Southern Thirteen-Card",
create_room: "Creat table",
play_now: "Play now",
refresh_room: "Refresh",
choose_bet_value: "Choose",
player: "Player",
password_room: "Room Password",
table: "Table: ",
bet_money: "Bet Money: ",
watting_for_start_game: "Waiting for a new game to start: ",
first_turn: " first turn!",
sort_card: "Sort",
hit_card: "Submit",
next_turn: "Cancel",
no_select_card: "You have not select card!",
card_avaiable_found: "card avaiable found",
viewing: "Watching",
dang_ki_exit_success: "You have successfully registered to leave the room!",
huy_dang_ki: "You have canceled leaving the room!",
invite_game: "Invite to play",
no_one_invite: "No suitable players",
not_open: "Function temporarily not open",
create_room_place_holder: "Name the room",
chat_place_holder: "Type",
result: "Result",
confirm: "Confirm",
room_not_found: "The selected room could not be found",
not_create_room: "Cannot create this table!",
not_enough_money: "The balance is not enough, please top up",
no_room_avaiable_found: "No valid table found",
error_check: "Error checking information",
bao_tri: "The system is maintenance",
time_wait: "Each room entry must be 10 seconds apart!!",
password_error: "Incorrect room password!",
room_full: "The room is full now!",
ban_room: "You are not allowed to enter the table by the host!",
info_create_room_error: "Incorrect table creation information!",
not_enough_vip: "You are not VIP level enough to create a table!",
not_enough_vip2: "Can't create more tables with current VIP level!",
chat_1: "You can't do it!",
chat_2: "Give me a like !",
chat_3: "Thanks!",
chat_4: "Lucky!",
chat_5: "Cool~",
chat_6: "Unlucky!",
chat_7: "So close!!",
chat_8: "Oops, Sorry!",
chat_9: "Oh, no…",
chat_10: "I got this!",
chat_11: "You're gonna lose!",
chat_12: "Hurry up!",
special_result_0: "DRAGON PARK",
special_result_1: "FOUR QUARTER 2",
special_result_2: "5 Pairs of Pine",
special_result_3: "6 PAIRS",
special_result_4: "13 COLORS",
special_result_5: "12 COLORS",
result_0: "TWO",
result_1: "DOUBLE TWO",
result_2: "3 TWO",
result_3: "3 DOUBLE THROUGH",
result_4: "4 DOUBLE THROUGH"
}, o.result_2 = "Win", o.result_4 = "Go to White", o.result_11 = "Loss", o.result_12 = "Cold", 
o.result_13 = "White Loss", o),
sam: {
sam_title: "Hell",
create_room: "Creat table",
play_now: "Play now",
refresh_room: "Refresh",
play_tour: "Tournament",
play_normal: "Normal",
create_room_place_holder: "Name the room",
choose_bet_value: "Choose",
player: "Player",
password_room: "Room Password",
table: "Table: ",
bet_money: "Bet Money: ",
watting_for_start_game: "Waiting for a new game to start: ",
first_turn: " first turn!",
noti_bao_sam: "Do you want to warning Sam?",
bao: "Warning",
ko_bao_sam: "Do not warning Sam",
co_bao_sam: "Warning Sam",
sort_card: "Sort",
hit_card: "Submit",
next_turn: "Cancel",
viewing: "Watching",
bao_sam: "Report Card",
huy_sam: "Cancel Report Card",
no_select_card: "You have not select card!",
card_avaiable_found: "card avaiable found",
dang_ki_exit_success: "You have successfully registered to leave the room!",
huy_dang_ki: "You have canceled leaving the room!",
invite_game: "Invite to play",
no_one_invite: "No suitable players",
not_open: "Function temporarily not open",
chat_place_holder: "Type",
result: "Result",
confirm: "Confirm",
room_not_found: "The selected room could not be found",
not_create_room: "Cannot create this table!",
not_enough_money: "The balance is not enough, please top up",
no_room_avaiable_found: "No valid table found",
error_check: "Error checking information",
bao_tri: "The system is maintenance",
time_wait: "Each room entry must be 10 seconds apart!!",
password_error: "Incorrect room password!",
room_full: "The room is full now!",
ban_room: "You are not allowed to enter the table by the host!",
info_create_room_error: "Incorrect table creation information!",
not_enough_vip: "You are not VIP level enough to create a table!",
not_enough_vip2: "Can't create more tables with current VIP level!",
chat_1: "You can't do it!",
chat_2: "Give me a like !",
chat_3: "Thanks!",
chat_4: "Lucky!",
chat_5: "Cool~",
chat_6: "Unlucky!",
chat_7: "So close!!",
chat_8: "Oops, Sorry!",
chat_9: "Oh, no…",
chat_10: "I got this!",
chat_11: "You're gonna lose!",
chat_12: "Hurry up!",
special_6: "Top Ginseng",
special_7: "Second Quarter",
special_8: "Five double",
special_9: "Same color",
special_4: "Block ginseng",
special_16: "Failed Ginseng",
result_3: "Win",
result_7: "Ginseng",
result_6: "Win and block Sam",
result_2: "Top Ginseng",
result_4: "Second quarter",
result_1: "Five double",
result_0: "Same color",
result_8: "Temple",
result_5: "Tie",
result_9: "Lose",
result_10: "Sam Temple"
},
poker: (a = {
poker_title: "Poker",
watting_for_start_game: "Waiting for a new game to start: ",
watting_for_end_game: "End game: ",
table: "Table: ",
bet_money: "Bet Money: ",
viewing: "Watching",
chat_place_holder: "Type",
invite_game: "Invite to play",
no_one_invite: "No suitable players",
not_open: "Function temporarily not open",
create_room: "Creat table",
create_room_place_holder: "Name the room",
play_now: "Play now",
refresh_room: "Refresh",
choose_bet_value: "Choose",
player: "Player",
password_room: "Room Password",
buy_in: "BUY IN",
auto_buy_in: "Automatically buy in when running out of chips",
confirm: "Confirm",
dang_ki_exit_success: "You have successfully registered to leave the room!",
huy_dang_ki: "You have canceled leaving the room!",
reg_buyin: "Registered to Buy In",
unreg_buyin: "Cancel Buy In subscription",
id_room: "Type ID room ...",
hide_full_table: "Hide full table",
room_not_found: "The selected room could not be found",
please_add_idroom: "Please enter the table you want to search for",
not_create_room: "Cannot create this table!",
not_enough_money: "The balance is not enough, please top up",
no_room_avaiable_found: "No valid table found",
error_check: "Error checking information"
}, a.no_room_avaiable_found = "No valid table found", a.bao_tri = "The system is maintenance", 
a.time_wait = "Each room entry must be 10 seconds apart!!", a.password_error = "Incorrect room password!", 
a.room_full = "The room is full now!", a.ban_room = "You are not allowed to enter the table by the host!", 
a.info_create_room_error = "Incorrect table creation information!", a.not_enough_vip = "You are not VIP level enough to create a table!", 
a.not_enough_vip2 = "Can't create more tables with current VIP level!", a.not_enough_gold = "The coins is not enough, please top up", 
a.chat_1 = "All in", a.chat_2 = "Fortunately", a.chat_3 = "All hands", a.chat_4 = "Hurry up auntie", 
a.chat_5 = "King's lobby", a.chat_6 = "It's so black", a.chat_7 = "I'm fine :)", 
a.chat_8 = "To money :)", a.chat_9 = "It's so boring", a.chat_10 = "Eat the whole village :)", 
a.chat_11 = "Dare to go all out", a.chat_12 = "Good fight", a.double = "Double", 
a.tripple = "Triple", a.allin = "Allin", a.check = "Check", a.fold = "Fold", a.open = "Open", 
a.follow = "Call", a.call = "Call", a.raise = "Raise", a.bet = "Bet", a.royalflush = "Royal Flush", 
a.straightflush = "Straight flush", a.fourofakind = "Four of a kind", a.fullhouse = "Full house", 
a.flush = "Flush", a.straight = "Straight", a.threeofakind = "Three of a kind", 
a.twopair = "Two pair", a.pair = "Pair", a.highcard = "High Card", a),
binh: (_ = {
binh_title: "Chinese Poker",
watting_for_start_game: "Waiting for a new game to start: ",
table: "Table: ",
bet_money: "Bet Money: ",
viewing: "Watching",
chat_place_holder: "Type",
invite_game: "Invite to play",
no_one_invite: "No suitable players",
not_open: "Function temporarily not open",
create_room: "Creat table",
create_room_place_holder: "Name the room",
play_now: "Play now",
refresh_room: "Refresh",
choose_bet_value: "Choose",
player: "Player",
password_room: "Room Password",
confirm: "Confirm",
dang_ki_exit_success: "You have successfully registered to leave the room!",
huy_dang_ki: "You have canceled leaving the room!",
id_room: "Type ID room ...",
hide_full_table: "Hide full table",
room_not_found: "The selected room could not be found",
please_add_idroom: "Please enter the table you want to search for",
not_create_room: "Cannot create this table!",
not_enough_money: "The balance is not enough, please top up",
no_room_avaiable_found: "No valid table found",
error_check: "Error checking information"
}, _.no_room_avaiable_found = "No valid table found", _.bao_tri = "The system is maintenance", 
_.time_wait = "Each room entry must be 10 seconds apart!!", _.password_error = "Incorrect room password!", 
_.room_full = "The room is full now!", _.ban_room = "You are not allowed to enter the table by the host!", 
_.info_create_room_error = "Incorrect table creation information!", _.not_enough_vip = "You are not VIP level enough to create a table!", 
_.not_enough_vip2 = "Can't create more tables with current VIP level!", _.chat_1 = "So long queue!", 
_.chat_2 = "Hurry up auntie", _.chat_3 = "Dragon lobby :)", _.chat_4 = "3 crates :)", 
_.chat_5 = "Its so black", _.chat_6 = "Luc waste bon ;)", _.chat_7 = "3 halls ;)", 
_.chat_8 = "The tunnel collapsed", _.chat_9 = "Mau Binh missed :(", _.chat_10 = "Its so boring", 
_.chat_11 = "The last penitentiary ;)", _.chat_12 = "Lose, baby", _.sorting = "Sort", 
_.sort_again = "Reorder", _.sort_done = "Sort done", _.bao_binh = "Reporter", _.sorting_time_remain = "Remaining sorting time", 
_.chi = "Hand", _.rs_fail = "WRONG STACK", _.rs_XAM_CHI_AT = "THREE OF ACE", _.rs_ROYAL_FLUSH = "ROYAL FLUSH", 
_.rs_TU_QUY_CHI_AT = "FOUR OF ACE", _.rs_THUNG_PHA_SANH = "STRAIGHT FLUSH", _.rs_TU_QUY = "FOUR OF A KIND", 
_.rs_CU_LU = "FULL HOUSE", _.rs_THUNG = "FLUSH", _.rs_SANH = "STRAIGHT", _.rs_XAM_CO = "THREE OF A KIND", 
_.rs_THU = "TWO PAIR", _.rs_DOI = "PAIR", _.rs_MAU_THAU = "HIGH CARD", _),
bacay: (i = {
bacay_title: "Three Card",
watting_for_start_game: "Waiting for a new game to start: ",
table: "Table: ",
bet_money: "Bet Money: ",
viewing: "Watching",
chat_place_holder: "Type",
invite_game: "Invite to play",
no_one_invite: "No suitable players",
not_open: "Function temporarily not open",
create_room: "Creat table",
create_room_place_holder: "Name the room",
play_now: "Play now",
refresh_room: "Refresh",
choose_bet_value: "Choose",
player: "Player",
password_room: "Room Password",
result: "Result",
confirm: "Confirm",
dang_ki_exit_success: "You have successfully registered to leave the room!",
huy_dang_ki: "You have canceled leaving the room!",
time_bet: "Time bet",
id_room: "Type ID room ...",
hide_full_table: "Hide full table",
room_not_found: "The selected room could not be found",
please_add_idroom: "Please enter the table you want to search for",
not_create_room: "Cannot create this table!",
not_enough_money: "The balance is not enough, please top up",
no_room_avaiable_found: "No valid table found",
error_check: "Error checking information"
}, i.no_room_avaiable_found = "No valid table found", i.bao_tri = "The system is maintenance", 
i.time_wait = "Each room entry must be 10 seconds apart!!", i.password_error = "Incorrect room password!", 
i.room_full = "The room is full now!", i.ban_room = "You are not allowed to enter the table by the host!", 
i.info_create_room_error = "Incorrect table creation information!", i.not_enough_vip = "You are not VIP level enough to create a table!", 
i.not_enough_vip2 = "Can't create more tables with current VIP level!", i.not_enough_gold = "The coins is not enough, please top up", 
i.chat_1 = "Heres the wax", i.chat_2 = "So lucky", i.chat_3 = "Lets steal the chapter", 
i.chat_4 = "So lucky", i.chat_5 = "Hurry up", i.chat_6 = "It's so black", i.chat_7 = "Here you go :)", 
i.chat_8 = "Make money :)", i.chat_9 = "This article is so boring", i.chat_10 = "Are you ready yet?", 
i.chat_11 = "Lose, baby", i.chat_12 = "X2 whole Village :)", i.chicken_win = "Win Pot", 
i.chicken_money = "Pot Money: ", i.bet_in_chicken = "Pot Pot", i.open_all = "Open all", 
i.bet_phase = "Betting Start!", i.danh_bien = "Fighting", i.ke_cua = "Pull the door", 
i.score = " Score", i.all_lose = "ALL LOSE", i.all_win = "ALL WIN", i.chuong = "BOSS", 
i.tit_name = "Player", i.tit_bet = "Bet", i.tit_cuocga = "Chicken bet", i.tit_kecua = "Door Pull", 
i.tit_danhbien = "Beat Bien", i.tit_tong = "Total", i),
xizach: (r = {
xizach_title: "Xì Zách",
watting_for_start_game: "Waiting for a new game to start: ",
table: "Table: ",
bet_money: "Bet Money: ",
viewing: "Watching",
chat_place_holder: "Type",
invite_game: "Invite to play",
no_one_invite: "No suitable players",
not_open: "Function temporarily not open",
create_room: "Creat table",
create_room_place_holder: "Name the room",
play_now: "Play now",
refresh_room: "Refresh",
choose_bet_value: "Choose",
player: "Player",
password_room: "Room Password",
confirm: "Confirm",
dang_ki_exit_success: "You have successfully registered to leave the room!",
huy_dang_ki: "You have canceled leaving the room!",
time_bet: "Time bet",
id_room: "Type ID room ...",
hide_full_table: "Hide full table",
room_not_found: "The selected room could not be found",
please_add_idroom: "Please enter the table you want to search for",
not_create_room: "Cannot create this table!",
not_enough_money: "The balance is not enough, please top up",
no_room_avaiable_found: "No valid table found",
error_check: "Error checking information"
}, r.no_room_avaiable_found = "No valid table found", r.bao_tri = "The system is maintenance", 
r.time_wait = "Each room entry must be 10 seconds apart!!", r.password_error = "Incorrect room password!", 
r.room_full = "The room is full now!", r.ban_room = "You are not allowed to enter the table by the host!", 
r.info_create_room_error = "Incorrect table creation information!", r.not_enough_vip = "You are not VIP level enough to create a table!", 
r.not_enough_vip2 = "Can't create more tables with current VIP level!", r.chat_1 = "Hurry up, aunty", 
r.chat_2 = "So lucky", r.chat_3 = "Im 20!", r.chat_4 = "Quack yet?", r.chat_5 = "Its so black!", 
r.chat_6 = "Ballast!", r.chat_7 = "Ngu Linh!", r.chat_8 = "Fuck it!", r.chat_9 = "Old enough", 
r.chat_10 = "Make money", r.chat_11 = "Oh my God! The Five Spirits", r.chat_12 = "Already eaten", 
r.act_danbai = "STAY", r.act_xetbai = "CHECK", r.score_quac = "BUSTED", r.score_xibang = "DOUBLE ACES", 
r.score_xizach = "BLACK JACK", r.score_ngulinh = "MAGIC FIVE", r.score_21d = "21 POINT", 
r.score_diem = " POINT", r),
slotdechemaya: {
unhappen: "Have not happened yet",
music: "Music",
sound: "Sound",
last_win: "Last win",
total_bet: "Total bet",
play_trial: "Play Trial",
play_real: "Play Real",
line: "Line",
spin: "Spin",
autoSpin: "Auto Spin",
stop: "Stop",
bet: "Bet",
popup: {
choose_line_title: "Choose line",
x2_win_title: "X2 bonus",
guide_title: "Rewards table",
jackpot_history_title: "Jackpot history",
trade_history_title: "Transaction history",
even_line: "Even Line",
odd_line: "Odd Line",
all_line: "All Line",
re_line: "Reset",
line_bet: "Bet Line",
line_win: "Win Line",
chose_room_title: "Choose Room",
resident: "Resident",
leader: "Leader",
boss: "Boss",
honor_title: "Honor",
congratulations_account: "Congratulations account",
remain_turn: "Remain Turn",
total_score: "Total Score",
lucky_box_title: "Lucky Box",
you_win: "You win",
time: "Time",
level: "Level",
jackpot: "Jackpot",
account: "Account",
result: "Result",
session: "Session",
detail: "Detail",
view: "View",
receive_gold: "Receive Gold",
jackpotx2: "Jackpot x2"
},
toast: {
function_dont_work_on_trial: "This function does not work in trial mode.",
off_auto_spin_to_leave: "Turn off the AUTO spin to exit the table",
funtion_in_develop: "The function are developing",
not_enough_gold: "The balance is not enough, please top up",
spin_unsuccess: "Spin unsuccess",
unvalid_bet: "Invalid bet",
unvalid_spin: "Invalid spin",
error_try_again: "An error occurred, please try again",
atleast_1_line: "You need to select at least 1 Line"
}
},
keno: {
door: {
tai: "Big",
xiu: "Small",
chan: "Even",
le: "Odd",
kim: "Metal",
moc: "Wood",
thuy: "Water",
hoa: "Fire",
tho: "Earth"
},
type_bet: {
number: "Number",
xien: "Xien",
truotxien: "Not Appear",
tx: "Big Small",
cl: "Odd Even",
xien2: "Xien 2",
xien3: "Xien 3",
xien4: "Xien 4",
xien5: "Xien 5",
truotxien4: "N-A Xien 4",
truotxien5: "N-A Xien 5",
truotxien6: "N-A Xien 6",
truotxien7: "N-A Xien 7",
truotxien8: "N-A Xien 8",
truotxien9: "N-A Xien 9",
truotxien10: "N-A Xien 10"
},
btn: {
chat: "CHAT",
vecuoc: "BET TICKET",
statistic: "STATISTICS",
number_bet: "NUMBER BET",
base_bet: "BASE BET",
guide: "GUIDE",
most: "MOST",
at_least: "AT LEAST",
consecutive: "CONSECUTIVE",
no_result: "NO RESULT",
bet: "BET",
cancel: "CANCEL",
off: "OFF",
dont_show_again: "Don't show again",
transaction: "Transaction"
},
statistic: {
number_kytai: "Total Big:",
number_kyxiu: "Total Small:",
number_kychan: "Total Odd:",
number_kyle: "Total Even:",
ratio: "Rate:",
explain: "Explain",
tai: "=BIG",
xiu: "=SMALL",
chan: "=ODD",
le: "=EVEN",
today: "Today",
yesterday: "Yesterday",
number: "Number",
session50: "50 session",
session100: "100 session",
session200: "200 session",
session400: "400 session",
frequency: "Frequency",
tx: "Big Small",
cl: "Odd Even"
},
popup_title: {
confirm_ticket: "Confirm ticket",
you_know: "Do you know",
history_transfer: "History transfer",
result: "Result"
},
popup_confirm: {
selected: "Selected",
money_bet: "Money bet",
total_bet: "Total bet:",
total_prize: "Total prize:"
},
editbox: {
placeholder_session: "Type session number"
},
message: {
times: "fre",
rounding: "ROUNDING",
total: "TOTAL: ",
result_session: "RESULT SESSION #",
get: "1 GET",
error_number: "number!",
error_enough_number: "You must choose enough",
error_choose_maximum: "You only choose maximum",
selected: "Selected:  ",
success_bet: "Successful bet!",
error_bet1: "The system is being interrupted.\n Please try again later!",
error_bet2: "Currently the system is stopping \n the drawing of prizes.\n Please contact hotline!",
error_bet3: "The betting session has ended.\n Please bet next session!",
error_bet4: "Login error!",
error_bet5: "Please select bet type,\n number and money to complete the bet!",
error_bet6: "Please deposit to bet!",
error_bet7: "There is no bet type.\n Please bet again!",
error_bet8: "Money too small/bet!",
error_bet9: "Money is too big/bet!",
error_bet10: "The amount has exceeded the stake threshold/number.\n Please bet smaller amount\n or try again with another number\n or try again later session.",
error_bet11: "Not enough balance.\n Please try again!",
error_bet12: "Params is the wrong format!",
error_bet13: "Bet time out!",
error_bet14: "Unavailable balance!",
error_bet15: "Invalid amount!"
},
popup: {
rlt_number: "No",
rlt_session: "Session",
rlt_result: "Result",
rlt_total: "Total",
rlt_tx: "Big/Small",
rlt_cl: "Odd/even",
rlt_ngu_hanh: "5 Ele",
rlh_session: "Session",
rlh_bet_type: "Bet Type",
rlh_bet_money: "Money",
rlh_prize: "Prize",
rlh_time: "Time"
}
},
lode79: {
ld_txt_dat: "Bet",
ld_txt_tai: "BIG",
ld_txt_xiu: "SMALL",
ld_txt_le: "EVEN",
ld_txt_chan: "ODD",
ld_tit_chuyen_rut: "TRANSFER/WITHDRAWAL",
ld_xo_so: "Lottery",
ld_phien: "V: ",
ld_so_du: "Balance",
ld_so_tien: "Money",
ld_so_diem: "Score",
ld_tong_diem: "Total Score",
ld_thanh_tien: "Total money",
ld_tong_tien: "Total amount",
bet_success: "Successful bet",
bet_fail: "Bet failed",
mien_bac: "NORTHERN",
mien_trung: "CENTRAL",
mien_nam: "SOUTH",
dat_cuoc: "BET",
ltr_huy: "CANCEL",
result: {
txt_giai_db: "Special",
txt_giai_1: "1st Prize",
txt_giai_2: "2nd Prize",
txt_giai_3: "3rd Prize",
txt_giai_4: "4th Prize",
txt_giai_5: "5th Prize",
txt_giai_6: "6th Prize",
txt_giai_7: "7th Prize",
txt_giai_8: "8th Prize"
},
lib: {
re_mien_bac: "NORTHERN",
re_mien_trung: "CENTRAL",
re_mien_nam: "SOUTH",
re_short_mien_bac: "NORTHERN",
re_short_mien_trung: "CENTRAL",
re_short_mien_nam: "SOUTH",
qs_con_giap: "12 ANIMAL",
cg_ty_9: "Rat (9)",
cg_suu_9: "Ox (9)",
cg_dan_9: "Tiger (9)",
cg_mao_9: "Cat (9)",
cg_thin_8: "Dragon (8)",
cg_ti_8: "Snake (8)",
cg_ngo_8: "Horse (8)",
cg_mui_8: "Goat (8)",
cg_than_8: "Monkey (8)",
cg_dau_8: "Rooster (8)",
cg_tuat_8: "Dog (8)",
cg_hoi_8: "Pig (8)",
qs_bo_so: "GROUP",
bo_so_01: "Group 01",
bo_so_02: "Group 02",
bo_so_03: "Group 03",
bo_so_04: "Group 04",
bo_so_12: "Group 12",
bo_so_13: "Group 13",
bo_so_14: "Group 14",
bo_so_23: "Group 23",
bo_so_24: "Group 24",
bo_so_34: "Group 34",
qs_so_kep: "DUAL",
kep_bang: "Similar",
bo_00: "Set of 00",
bo_11: "Set of 11",
bo_22: "Set of 22",
bo_33: "Set of 33",
bo_44: "Set of 44",
qs_de_tong: "TOTAL",
tong_0: "Total 0",
tong_1: "Total 1",
tong_2: "Total 2",
tong_3: "Total 3",
tong_4: "Total 4",
tong_5: "Total 5",
tong_6: "Total 6",
tong_7: "Total 7",
tong_8: "Total 8",
tong_9: "Total 9",
type_de: "2D-L SPECIAL",
type_de_dau: "2D-F SPECIAL",
type_de_duoi: "2D-L 8th-S",
type_de_giai_8: "2D-F 8th",
type_de_giai_nhat: "2D-L 1st",
type_de_giai_7: "2D-L 7th",
type_de_dau_db: "1D-F SPECIAL",
type_de_duoi_db: "1D-L SPECIAL",
type_de_3_cang: "3D-L SPECIAL",
type_3d_dac_biet: "3D-L SPECIAL",
type_3d_giai_7: "3D-L 7th",
type_3d_duoi: "3D-L 7th-S",
type_lo: "LO",
type_lo_xien_2: "PARLAY LO 2",
type_lo_xien_3: "PARLAY LO 3",
type_lo_xien_4: "PARLAY LO 4",
type_lo_truot_4: "LO FAIL 4",
type_lo_truot_8: "LO FAIL 8",
type_lo_truot_10: "LO FAIL 10",
type_tai_xiu: "BIG SMALL",
type_chan_le: "ODD EVEN",
type_s_de: "2D-L SPECIAL",
type_s_de_dau: "2D-F SPECIAL",
type_s_de_duoi: "2D-L 8th-S",
type_s_de_giai_8: "2D-F 8th",
type_s_de_giai_nhat: "2D-L 1st",
type_s_de_giai_7: "2D-L 7th",
type_s_de_dau_db: "1D-F SPECIAL",
type_s_de_duoi_db: "1D-L SPECIAL",
type_s_de_3_cang: "3D-L SPECIAL",
type_s_3d_dac_biet: "3D-L SPECIAL",
type_s_3d_giai_7: "3D-L 7th",
type_s_3d_duoi: "3D-L 7th-S",
type_s_lo: "LO",
type_s_lo_xien_2: "PARLAY LO 2",
type_s_lo_xien_3: "PARLAY LO 3",
type_s_lo_xien_4: "PARLAY LO 4",
type_s_lo_truot_4: "LO FAIL 4",
type_s_lo_truot_8: "LO FAIL 8",
type_s_lo_truot_10: "LO FAIL 10",
type_s_tai_xiu: "BIG SMALL",
type_s_chan_le: "ODD EVEN"
},
responseWs: {
bet_success: "Successful bet.",
bet_fail: "Bet failed.",
resNotifyLivestream1: "Please invite you to bet\n on Lottery LiveStream\n  XXXX - YYYY session!",
resNotifyLivestream2: "Currently in the spinning.\n Please wait a few minutes \nto open the next session!",
resNotifyLivestream3: "Please stop betting.\n The system will start spinning\n the current session!",
resNotifyLivestream4: "Open bets on the next session\n XS XXXX Session YYYY.\n Please place your bets!",
resBet_am_1: "The token is in the wrong format!",
resBet_0: "Successful bet!",
resBet_1: "The system is busy.\n Please try again in a few minutes!",
resBet_2: "Configuration does not exist!",
resBet_3: "The prize draw is paused today!",
resBet_4: "Failed to load Lotery time bet",
resBet_5: "It's not time to open bets yet!",
resBet_6: "Account does not exist!",
resBet_7: "Nothing",
resBet_8: "Bets are required information!",
resBet_9: "The system is busy.\n Please try again in a few minutes!",
resBet_10: "The bet amount is too small!",
resBet_11: "The bet is too big!",
resBet_12: "Lotery type does not exist!",
resBet_13: "The bet is too big!",
resBet_14: "The bet amount is too small!",
resBet_15: "The bets are not in the correct format!",
resBet_16: "The bet number is not in the correct format!",
resBet_17: "The bet amount is too large!",
resBet_18: "Your account is not enough!",
resBet_19: "The province does not exist!",
resBet_20: "The system is busy.\n Please try again in a few minutes!",
resBet_21: "There is no prize draw at this location today!",
resBet_22: "The system is busy.\n Please try again in a few minutes!",
resBet_23: "Respose bet!",
resBet_24: "Respose bet!",
resBet_25: "Respose bet!",
resBet_26: "Respose bet!",
resBet_27: "Respose bet!",
resBet_28: "The system is busy.\n Please try again in a few minutes!",
resBet_29: "Bet amount is too big!",
resBet_30: "The system is busy.\n Please try again in a few minutes!",
resBet_31: "The system is busy.\n Please try again in a few minutes!",
resBet_32: "The system is busy.\n Please try again in a few minutes!",
resBet_33: "The account session has expired.\n Please login and action again!",
resBet_34: "Required minimum deposit to be eligible to bet!"
},
popup: {
title_huong_dan: "GUIDE",
title_thong_so: "PARAMETER",
title_thong_so_tra: "Traditional parameters",
title_thong_so_liv: "Livestream specs",
thong_so_header_gia_ban: "Price",
thong_so_header_tra_thuong: "Reward",
thong_so_header_toi_da_lan_cuoc: "Max/number of bets",
thong_so_header_toi_da_so: "Max/number",
title_sao_ke: "STATEMENT",
title_sao_ke_tra: "Traditional statement",
title_sao_ke_liv: "Livestream statement",
sao_ke_loai_phien: "Session Type",
sao_ke_thoi_gian: "Time",
sao_ke_de_lo: "De/Lo",
sao_ke_tien_cuoc: "Bets",
sao_ke_nhan_thuong: "Get rewarded",
title_bang_cuoc: "BET TABLE",
title_bang_cuoc_tra: "Traditional betting table",
title_bang_cuoc_liv: "Live betting table",
bang_cuoc_loai_phien: "Session Type",
bang_cuoc_thoi_gian: "Time",
bang_cuoc_de_lo: "De/Lo",
bang_cuoc_tien_cuoc: "Bets",
quy_tit_chuyen_quy: "FUND TRANSFER",
quy_tit_rut_quy: "WITHDRAWAL",
quy_lbcq_gold_c: "Gold transfer:",
quy_lbcq_gold_n: "Gold received:",
quy_lbrq_gold_r: "Gold withdrawn:",
quy_lbrq_gold_n: "Gold received:",
quy_tit_ti_le: "Ratio:",
quy_tit_so_du: "Balance:",
quy_btn_chuyen_quy: "OK",
quy_btn_rut_quy: "OK",
quy_btn_choi_ngay: "PLAY NOW"
},
validate: {
vli_1: "Unavailable balance.",
vli_2: "You have not selected a number.",
vli_3: "Please enter the amount.",
vli_4: "Please enter the score.",
vli_5: "Please choose enough XXXX number/lo.",
vli_6: "The next session is currently\n yet open. Please wait!",
vli_7: "Please choose enough 10 number/bet."
},
resChuyenRutQuy: {
res_01: "Invalid amount",
res_02: "The amount to withdraw exceeds the balance",
res_03: "Unavailable balance.",
res_cp_0: "Fund transfer successful.",
res_rq_0: "Successful withdrawal."
}
},
MiniHoaQua: {
big_win: "Big Win",
jackpot: "Jackpot",
line: "Line",
spin: "Spin",
autoSpin: "Auto Spin",
stop: "Stop",
popup: {
detail_title: "BET DETAIL",
guide_title: "GUIDE",
history_title: "PLAY HISTORY",
honor_title: "HONORS",
select_line_title: "SELECT LINE",
session: "SESSION",
time: "TIME",
bet_level: "BET LEVEL",
bet_line: "BET LINE",
bet: "BET",
gain_gift: "GET A REWARDS",
room: "ROOM",
detail: "DETAIL",
account: "ACCOUNT",
status: "STATUS",
win: "WIN",
unselect: "UNSELECT",
even_line: "EVEN LINE",
odd_line: "ODD LINE",
all_line: "ALL",
line_win: "WIN LINE"
},
toast: {
action_too_quick: "You act too quickly.",
not_enough_gold: "The coins is not enough, please top up",
error_try_again: "An error occurred, please try again later",
connecting_server: "Connecting to the server",
you_need_choose_at_least_1_line: "You must select at least 1 line"
}
},
slotnudiepvien: {
unhappen: "Have not happened yet",
music: "Music",
sound: "Sound",
last_win: "Win",
total_bet: "Total bet",
play_trial: "Play Trial",
play_real: "Play Real",
line: "Line",
bet_level: "Bet Level",
popup: {
choose_line_title: "Choose line",
x2_win_title: "X2 bonus",
guide_title: "Rewards table",
jackpot_history_title: "Jackpot history",
trade_history_title: "Transaction history",
even_line: "Even Line",
odd_line: "Odd Line",
all_line: "All Line",
re_line: "Reset",
line_bet: "Bet Line",
line_win: "Win Line",
chose_room_title: "Choose Room",
resident: "Resident",
leader: "Leader",
boss: "Boss",
honor_title: "Honor",
congratulations_account: "Congratulations account",
remain_turn: "Remain Turn",
total_score: "Total Prize",
lucky_box_title: "Lucky Box",
you_win: "You win",
time: "Time",
level: "Level",
jackpot: "Jackpot",
account: "Account",
result: "Result",
session: "Session",
detail: "Detail",
view: "View",
receive_gold: "Receive Gold",
jackpotx2: "Jackpot x2",
minigame_title: "Multi-function suitcase",
extra_turns: "Extra turn"
},
toast: {
function_dont_work_on_trial: "This function does not work in trial mode.",
off_auto_spin_to_leave: "Turn off the AUTO spin to exit the table",
funtion_in_develop: "The function are developing",
not_enough_gold: "The balance is not enough, please top up",
spin_unsuccess: "Spin unsuccess",
unvalid_bet: "Invalid bet",
unvalid_spin: "Invalid spin",
error_try_again: "An error occurred, please try again",
atleast_1_line: "You need to select at least 1 Line"
}
},
shankoemee: {
cannot_out_room: "You are a banker can not make out room",
cancel_leave_room: "Cancel leave",
refresh_room: "Refresh",
skm_card_score: "Score",
skm_nguoi_choi: "Player",
skm_muc_cuoc: "Bet Levels",
draw_card: "Draw card",
do_not_draw_card: "Not draw",
bet: "Bet",
quick_chat_1: "Are you cold yet?",
quick_chat_2: "What age are you?",
quick_chat_3: "Life is not a dream",
quick_chat_4: "Lucky",
quick_chat_5: "Very good",
quick_chat_6: "Unlucky",
quick_chat_7: "But still demanding",
quick_chat_8: "This is dead",
quick_chat_9: "The card is not good",
quick_chat_10: "Have you broken your mouth?",
quick_chat_11: "Lose, friend",
quick_chat_12: "Hurry up",
enter_chat_content: "Enter chat content ...",
do_not: "No",
accept: "Accept",
invite: "INVITE",
double_banker: "Do you want to add double the amount to the bank to continue being a banker?",
play_now: "Playnow",
choose_room: "Choose room",
bank: "Bank",
enter_table_id: "Enter table id ...",
hidden_table_full: "Hidden table full",
table_id: "Table: %{table}#%{game}",
bet_value: "BET",
bet_value_num: "Bet:",
watching: "Watching",
empty_list: "Empty list",
not_enough_money_to_join_the_table: "Not enough money to join the room!",
value_slot: "%{value} slot",
pot_bank: "Pot: %{value}",
banker_turn: "Banker turn: %{turn}",
banker_turn2: "Continue to be the banker round 2",
banker_turn3: "Continue to be the banker round %{turn}",
waiting_new_game: "Waiting for the new game to start",
waiting_banker: "Waiting banker",
change_banker: "Change banker",
banker_win_title: "Banker win",
not_open_yet: "Function not open",
can_not_find_table_selected: "The selected room could not be found",
enter_the_table_you_want_to_search: "Please enter the table you want to search for",
can_not_create_table: "This game does not allow creating tables!",
no_valid_table_found: "No valid table found",
invite_user: "%{name} invites you to play, do you want to join?",
error_not_defined: "Error %{id}, undefined.",
error_check_infomation: "Error checking information!",
error_can_not_find_table_try_again: "The appropriate room could not be found. Please try again later!",
error_not_enough_money_to_join_table: "You don't have enough money to enter this room!",
error_join_room_too_fast: "Join the room too fast",
error_server_maintenance: "Maintenance system!",
error_can_not_find_table: "Playroom not found!",
error_password_table_not_correct: "The game room password is incorrect!",
error_room_full: "The playroom is full!",
error_has_been_kick: "You are not allowed to enter the table by the owner of the room!",
register_leave_table_success: "You have registered to leave the room!",
place_bet: "Place bets",
error_bet_already: "Bet already",
error_not_enough_money: "Not enough money",
error_bet_not_correct: "Incorrect bet value",
not_enough_gold_please_deposit: "The balance is not enough, please top up",
cancel_register_leave_table: "You unsubscribed to leave the room",
open_card: "Open card",
id: "ID",
table_name: "Name:",
table_require: "Require",
table_min_bet: "Min bet",
table_num_user: "User",
leave_room_title: "Leave",
leave_room_contect: "Are you sure to leave the table?",
on_sound: "On",
off_sound: "Off",
send_chat: "Send"
},
boogyi: {
cannot_out_room: "You are a banker can not make out room",
cancel_leave_room: "Cancel leave",
boo_tong_diem: "Total Score",
refresh_room: "Refresh",
skm_card_score: "Score",
skm_nguoi_choi: "Player",
skm_muc_cuoc: "Bet Levels",
draw_card: "Draw card",
do_not_draw_card: "Not draw",
bet: "Bet",
quick_chat_1: "Are you cold yet?",
quick_chat_2: "What age are you?",
quick_chat_3: "Life is not a dream",
quick_chat_4: "Lucky",
quick_chat_5: "Very good",
quick_chat_6: "Unlucky",
quick_chat_7: "But still demanding",
quick_chat_8: "This is dead",
quick_chat_9: "The card is not good",
quick_chat_10: "Have you broken your mouth?",
quick_chat_11: "Lose, friend",
quick_chat_12: "Hurry up",
enter_chat_content: "Enter chat content ...",
do_not: "No",
accept: "Accept",
invite: "INVITE",
double_banker: "Do you want to add double the amount to the bank to continue being a banker?",
play_now: "Playnow",
choose_room: "Choose room",
bank: "Bank",
enter_table_id: "Enter table id ...",
hidden_table_full: "Hidden table full",
table_id: "Table: %{table}#%{game}",
bet_value: "BET",
bet_value_num: "Bet:",
watching: "Watching",
empty_list: "Empty list",
not_enough_money_to_join_the_table: "Not enough money to join the room!",
value_slot: "%{value} slot",
pot_bank: "Pot: %{value}",
banker_turn: "Banker turn: %{turn}",
banker_turn2: "Continue to be the banker round 2",
banker_turn3: "Continue to be the banker round %{turn}",
waiting_new_game: "Waiting for the new game to start",
waiting_banker: "Waiting banker",
change_banker: "Change banker",
banker_win_title: "Banker win",
not_open_yet: "Function not open",
can_not_find_table_selected: "The selected room could not be found",
enter_the_table_you_want_to_search: "Please enter the table you want to search for",
can_not_create_table: "This game does not allow creating tables!",
no_valid_table_found: "No valid table found",
invite_user: "%{name} invites you to play, do you want to join?",
error_not_defined: "Error %{id}, undefined.",
error_check_infomation: "Error checking information!",
error_can_not_find_table_try_again: "The appropriate room could not be found. Please try again later!",
error_not_enough_money_to_join_table: "You don't have enough money to enter this room!",
error_join_room_too_fast: "Join the room too fast",
error_server_maintenance: "Maintenance system!",
error_can_not_find_table: "Playroom not found!",
error_password_table_not_correct: "The game room password is incorrect!",
error_room_full: "The playroom is full!",
error_has_been_kick: "You are not allowed to enter the table by the owner of the room!",
register_leave_table_success: "You have registered to leave the room!",
place_bet: "Place bets",
error_bet_already: "Bet already",
error_not_enough_money: "Not enough money",
error_bet_not_correct: "Incorrect bet value",
not_enough_gold_please_deposit: "The balance is not enough, please top up",
cancel_register_leave_table: "You unsubscribed to leave the room",
open_card: "Open card",
id: "ID",
table_name: "Name",
table_require: "Require",
table_min_bet: "Min bet",
table_num_user: "User",
leave_room_title: "Leave",
leave_room_contect: "Are you sure to leave the table?",
on_sound: "On",
off_sound: "Off",
send_chat: "Send",
test: "test",
zero_slot: "Leaks",
confirm: "Xác nhận",
not_bid: "Không bid",
place_bid: "Mời đấu giá",
bid_value: "bid x%{value}",
bid_error_1: "Mức bid không đúng",
bid_error_2: "Không đủ tiền",
start_compare: "So bài"
},
shweshan: {
cannot_out_room: "You are a banker can not make out room",
cancel_leave_room: "Cancel leave",
shw_resort: "Rearrange",
game_name: "Shweshan",
zero_slot: "Leaks",
arranage_done: "Arrange done",
shweshan_nguoi_choi: "Player",
shweshan_muc_cuoc: "Bet Levels",
watching: "Watching",
do_not: "No",
accept: "Accept",
invite: "INVITE",
refresh_room: "REFRESH",
empty_list: "Empty list",
play_now: "Play now",
confirm: "Confirm",
start_compare: "Compare",
skm_card_score: "Score",
skm_nguoi_choi: "Player",
skm_muc_cuoc: "Bet Levels",
draw_card: "Draw card",
do_not_draw_card: "Not draw",
bet: "Bet",
quick_chat_1: "Are you cold yet?",
quick_chat_2: "What age are you?",
quick_chat_3: "Life is not a dream",
quick_chat_4: "Lucky",
quick_chat_5: "Very good",
quick_chat_6: "Unlucky",
quick_chat_7: "But still demanding",
quick_chat_8: "This is dead",
quick_chat_9: "The card is not good",
quick_chat_10: "Have you broken your mouth?",
quick_chat_11: "Lose, friend",
quick_chat_12: "Hurry up",
enter_chat_content: "Enter chat content ...",
double_banker: "Do you want to add double the amount to the bank to continue being a banker?",
choose_room: "Choose room",
bank: "Bank",
enter_table_id: "Enter table id ...",
hidden_table_full: "Hidden table full",
table_id: "Table: %{table}#%{game}",
bet_value: "BET",
bet_value_num: "Bet:",
not_enough_money_to_join_the_table: "Not enough money to join the room!",
value_slot: "slot:%{value}",
pot_bank: "Pot: %{value}",
banker_turn: "Banker turn: %{turn}",
banker_turn2: "Continue to be the banker round 2",
banker_turn3: "Continue to be the banker round %{turn}",
waiting_new_game: "Waiting for the new game to start",
waiting_banker: "Waiting banker",
change_banker: "Change banker",
banker_win_title: "Banker win",
not_open_yet: "Function not open",
can_not_find_table_selected: "The selected room could not be found",
enter_the_table_you_want_to_search: "Please enter the table you want to search for",
can_not_create_table: "This game does not allow creating tables!",
no_valid_table_found: "No valid table found",
invite_user: "%{name} invites you to play, do you want to join?",
error_not_defined: "Error %{id}, undefined.",
error_check_infomation: "Error checking information!",
error_can_not_find_table_try_again: "The appropriate room could not be found. Please try again later!",
error_not_enough_money_to_join_table: "You don't have enough money to enter this room!",
error_join_room_too_fast: "Join the room too fast",
error_server_maintenance: "Maintenance system!",
error_can_not_find_table: "Playroom not found!",
error_password_table_not_correct: "The game room password is incorrect!",
error_room_full: "The playroom is full!",
error_has_been_kick: "You are not allowed to enter the table by the owner of the room!",
register_leave_table_success: "You have registered to leave the room!",
place_bet: "Place bets",
error_bet_already: "Bet already",
error_not_enough_money: "Not enough money",
error_bet_not_correct: "Incorrect bet value",
not_enough_gold_please_deposit: "The balance is not enough, please top up",
cancel_register_leave_table: "You unsubscribed to leave the room",
open_card: "Open card",
id: "ID",
table_name: "Name",
table_require: "Require",
table_min_bet: "Min bet",
table_num_user: "User",
leave_room_title: "Leave",
leave_room_contect: "Are you sure to leave the table?",
on_sound: "On",
off_sound: "Off",
send_chat: "Send"
}
};
cc._RF.pop();
}, {} ],
mm: [ function(e, t) {
"use strict";
cc._RF.push(t, "2d3b6Srw0hF4JkZD8oWdhD/", "mm");
var n, o;
t.exports = {
alert: {
title_notification: "အသိပေးချက်",
ok: "လက်ခံပါတယ်။",
yes: "ဟုတ်ကဲ့",
no: "မရှိ",
loaded: "စောင့်ပါ။",
close: "မလုပ်တော့",
refuse: "ငြင်းပါ။",
veritify: "စိစစ်ပါ။",
fail: "မအောင်မြင်",
discard: "ပြန်ရွေးပါ။",
confirm_logout: "ထွက်လိုသည်မှာ သေချာပါသလား။",
you_need_veritify_pin: "PIN အတည်ပြုခြင်း လိုအပ်ပါသည်။",
you_need_veritify_phone_number: "သင့်ဖုန်းနံပါတ်ကို အတည်ပြုရန် လိုအပ်ပါသည်။",
you_need_veritify_loaded_card: "ငွေဖြည့်ရန် လိုအပ်ပါသည်။",
coming_soon: "Function မကြာမီလာမည်။",
coming_soon_game: "ဂိမ်းမကြာမီလာမည်။",
game_maintian: "ပြုပြင်ထိန်းသိမ်းမှုအောက်တွင် လုပ်ဆောင်နိုင်သော လုပ်ဆောင်ချက်။",
fucntion_maintian: "ပြုပြင်ထိန်းသိမ်းမှုအောက်တွင် လုပ်ဆောင်နိုင်သော လုပ်ဆောင်ချက်။",
fucntion_use_lobby: "လုပ်ဆောင်ချက်ကို ဧည့်ခန်းပြင်ပတွင်သာ အသုံးပြုနိုင်သည်။",
action_fast: "မင်းက အရမ်းမြန်လွန်းတယ်။\nခဏနေရင် ထပ်စမ်းကြည့်ပါ။",
error: {
not_enough_gold: "အကြွေမလောက်ဘူး။XU",
wrong_captcha: "captcha ကုဒ် မှားနေသည်။",
wrong_syntax: "Syntax မှားနေပါသည်။ ",
wrong_pin: "ပင်နံပါတ် မှားယွင်းနေသည် သို့မဟုတ် ပင်နံပါတ်ကို စာရင်းမသွင်းရသေးပါ။",
wrong_pin_or_not_reg_pin: "ပင်နံပါတ် မှားနေသည် သို့မဟုတ် မှတ်ပုံတင်ထားသော ပင်နံပါတ်ကုဒ် မရှိပါ။",
account_undefined: "Player မရှိပါ။",
connector: {
fail: "အင်တာနက်ချိတ်ဆက်မှုမရှိပါ။ သင့်ချိတ်ဆက်မှုကို ထပ်မံစစ်ဆေးပါ။",
a_2: "အင်တာနက်ချိတ်ဆက်မှု လိုအပ်ပါတယ်!!!",
a_3: "စနစ်သို့ချိတ်ဆက်ခြင်း။",
a_4: "သင့်တွင် လက်ဆောင်မရှိသေးပါ။ . . လက်ဆောင်များရယူရန် Event တွင် ပါဝင်လိုက်ပါ။",
a_5: "ကျေးဇူးပြု၍ သင်၏ PIN ကိုထည့်ပါ။",
a_6: "ကျေးဇူးပြု၍ Captcha ထည့်ပါ။",
expired: "အကောင့်ဝင်ချိန် သက်တမ်းကုန်သွားပါပြီ၊ ကျေးဇူးပြု၍ ထပ်မံဝင်ရောက်ပါ။",
ban: "ဤအကောင့်ကို စနစ်ဖြင့် လော့ခ်ချထားသည်။",
a_9: "စနစ်က ပြုပြင်ထိန်းသိမ်းမှုပါ။ ကျေးဇူးပြု၍ နောက်မှပြန်လာပါ။",
some_where: "အကောင့်သည် အခြားနေရာများတွင် ဝင်ရောက်ပြီးဖြစ်သည်။"
},
services: {
a_10: "အကောင့် သို့မဟုတ် စကားဝှက် မမှန်ကန်ပါ။",
a_11: "အကောင့်အသုံးပြုပြီးဖြစ်သည်။",
a_12: "အကောင့်မရှိပါ။",
a_13: "စကားဝှက်မှား",
a_14: "သင်သည် အကောင့်များစွာကို စာရင်းသွင်းထားပြီးဖြစ်သည်။",
a_15: "အကောင့်တစ်ခုဆက်လက်ဖန်တီးရန် မိနစ်အနည်းငယ်စောင့်ပါ။",
a_16: "သင်သည် အကောင့်များစွာကို ဖန်တီးထားသည်။ ကျေးဇူးပြုပြီး မနက်ဖြန်ပြန်လာပါ။"
},
defined: {
fail: "အမည်မသိ အမှားတစ်ခု",
param_invalid: "သတ်မှတ်ချက် မမှန်ကန်ပါ။",
maintain_system: "စနစ်က ပြုပြင်ထိန်းသိမ်းမှုပါ။",
session_key_invalid: "စက်ရှင်ကီး မရှိပါ။",
session_expired: "စက်ရှင်ကီး သက်တမ်းကုန်သွားပါပြီ။",
session_room_not_exist: "ကစားခန်း မရှိပါ။",
session_not_enough_min_buy_in: "အနည်းဆုံး လောင်းကြေး မလုံလောက်ပါ။",
out_buy_in_range: "အလောင်းအစားထဲက",
game_structure_invalid: "ဂိမ်းဖွဲ့စည်းပုံ မရှိပါ။",
already_in_game: "သင်သည် ဂိမ်းတွင် ပါဝင်နေပြီဖြစ်သည်။",
entering_game: "ဂိမ်းထဲသို့ဝင်",
gift_code_invalid: "လက်ဆောင်ကုဒ်မရှိပါ။",
gift_code_is_used: "လက်ဆောင်ကုဒ်ကို အသုံးပြုပြီးဖြစ်သည်။",
gift_code_is_expired: "လက်ဆောင်ကုဒ် သက်တမ်းကုန်သွားပါပြီ။",
login_banned_ip: "သင်၏ IP ကို ​​လော့ခ်ချထားသည်။ . အသေးစိတ်အချက်အလက်များအတွက် ဖောက်သည်ဝန်ဆောင်မှုကို ဆက်သွယ်ပါ။",
login_banned_user: "သင့်အကောင့်ကို လော့ခ်ချထားသည်။ . အသေးစိတ်အချက်အလက်များအတွက် ဖောက်သည်ဝန်ဆောင်မှုကို ဆက်သွယ်ပါ။",
player_action_invalid: "မမှန်ကန်သောလုပ်ဆောင်ချက်",
player_action_fail: "လုပ်ဆောင်ချက်အမှား",
not_enough_gold: "COINS မလုံလောက်ပါ။XU",
default: "အမှား",
not_bet_too_long: "အချိန်အကြာကြီး အပြန်အလှန်မတုံ့ပြန်သည့်အတွက် သင့်အား စနစ်မှ ဖိတ်ခေါ်ထားသည်။"
}
}
},
LuckyWheel: {
system_error: "စနစ်အမှား",
received_code: "အကောင့်သည် လုံခြုံသောလက်ဆောင်ကုဒ်ကို လက်ခံရရှိထားသည်။",
system_error_cache: "စနစ်အမှား။ ကက်ရှ်လုပ်ခြင်း အမှားအယွင်း။",
system_error_database: "စနစ်အမှား။ ဒေတာဘေ့စ် အမှားကို သိမ်းဆည်းပါ။",
success: "ဂုဏ်ယူပါသည်၊ သင်သည် %{XXX} GOLD လက်ဆောင်ကို ယခုလေးတင် ရရှိသွားပါပြီ။ သင်၏ဆုလာဘ်ကိုရယူရန် ဖောက်သည်ဝန်ဆောင်မှုကို ဆက်သွယ်ပါ။",
contact: "လက်ဆောင်ရရှိရန် ဖောက်သည်ဝန်ဆောင်မှုကို ဆက်သွယ်ပါ။"
},
loading: {
check_server: "Checking server information",
update: "Update",
update_success: "Update successful",
update_fail: "Update failed",
please_wait_update_version: "Please update to the latest version",
check_version: "Checking version",
progress_loading_new: "Updating the new version.",
not_loading_manifest: "Could not load manifest",
latest_current_version: "Latest current version",
load: "Loading"
},
lobby: {
lobby_notify_no_talk: "လောလောဆယ် Live မလွှင့်သေးပါဘူး။\n ကျေးဇူးပြုပြီး နောက်မှပြန်လာပါ။",
not_have_account: "သင့်တွင်အကောင့်တစ်ခုမရှိပါ။",
profile: "ကိုယ်ရေးအကျဉ်း",
join_time: "ပါဝင်သည့်ရက်စွဲ",
birth_date: "မွေးနေ့",
ip_address: "IP လိပ်စာ",
invite_code: "ရည်ညွှန်းကုဒ်",
change_password: "စကားဝှက်ကိုပြောင်းရန်",
change_avatar: "ဇာတ်ကောင်ပြောင်းရန်",
back: "ကျော",
change: "ပြောင်းလဲပါ။",
current_password: "လက်ရှိစကားဝှက်",
new_password: "စကားဝှက်အသစ်",
confirm_new_password: "သင့်စကားဝှက်အသစ်ကို ပြန်လည်ထည့်သွင်းပါ။",
update: "မွမ်းမံ",
deposit_gold: "ရွှေငွေဖြည့်ပါ။",
deposit_history: "ငွေဖြည့်မှတ်တမ်း",
sell_gold: "ရွှေရောင်း",
sell_history: "သမိုင်းရောင်း",
current_credit: "လက်ကျန်ငွေ",
agency: "အေဂျင်စီ",
deposit_money: "သိုက်",
receive_gold: "ရွှေလက်ခံသည်။",
agency_note: "မှတ်ချက်- မလွှဲပြောင်းမီ အေးဂျင့်၏ အချက်အလက်ကို သေချာစစ်ဆေးပါ၊ မပံ့ပိုးသော မှားယွင်းသောထုတ်ဝေသူထံ လွှဲပြောင်းပါ။ ၅ မိနစ်ကြာပြီးနောက် ရွှေအဆက်အသွယ် မရခဲ့ပါ။",
or_call_to: "ဆက်သွယ်ရန်",
note: "မှတ်စုများ",
minimum_trade: "အနိမ့်ဆုံးငွေပေးငွေယူ",
exchange_rate: "ကူးပြောင်းနှုန်း",
account_number: "အကောင့်နံပါတ်",
account_name: "အကောင့်နာမည်",
area: "ဧရိယာ",
confirm: "အတည်ပြုပါ။",
deposit_note: "ငွေသွင်းအမှာစာကို သင် အောင်မြင်စွာ ဖန်တီးပြီးပါပြီ။ ထို့နောက် ငွေသွင်းခြင်းလုပ်ငန်းစဉ်ကို အပြီးသတ်ရန်။ ငွေလွှဲပြေစာပေးပို့ရန် ဖောက်သည်ဝန်ဆောင်မှုကို ဆက်သွယ်ပါ။",
branch: "ကိုင်း",
transfer_code_short: "ငွေလွှဲကုတ်",
num_transfer_money: "လွှဲပြောင်းပမာဏ",
account_owner_name: "ကိုင်ဆောင်သူအမည်",
status: "အဆင့်အတန်း",
korea: "ကိုရီးယား",
japan: "ဂျပန်",
taiwan: "ထိုင်ဝမ်",
lao: "လာအို",
campuchia: "ကမ္ဘောဒီးယား",
no: "ဂဏန်းအလို့ငှာ",
nickname: "အမည်ပြောင်",
phone_number: "ဖုန်းနံပါတ်",
contact: "ဆက်သွယ်ပါ။",
action: "အက်ရှင်",
buy: "ဝယ်ပါ။",
sell: "ရောင်း",
attendance: "ကျောင်းခေါ်ချိန်",
day: "နေ့",
day1: "နေ့ ၁",
day2: "နေ့ ၂",
day3: "နေ့ ၃",
day4: "နေ့ 4",
day5: "နေ့ ၅",
day6: "၆ ရက်",
day7: "၇ ရက်",
attendance_note: "စနေ၊",
open_egg: "ကြက်ဥကိုဖွင့်ပါ။",
gold_egg: "ရွှေဥ",
white_egg: "ကြက်ဥအဖြူ",
game_download: "ဂိမ်းဒေါင်းလုဒ်လုပ်ပါ။",
download: "ဒေါင်းလုဒ်လုပ်ပါ။",
list_giftcode: "လက်ဆောင်ကုဒ်စာရင်း",
received: "ရရှိခဲ့သည်။",
title_events: "အဲ့ဒါနဲ့",
event: "အဲ့ဒါနဲ့",
event_top_bet: "ထိပ်တန်းလောင်းကစားပွဲ",
event_attendace: "ပွဲတက်ရောက်သူ",
event_receive_bet: "လောင်းကစားပွဲကို ရယူပါ။",
event_find_million: "သန်းကြွယ်သူဌေးဖစ်ရှာပါ။",
event_sicbo: "Sicbo ပွဲ",
event_jackpot_sicbo: "Sicbo Jackpot",
trade_history: "ငွေလွှဲမှတ်တမ်း",
play_gold: "ရွှေကစားပါ။",
play_chip: "ဒင်္ဂါးပြားများကို ကစားပါ။",
deposit_chip: "ငွေဖြည့်ဒင်္ဂါးများ",
expense_gold: "ရွှေဖြုန်း",
trade_code: "ငွေလွှဲကုတ်",
time: "အချိန်",
service: "ဝန်ဆောင်မှု",
incurred: "ကြုံမည်။",
credit: "လက်ကျန်",
description: "ဖော်ပြချက်",
detail: "အသေးစိတ်",
view: "အမြင်",
account: "အကောင့်",
account_note_full_info: "အထောက်အပံ့ရဖို့။ ကျေးဇူးပြု၍ အောက်ပါအချက်အလက်များကိုဖြည့်ပါ။",
account_note_username: "ဇာတ်ကောင်အမည်သည် အချက်အလက် လိုအပ်သည်။",
type_login_name: "အသုံးပြုသူအမည်ထည့်ပါ။",
authentication_code: "အတည်ပြုရန်ကုတ်",
send: "ပို့ပါ။",
forgot_password: "စကားဝှက်ကိုမေ့နေပါသလား",
telegram_authentication_code: "ကြေးနန်းအထောက်အထားစိစစ်ခြင်းကုဒ်...",
username: "ဇာတ်ကောင်နာမည်",
account_note_username1: "စာလုံး 6 လုံးမှ 16 လုံးကြားရှိ ဇာတ်ကောင်အမည်၊ ထိလွယ်ရှလွယ် စာလုံးများမရှိ၊ အထူးဇာတ်ကောင်များနှင့် နေရာလွတ်များမရှိပါ။",
create_new: "အသစ်ဖန်တီးပါ။",
login_name: "အသုံးပြုသူအမည်",
password: "စကားဝှက်",
save_password: "စကားဝှက်ကိုသိမ်းဆည်းပါ။",
login: "လော့ဂ်အင်",
register: "မှတ်ပုံတင်ပါ။",
confirm_password: "စကားဝှက်အတည်ပြုခြင်း",
invite_code_note: "ရည်ညွှန်းကုဒ် (ချန်လှပ်ထားနိုင်သည်)",
captcha: "အတည်ပြုကုဒ်များ",
sender: "ပေးပို့သူ",
content: "အကြောင်းအရာ",
notify: "အကြောင်းကြားပါ။",
agency_account: "အေဂျင်စီအကောင့်",
notify_note_cheat: "လိမ်လည်မှုများကို ရှောင်ရှားရန် အေးဂျင့်များနှင့်သာ ဆက်ဆံပါ။",
you_sure_send: "သေချာပေါက် လွှဲပြောင်းချင်ပါသည်။",
amount_money: "ငွေပမာဏ",
reason: "အကြောင်းပြချက်",
reject: "မလုပ်တော့",
accept: "လက်ခံပါတယ်။",
buy_gold: "ရွှေဝယ်ပါ။",
gold: "ရွှေ",
type_amount_money: "ငွေဖြည့်သွင်းသည့်ပမာဏကို ထည့်ပါ...",
receive_money: "ရရှိသည့်ပမာဏ",
received_money: "လက်ခံရရှိသည့်ပမာဏ",
num_receive_gold: "ရွှေလက်ခံသည်။",
other_agency: "အခြားအေးဂျင့်များ",
buy_gold_rule: "ရွှေဝယ်ရန်စည်းကမ်းများ",
minimum_trade_value: "အနိမ့်ဆုံး ငွေပေးငွေယူတန်ဖိုး",
trade_fee: "ငွေလွှဲကြေး",
buy_gold_rule_note: "",
buy_gold_rule_note_check_nickname: "ငွေပေးငွေယူမပြုလုပ်မီ လက်ခံရရှိသော အမည်ဝှက်ကို နှစ်ဆစစ်ဆေးပါ။",
type_nickname: "အမည်ပြောင်ထည့်ပါ။",
type_nickname_again: "အမည်ပြောင်ကို ပြန်ထည့်ပါ။",
type_amount_sell_money: "လွှဲပြောင်းရန် ပမာဏကို ထည့်သွင်းပါ။",
type_num_gold: "ရွှေနံပါတ်ထည့်ပါ။",
transfer_reason: "ပြောင်းရွှေ့ရခြင်း အကြောင်းအရင်း",
transfer_note_nickname: 'ရရှိထားသောအမည်ပြောင်သည် လော့ဂ်အင်အကောင့်အမည်မဟုတ်ဘဲ "ဂိမ်းတွင်းပြသမှုအမည်" ဇာတ်ကောင်အမည်ဖြစ်သည်။ ',
transfer_note_wrong_transfer: "*မှားယွင်းသော အကောင့်အမည်သို့ လွှဲပြောင်းလိုက်သော ငွေလွှဲမှုများကို စနစ်က တရားဝင်သော လွှဲပြောင်းမှုများအဖြစ် အလိုအလျောက် သတ်မှတ်ပြီး ပြန်အမ်း၍မရပါ။",
continue: "ဆက်လက်",
transfer_rule: "အပြောင်းအရွှေ့စည်းမျဉ်းများ",
transfer: "အပြောင်းအရွှေ့",
choose_nation: "နိုင်ငံကိုရွေးချယ်ပါ",
transfer_withdraw: "လွှဲပြောင်း/ငွေထုတ်ခြင်း။",
num_transfer_gold: "ရွှေနံပါတ်ပြောင်းပါ။",
current_money: "လက်ရှိငွေ",
transfer_fund: "ရန်ပုံငွေလွှဲပြောင်း",
play_now: "ယခုကစားပါ။",
withdraw_fund: "ရန်ပုံငွေထုတ်ယူ",
withdraw_money: "ထုတ်ယူရမည့်ပမာဏ",
notify_common_noti: " ထုတ်ဝေသူအား ဝမ်းမြောက်စွာ ကြေငြာအပ်ပါသည်။",
notify_common_admin: "BOSS79 စီမံခန့်ခွဲမှုဘုတ်အဖွဲ့မှ လေးစားစွာဖြင့် အသိပေးကြေငြာအပ်ပါသည်။",
notify_common_content: 'အေးဂျင့်များနှင့် ဖောက်သည်များ၏ လိုအပ်ချက်များကို ဖြည့်ဆည်းရန်၊ ကျွန်ုပ်တို့သည် စျေးကွက်နှင့် နှိုင်းယှဉ်ပါက အလွန်ဆွဲဆောင်မှုရှိသော ပေးချေမှုအချိုးဖြင့် "မြောက်၊ အလယ်ပိုင်း၊ တောင်" ဂိမ်းမျိုးစုံဖြင့် ဂိမ်းအမျိုးမျိုးဖြင့် နောက်ထပ် portals ကို တရားဝင်ဖွင့်ထားသည်-.......... ကာစီနိုဂိမ်းများ၊ အားကစား လောင်းကစားများ၊ Baccarat သည် အလွန်မြင့်မားသော ပြန်ပေးနှုန်းများဖြင့် 1:1 အပ်ငွေနှင့် ငွေထုတ်အချိုးဖြင့် အလွန်ဆွဲဆောင်မှုရှိသော အတွေ့အကြုံကို ပေးဆောင်သည်။',
term_of_use: "သတ်မှတ်ချက်များ",
cmtnd: "ID နံပါတ်များ",
active: "လှုပ်လှုပ်ရှားရှား",
email: "အီးမေးလ်",
phone_number_long: "ဖုန်းနံပါတ်",
profile_note_scuriry: "လျှို့ဝှက်အချက်အလက်များအကြောင်း မှတ်သားထားပါ။",
profile_note_update: "အကျိုးခံစားခွင့်များသေချာစေရန် အချက်အလက်ကို အပ်ဒိတ်လုပ်ပါ။",
music: "ဂီတ",
feedBack: "တုံ့ပြန်ချက်",
shop: "စျေးဆိုင်",
gift_code: "GIFTCODE",
type_gift_code: "GiftCode ရိုက်ထည့်ပါ။",
receive: "လက်ခံတယ်။",
mailbox: "စာတိုက်ပုံး",
setting: "ဆက်တင်",
get_otp: "OTP ရယူပါ။",
title_sold_gold: "ရွှေရောင်း",
title_tranfers_gold: "အပြောင်းအရွှေ့",
title_language: "ဘာသာစကား",
title_safe: "မီးခံသေတ္တာ",
title_shop: "စျေးဆိုင်",
title_history: "သမိုင်း",
title_naprut: "ငွေဖြည့် / ငွေထုတ်ပါ။",
title_support: "အထောက်အပံ့",
title_security: "လုံခြုံရေး",
title_mail: "အီးမေးလ်",
title_fanpage: "Fanpage",
title_giftcode: "Gift Code",
title_group: "Group",
logout: "ထွက်လိုက်ပါ။",
jackpot: {
jungle_spirit: "Jungle Spirit",
captians: "Captian's",
agent_royale: "Agent Royale",
sexy_girl: "Dance Girl",
avangers: "Avangers",
fortune: "Fortune"
},
tab_game: {
all_game: "All Game",
mini_game: "Mini Game",
betting: "Betting",
live_game: "Live Game",
slot: "Slot Game",
casino: "Casino"
},
warning: {
error_try_gain: "အမှားအယွင်းတစ်ခု ဖြစ်ပွားခဲ့သည်။ နောက်မှ ထပ်စမ်းကြည့်ပါ။!",
minimum_transfer_500k: "အနိမ့်ဆုံးပမာဏမှာ ရွှေ 500,000 ဖြစ်သည်။!",
not_enough_gold: "လက်ကျန်ငွေ မရရှိနိုင်ပါ။",
maximum_bet_10M: "အားကစားလောင်းကစားအကောင့် 10M ထက်မပိုရပါ။",
transfer_success: "ဂုဏ်ယူပါသည်။ သင် အောင်မြင်စွာ ရုပ်သိမ်းလိုက်ပါပြီ။ ",
error_in_processing: "လုပ်ဆောင်ရာတွင် အမှားအယွင်းရှိခဲ့သည်။",
you_need_type_withdraw_money: "ငွေထုတ်သည့်ပမာဏကို ထည့်သွင်းရန် လိုအပ်ပါသည်။!",
wrong_money: "ပမာဏ မမှန်ပါ။",
cant_get_credit_try_again: "လက်ကျန်ကို မရနိုင်ပါ။ ထပ်စမ်းကြည့်ပါ။",
withdraw_success: "ဂုဏ်ယူပါသည်။ သင် အောင်မြင်စွာ ရုပ်သိမ်းလိုက်ပါပြီ။",
delete_mail_success: "မေးလ်ကို အောင်မြင်စွာ ဖျက်လိုက်ပါ။",
you_sure_delete_mail: "သေချာပေါက် မေးလ်ကို ဖျက်ချင်နေပီ",
error: "အမှားအယွင်းတစ်ခု ဖြစ်ပွားခဲ့သည်။",
developing_feature: "အင်္ဂါရပ်သည် ဖွံ့ဖြိုးဆဲဖြစ်သည်။!",
wrong_giftcode_check_again: "လက်ဆောင်ကုဒ် မမှန်ပါ။ ထပ်မံစစ်ဆေးပါ။!",
gift_code_is_used: "လက်ဆောင်ကုဒ်ကို အသုံးပြုပြီးပါပြီ။!",
congluratulation: "ဂုဏ်ယူပါသည်။ သင်လက်ခံရရှိပြီးပါပြီ။",
invalid_giftcode: "ထည့်သွင်းထားသော လက်ဆောင်ကုဒ်သည် မမှန်ကန်ပါ။",
over_exp_giftcode: "လက်ဆောင်ကုဒ် သက်တမ်းကုန်သွားပါပြီ။!",
unsecury_account: "စာရင်းမသွင်းရသေးသော အကောင့်လုံခြုံရေး။!",
giftcode_cant_use_phone_number: "လက်ဆောင်ကုဒ်သည် ဗီယက်နမ်ဖုန်းနံပါတ်များဖြင့် လုံခြုံသောအကောင့်များနှင့် သက်ဆိုင်ခြင်းမရှိပါ။",
giftcode_cant_use_this_account: "လက်ဆောင်ကုဒ်ကို ဤအကောင့်အတွက် အသုံးမပြုနိုင်ပါ။!",
please_type_num_money: "ကျေးဇူးပြု၍ ပမာဏကို ထည့်ပါ။!",
minimum_trade: "အနိမ့်ဆုံးငွေပေးငွေယူ",
gold_up: "ရွှေ",
gold_n: "ရွှေ",
not_enough_gold1: "အကောင့်လက်ကျန် မလုံလောက်ပါ။",
username_must_same: "အကောင့်အမည်သည် တူညီရပါမည်။!!",
please_type_full_info: "အချက်အလက်အပြည့်အစုံကို ထည့်သွင်းပါ။ (ကိုယ်စားလှယ်အမည်၊ အမည်ပြောင်၊ ပမာဏ)",
un_phone_number_verify_account: "အထောက်အထားမခိုင်လုံသောအကောင့် လုံခြုံသောဖုန်းနံပါတ်",
cant_transfer_yourselft: "သင်ကိုယ်တိုင် လွှဲပြောင်းလို့ မရပါဘူး။",
change_avatar_success: "ကိုယ်ပွားကို အောင်မြင်စွာပြောင်းလဲပါ။!!",
please_type_full_info1: "အချက်အလက်အားလုံးကို ဖြည့်ပါ။!",
password_confirm_password_must_same: "စကားဝှက်အသစ်နှင့် အသစ်ပြန်ထည့်သည့် စကားဝှက်သည် အတူတူဖြစ်ရပါမည်။!",
old_password_wrong: "စကားဝှက်ဟောင်း မမှန်ပါ။",
you_sure_withdraw: "VND ထုတ်ယူလိုသည်မှာ သေချာသည်။ ရွှေနံပါတ် ",
unexist_account: "အကောင့် မရှိပါ။!",
untype_username: "အသုံးပြုသူအမည်ကို သင်မထည့်ရသေးပါ။",
untype_password: "စကားဝှက်မထည့်ရသေးပါ။",
server_lost_connect: "ဆာဗာချိတ်ဆက်မှု ပြတ်တောက်သွားသည်။",
account_logining_please_logout: "သင့်အကောင့်ကို အခြားနေရာတွင် ဝင်ရောက်နေပါသည်။ အကောင့်မဝင်ခင် အကောင့်ထွက်ပါ။.",
account_banning: "အကောင့်ကို ပိတ်ပင်ထားသည်။.",
invalid_authentication_code: "အထောက်အထားစိစစ်ခြင်းကုဒ် မမှန်ပါ။.",
overtime_authentication: "အတည်ပြုကုဒ် သက်တမ်းကုန်သွားပါပြီ။.",
server_maintain_go_later: "စနစ်က ပြုပြင်ထိန်းသိမ်းမှုပါ။ ကျေးဇူးပြုပြီး နောက်မှပြန်လာပါ။",
password_wrong: "စကားဝှက်မှား",
login_banned: "ဝင်ရောက်ရန် တားမြစ်ထားသည်။",
unexist_user: "အသုံးပြုသူမရှိပါ။",
you_not_create_username: "အကောင့်အတွက် နာမည်ပြောင်တစ်ခု မဖန်တီးရသေးပါ။",
username_warning: "အသုံးပြုသူအမည်သည် အက္ခရာ 6 လုံးမှ 18 လုံးအထိရှိရမည်ဖြစ်ပြီး အသံထွက်မပါဘဲ ချက်ချင်းရေးပါ၊ အထူးစာလုံးများမရှိပါ။",
password_same_warning: "ပြန်လည်ထည့်သွင်းထားသော စကားဝှက်သည် ထည့်သွင်းထားသော စကားဝှက်နှင့် မကိုက်ညီပါ။",
verify_code_wrong: "ကုဒ်မမှန်ပါ။",
internet_unstable: "ကွန်ရက်ချိတ်ဆက်မှု မတည်ငြိမ်ပါ။ wifi/3g ချိတ်ဆက်မှုကို စစ်ဆေးပါ။",
invalid_username: "အသုံးပြုသူအမည် မမှန်ကန်ပါ။",
username_exist: "အသုံးပြုသူအမည် ရှိနှင့်ပြီးဖြစ်သည်။",
invite_code_unexist: "ရည်ညွှန်းကုဒ်မရှိပါ။",
invite_code_wrong_type: "မမှန်ကန်သော ရည်ညွှန်းကုဒ် (ဥပမာ-K1234567)",
captcha_wrong: "captcha ကုဒ် မမှန်ပါ။",
captcha_error: "Captcha အမှား",
nickname_invalid: "မမှန်ကန်သော အမည်ပြောင်",
nickname_exist: "နာမည်ပြောင် ရှိပြီးသားပါ။",
nickname_not_same_username: "အမည်ပြောင်သည် အသုံးပြုသူအမည်နှင့် တူညီနိုင်မည်မဟုတ်ပေ။",
nickname_had: "နာမည်ပြောင်ရှိပြီးသား။",
nickname_not_sentitive: "ထိလွယ်ရှလွယ် နာမည်ပြောင်များကို မရွေးချယ်ပါနှင့်။",
check_network: "ကွန်ရက်ချိတ်ဆက်မှု မတည်ငြိမ်ပါ။",
logined_other_device: "သင်သည် အခြားစက်ပစ္စည်းတွင် အကောင့်ဝင်ထားသည်။",
giftcode_please_enter_full: "လက်ဆောင်ကုဒ်ကိုဖြည့်ပါ။",
info_update_success_contact_to_complete: "အောင်မြင်စွာ မွမ်းမံပြီးပါပြီ။ လုံခြုံရေးအဆင့်ကို အပြီးသတ်ရန် တယ်လီဘော့တ်နှင့် စကားပြောပါ။",
info_error_update: "အချက်အလက်ကို အပ်ဒိတ်လုပ်နေစဉ် အမှားအယွင်းတစ်ခု ဖြစ်ပေါ်ခဲ့သည်။",
info_email_wrong_type: "အီးမေးလ်ဖော်မတ် မမှန်ပါ။",
info_phone_number_wrong_type: "ဖုန်းနံပါတ်ဖော်မတ် မမှန်ပါ။",
info_email_registered_other_account: "အီးမေးလ်ကို အခြားအကောင့်ဖြင့် မှတ်ပုံတင်ပြီးဖြစ်သည်။",
info_not_need_otp_unsecure_account: "လုံခြုံမှုမရှိသောအကောင့်များအတွက် OTP မလိုအပ်ပါ။",
info_phone_number_registered_try_other: "မှတ်ပုံတင်ထားသော ဖုန်းနံပါတ်။ ကျေးဇူးပြု၍ အခြားဖုန်းနံပါတ်ကို အသုံးပြုပါ။",
phone_number_warning: "ဖုန်းနံပါတ်များသည် 10-15 နံပါတ်များရှည်ရပါမည်။",
otp_required: "OTP ကုဒ်သည် အချက်အလက် လိုအပ်ပါသည်။",
otp_tele_wrong: "Tele OTP ကုဒ်မှားရိုက်ထည့်ပါ။ ထပ်စမ်းကြည့်ပါ။",
otp_wrong: "OTP ကုဒ် မမှန်ပါ။",
otp_unexist: "OTP ကုဒ်မရှိပါ။",
otp_overtime_use: "OTP ကုဒ် သက်တမ်းကုန်သွားပါပြီ။",
you_sure_out_game: "ဂိမ်းမှ ထွက်လိုသည်မှာ သေချာပါသလား။",
password_change_success: "စကားဝှက်ပြောင်းလဲခြင်း အောင်မြင်ပါသည်။",
password_required: "စကားဝှက်အသစ်သည် အချက်အလက်လိုအပ်သည်။",
password_confirm_required: "ပြန်လည်ထည့်သွင်းရန် လိုအပ်သော အချက်အလက်",
password_confirm_wrong: "မမှန်သော စကားဝှက်အသစ်ကို ပြန်ထည့်ပါ။",
password_current_wrong: "လက်ရှိ စကားဝှက် မမှန်ပါ။",
account_login_fb_gg_cant_use_feature: "Facebook သို့မဟုတ် Google+ ဖြင့် ဝင်ရောက်ထားသည့် အကောင့်များသည် ဤလုပ်ဆောင်ချက်ကို အသုံးမပြုနိုင်ပါ။",
feature_for_register_secury_account: "ဤအင်္ဂါရပ်သည် မှတ်ပုံတင်ထားသော လုံခြုံရေးအကောင့်များအတွက်ဖြစ်သည်။",
account_warning_nickname: "အမည်ပြောင်များကို မွမ်းမံမွမ်းမံထားသော အကောင့်များကို စနစ်က မပံ့ပိုးပါ။",
you_need_enter_money: "ပမာဏကို ထည့်သွင်းရန် လိုအပ်ပါသည်။",
deposit_order_double: "သင်သည် ငွေဖြည့်သွင်းခြင်း 2 ခုကို နီးကပ်လွန်းစွာ ဖန်တီးထားသည်။",
deposit_order_limit_per_day: "တစ်ရက်အတွင်း အပ်ငွေ အော်ဒါများ ပြုလုပ်ရန် ကန့်သတ်ချက်ကို ကျော်လွန်သွားပါပြီ။ နောက်အမှာစာ မဖန်တီးမီ အပ်ငွေကို အပြီးသတ်ရန် လွှဲပြောင်းရန် လိုအပ်ပါသည်။",
buy_gold_faild: "ရွှေဝယ်ရန် မအောင်မြင်ပါ။",
withdraw_money_faild: "ငွေထုတ်ခြင်း မအောင်မြင်ပါ။",
withdraw_fail: "ငွေထုတ်ခြင်း မအောင်မြင်ပါ။",
success: "အောင်မြင်သည်!",
bank_id_required: "ဘဏ် ID လိုအပ်ပါသည်။",
account_number_required: "အကောင့်နံပါတ် လိုအပ်ပါသည်။",
username_required: "အသုံးပြုသူအမည် လိုအပ်ပါသည်။",
nickname_required: "အမည်ပြောင် လိုအပ်ပါသည်။",
num_gold_required: "ရွှေနံပါတ် လိုအပ်ပါသည်။",
account_number_wrong_type: "အကောင့်နံပါတ် မမှန်ပါ။",
num_gold_wrong_type: "ရွှေနံပါတ် မမှန်ပါ။",
account_banned_transfer: "လွှဲပြောင်းခြင်းလုပ်ဆောင်ချက်မှ အကောင့်ကို လော့ခ်ချထားသည်။",
withdraw_money_minimum: "ငွေထုတ်သည့်ပမာဏသည် ထက်ကြီးသည် သို့မဟုတ် ညီမျှရပါမည်။",
error_undetermine: "အမည်မသိ အမှားတစ်ခု",
not_enough_transfer_require_contact_service: "သင်သည် အရောင်းအ၀ယ်ပြုလုပ်ရန် အရည်အချင်းမပြည့်မီပါ။ အသေးစိတ်အချက်အလက်များကို ဖောက်သည်ဝန်ဆောင်မှုကို ဆက်သွယ်ပါ။",
attendance_success: "အောင်မြင်စွာတက်ရောက်ခြင်း။",
attendance_fail: "တက်ရောက်မှု မအောင်မြင်ပါ။",
account_unregister_secure: "လုံခြုံရေး မှတ်ပုံတင်မထားသည့် အကောင့်",
account_unregister_secure_contact_service: "အကောင့်သည် လုံခြုံရေးလုပ်ဆောင်ချက်ကို စာရင်းမသွင်းရသေးပါ။ အကူအညီအတွက် Telegram:@cskhboss79 သို့မဟုတ် call center 19006896 သို့ ဆက်သွယ်ပါ၊ စကားဝှက်ရယူရန် အကောင့်အချက်အလက်ကို အတည်ပြုပါ။ ကျေးဇူးတင်ပါတယ်!",
account_unexist: "အကောင့်မရှိပါ။",
support: "နောက်ထပ်အချက်အလက်များအတွက် ဖောက်သည်ဝန်ဆောင်မှုကို ဆက်သွယ်ပါ။",
server_unconnect: "ဆာဗာသို့ မချိတ်ဆက်ပါ။",
server_terminate_interupt: "ဆာဗာ ခေတ္တပိတ်ထားသည်။",
account_not_enter: "အသုံးပြုသူအမည်ကို သင်မထည့်ရသေးပါ။",
password_not_enter: "စကားဝှက်မထည့်ရသေးပါ။",
play_game_fun: "ဂိမ်းကို ပျော်ရွှင်စွာ ကစားပါ။",
good_luck_later: "နောက်တစ်ကြိမ် ကံကောင်းပါစေလို့ ဆုတောင်းပါတယ်။",
transfer_account_receive_unexist: "လက်ခံသည့်အကောင့် မရှိပါ။",
transfer_minimum_money: "လွှဲပြောင်းသည့်ပမာဏသည် အနည်းဆုံး ငွေပေးငွေယူတန်ဖိုးထက် နည်းပါသည်။",
account_not_enought_transfer_condition: "အကောင့်သည် ကုန်သွယ်မှုအတွက် အရည်အချင်းမပြည့်မီပါ။ ထုတ်ဝေသူကို ဆက်သွယ်ပါ။",
sercure_feature_auto_active: "မှတ်ပုံတင်ခြင်းအောင်မြင်သည့်အချိန်မှ ၂၄ နာရီအကြာတွင် လုံခြုံရေးလုပ်ဆောင်ချက်ကို အလိုအလျောက် စတင်အသုံးပြုနိုင်မည်ဖြစ်သည်။",
transfer_limit: "ငွေပမာဏအချို့ကို အထွေထွေကိုယ်စားလှယ်ထံသို့သာ လွှဲပေးနိုင်ပါသည်။",
transfer_over_credit: "လွှဲပြောင်းသည့်ပမာဏသည် ကန့်သတ်ချက်ထက်ကျော်လွန်သွားပြီ။",
transfer_account_send_unexist: "ငွေလွှဲအကောင့် မရှိပါ။",
transfer_enter_content: "လိုအပ်သော လွှဲပြောင်းအကြောင်းအရာကို ထည့်သွင်းပါ။",
tranfer_same_account: "ငွေလွှဲအကောင့်သည် လက်ခံအကောင့်နှင့် အတူတူပင်ဖြစ်ပါသည်။",
transfer_local_feature_terminated_contact_service: "အတွင်းပိုင်းလွှဲပြောင်းခြင်းလုပ်ဆောင်ချက်ကို ယာယီဆိုင်းငံ့ထားသည်။ အကူအညီအတွက် ဖောက်သည်ဝန်ဆောင်မှုကို ဆက်သွယ်ပါ။",
transfer_local_feature_terminated_contact_service1: "အတွင်းပိုင်း လွှဲပြောင်းခြင်း လုပ်ဆောင်ချက်ကို ယာယီ ပိတ်ထားသည်။ အသေးစိတ်အချက်အလက်များအတွက် ဖောက်သည်ဝန်ဆောင်မှုကို ဆက်သွယ်ပါ။"
},
gui_profile: {
profile_title: "ကိုယ်ရေးအကျဉ်း",
join_time: "ပါဝင်သည့်ရက်စွဲ",
birth_date: "မွေးနေ့",
ip_address: "IP လိပ်စာ",
invite_code: "ရည်ညွှန်းကုဒ်",
change_password: "စကားဝှက်ကိုပြောင်းရန်",
change_password1: "စကားဝှက်ကိုပြောင်းရန်",
change_avatar: "ဇာတ်ကောင်ပြောင်းရန်",
back: "ကျော",
change: "ပြောင်းလဲပါ။",
current_password: "လက်ရှိစကားဝှက်",
new_password: "စကားဝှက်အသစ်",
confirm_new_password: "စကားဝှက်အသစ်ထည့်ပါ။",
update: "အပ်ဒိတ်",
alert: {
warning_1: "သင့်ကိုယ်ပွားသည် ယခင်ရုပ်ပွားတော်နှင့် မတူပါ။",
warning_2: "သင်ပြောင်းလိုသော Avatar ကို ရွေးပါ။"
}
},
gui_agency: {
deposit_title: "ရွှေငွေဖြည့်ပါ။",
deposit_gold: "ရွှေငွေဖြည့်ပါ။",
deposit_history: "ငွေဖြည့်မှတ်တမ်း",
sell_title: "ရွှေရောင်း",
sell_gold: "ရွှေရောင်း",
sell_history: "သမိုင်းကိုရောင်း",
current_credit: "လက်ကျန်ငွေ",
agency: "အေဂျင်စီ",
deposit_money: "အပ်ငွေ",
receive_gold: "ရွှေလက်ခံ",
agency_note: "မှတ်ချက်- မလွှဲပြောင်းမီ အေးဂျင့်၏အချက်အလက်များကို သေချာစစ်ဆေးပါ၊ မပံ့ပိုးသော ထုတ်ဝေသူမှားသို့ လွှဲပြောင်းပါ။ ၅ မိနစ်ကြာပြီးနောက် ရွှေအဆက်အသွယ် မရခဲ့ပါ။",
or_call_to: "ဆက်သွယ်ရန်",
note: "မှတ်ချက်",
minimum_trade: "အနိမ့်ဆုံးငွေပေးငွေယူ",
rate_trade: "ငွေလွှဲခ",
exchange_rate: "ကူးပြောင်းနှုန်း",
account_number: "အကောင့်နံပါတ်",
account_name: "အကောင့်နာမည်",
area: "ဧရိယာ",
confirm: "အတည်ပြုပါ။",
deposit_note: "ငွေသွင်းအမှာစာကို သင်အောင်မြင်စွာ ဖန်တီးပြီးဖြစ်သည်။ ထို့နောက် ငွေသွင်းခြင်းလုပ်ငန်းစဉ်ကို အပြီးသတ်ရန်။ ငွေလွှဲပြေစာပေးပို့ရန် ဖောက်သည်ဝန်ဆောင်မှုကို ဆက်သွယ်ပါ။",
notify_title: "အကြောင်းကြားပါ။",
num_transfer_gold: "ရွှေနံပါတ်ကို လွှဲပြောင်းပါ။",
receive_money: "လက်ခံရရှိသည့်ပမာဏ",
branch: "ကိုင်း",
account_owner_name: "အကောင့်ပိုင်ရှင်အမည်",
continue: "ဆက်လက်",
status: "အဆင့်အတန်း",
time: "အချိန်",
transfer_code_short: "ငွေလွှဲကုတ်",
num_transfer_money: "လွှဲပြောင်းပမာဏ",
title_new_bank: "ဘဏ်အသစ်ဝင်ပါ။",
title_bank_other: "တခြားဘဏ်",
title_new_bank_message: "ငွေထုတ်ဘဏ်ကိုဝင်ပါ။",
lao: "လာအို",
taiwan: "ထိုင်ဝမ်",
vietnam: "ဗီယက်နမ်",
thailan: "ထိုင်း",
pending: "ဆိုင်းငံ့ထားသည်",
accepted: "လက်ခံတယ်",
rejected: "ပယ်ချသည်",
huy: "ဖျက်သိမ်းလိုက်သည်"
},
gui_list_agency: {
country_code: {
VN: "Vietnamese",
JP: "Japan",
KR: "Korea",
TW: "Taiwan",
LA: "Laos",
KH: "Cambodia",
US: "United States",
MM: "Myanmar",
TH: "Thailand",
LD: "LD",
WB: "WB",
JL: "JL"
},
agency_title: "အေဂျင်စီ",
korea: "Korea",
japan: "Japan",
taiwan: "Taiwan",
lao: "Laos",
campuchia: "Cambodia",
singapore: "Singapore",
thailand: "Thailand",
myanmar: "Myanmar",
no: "ဂဏန်းအလို့ငှာ",
agency: "အေဂျင်စီ",
nickname: "အမည်ပြောင်",
phone_number: "ဖုန်းနံပါတ်",
contact: "ဆက်သွယ်ပါ။",
area: "ဧရိယာ",
action: "အက်ရှင်",
buy: "ဝယ်ပါ။",
sell: "ရောင်း",
rate: "နှုန်းထား",
people_rate: " လူတွေက အဆင့်သတ်မှတ်တယ်။",
action_rate: "ကိုယ်စားလှယ်ကို အဆင့်သတ်မှတ်ရန် နှိပ်ပါ။",
title_rate: "အေးဂျင့်အကြောင်း အကြံပြုချက်ကို အကဲဖြတ်ပါ။ ",
feedback_rate: "အခြားသူများထံမှ တုံ့ပြန်ချက်",
enter_content: "အကြောင်းအရာ...",
rate_success: "အဆင့်သတ်မှတ်ခြင်း အောင်မြင်သည်။",
rate_fail: "အဆင့်သတ်မှတ်မှု မအောင်မြင်ပါ။",
dk_rate: "စိစစ်မှုကို လက်ခံရရှိရန် အရောင်းကိုယ်စားလှယ်နှင့် အနည်းဆုံး ရွှေ 100,000 ကို ရောင်းဝယ်ရပါမည်။ ကျေးဇူးတင်ပါသည်!",
dk_rate_1: "သုံးသပ်ချက်ကို အပြီးသတ်ရန် မှတ်ချက်အကြောင်းအရာကို ထည့်သွင်းပါ (အနည်းဆုံး စာလုံး 12 လုံး)။",
dk_rate_2: "အရောင်းအဝယ်အောင်မြင်သည်။ ကျွန်ုပ်တို့၏ဝန်ဆောင်မှုကို ပိုမိုကောင်းမွန်အောင် လုပ်ဆောင်နိုင်ရန် အေးဂျင့်ကို အဆင့်သတ်မှတ်ရန် အချိန်အနည်းငယ်ယူပါ။",
dk_rate_content_0: "ယုံကြည်ရသောကုန်သွယ်အေးဂျင့်",
dk_rate_content_1: "အမြန်ငွေပေးငွေယူအေးဂျင့်",
dk_rate_content_2: "OK",
dk_rate_content_3: "ပံ့ပိုးမှုကိုယ်စားလှယ်",
dk_rate_content_4: "ကိုယ်စားလှယ် များ ကံကောင်းခြင်း ချမ်းသာကြပါစေ"
},
gui_attendance: {
attendance: "ကျောင်းခေါ်ချိန်",
attendance_title: "ကျောင်းခေါ်ချိန်",
day: "နေ့",
day1: "နေ့ ၁",
day2: "နေ့ ၂",
day3: "နေ့ ၃",
day4: "နေ့ ၄",
day5: "နေ့ ၅",
day6: "၆ ရက်",
day7: "၇ ရက်",
attendance_note: "ကျေးဇူးပြု၍ သီတင်းပတ်ကုန်တွင် ဆွဲဆောင်မှုရှိသော ဆုလက်ဆောင်များရယူရန် အပြည့်အစုံတက်ရောက်ပါ။"
},
gui_open_egg: {
open_egg: "ကြက်ဥကိုဖွင့်ပါ။",
gold_egg: "ရွှေဥ",
white_egg: "ရွှေဥ",
no_egg: "ဥလည်း မရှိဘူး။"
},
gui_bundle_download: {
download_game: "ဂိမ်းဒေါင်းလုဒ်လုပ်ပါ။",
download: "ဒေါင်းလုဒ်လုပ်ပါ။"
},
gui_event_list_giftcode: {
list_giftcode_title: "လက်ဆောင်ကုဒ်စာရင်း"
},
gui_events: {
event_title: "ပွဲ",
event: "ပွဲ",
event_top_bet: "ထိပ်တန်းလောင်းကစားပွဲ",
event_attendace: "ပွဲတက်ရောက်သူ",
event_receive_bet: "အလောင်းအစားပွဲကို လက်ခံပါ။",
event_find_million: "သန်းကြွယ်သူဌေးဖစ်ရှာပါ။",
event_sicbo: "Sicbo ပွဲ",
event_jackpot_sicbo: "Sicbo Jackpot",
rules: "ထိပ်တန်းစည်းကမ်း",
daily_top: "ထိပ်တန်းနေ့စဉ်",
top_bet: "ထိပ်တန်းလောင်း",
attendace_again: "တက်ရောက်လာပြန်တယ်",
rank: "အဆင့်",
user: "သုံးစွဲသူ",
bet: "လောင်းကစား",
refund: "ပြန်အမ်းငွေ",
money: "ပိုက်ဆံ"
},
gui_trade_history: {
trade_history_title: "ငွေလွှဲမှတ်တမ်း",
trade_history: "ငွေလွှဲမှတ်တမ်း",
play_gold: "ရွှေကစားပါ။",
play_chip: "အကြွေစေ့ကစားပါ။",
deposit_chip: "ငွေဖြည့်ဒင်္ဂါးများ",
deposit_gold: "ရွှေငွေဖြည့်ပါ။",
expense_gold: "ရွှေဖြုန်း",
trade_code: "ငွေလွှဲကုတ်",
time: "အချိန်",
service: "ဝန်ဆောင်မှု",
incurred: "ကြုံမည်။",
credit: "လက်ကျန်",
description: "ဖော်ပြချက်",
detail: "အသေးစိတ်",
view: "အမြင်"
},
gui_forgot_password: (n = {
account: "အကောင့်",
account_title: "အကောင့်",
account_note_full_info: "အထောက်အပံ့ရဖို့။ ကျေးဇူးပြု၍ အောက်ပါအချက်အလက်များကိုဖြည့်ပါ။",
account_note_username: "ဇာတ်ကောင်အမည်သည် အချက်အလက် လိုအပ်သည်။",
type_login_name: "အသုံးပြုသူအမည်ထည့်ပါ။",
authentication_code: "အတည်ပြုရန်ကုတ်",
send: "ပို့ပါ။",
forgot_password: "စကားဝှက်ကိုမေ့နေပါသလား",
forgot_password_title: "စကားဝှက်ကိုမေ့နေပါသလား",
telegram_authentication_code: "ကြေးနန်းအထောက်အထားစိစစ်ခြင်းကုဒ်..."
}, n.send = "ပါ", n.new_password = "စကားဝှက်အသစ်", n.confirm_new_password = "သင့်စကားဝှက်အသစ်ကို ပြန်လည်ထည့်သွင်းပါ။", 
n),
gui_display_name: {
account_title: "အကောင့်",
account_note_username: "ဇာတ်ကောင်အမည်သည် အချက်အလက် လိုအပ်သည်။",
username: "အသုံးပြုသူအမည်",
account_note_username1: "စာလုံး 6 လုံးမှ 16 လုံးကြားရှိ ဇာတ်ကောင်အမည်၊ ထိလွယ်ရှလွယ် စာလုံးများမရှိ၊ အထူးဇာတ်ကောင်များနှင့် နေရာလွတ်များမရှိပါ။",
create_new: "အသစ်ဖန်တီးပါ။"
},
gui_login: {
login_title: "အကောင့်",
login_name: "အသုံးပြုသူအမည်",
password: "စကားဝှက်",
save_password: "စကားဝှက်ကိုသိမ်းဆည်းပါ။",
login: "လော့ဂ်အင်",
forgot_password: "စကားဝှက်ကိုမေ့နေပါသလား"
},
gui_registry: {
register_title: "မှတ်ပုံတင်ပါ။",
register: "မှတ်ပုံတင်ပါ။",
login_name: "အသုံးပြုသူအမည်",
password: "စကားဝှက်",
confirm_password: "စကားဝှက်ကိုပြန်လည်ထည့်ပါ",
invite_code_note: "ရည်ညွှန်းကုဒ် (ချန်လှပ်ထားနိုင်သည်)",
captcha: "အတည်ပြုကုဒ်များ"
},
gui_mailbox: {
title: "ခေါင်းစဥ်:",
content: "အကြောင်းအရာ-",
sender: "ပေးပို့သူ-",
unread: "မဖတ်ရသေး",
read: "ဖတ်",
mailbox_title: "စာတိုက်ပုံး",
mess_delete_mail: "သေချာပေါက် မေးလ်ကို ဖျက်ချင်နေပီ?"
},
gui_minigame: {
game_download: "ဂိမ်းဒေါင်းလုဒ်လုပ်ပါ။",
taixiu: "အကြီးအသေး",
caothap: "မြင့်သည်နှင့် အနိမ့်",
chanle: "အထူးအဆန်း - ပင်",
xocdia: "SeDie",
pokego: "ပိုကီမွန်",
baucua: "Kla Klouk"
},
gui_confirm_transfer: {
notify: "အကြောင်းကြားပါ။",
agency_account: "အေဂျင်စီအကောင့်",
notify_note_cheat: "လိမ်လည်မှုများကို ရှောင်ရှားရန် အေးဂျင့်များနှင့်သာ ဆက်ဆံပါ။",
you_sure_send: "သင် သေချာပေါက် လွှဲပြောင်းချင်ပါသည်။",
amount_money: "ငွေပမာဏ",
reason: "အကြောင်းပြချက်",
reject: "မလုပ်တော့",
accept: "လက်ခံပါတယ်။",
account: "အကောင့်",
confirm_transfer_title: "အကြောင်းကြားပါ။"
},
gui_buy_gold: {
buy_gold: "ရွှေဝယ်ပါ။",
buy_gold_title: "ရွှေဝယ်ပါ။",
current_credit: "လက်ရှိအကြွေး",
agency: "အေဂျင်စီ",
enter_agency: "အေဂျင်စီသို့ဝင်ပါ",
nickname: "Nickname",
enter_nickname: "Nickname ထည့်ပါ",
buy_money: "ငွေပမာဏ",
number_buy_money: "ငွေပမာဏ...",
gold: "ရွှေ",
receive_gold: "ရွှေလက်ခံသည်။...",
other_agency: "အခြားအေဂျင်စီ",
lb_warning_1: "တိုက်ရိုက်လဲလှယ်ရန်အေဂျင်စီကိုဆက်သွယ်ပါ။",
lb_warning_2: "အေဂျင်စီဖုန်းနံပါတ်:",
lb_warning_3: "သို့မဟုတ် လင့်ခ်ကို ဝင်ရောက်ကြည့်ရှုပါ: ",
lao: "လာအို",
cam: "ကမ္ဘောဒီးယား",
vn: "ဗီယက်နမ်",
kor: "ကိုရီးယား",
jp: "ဂျပန်",
tw: "ထိုင်ဝမ်"
},
gui_sell_gold: {
sell_gold: "ရွှေရောင်း",
sell_gold_title: "ရွှေရောင်း",
current_credit: "လက်ကျန်ငွေ",
agency: "အေဂျင်စီ",
enter_agency: "အေဂျင်စီသို့ဝင်ပါ",
nickname: "NickName",
enter_nickname: "Nickname ထည့်ပါ",
buy_money: "ငွေပမာဏ",
number_sell_gold: "ငွေပမာဏ...",
gold: "ရွှေ",
receive_money: "ရရှိသည့်ပမာဏ...",
other_agency: "အခြားအေးဂျင့်များ",
continue: "ဆက်လက်",
transfer_reason: "ပြောင်းရွှေ့ရခြင်း အကြောင်းအရင်း",
lao: "လာအို",
cam: "ကမ္ဘောဒီးယား",
vn: "ဗီယက်နမ်",
kor: "ကိုရီးယား",
jp: "ဂျပန်",
tw: "ထိုင်ဝမ်"
},
gui_notify: {
title_notify: "အကြောင်းကြားပါ။",
notify_common_admin: "BOSS79 စီမံခန့်ခွဲမှုဘုတ်အဖွဲ့မှ လေးစားစွာဖြင့် အသိပေးကြေငြာအပ်ပါသည်။",
notify_common_noti: " ထုတ်ဝေသူအား ဝမ်းမြောက်စွာ ကြေငြာအပ်ပါသည်။",
notify_common_content: 'အေးဂျင့်များနှင့် ဖောက်သည်များ၏ လိုအပ်ချက်များကို ဖြည့်ဆည်းပေးရန်,\nကျွန်ုပ်တို့သည် အခြားဆိုက်ကို တရားဝင်ဖွင့်ထားသည်။                                          \nဂိမ်းမျိုးစုံနဲ့, "မြောက် ၊ အလယ်ပိုင်း နှင့် တောင် ထီ ပေါက် သည်\nစျေးကွက်နှင့်နှိုင်းယှဉ်လျှင် ဆွဲဆောင်မှုရှိသောပေးချေမှုနှုန်းထားများနှင့်\nကာစီနိုဂိမ်းများ၊ အားကစားလောင်းကစားများ၊ Baccarat သည်\nအလွန်မြင့်မားသောပြန်နှုန်းများဖြင့် 1:1 အပ်ငွေ/ငွေထုတ်အချိုးဖြင့် \n အလွန်ဆွဲဆောင်မှုရှိသောအတွေ့အကြုံကို ယူဆောင်လာပါသည်။'
},
safetybox: {
safetybox_title: "မီးခံသေတ္တာ",
lb_goldin: "မီးခံသေတ္တာ တွင် ရွှေ",
note: "မီးခံသေတ္တာ ကိုအသုံးပြုရန် စကားဝှက်တစ်ခုဖန်တီးပါ။!",
lb_btn: {
chuyen: "သိုက်",
rut: "ငွေထုတ်ပါ",
doimk: "စကားဝှက်ကိုပြောင်းရန်",
dongy: "လက်ခံပါတယ်။",
back: "ကျော"
},
lb_editbox: {
lb_chuyen: "ရွှေငွေဖြည့်ပါ။",
lb_rut: "ရွှေထုတ်ယူ",
placeholder_password_rut: "ရုပ်သိမ်းရန် မီးခံသေတ္တာ စကားဝှက်ကို ရိုက်ထည့်ပါ။",
placeholder_password_create: "စကားဝှက်ဖန်တီးပါ",
placeholder_re_password_create: "စကားဝှက်ပြန်ထည့်ပါ",
placeholder_password_old: "စကားဝှက်ဟောင်း",
placeholder_new_password_update: "စကားဝှက်အသစ်",
placeholder_re_new_password_update: "စကားဝှက်အသစ်ပြန်ထည့်ပါ"
},
message: {
wrong_password: "စကားဝှက်မှား။ ထပ်စမ်းကြည့်ပါ။",
wrong_password_retype: "စကားဝှက်မှားပြန်ထည့်ပါ။ ထပ်စမ်းကြည့်ပါ။",
wrong_old_pass: "စကားဝှက်ဟောင်း မမှန်ပါ။ ထပ်စမ်းကြည့်ပါ။",
withdraw_success: "အောင်မြင်စွာ ရုပ်သိမ်းလိုက်ပါပြီ",
transfer_success: "အောင်မြင်သောငွေဖြည့်!",
transfer_failed: "အားပြန်သွင်းခြင်း မအောင်မြင်ပါ",
create_password_success: "စကားဝှက် အောင်မြင်အောင် ဖန်တီးပါ။",
update_password_success: "စကားဝှက်ကို အပ်ဒိတ်လုပ် အောင်မြင်ပါပြီ။",
please_type_money_withdraw: "ထုတ်ယူသည့် ပမာဏကို ထည့်ပါ။",
please_type_money_transfer: "အပ်ငွေပမာဏကို ထည့်ပါ။",
error_create: "ပျက်ကွက်ဖန်တီးပါ။ ထပ်စမ်းကြည့်ပါ။",
error_update: "အပ်ဒိတ် မအောင်မြင်ပါ။ ထပ်စမ်းကြည့်ပါ။",
error_network: "ကွန်ရက်ချိတ်ဆက်မှု မတည်ငြိမ်ပါ။ နောက်မှ ထပ်စမ်းကြည့်ပါ။"
}
},
gui_setting: {
music: "ဂီတ",
music_on: "ဂီတ (On)",
music_off: "ဂီတ (Off)",
term_of_use: "သတ်မှတ်ချက်များ",
feedBack: "တုံ့ပြန်ချက်"
},
gui_chuyen_quy: {
transfer_withdraw_title: "လွှဲပြောင်း/ငွေထုတ်ခြင်း",
num_transfer_gold: "ရွှေနံပါတ်ပြောင်းပါ",
receive_money: "လက်ခံရရှိသည့်ပမာဏ",
transfer_fund: "ရန်ပုံငွေလွှဲပြောင်း",
play_now: "ယခုကစားပါ။",
withdraw_fund: "ရန်ပုံငွေထုတ်ယူ",
withdraw_money: "ထုတ်ယူရမည့်ပမာဏ",
num_receive_gold: "လက်ခံရရှိသည့်ပမာဏ",
type_num_gold: "ရွှေနံပါတ်ထည့်ပါ။",
type_num_money: "ပမာဏကို ထည့်ပါ။",
receive_gold: "လက်ခံရရှိသည့်ပမာဏ",
current_money: "လက်ရှိငွေ"
},
gui_transfer: {
transfer: "အပြောင်းအရွှေ့",
transfer_title: "အပြောင်းအရွှေ့",
current_credit: "လက်ကျန်ငွေ",
enter_nickname: "အမည်ပြောင် ထည့်ပါ။",
re_enter_nickname: "အမည်ပြောင်ကို ပြန်ထည့်ပါ",
enter_sell_money: "လွှဲပြောင်းရန် ပမာဏကို ထည့်ပါ။",
receive_gold: "ရွှေလက်ခံသည်",
reason: "ပြောင်းရွှေ့ရခြင်း အကြောင်းအရင်း",
continue: "ဆက်လက်",
agency: "အေဂျင်စီ",
gold: "ရွှေ",
amount_less_than_minimum: "လွှဲပြောင်းသည့်ပမာဏသည် အနည်းဆုံး ငွေပေးငွေယူတန်ဖိုးထက် နည်းပါသည်။",
unregister_security: "လုံခြုံရေး မှတ်ပုံတင်မထားသည့် အကောင့်။ ဖောက်သည်ဝန်ဆောင်မှုကို ဆက်သွယ်ပါ။",
otp_expired: "OTP ကုဒ် သက်တမ်းကုန်သွားပါပြီ။",
otp_not_correct: "OTP ကုဒ် မမှန်ပါ။",
otp_error: "OTP ကုဒ် အမှား။",
una_balance: "လက်ကျန်ငွေ မရရှိနိုင်ပါ။",
lock_transfer: "အမည်ပြောင်ကို လွှဲပြောင်းခြင်းလုပ်ဆောင်ချက်မှ လော့ခ်ချထားသည်။",
acc_not_exist: "နာမည်ပြောင် မရှိပါ။",
enter_details: "ကျေးဇူးပြု၍ လွှဲပြောင်းမှုအသေးစိတ်အချက်အလက်များကို ထည့်သွင်းပါ။",
not_transfer_yourself: "သင်ကိုယ်တိုင် မလွှဲပြောင်းနိုင်ပါ။",
not_transfer_agency: "အေးဂျင့်ကို အေးဂျင့်ကို လွှဲလို့ မရဘူး။",
not_transfer_agency2: "အဆင့် 2 အေးဂျင့်များသည် အဆင့် 2 အေးဂျင့်များသို့ လွှဲပြောင်း၍မရပါ။",
not_transfer_not_your_agency2: "သင့်ပိုင်မဟုတ်သော အဆင့် 2 အေးဂျင့်ထံသို့ ငွေလွှဲ၍မရပါ။",
amount_maximum: "\n\nGIFTCODE ယန္တရားအရ လွှဲပြောင်းနိုင်သော အများဆုံးပမာဏမှာ %{money} ဖြစ်သည်။ အသေးစိတ်အချက်အလက်များအတွက်၊ ဖောက်သည်ဝန်ဆောင်မှုကို ဆက်သွယ်ပါ။",
transfer_fail: "လွှဲပြောင်းမှု မအောင်မြင်ပါ။",
transfer_success: "လွှဲပြောင်းအောင်မြင် ",
sell_gold: "Sell Gold to ",
sell_gold_user_text_0: "ကံကောင်းရင် ကံကောင်းတယ်။",
sell_gold_user_text_1: "ယုံကြည်စွာ အောင်ပွဲခံပါ။ ",
sell_gold_user_text_2: "%{myNickName} GOLD သို့ လွှဲပြောင်းပါ။ %{otherNickName} ",
sell_gold_user_text_3: "Lucky Money "
},
gui_logout: {
logout_title: "ထွက်လိုက်ပါ",
warning: "ဂိမ်းမှ ထွက်လိုသည်မှာ သေချာပါသလား။",
no: "မလုပ်တော့",
yes: "ဟုတ်ကဲ့"
},
gui_policy: {
policy_title: "သတ်မှတ်ချက်များ"
},
gui_security: {
security_title: "လုံခြုံရေး",
account_name: "အကောင့်နာမည်",
username: "အသုံးပြုသူအမည်",
cmtnd: "ID နံပါတ်များ",
email: "အီးမေးလ်",
phone_number: "ဖုန်းနံပါတ်",
update: "အပ်ဒိတ်",
active: "လှုပ်လှုပ်ရှားရှား",
get_otp: "OTP ရယူပါ။"
},
gui_buy_and_sold: {
buy_and_sold_title: "ဆိုင်",
transfer: "ဆိုင်အပြောင်းအရွှေ့",
sell_gold: "ရွှေရောင်း",
input_otp: "OTP ထည့်ပါ"
},
gui_gift_code: {
notice: "* လက်ဆောင်လက်ခံရရှိရန် မှန်ကန်ကြောင်းကို ဖြည့်သွင်းပြီး လက်ခံမည့်အချိန်ကို သတိပြုပါ။\n* လက်ဆောင်ကုဒ်တစ်ခုစီသည် အကောင့် 1 ခုအတွက်သာ အကျုံးဝင်ပါသည်။",
gift_code_title: "လက်ဆောင်ကုဒ်",
enter_gift_code: "GiftCode ရိုက်ထည့်ပါ။",
receive: "လက်ခံသည်။",
price: "စျေးနှုန်း ",
code: "ကုဒ် "
},
gui_header: {
logout: "လက်ဆောင်ကုဒ်",
safetybox: "မီးခံသေတ္တာ",
history: "သမိုင်း",
language: "ဘာသာစကား",
shop: "ဆိုင်",
setting: "ဆက်တင်",
confirm_change_language: "ဘာသာစကားကို %{language}လို ပြောင်းချင်ပါသလား။",
ok: "ဟုတ်ကဲ့",
cancel: "မရှိ",
win: "နောက်ဆုံးအနိုင်",
day: "နေ့"
},
gui_choose_nation: {
choose_nation_title: "လူမျိုးကို ရွေးပါ"
},
gui_language: {
language_title: "ဘာသာစကား"
},
mergeWord: {
transaction_failed: "Transaction failed. Please try again later!",
transaction_success: "Successful transaction",
seller_not_online: "The seller is currently not online",
insufficient_balance: "Insufficient balance!",
letter_not_exist: "Letters/Numbers do not exist!",
sys_err: "System error. Please try again later!",
price_greater: "The price of letters/numbers must be greater than the floor price!",
wants_to_sell: " wants to sell you the letter/number",
price: "Price: ",
please_choose_letters: "Please choose the letters from the inventory on the left to combine them!",
pairing_fail: "Pairing letters failed.",
pairing_success: "Pairing letters successfully. You receive ",
empty_data: "Empty data",
word_incorrect: "The word set is incorrect!",
not_enough_letters: "You don't have enough letters/numbers!",
account_not_exist: "Account does not exist!",
selling_failed: "Selling words failed. Please try again later!",
selling_success: "Selling words successfully. Please wait for the buyer to confirm!",
buyer_not_online: "The buyer is not online. Please try again later!",
action_fast: "You act too fast. Please try again in a moment!",
greater_minimum: "The transaction amount must be greater than the specified minimum transaction amount",
minimum_selling: "Minimum selling price is 10,000 Gold.",
transaction_fee: "Transaction fee is 5% (Minimum is 10,000 Gold)",
transaction_note: "You want to trade this word with someone else. Please carefully check the sender information and denomination, if the operation is wrong, no refund will be given!",
selling_err: " An error occurred when selling %s for %s to %s",
acepted_buy: "%s agrees to buy letter %s for %s Gold",
not_acepted_buy: "%s doesn't agree to buy letter %s for %s Gold",
please_choose_word: "Please select letter to sell",
please_type_nickname: "Please enter a nickname!",
please_type_price: "Please enter selling price!",
buy: "Buy",
sell: "Sell",
history_buy_sell: "Transaction History",
history_trade_word: "History of letter exchange",
nickname: "Nickname"
}
},
minigame: {
chat: {
input_chat: "ချတ်လုပ်ရန် နှိပ်ပါ",
send: "ပို့ပါ",
error: "အမှား",
greeting: "မင်းကံကောင်းပါစေ!",
banned: "*** သင့်တွင် Chat ရန်ခွင့်ပြုချက်မရှိပါ။",
temp_banned: "*** Chat မှ ခေတ္တ ပိတ်ပင်ထားသည်။",
limited_length: "*** ချတ်အကြောင်းအရာသည် ရှည်လွန်းသည်။",
not_enough_gold: "*** လက်ကျန်ငွေသည် ချတ်အတွက် မလုံလောက်ပါ။",
ban_forever: "*** သင် စကားပြောခွင့်ကို ထာဝရပိတ်ပင်ထားသည်။",
action_quickly: "*** သင် စကားပြောတာ အရမ်းမြန်တယ်။",
require_length: "ကျေးဇူးပြု၍ စာလုံး 1 လုံးထက်ပိုထည့်ပါ။",
require_topup: "ချတ်ဝန်ဆောင်မှုကိုဖွင့်ရန် သင့်အား ငွေဖြည့်ရန် လိုအပ်သည်။"
},
common: {
rebet: "ပြန်လောင်းသည်။",
accept: "လက်ခံပါတယ်။",
destroy: "မလုပ်တော့",
select: "ရွေးချယ်ပါ။",
all_in: "အားလုံးထဲမှာ",
dice_1: "အန်စာတုံး 1",
dice_2: "အန်စာတုံး 2",
dice_3: "အန်စာတုံး 3",
top_day: "နေ့",
top_month: "လ",
top_year: "တစ်နှစ်",
top_round: "ဝိုင်း",
top_round1: "ဝိုင်း 1",
top_round2: "ဝိုင်း 2",
title_help: "လမ်းညွှန်",
title_session_detail: "အပိုင်းအသေးစိတ်",
title_session: "အပိုင်း",
title_nickname: "အမည်ပြောင်",
title_name: "နာမည်",
title_time: "အချိန်",
title_side: "လောင်းကြေးတံခါး",
title_bet: "လောင်းကစား",
title_refund: "ပြန်အမ်းငွေ",
title_reward: "လက်ခံသည်။",
title_result: "ရလဒ်",
title_total_bet_refund: "လောင်းကြေး/ပြန်အမ်းငွေ",
title_transaction_history: "ငွေလွှဲမှတ်တမ်း",
title_top_bet: "ထိပ်တန်းလောင်း",
title_top_daily: "ထိပ်တန်းနေ့စဉ်",
title_top_monthly: "လစဉ် ထိပ်တန်း",
title_top_rule: "ထိပ်တန်းစည်းကမ်း",
title_top_number: "အော်ဒါနံပါတ်",
title_account: "အကောင့်",
title_top_money: "ပိုက်ဆံ",
title_top_reward: "ဆုလာဘ်",
title_top_refund: "ပြန်အမ်းငွေ",
xiu: "အငယ်",
tai: "ကြီးတယ်။",
chan: "ပင်",
le: "ဂဏန်း",
bet_success: "အလောင်းအစားအောင်မြင်.",
bet_fail: "အလောင်းအစားမအောင်မြင်",
bet_system_error: "စနစ်အမှား",
bet_timeout: "လောင်းကြေးအချိန်ထွက်",
bet_not_enough_chip: "ချစ်ပ်မလုံလောက်ပါ။",
bet_money_invalid: "လောင်းကြေးမမှန်ကန်ပါ။",
bet_money_invalid_tour: "လောင်းကြေးမမှန်ကန်ပါ။",
bet_min_100: "ပမာဏသည် 100 ထက်ပိုရပါမည်။",
bet_min_1000: "ပမာဏ 1,000 ထက်ပိုရပါမည်။",
bet_only_1_side: "နောက်တစ်ယောက်နဲ့ လောင်းပြီးပြီ။",
bet_invalid_side: "လောင်းကြေးမမှန်ကန်သောဘက်",
bet_side_other: "1 ဘက်သာလောင်းပါ။",
bet_invalid: "သင်လောင်းကြေးကို မရွေးချယ်ရသေးပါ။",
prestart_phase: "ဂိမ်းအသစ်ကို စောင့်ပါ။",
start_phase: "ဂိမ်းအသစ်တစ်ခု စတင်ပါ။",
bet_phase: "ကျေးဇူးပြု၍လောင်းပါ။",
result_phase: "Sအလောင်းအစားကို ရပ်လိုက်ပါ။",
reward_phase: "ဆုငွေကို ပေးလိုက်ပါ။",
win_streak: "ဆက်တိုက်အနိုင်ရ",
lose_streak: "ဆက်တိုက်ရှုံးတယ်",
nan: "လျှော",
bo_nan: "ဖွင့်ပ",
no_data: "ဤစက်ရှင်တွင် ဒေတာမရှိပါ။"
},
sicbo: {
gate: {
0: "သေးငယ်သည်။",
1: "အကြီးကြီး",
2: "Sicbo သေးငယ်သည်။",
3: "Sicbo ကြီးတယ်။",
4: "ပင်",
5: "အထူးအဆန်း",
6: "Sicbo ပင်",
7: "Sicbo အထူးအဆန်း",
14: "စုစုပေါင်း ၄",
15: "စုစုပေါင်း ၅",
16: "စုစုပေါင်း ၆",
17: "စုစုပေါင်း ၇",
18: "စုစုပေါင်း ၈",
19: "စုစုပေါင်း ၉",
20: "စုစုပေါင်း ၁၀",
21: "စုစုပေါင်း ၁၁",
22: "စုစုပေါင်း ၁၂",
23: "စုစုပေါင်း ၁၃",
24: "စုစုပေါင်း ၁၄",
25: "စုစုပေါင်း ၁၅",
26: "စုစုပေါင်း ၁၆",
27: "စုစုပေါင်း ၁၇",
31: "နံပါတ် 1",
32: "နံပါတ် ၂",
33: "နံပါတ် ၃",
34: "နံပါတ် ၄",
35: "နံပါတ် ၅",
36: "နံပါတ် ၆",
40: "မုန်တိုင်းတစ်ခုခု",
41: "မုန်တိုင်း ၁",
42: "မုန်တိုင်း ၂",
43: "မုန်တိုင်း ၃",
44: "မုန်တိုင်း ၄",
45: "မုန်တိုင်း ၅",
46: "မုန်တိုင်း ၆"
},
bao: "မုန်တိုင်း",
bet_side_other: "အလောင်းအစား 2 ခုအနက် 1 ခုသာ ပြီးသည် သို့မဟုတ် အောက်သာရှိသည်။"
},
taixiu: {
bet_tai: "ကြီးတယ်။",
bet_xiu: "အငယ်",
open: "ဖွင့်သည်။",
chitietbangdau: {
group_A: "အုပ်စု A",
group_B: "အုပ်စု B",
group_C: "အုပ်စု C",
group_D: "အုပ်စု D",
group_E: "အုပ်စု E",
group_F: "အုပ်စု F",
group_G: "အုပ်စု G",
group_H: "အုပ်စု H",
nickname: "အမည်ပြောင်",
gold: "ရွှေ",
time: "အချိန်",
small_gate: "အငယ်",
big_gate: "အကြီးကြီ",
group: "အဖွဲ့",
rank: "အဆင့်",
finnal: "Final"
},
jackpot: {
Tai: "မင်းရလာတဲ့ တံခါးပေါက်ကြီး ",
Xiu: "သင်ရနိုင်သော တံခါးပေါက်အသေးစား "
}
},
xocdia: {
gate: {
0: "အနီရောင် ၄ ပင်",
1: "အနက်ရောင် အထူးအဆန်း ၁",
2: "ပင်",
3: "အနီရောင် ၁",
4: "အနက်ရောင် ၄ ပင်"
}
},
chanle: {
bet_chan: "စုံ လောင်းခြင်း",
bet_le: "မ လောင်းခြင်း",
open: "ဖွင့်သည်။"
},
rutloc: {
quy_loc: "ကံဇာတာရန်ပုံငွေ",
tan_loc: "ကံကြမ္မာကိုမျှဝေပါ",
rut_loc: "ငွေထုတ်ခြင်းကံကြမ္မာ",
bet_success: "အောင်မြင်သောကံကြမ္မာ။ မင်းကံကောင်းပါစေ!",
bet_fail: "ကံကြမ္မာပျက်ကွက်!",
bet_min_1000: "ကံကြမ္မာသည် ရွှေ 1,000 ထက် ကြီးရမည်။",
bet_outtime: "ငွေထုတ်ခြင်း မအောင်မြင်ပါ။ နောက်ဆုံးစက္ကန့် 30 စောင့်ပါ။",
bet_nexttime: "နောက်တစ်ကြိမ် ကံကောင်းပါစေလို့ ဆုတောင်းပါတယ်။",
reward: "ကံကြမ္မာကို ထုတ်ယူနိုင်ပါတယ်။",
not_money: "ကံကြမ္မာက မလုံလောက်ဘူး။",
out: "မင်း သရေပွဲတွေ ကုန်သွားပြီ။"
},
tournament: {
title_user: "အသုံးပြုသူကို",
no: "မရှိ",
title_user_history: "အသုံးပြုသူသမိုင်း",
phien: "အပိုင်း",
time: "အချိန်",
bet_1: "လောင်းကစားတံခါး",
result: "ရလဒ်",
bet_2: "လောင်းကစား",
rev: "ရရှိခဲ့သည်။",
nickname: "အမည်ပြောင်",
gold: "လက်ကျန်",
day: "နေ့",
tour_status_1: "မကြာမီ လာမည့် ပြိုင်ပွဲ!",
tour_status_2: "ပြိုင်ပွဲ အဆင်သင့်ဖြစ်ပြီ!",
tour_status_3: "ပြိုင်ပွဲစတော့မည်!",
tour_status_4: "ပြိုင်ပွဲကျင်းပဆဲ",
tour_status_5: "အဝိုင်းအဆုံး",
tour_status_6: "ပြိုင်ပွဲပြီးဆုံးသည်",
tit_players: "ကစားသမားမျာ",
tit_tour_info: "သတင်းအချက်အလက်မျာ",
tit_join_tour: "ခရီးစဉ်တွင် ပါဝင်ပါ။",
tit_num_players: "ကစားသမားမျာ:",
tit_num_rounds: "ဟိုနေ့က:",
tit_min_bet: "မင်းလောင်:",
tit_ticket_prize: "လက်မှတ်ဆု:",
tit_nph_prize: "Discount:",
tit_reg: "အဖွဲ့အတွက် မှတ်ပုံတင်ရန်",
err_reg_0: "မှတ်ပုံတင်ခြင်း အောင်မြင်သည်",
err_reg_1: "မမှန်ကန်သောကုဒ်",
err_reg_2: "ကုဒ်ပွားနေသည်",
err_reg_4: "အသုံးပြုသူကို ရှာမတွေ့ပါ",
err_reg_5: "ကုဒ်မတွေ့ပါ",
err_reg_6: "ကုဒ်ကို အသုံးပြုနေပြီ",
err_reg_7: "ကုဒ်သက်တမ်းကုန်သွားပြီ",
err_reg_8: "ခရီးစဉ် မတွေ့ပါ",
err_reg_9: "ကုဒ်မပါဘဲ ခရီးသွားခြင်း",
err_reg_10: "အသုံးပြုသူသည် ခရီးသွားနေသည်",
err_reg_11: "မည်သည့်အဖွဲ့မှ မတွေ့ပါ",
err_reg_12: "ပြိုင်ပွဲစတင်ပါပြီ။ စာရင်းသွင်း၍မရပါ",
err_reg_14: "ပြိုင်ပွဲသည် ၎င်း၏ အများဆုံး ကစားသမား အရေအတွက်သို့ ရောက်ရှိသွားပြီ ဖြစ်သည်။",
tit_ticket: "လက်မှတ်ခ",
tit_top_tour_0: "အပတ်၏ထိပ်တန်း",
tit_top_tour_1: "လ၏ထိပ်တန်း",
tit_top_tour_2: "ထိပ်တန်းအဆင့် ယှဉ်ပြိုင်မှု",
tit_top_tour_3: "ထိပ်တန်းအဆင့် ယှဉ်ပြိုင်မှု",
thele: {
week: {
text_1: "- အပတ်စဉ်ပြိုင်ပွဲ\nစနေနေ့တိုင်း ကျင်းပပါသည်။",
text_2: "* အပတ်စဉ်ပြိုင်ပွဲယှဉ်ပြိုင်မှုပုံစံ\n-ကစားသမား 32 ဦးကို အုပ်စု 8 ခုခွဲကာ 4 ယောက်စီ၊ အုပ်စုတစ်ခုစီတွင် အကောင်းဆုံးစွမ်းဆောင်ရည်ရှိသည့် ကစားသမား 2 ဦးကို ရွေးချယ်ကာ နောက်တစ်ဆင့်တက်သွားမည်ဖြစ်သည်။ လစဉ်ပြိုင်ပွဲတွင် ယှဉ်ပြိုင်ရန် ရက်သတ္တပတ်တစ်ပတ်၏ ထိပ်တန်းအဆင့် ၃ ဦးကိုရွေးချယ်ပြီးယှဉ်ပြိုင်ရန် စုစုပေါင်း နောက်ဆုံးဆန်ကာတင် ၈ ဦး။.",
prize_0: "+ ပထမဆု: %{money} Gold “လစဉ်နောက်ဆုံးပြိုင်ပွဲ”  ",
prize_1: "+ ဒုတိယဆု: %{money} Gold “လစဉ်နောက်ဆုံးပြိုင်ပွဲ”  ",
prize_2: "+ တတိယဆု: %{money} Gold “လစဉ်နောက်ဆုံးပြိုင်ပွဲ”  ",
prize_3: "+ 4th ဆု: %{money} Gold ",
prize_4: "+ 5th ဆု: %{money} Gold ",
prize_5: "+ 6th ဆု: %{money} Gold ",
prize_6: "+ 7th ဆု: %{money} Gold ",
prize_7: "+ 8th ဆု: %{money} Gold ",
text_3: "* ပရိသတ်အတွက်",
text_4: "+ ဆီမီးဖိုင်နယ်၏ ဇာတ်ကောင်အမည် 4 လုံးနှင့် အနီးစပ်ဆုံး မှန်မှန်ကန်ကန် ခန့်မှန်းသူများအတွက် + 1,000,000 ရွှေ - 500,000 ရွှေ - 200,000 ရွှေ",
text_5: "+ နှစ်သိမ့်ဆု 30- ခန့်မှန်းရန် ပါဝင်သူများအတွက် လက်ဆောင်ကုဒ် 50,000 +သူငယ်ချင်း5ယောက်ကိုtagတွဲရန်” clone nickname၊ virtual FB ကိုထည့်မတွက်ပါဘူး။ သူငယ်ချင်း 200 သိုမဟုတ် ထိုထက်ပိုသော တကယ့် Facebook accပိုင်ရှင်များအတွက်သာ"
},
month: {
text_1: "- လစဉ်ပြိုင်ပွဲ\nလတစ်လ၏ လကုန်တနင်္ဂနွေညတိုင်း ကျင်းပပါသည်။",
text_2: "* လစဉ်ပြိုင်ပွဲ\nပြိုင်ပွဲပုံစံ- လူ ၁၆ ဦးဖြင့် လစဉ်ပြိုင်ပွဲ။ အုပ်စု ၄ ဖွဲ ခွဲကာ အုပ်စုတစ်ခုစီတွင် ကစားသမား ၄ ဦးစီ ယှဉ်ပြိုင်ကြရသည်။လ၏ ဖိုင်နယ်အထိ အကောင်းဆုံးရလဒ်များရှိသည့် လူ ၈ ဦးကို ရွေးချယ်ပါမည်။",
prize_0: "+ ပထမဆု: %{money} Gold ",
prize_1: "+ ဒုတိယဆု: %{money} Gold ",
prize_2: "+ တတိယဆု: %{money} Gold ",
prize_3: "+ 4th ဆု: %{money} Gold ",
prize_4: "+ 5th ဆု: %{money} Gold ",
prize_5: "+ 6th ဆု: %{money} Gold ",
prize_6: "+ 7th ဆု: %{money} Gold ",
prize_7: "+ 8th ဆု: %{money} Gold ",
text_3: "* ပရိသတ်အတွက်",
text_4: "+ ဆီမီးဖိုင်နယ်၏ ဇာတ်ကောင်အမည် 4 လုံးနှင့် အနီးစပ်ဆုံး မှန်မှန်ကန်ကန် ခန့်မှန်းသူများအတွက် + 1,000,000 ရွှေ - 500,000 ရွှေ - 200,000 ရွှေ",
text_5: "+ နှစ်သိမ့်ဆု 30- ခန့်မှန်းရန် ပါဝင်သူများအတွက် လက်ဆောင်ကုဒ် 50,000 +သူငယ်ချင်း5ယောက်ကိုtagတွဲရန်” clone nickname၊ virtual FB ကိုထည့်မတွက်ပါဘူး။ သူငယ်ချင်း 200 သိုမဟုတ် ထိုထက်ပိုသော တကယ့် Facebook accပိုင်ရှင်များအတွက်သာ"
}
}
}
},
minibaucua: {
check_ball: "ဘောလုံးကိုစစ်ဆေးပါ။",
rebet: "ထပ်လောင်းပါ။",
accept: "လက်ခံပါတယ်။",
destroy: "မလုပ်တော့",
popup: {
guide_title: "လမ်းညွှန်",
history_title: "ငွေလွှဲမှတ်တမ်း",
honor_title: "ထိပ်တန်းကစားနည်းများ",
session: "အပိုင်း",
time: "အချိန်",
bet_position: "လောင်းကစားနေရာ",
result: "ရလဒ်",
bet: "လောင်းကစား",
return: "ပြန်လာ",
gain: "ယူ",
detail: "အသေးစိတ်",
rank: "အဆင့်",
account: "အကောင့်",
win: "နောက်ဆုံးအနိုင်"
},
his_detail: {
session: "အပိုင်း:",
day: "နေ့:",
result: "ရလဒ်:",
bau: "ဘူးသီ",
cua: "ဂဏန်း",
tom: "ပုဇွန်",
ca: "ငါး",
ga: "ကြက်သား",
huou: "သမင်"
},
toast: {
bet_fail: "အလောင်းအစားမအောင်မြင်",
unreach_bet_time: "လောင်းကစားရန်အချိန်မရောက်သေးပါ။",
over_bet_time: "လောင်းကြေးအချိန်ကုန်",
not_enough_gold: "လက်ကျန်မလုံလောက်။",
bet_success: "အလောင်းအစားအောင်မြင်",
action_too_quick: "လုပ်ဆောင်ချက်က အရမ်းမြန်တယ်။",
bet_no_position: "လောင်းကြေးမသတ်မှတ်ထားဘူး။",
no_bet_last_session: "သင်သည် ယခင်ဆက်ရှင်ကို မလောင်းရသေးပါ။",
no_bet_before: "မင်းအရင်က လောင်းကြေးမချဖူးဘူး။",
only_rebet_in_first_time: "ပထမလောင်းကြေးအတွက်သာ သင်ပြန်လည်သတ်မှတ်နိုင်ပါသည်။"
}
},
caothap: {
play: "ကစားပါ။",
stop: "ရပ်",
popup: {
guide_title: "လမ်းညွှန်",
history_title: "သမိုင်း",
honor_title: "ဂုဏ်ထူးများ",
session: "အပိုင်း",
time: "အချိန်",
bet: "လောင်းကစား",
step: "အဆင့်",
result: "ရလဒ်",
bet_door: "လောင်းကစားနေရာ",
win: "နောက်ဆုံးအနိုင်",
account: "အကောင့်",
bet_level: "လောင်းကြေးအဆင့်",
status: "အဆင့်အတန်း",
jackpot: "Jackpot",
big_win: "နောက်ဆုံးအနိုင်ကြီး",
high: "High",
low: "Low"
},
toast: {
not_enough_gold: "လက်ကျန်ငွေ မလုံလောက်ပါ၊ ငွေဖြည့်ပါ။",
you_loose: "သင်ရှုံးသည်! နောက်တစ်ကြိမ် ကံကောင်းပါစေ။",
congratulations: "ဂုဏ်ယူပါသည်။ မင်းအနိုင်ရခဲ့တယ်!",
gold: "ရွှေ",
click_to_start_game: 'ဂိမ်းစတင်ရန် "Play" ကိုနှိပ်ပါ။',
action_too_quick: "မင်းလုပ်ရပ်က အရမ်းမြန်တယ်။",
not_enough_gold_at_bet_level: "ဤလောင်းကြေးကိုကစားရန် သင့်တွင် ငွေအလုံအလောက်မရှိပါ။"
}
},
longho: {
dragon: "နဂါး",
tiger: "ကျား",
draw: "ဆွဲသည်။",
tai: "ကြီးတယ်။",
xiu: "အငယ်",
black: "အနက်ရောင်",
red: "အနီေရာင်",
session: "အပိုင်း",
menu: {
exit: "ထွက်ပေါက်",
rule: "စည်းကမ်း",
history: "သမိုင်း",
rank: "အဆင့်"
},
popup: {
chat_title: "စကားစမြည်",
playing_people_title: "တွဲကစားသူတွေ",
check_ball_title: "လက်ရှိ စက်ရှင်အသေးစိတ်",
guide_title: "လမ်းညွှန်",
history_title: "ငွေလွှဲမှတ်တမ်း",
rank_title: "ထိပ်တန်းအောင်နိုင်သူ",
chat_placeholder: "စကားစမြည်",
exit_table: "စားပွဲမှထွက်ပါ။",
history: "သမိုင်း",
rule: "စည်းကမ်း",
rank: "အဆင့်",
title_statitics: "statitics",
title_count_statitics: "Count statitics",
title_dishroad: "Dish road",
title_bigroad: "Big road",
nick_name: "အမည်ပြောင်",
bet_door: "လောင်းကစား",
money: "ပိုက်ဆံ",
time: "အချိန်",
session: "အပိုင်း",
bet_money: "လောင်းကြေးငွေ",
win_money: "ပိုက်ဆံအနိုင်ရ",
result: "ရလဒ်",
dragon: "နဂါး",
tiger: "ကျား",
no: "အမိန့်",
user_name: "အသုံးပြုသူအမည်",
play_together: "အသုံးပြုသူများ အတူတူကစားပါ။"
},
toast: {
no_chat_permission: "*** သင့်တွင် Chat ရန်ခွင့်ပြုချက်မရှိပါ။",
banned_chat: "*** Chat မှ ခေတ္တ ပိတ်ပင်ထားသည်။",
too_long_chat_content: "*** ချတ်အကြောင်းအရာသည် ရှည်လွန်းသည်။",
banned_chat_to: "သင် chat ခြင်းကို ပိတ်ပင်ထားသည်။",
serverr_busy_try_later: "စနစ်က အလုပ်ရှုပ်နေတယ်၊ ​​ကျေးဇူးပြုပြီး နောက်မှ ထပ်ကြိုးစားပါ။",
not_enough_gold: "အကောင့်လက်ကျန်ငွေသည် လောင်းရန်မလုံလောက်ပါ။",
bet_too_small: "လောင်းကြေးပမာဏသည် အလွန်သေးငယ်သည်။",
only_allow_bet_dragon_or_tiger: "သင်သည် Dragon သို့မဟုတ် Tiger တွင်လောင်းရန်နေရာဖြစ်သည်။",
only_alow_bet_red_or_black_dragon: "Dragon-Red သို့မဟုတ် Dragon-Black တံခါး 2 ခုအနက်မှ တစ်ခုသာ လောင်းနိုင်သည်။",
only_alow_bet_tai_or_xiu_dragon: "Dragon-Big သို့မဟုတ် Dragon-Small တံခါး 2 ခုအနက်မှ တစ်ခုသာ လောင်းနိုင်သည်။",
only_alow_bet_red_or_black_tiger: "ကျား-အနီ သို့မဟုတ် ကျား-အနက်ရောင် တံခါး 2 ပေါက်မှ တစ်ခုသာ လောင်းနိုင်သည်။",
only_alow_bet_tai_or_xiu_tiger: "တံခါး 2 ပေါက်အနက်မှ Tiger-Big သို့မဟုတ် Tiger-Small တွင်သာ လောင်းနိုင်သည်။",
start_return_reward: "စတင်ပေးဆပ်လိုက်ပါ။",
start_bet_door: "စတင်လောင်းကြေး",
not_in_bet_time: "ယခုအချိန်သည် လောင်းကစားရန် အချိန်မဟုတ်ပေ။",
please_choose_bet: "ကျေးဇူးပြု၍ အလောင်းအစားကို ရွေးချယ်ပါ။",
over_time_bet: "လောင်းကြေးအချိန်ထွက်",
not_enough_gold1: "လက်ကျန်မလုံလောက်"
}
},
minilongho: {
accept: "လက်ခံပါတယ်။",
destroy: "မလုပ်တော့",
bet_dragon: "လောင်ကြေး နဂါး",
bet_draw: "လောင်ကြေး သရေ",
bet_tiger: "လောင်ကြေး ကျား",
dragon: "နဂါး",
tiger: "ကျား",
draw: "ဆွဲသည်။",
big_road: "Big လမ်း",
disk_road: "Disk လမ်း",
top_bet: "ထိပ်တန်းလောင်း",
total_game: "စုစုပေါင်းဂိမ်း",
popup: {
guide_title: "လမ်းညွှန်",
history_title: "သမိုင်း",
honor_title: "ထိပ်တန်းအနိုင်ရ",
session: "အပိုင်း",
bet_door: "လောင််းကြေးချပါ",
bet: "လောင်းကစား",
time: "အချိန်",
win: "နောက်ဆုံးအနိုင်",
result: "ရလဒ်",
no: "အော်ဒါနံပါတ်",
account: "အကောင့်",
bet_money: "လောင်းကြေးငွေ",
win_money: "ပိုက်ဆံအနိုင်ရ"
},
toast: {
start_new_game: "ဂိမ်းအသစ်တစ်ခု စတင်ပါ။",
start_return_reward: "စတင်ပေးဆပ်လိုက်ပါ။",
have_err_betting: "လောင်းကစားလုပ်ငန်းစဉ်အတွင်း အမှားအယွင်းတစ်ခုရှိခဲ့သည်။",
minimum_bet: "လောင်းကြေးပမာဏ 1,000 ထက်ပိုရပါမည်။",
not_enough_gold: "လက်ကျန်မလုံလောက်ဘူး။",
over_bet_time: "လောင်းကြေးကျော်ချိန်",
not_in_bet_time: "လောင်းကစားရန်အချိန်မရောက်သေးပါ။"
}
},
minipoker: {
auto_spin: "အလိုအလျောက်လှည့်ခြင်း။",
play_gold: "ရွှေကစားပါ။",
play_chip: "အကြွေစေ့ကစားပါ။",
popup: {
guide_title: "လမ်းညွှန်",
history_title: "ငွေလွှဲမှတ်တမ်း",
honor_title: "ဦးဆောင်သူ",
time: "အချိန်",
bet: "တန်း",
type: "ကတ်အုပ်စု",
win: "နောက်ဆုံးအနိုင်",
account: "အကောင့်",
straight: "Straight",
pair_j: "Pair of J++",
full_house: "Full House",
two_pair: "Two Pair",
flush: "Flush",
three_of_a_kind: "Three of a kind",
straight_flush: "Straight Flush",
jackpot: "Jackpot",
four_of_a_kind: "Four of a kind"
},
toast: {
action_too_quick: "မင်းလုပ်ရပ်က မြန်လွန်းတယ်။",
not_enough_gold: "လက်ကျန်ငွေ မလုံလောက်ပါ၊ ငွေဖြည့်ပါ။",
error_try_later: "အမှားအယွင်းဖြစ်သွားသည်၊ ကျေးဇူးပြု၍ နောက်မှထပ်ကြိုးစားပါ။",
game_in_auto_spin: "ဂိမ်းသည် အလိုအလျောက်လှည့်ခြင်းမုဒ်တွင်ရှိသည်။"
}
},
pokemon: {
line: "လိုင်း",
spin: "လှည့်သည်",
autoSpin: "အော်တိုလှည့်",
stop: "ရပ်",
popup: {
detail_title: "အလောင်းအစားအသေးစိတ်",
guide_title: "လမ်းညွှန်",
history_title: "ကစားမှတ်တမ်း",
honor_title: "ဂုဏ်ထူးများ",
select_line_title: "လိုင်းကိုရွေးပါ။",
session: "အပိုင်း",
time: "အချိန်",
bet_level: "အလောင်းအစားအဆင့်",
bet_line: "လောင်းကြေးလိုင်း",
bet: "လောင်းကစား",
gain_gift: "ဆုလာဘ်တစ်ခုရယူပါ။",
room: "အခန်း",
detail: " အသေးစိတ်",
account: "အကောင့်",
status: "အဆင့်အတန်း",
win: "နောက်ဆုံးအနိုင်",
unselect: "ရွေးဖြုတ်ပါ။",
even_line: "စုံ လိုင်း",
odd_line: "မ လိုင်း",
all_line: "အားလုံး",
line_win: "နောက်ဆုံးအနိုင်လိုင်း",
jackpot: "Jackpot",
big_win: "နောက်ဆုံးအနိုင်ကြီး"
},
toast: {
action_too_quick: "မင်းလုပ်ရပ်က မြန်လွန်းတယ်။",
not_enough_gold: "ဒင်္ဂါးများ မလုံလောက်ပါ၊ ကျေးဇူးပြု၍ ငွေဖြည့်ပါ။",
error_try_again: "အမှားဖြစ်သွားသည်၊ ကျေးဇူးပြု၍ နောက်မှ ထပ်ကြိုးစားပါ။",
connecting_server: "ဆာဗာသို့ ချိတ်ဆက်နေသည်။"
}
},
slot_avengers: {
unhappen: "ဖြစ်မလာသေးဘူး။",
music: "ဂီတ",
sound: "အသံ",
win: "နောက်ဆုံးအနိုင်",
total_bet: "လောင်းကြေး",
autoSpin: "အော်တိုလှည့်",
line: "လိုင်း",
bet: "လောင်းကစား",
play_trial: "အစမ်းကစားပါ။",
play_real: "တီးပါ။",
popup: {
jackpot_history_title: "Jackpot မှတ်တမ်း",
choose_line_title: "လိုင်းရွေးပါ။",
trade_history_title: "ငွေလွှဲမှတ်တမ်း",
x2_win_title: "X2 ဘောနပ်စ်",
time: "အချိန်",
level: "အဆင့်",
jackpot: "Jackpot",
account: "အကောင့်",
result: "ရလဒ်",
session: "အပိုင်း",
line_bet: "လောင်းကြေးလိုင်း",
line_win: "နောက်ဆုံးအနိုင်လိုင်း",
receive_gold: "ရွှေလက်ခံ",
even_line: "စာကြောင်းပင်း",
odd_line: "မျဉ်းကြောင်းများ",
all_line: "လိုင်းအားလုံး",
re_select: "ပြန်လည်သတ်မှတ်ပါ။",
big_win: "နောက်ဆုံးအနိုင်ကြီး",
choose_pearl: "ပုလဲကို ရွေးပါ။",
congratulations: "မင်းနောက်ဆုံးအနိုင်",
jackpotx2: "Jackpot x2"
},
toast: {
need_choose_minimum_1_line: "အနည်းဆုံး 1 လိုင်းကို ရွေးချယ်ရပါမည်။",
function_dont_work_in_trial: "ဤအင်္ဂါရပ်သည် အစမ်းသုံးမုဒ်တွင် အလုပ်မလုပ်ပါ။",
off_auto_spin_to_leave: "ဇယားမှထွက်ရန် AUTO လှည့်ခြင်းကို ပိတ်ပါ။",
function_in_develop: "လုပ်ဆောင်ချက်တွေ ဖွံ့ဖြိုးလာပါတယ်။",
not_enough_gold: "လက်ကျန်ငွေ မလုံလောက်ပါ၊ ငွေဖြည့်ပါ။",
error_try_again: "အမှားဖြစ်သွားသည်၊ ကျေးဇူးပြု၍ ထပ်စမ်းကြည့်ပါ။"
}
},
slot_dancing_girls: {
holdToSpin: "သင်ကိုယ်တိုင်လှည့်ရန် ကိုင်ထားပါ။",
unhappen: "ဖြစ်မလာသေးဘူး။",
music: "ဂီတ",
sound: "အသံ",
win: "နောက်ဆုံးအနိုင်",
total_bet: "လောင်းကြေး",
autoSpin: "အော်တိုလှည့်",
line: "လိုင်း",
bet: "လောင်းကစား",
play_trial: "အစမ်းကစားပါ။",
play_real: "တီးပါ။",
popup: {
jackpot_history_title: "Jackpot မှတ်တမ်း",
choose_line_title: "လိုင်းရွေးပါ။",
trade_history_title: "ငွေလွှဲမှတ်တမ်း",
x2_win_title: "X2 ဘောနပ်စ်",
guide_title: "ဆုပေးပွဲ",
time: "အချိန်",
level: "အဆင့်",
jackpot: "Jackpot",
account: "အကောင့်",
result: "ရလဒ်",
session: "အပိုင်း",
line_bet: "လောင်းကြေးလိုင်း",
line_win: "နောက်ဆုံးအနိုင်လိုင်း",
receive_gold: "ရွှေလက်ခံ",
even_line: "စာကြောင်းပင်း",
odd_line: "မျဉ်းကြောင်းများ",
all_line: "လိုင်းအားလုံး",
re_select: "ပြန်လည်သတ်မှတ်ပါ။",
big_win: "နောက်ဆုံးအနိုင်ကြီး",
choose_pearl: "ပုလဲကို ရွေးပါ။",
congratulations: "မင်းနောက်ဆုံးအနိုင်",
jackpotx2: "Jackpot x2"
},
toast: {
need_choose_minimum_1_line: "အနည်းဆုံး 1 လိုင်းကို ရွေးချယ်ရပါမည်။",
function_dont_work_in_trial: "ဤအင်္ဂါရပ်သည် အစမ်းသုံးမုဒ်တွင် အလုပ်မလုပ်ပါ။",
off_auto_spin_to_leave: "ဇယားမှထွက်ရန် AUTO လှည့်ခြင်းကို ပိတ်ပါ။",
function_in_develop: "လုပ်ဆောင်ချက်တွေ ဖွံ့ဖြိုးလာပါတယ်။",
not_enough_gold: "လက်ကျန်ငွေ မလုံလောက်ပါ၊ ငွေဖြည့်ပါ။",
error_try_again: "အမှားဖြစ်သွားသည်၊ ကျေးဇူးပြု၍ ထပ်စမ်းကြည့်ပါ။"
}
},
slotdechemaya: {
unhappen: "ဖြစ်မလာသေးဘူး။",
music: "ဂီတ",
sound: "အသံ",
last_win: "နောက်ဆုံးအနိုင်",
total_bet: "လောင်းကြေး",
play_trial: "အစမ်းကစားပါ။",
play_real: "တီးပါ။",
line: "လိုင်း",
spin: "လှည့်သည်",
autoSpin: "အော်တိုလှည့်",
stop: "ရပ်",
bet: "လောင်းကစား",
popup: {
choose_line_title: "လိုင်းရွေးပါ။",
x2_win_title: "X2 ဘောနပ်စ်",
guide_title: "ဆုပေးပွဲ",
jackpot_history_title: "Jackpot မှတ်တမ်း",
trade_history_title: "ငွေလွှဲမှတ်တမ်း",
even_line: "စာကြောင်းပင်း",
odd_line: "မျဉ်းကြောင်းများ",
all_line: "လိုင်းအားလုံး",
re_line: "ပြန်လည်သတ်မှတ်ပါ။",
line_bet: "လောင်းကြေးလိုင်း",
line_win: "နောက်ဆုံးအနိုင်လိုင်း",
chose_room_title: "အခန်းရွေးပါ။",
resident: "နေထိုင်သူ",
leader: "ခေါင်းဆောင်",
boss: "သူဌေး",
honor_title: "ဂုဏ်ပြုပါ။",
congratulations_account: "ဂုဏ်ယူပါတယ်အကောင့်",
remain_turn: "လှည့်နေပါ။",
total_score: "စုစုပေါင်းရမှတ်",
lucky_box_title: "ကံကောင်းသောသေတ္တာ",
you_win: "မင်းနောက်ဆုံးအနိုင်",
time: "အချိန်",
level: "အဆင့်",
jackpot: "Jackpot",
account: "အကောင့်",
result: "ရလဒ်",
session: "အပိုင်း",
detail: "အသေးစိတ်",
view: "အမြင်",
receive_gold: "ရွှေလက်ခံ",
jackpotx2: "Jackpot x2"
},
toast: {
function_dont_work_on_trial: "ဤလုပ်ဆောင်ချက်သည် အစမ်းသုံးမုဒ်တွင် အလုပ်မလုပ်ပါ။",
off_auto_spin_to_leave: "ဇယားမှထွက်ရန် AUTO လှည့်ခြင်းကို ပိတ်ပါ။",
funtion_in_develop: "လုပ်ဆောင်ချက်တွေ ဖွံ့ဖြိုးလာပါတယ်။",
not_enough_gold: "လက်ကျန်ငွေ မလုံလောက်ပါ၊ ငွေဖြည့်ပါ။",
spin_unsuccess: "လှည့်လို့ မအောင်မြင်ဘူး။",
unvalid_bet: "လောင်းကြေးမမှန်ကန်ပါ။",
unvalid_spin: "လှည့်ဖျားမှု မမှန်ကန်ပါ။",
error_try_again: "အမှားဖြစ်သွားသည်၊ ကျေးဇူးပြု၍ ထပ်စမ်းကြည့်ပါ။",
atleast_1_line: "အနည်းဆုံး 1 လိုင်းကို ရွေးချယ်ရပါမည်။"
}
},
slotkhobau: {
unhappen: "ဖြစ်မလာသေးဘူး။",
music: "ဂီတ",
sound: "အသံ",
bet: "လောင်းကစား",
total_bet: "လောင်းကြေး",
last_win: "နောက်ဆုံးအနိုင်",
hide: "ဖွက်ပါ။",
line: "လိုင်း",
autoSpin: "အော်တိုလှည့်",
popup: {
choose_line_title: "လိုင်းရွေးပါ။",
x2_win_title: "X2 ဘောနပ်စ်",
guide_title: "ဆုပေးပွဲ",
jackpot_history_title: "ဦးဆောင်သူ",
trade_history_title: "ငွေလွှဲမှတ်တမ်း",
time: "အချိန်",
level: "အဆင့်",
jackpot: "Jackpot",
account: "အကောင့်",
result: "ရလဒ်",
session: "အပိုင်း",
line_bet: "လိုင်း\nအလောင်းအစား",
line_win: "လိုင်း\nအနိုင်ရ",
receive_gold: "ရွှေလက်ခံ",
even_line: "စာကြောင်းပင်း",
odd_line: "မျဉ်းကြောင်းများ",
all_line: "လိုင်းအားလုံး",
re_select: "ပြန်လည်သတ်မှတ်ပါ။",
big_win: "နောက်ဆုံးအနိုင်ကြီး",
choose_pearl: "ပုလဲကို ရွေးပါ။",
you_win: "မင်းနောက်ဆုံးအနိုင်",
remain_turn: "လှည့်နေပါ။",
total_score: "စုစုပေါင်းရမှတ်",
click_to_exit: "ထွက်ရန် နှိပ်ပါ။",
minigame_title: "မီနီဂိမ်း ရတနာ"
},
toast: {
function_dont_work_on_trial: "ဤအင်္ဂါရပ်သည် အစမ်းသုံးမုဒ်တွင် အလုပ်မလုပ်ပါ။",
off_auto_spin_to_leave: "ဇယားမှထွက်ရန် AUTO လှည့်ခြင်းကို ပိတ်ပါ။",
funtion_in_develop: "လုပ်ဆောင်ချက်တွေ ဖွံ့ဖြိုးလာပါတယ်။",
not_enough_gold: "လက်ကျန်ငွေ မလုံလောက်ပါ၊ ငွေဖြည့်ပါ။",
spin_unsuccess: "လှည့်လို့ မအောင်မြင်ဘူး။",
unvalid_bet: "လောင်းကြေးမမှန်ကန်ပါ။",
unvalid_spin: "လှည့်ဖျားမှု မမှန်ကန်ပါ။",
error_try_again: "အမှားဖြစ်သွားသည်၊ ကျေးဇူးပြု၍ ထပ်စမ်းကြည့်ပါ။",
atleast_1_line: "အနည်းဆုံး 1 လိုင်းကို ရွေးချယ်ရပါမည်။"
}
},
MiniHoaQua: {
big_win: "နောက်ဆုံးအနိုင်ကြီး",
jackpot: "Jackpot",
line: "လိုင်း",
spin: "လှည့်ဖျားသည်။",
autoSpin: "အော်တိုလှည့်",
stop: "ရပ်",
popup: {
detail_title: "အလောင်းအစားအသေးစိတ်",
guide_title: "ဆုပေးပွဲ",
history_title: "ငွေလွှဲမှတ်တမ်း",
honor_title: "ထိပ်တန်းကစားနည်းများ",
select_line_title: "လိုင်းကိုရွေးပါ။",
session: "အပိုင်း",
time: "အချိန်",
bet_level: "အလောင်းအစား",
bet_line: "လောင်းကြေးလိုင်း",
bet: "လောင်းကစား",
gain_gift: "ဆုလာဘ်တစ်ခုရယူပါ။",
room: "အခန်း",
detail: "အသေးစိတ်",
account: "အကောင့်",
status: "အဆင့်အတန်း",
win: "နောက်ဆုံးအနိုင်",
unselect: "ရွေးဖြုတ်ပါ။",
even_line: "စာကြောင်းပင်း",
odd_line: "မျဉ်းကြောင်းများ",
all_line: "လိုင်းအားလုံး",
line_win: "နောက်ဆုံးအနိုင်လိုင်း"
},
toast: {
action_too_quick: "လုပ်ဆောင်ချက်က အရမ်းမြန်တယ်။",
not_enough_gold: "လက်ကျန်ငွေ မလုံလောက်ပါ၊ ငွေဖြည့်ပါ။",
error_try_again: "အမှားဖြစ်သွားသည်၊ ကျေးဇူးပြု၍ ထပ်စမ်းကြည့်ပါ။",
connecting_server: "ဆာဗာသို့ ချိတ်ဆက်နေသည်။",
you_need_choose_at_least_1_line: "အနည်းဆုံး 1 လိုင်းကို ရွေးချယ်ရပါမည်။"
}
},
slotnudiepvien: {
unhappen: "ဖြစ်မလာသေးဘူး။",
music: "ဂီတ",
sound: "အသံ",
last_win: "နောက်ဆုံးအနိုင်",
total_bet: "လောင်းကြေး",
play_trial: "အစမ်းကစားပါ။",
play_real: "တီးပါ။",
line: "လိုင်း",
bet_level: "အလောင်းအစား",
popup: {
choose_line_title: "လိုင်းရွေးပါ။",
x2_win_title: "X2 ဘောနပ်စ်",
guide_title: "ဆုပေးပွဲ",
jackpot_history_title: "ဦးဆောင်သူ",
trade_history_title: "ငွေလွှဲမှတ်တမ်း",
even_line: "စာကြောင်းပင်း",
odd_line: "မျဉ်းကြောင်းများ",
all_line: "လိုင်းအားလုံး",
re_line: "ပြန်လည်သတ်မှတ်ပါ။",
line_bet: "လောင်းကြေးလိုင်း",
line_win: "နောက်ဆုံးအနိုင်လိုင်း",
chose_room_title: "အခန်းရွေးပါ။",
resident: "နေထိုင်သူ",
leader: "ခေါင်းဆောင်",
boss: "သူဌေး",
honor_title: "ဂုဏ်ပြုပါ။",
congratulations_account: "ဂုဏ်ယူပါတယ်အကောင့်",
remain_turn: "လှည့်နေပါ။",
total_score: "စုစုပေါင်းရမှတ်",
lucky_box_title: "ကံကောင်းသောသေတ္တာ",
you_win: "မင်းနောက်ဆုံးအနိုင်",
time: "အချိန်",
level: "အဆင့်",
jackpot: "Jackpot",
account: "အကောင့်",
result: "ရလဒ်",
session: "အပိုင်း",
detail: "အသေးစိတ်",
view: "အမြင်",
receive_gold: "ရွှေလက်ခံ",
jackpotx2: "Jackpot x2",
minigame_title: "လုပ်ဆောင်ချက်မျိုးစုံ ခရီးဆောင်အိတ်",
extra_turns: "အပိုလှည့်"
},
toast: {
function_dont_work_on_trial: "ဤအင်္ဂါရပ်သည် အစမ်းသုံးမုဒ်တွင် အလုပ်မလုပ်ပါ။",
off_auto_spin_to_leave: "ဇယားမှထွက်ရန် AUTO လှည့်ခြင်းကို ပိတ်ပါ။",
funtion_in_develop: "လုပ်ဆောင်ချက်တွေ ဖွံ့ဖြိုးလာပါတယ်။",
not_enough_gold: "လက်ကျန်ငွေ မလုံလောက်ပါ၊ ငွေဖြည့်ပါ။",
spin_unsuccess: "လှည့်လို့ မအောင်မြင်ဘူး။",
unvalid_bet: "လောင်းကြေးမမှန်ကန်ပါ။",
unvalid_spin: "လှည့်ဖျားမှု မမှန်ကန်ပါ။",
error_try_again: "အမှားဖြစ်သွားသည်၊ ကျေးဇူးပြု၍ ထပ်စမ်းကြည့်ပါ။",
atleast_1_line: "အနည်းဆုံး 1 လိုင်းကို ရွေးချယ်ရပါမည်။"
}
},
SlotTreeOfFortune: {
main: {
total_bet: "လောင်းကြေး",
total_win: "နောက်ဆုံးအနိုင်",
music: "ဂီတ",
sound: "အသံ"
},
choose_line: {
title: "လိုင်းကို ရွေးပါ။",
even_line: "စာကြောင်းပင်း",
odd_line: "မျဉ်းကြောင်းများ",
all_line: "လိုင်းအားလုံး",
re_line: "ပြန်ရွေးပါ။"
},
mini_game: {
notice: "တုန်ခါရန် သစ်ပင်ကို နှိပ်ပါ။",
close: "ပိတ်လိုက်",
you_get: "မင်းလက်ခံတယ်။",
time_left: "ကျန်ရှိသောအချိန်:",
score: "အားသွင်းအချက်များ"
},
history: {
title: "သမိုင်း",
phien: "အပိုင်း",
time: "အချိန်",
muc: "အဆင့်",
line_bet: "လောင်းကြေးလိုင်း",
line_win: "နောက်ဆုံးအနိုင်လိုင်း",
gold_receive: "ရွှေ"
},
top: {
title: "ထိပ်တန်း",
time: "အချိန်",
muc: "အဆင့်",
jackpot: "JACKPOT",
account: "အကောင့်",
result: "ရလဒ်",
nohu: "JACKPOT"
},
guide: "လမ်းညွှန်",
message: {
message1: "ဤအင်္ဂါရပ်သည် အစမ်းသုံးမုဒ်တွင် အလုပ်မလုပ်ပါ။",
message2: "နေ့စဥ်လှည့်ခြင်းသည် အလိုအလျောက် မှတ်တမ်းကို အသုံးမပြုနိုင်ပါ။",
message3: "မင်းအခန်းပြောင်းနေတယ်၊ ခဏစောင့်",
message4: "သင်ရိုက်ကူးနေသည်၊ မှတ်တမ်းတင်ခြင်းပြီးဆုံးရန်စောင့်ဆိုင်းပါ။",
message5: "စနစ်က လုပ်ဆောင်နေသည်၊ ကျေးဇူးပြု၍ စောင့်ပါ။",
message6: "သင်သည် အစမ်းသုံးမုဒ်တွင် ရှိနေသည်၊ မည်သည့်လိုင်းကိုမျှ မရွေးချယ်ပါ။",
message7: "သင့်တွင် အခမဲ့လှည့်ခြင်းများ ရှိပါသည်။",
message8: "သင်သည် အလိုအလျောက် မှတ်တမ်းတင်နေပါသည်။",
message9: "မှတ်တမ်းတင်ခြင်း မအောင်မြင်ပါ။",
unvalid_bet: "လောင်းကြေးမမှန်ကန်ပါ။",
message11: "မင်းမှာ ပိုက်ဆံမလောက်ဘူး။",
unvalid_spin: "လှည့်ဖျားမှု မမှန်ကန်ပါ။",
message13: "နောက်တစ်ကြိမ် ကံကောင်းပါစေ။",
message14: "အနည်းဆုံး 1 လိုင်းကို ရွေးချယ်ရပါမည်။"
}
},
lodenormal: {
betted: "လောင်းကစား",
betting: "လောင်းကစား",
bet: "လောင်းကစား",
winned: "ဝမ်",
eat: "နောက်ဆုံးအနိုင်",
de: "တရ",
lo: "အကယ်",
de_3_num: "တရ ၃",
de_first: "De ပဌမ",
de_last: "De နောက်ဆုံး",
lo_through_2: "2 Lo Parlay",
lo_through_3: "3 Lo parlay",
lo_through_4: "4 Lo parlay",
lo_fail_10: "လော်ပြတ် ၁၀",
de_group: "De group",
no_group: "နံပါတ်အဖွဲ့",
couple_number: "စုံတွဲနံပါတ်",
rate_number: "ကိန်းဂဏန်း",
group: "အဖွဲ့",
double_group: "နှစ်ထပ်အုပ်စု",
double_type: "နှစ်ထပ်အမျိုးအစားအုပ်စု",
type_double: "နှစ်ထပ်အမျိုးအစား",
type_double1: "နှစ်ချက်ရိုက်ပါ။",
num_lo_de_group: "Lo de နံပါတ်အဖွဲ့",
animal_designation_12: "တိရိစ္ဆာန်သတ်မှတ်ခြင်း ၁၂",
double_similar: "နှစ်ထပ်တူ",
double_dif: "နှစ်ဆကွာခြားမှု",
de_sum: "တရလဒ်",
special: "အထူး",
first_prize: "ပထမဆု",
second_prize: "ဒုတိယဆု",
third_prize: "တတိယဆု",
fourth_prize: "စတုတ္ထဆု",
fifth_prize: "၅ ကြိမ်မြောက်ဆု",
sixth_prize: "ဆဋ္ဌမဆု",
seventh_prize: "သတ္တမဆု",
north_lottery: "မြောက်ပိုင်း ထီ",
last_second: "စက္ကန့်ပိုင်းလောက်က",
last_minute: "လွန်ခဲ့သော မိနစ်က",
last_hour: "နာရီအတော်ကြာခဲ့ပြီ",
last_day: "မနေ့က",
last_month: "ပြီးခဲ့သည့်လ",
last_year: "မနှစ်က",
rat: "ကြွက်",
ox: "နွား",
tiger: "ကျား",
cat: "ကြောင်",
dragon: "နဂါး",
snake: "မြွေ",
horse: "မြင်း",
goat: "ဆိတ်သား",
monkey: "မျောက်",
rooster: "ကြက်ဖ",
dog: "ခွေး",
pig: "ဝက်",
popup: {
month: "လ",
year: "တစ်နှစ်",
end_bet_title: "သတင်းအချက်အလက်",
inputbet_title: "ငွေထည့်ပါ။",
choose_de_num_title: "De နံပါတ်ကို ရွေးပါ။",
choose_lo_num_title: "Lo နံပါတ်ကို ရွေးပါ။",
de_3_num_title: "တရ ၃",
choose_de_group_title: "De group ကို ရွေးပါ။",
choose_lo_through_2: "2 Lo parlay ကိုရွေးချယ်ပါ။",
choose_lo_through_3: "3 Lo parlay ကိုရွေးချယ်ပါ။",
choose_lo_through_4: "4 Lo parlay ကိုရွေးချယ်ပါ။",
choose_lo_fail_10: "Lo fail 10 ကိုရွေးပါ။",
choose_num_group_12: "နံပါတ်အုပ်စု 12 တိရိစ္ဆာန်သတ်မှတ်ခြင်းကိုရွေးချယ်ပါ။",
choose_double_similar: "De double အလားတူ",
double_similar_detail: " ဂဏန်းများအစု- ၀၀၊ ၁၁၊ ၂၂၊ ၃၃၊ ၄၄၊ ၅၅၊ ၆၆၊ ၇၇၊ ၈၈၊ ၉၉",
choose_double_dif: "De group double diff ကို ရွေးပါ။",
choose_de_sum_title: "De group sum ကို ရွေးပါ။",
confirm: "အတည်ပြုပါ။",
reject: "မလုပ်တော့",
bet: "လောင်းကစား",
bet_num: "လောင်းကြေး",
bet_money: "လောင်းကြေးငွေ",
bet_money_total: "လောင်းကြေးငွေ",
win_total: "စုစုပေါင်းအနိုင်ရ",
de: "တရ",
lo: "အကယ်",
end_bet_warning: "သင်၏လောင်းကြေးအချက်အလက်ကို အတည်ပြုပါ။",
bet_money_total1: "စုစုပေါင်း သတ်မှတ်ပမာဏ",
input_bet_placeholder: "ပမာဏကိုထည့်ပါ။",
input_num_placeholder: "နံပါတ်ထည့်ပါ။",
gold: "ရွှေ",
bet_total: "လောင်းကြေး",
time_warning: "အချိန် 18:10 မှ 18:45 (ဗီယက်နမ်စံတော်ချိန်) သည် ဆုထုတ်ယူခြင်းနှင့် ပေးချေရမည့်အချိန်ဖြစ်သည်၊ ဤကာလအတွင်း ကျွန်ုပ်တို့သည် အလောင်းအစားများကို လက်မခံပါ။"
},
warning: {
bet_success: "အောင်မြင်သောလောင်းကြေး။",
invalid_bet: "မမှန်ကန်သောလောင်းကြေးပမာဏ",
error_in_betting: "လောင်းကြေးတင်ရာတွင် အမှားအယွင်းတစ်ခုရှိခဲ့သည်။",
cant_bet_this_time: "ဤကာလအတွင်း လောင်းကြေးမတင်နိုင်ပါ။",
not_enough_gold: "သင့်တွင် လက်ကျန်ငွေ မလုံလောက်ပါ။",
please_choose_bet: "ကျေးဇူးပြု၍ သင်၏အလောင်းအစားအဆင့်ကို ရွေးချယ်ပါ။",
server_stop_spin_and_return_reward: "ယနေ့စနစ်သည် လည်ပတ်မှုရပ်သွားပြီး ငွေပေးချေမှု ရပ်တန့်သွားပါသည်။",
please_cash_in_before_bet: "ကျေးဇူးပြု၍ အလောင်းအစားမတင်မီ ငွေသွင်းပါ။",
please_choose_no_bet: "ကျေးဇူးပြု၍ လောင်းကြေးနံပါတ်ကို ရွေးပါ။",
please_choose_bet_money: "သင့်လောင်းကြေးပမာဏကို ရွေးချယ်ပါ။",
over_bet_bound: "သတ်မှတ်ကန့်သတ်ချက် ကျော်လွန်သွားပြီ",
only_can_bet: "အလောင်းအစားလုပ်လို့ရတယ်။",
gold: "ရွှေ",
no: "နံပါတ်",
error_in_betting_door: "လောင်းကြေးထည့်သည့်လုပ်ငန်းစဉ်တွင် အမှားအယွင်းရှိသည်။"
}
},
xeng: {
title_help: "လမ်းညွှန်",
title_transaction: "ငွေလွှဲမှတ်တမ်း",
title_top: "ထိပ်တန်းလောင်းကစားများ",
title_session: "အပိုင်း",
title_time: "အချိန်",
title_side: "လောင်းကစားတံခါး",
title_result: "ရလဒ်",
title_bet: "လောင်းကစား",
title_reward: "လက်ခံသည်။",
title_stt: "အမိန့်",
title_account: "အကောင့်",
title_gold: "ရွှေ",
bet_phase: "စတင်လောင်းကြေး။",
result_phase: "အလောင်းအစားအချိန်ကုန်။",
bet_success: "အောင်မြင်သောလောင်းကြေး။",
bet_invalid_money: "လောင်းကြေးမမှန်ကန်ပါ။",
bet_not_enough_money: "လက်ကျန်မလုံလောက်ဘူး။",
bet_fail: "အလောင်းအစား မအောင်မြင်ပါ။"
},
card_game_52: {
tlmn_title: "တောင်ပိုင်းဆယ့်သုံးကတ်",
sam_title: "ငရဲ",
binh_title: "တရုတ်ဖဲချပ်",
bacay_title: "သုံးကတ်",
poker_title: "Poker",
xizach_title: "Xì Zách",
baicao_title: "Bài Cào",
sort_card: "ကတ်စီခြင်း",
hit_card: "Submit",
next_turn: "Cancel တ",
bao_sam: "အစီရင်ခံကတ်",
huy_sam: "အစီရင်ခံစာကတ်ကို ပယ်ဖျက်ပါ။",
watting_for_start_game: "ဂိမ်းအသစ် စတင်ရန် စောင့်နေသည်။ ",
table: "စားပွဲ: ",
bet_money: "လောင်းကြေးငွေ: ",
viewing: "စောင့်ကြည့်",
chat_place_holder: "ရိုက်ပါ။",
invite_game: "ကစားဖို့ ဖိတ်ခေါ်ပါတယ်။",
no_one_invite: "သင့်လျော်သောကစားသမားမရှိပါ။",
not_open: "လုပ်ဆောင်ချက်ကို ခေတ္တမဖွင့်ပါ။",
create_room: "ဇယားဖန်တီးပါ။",
create_room_place_holder: "အခန်းနာမည်",
play_now: "ယခုကစားပါ။",
refresh_room: "ပြန်လည်ဆန်းသစ်ပါ။",
choose_bet_value: "ရွေးချယ်ပါ။",
player: "ဘာညာ",
password_room: "အခန်းစကားဝှက်",
buy_in: "ဝယ်ပါ။",
auto_buy_in: "ချစ်ပ်များကုန်သွားသောအခါ အလိုအလျောက်ဝယ်ယူပါ။",
result: "ရလဒ်",
confirm: "အတည်ပြုပါ။",
dang_ki_exit_success: "မင်း အခန်းထဲက ထွက်ဖို့ အောင်မြင်စွာ စာရင်းသွင်းပြီးပြီ!",
huy_dang_ki: "အခန်းမှထွက်ခြင်းကို သင်ပယ်ဖျက်လိုက်ပါပြီ။",
first_turn: " ပထမအလှည့်!",
no_select_card: "သင့်တွင် ရွေးချယ်ထားသောကတ် မရှိပါ။",
card_avaiable_found: "ရရှိနိုင်သောကတ်ကို တွေ့ရှိခဲ့သည်။",
time_bet: "Time bet",
reg_buyin: "ဝယ်ရန် မှတ်ပုံတင်ထားသည်",
unreg_buyin: "စာရင်းသွင်းမှုတွင် ဝယ်ယူမှုကို ပယ်ဖျက်ပါ",
play_tour: "Tournament",
play_normal: "Normal",
not_enough_gold: "The coins is not enough, please top up",
tlmn: {
chat_1: "မင်း မလုပ်နိုင်ဘူး!",
chat_2: "ငါ့ကို ကြိုက်တာပေးပါ!",
chat_3: "ကျေးဇူးတင်ပါတယ်!",
chat_4: "ကံကောင်းတယ်!",
chat_5: "အေး~",
chat_6: "ကံမကောင်း!",
chat_7: "ပိတ်ပြီ!!",
chat_8: "အိုး တောင်းပန်ပါတယ်!",
chat_9: "အိုး၊ မဟုတ်ဘူး…",
chat_10: "ဒါကို ရပြီ!",
chat_11: "မင်းရှုံးလိမ့်မယ်!",
chat_12: "မြန်မြန်လုပ်!",
"အထူး_ရလဒ်_0": "DRAGON PARK",
special_result_1: "လေးလပတ် 2",
special_result_2: "ထင်းရှူး အတွဲ ၅ တွဲ",
special_result_3: "6 တွဲ",
"အထူး_ရလဒ်_4": "13 COLORS",
special_result_5: "12 COLORS",
"ရလဒ်_0": "TWO",
"ရလဒ်_1": "Double TWO",
"ရလဒ်_2": "3 TWO",
"ရလဒ်_3": "3 နှစ်ဆဆင့်",
"ရလဒ်_4": "4 နှစ်ဆဆင့်",
result_cong: "အေး",
result_batcong: "ဖမ်းဆွဲထားခြင်း",
result_toitrang: "အဖြူရောင်သွားပါ",
result_thuatoitrang: "ပျောက်"
},
sam: {
chat_1: "အဆင်သင့်ဖြစ်ပြီလား",
chat_2: "ဖမ်းဖို့ ဘယ်အသက်အရွယ်",
chat_3: "ဘဝက အိပ်မက်တစ်ခုလိုမဟုတ်ဘူး",
chat_4: "ကံကောင်းစွာဖြင့်",
chat_5: "အစားအစာစားပါ :v",
chat_6: "အရမ်းမည်းနေတယ်",
chat_7: "ဒါပေမယ့် ဂျင်ဆင်းကို တောင်းနေတုန်းပဲ",
chat_8: "သေ",
chat_9: "ပျင်းစရာကြီး",
chat_10: "ပျက်သေးလား?",
chat_11: "ပျောက်၊ ကလေး",
chat_12: "မြန်မြန်လုပ်ပါ အန်တီ",
special_6: "ထိပ်တန်းဂျင်ဆင်း",
special_7: "ဒုတိယသုံးလပတ်",
special_8: "ငါးနှစ်ဆ",
special_9: "အရောင်တူ",
special_4: "ဂျင်ဆင်းတုံး",
special_16: "မအောင်မြင်သော ဂျင်ဆင်း",
result_3: "Win",
result_7: "ဂျင်ဆင်း",
result_6: "အနိုင်ရပြီး Sam ကိုပိတ်ဆို့",
result_2: "ထိပ်တန်း ဂျင်ဆင်း",
result_4: "ဒုတိယသုံးလပတ်",
result_1: "ငါးနှစ်ဆ",
result_0: "အရောင်တူ",
result_8: "ဘုရားကျောင်း",
result_5: "ကြိုး",
result_9: "ဆုံးရှုံးမှု",
result_10: "Sam Temple",
bao_sam: "Sam သတိပေးချင်တာလား?",
bao: "သတိ",
ko_bao_sam: "Sam ကိုသတိမပေးနဲ့",
co_bao_sam: "သတိပေးဆမ်"
},
binh: {
sort_again: "ပြန်စီပါ။",
sort_done: "အပြီးသတ် အမျိုးအစားခွဲခြင်း။",
bao_binh: "ပေါက်ဘင်"
},
bacay: {
chicken_money: "ငွေအိုး ",
bet_in_chicken: "အိုးအိုး",
open_all: "အားလုံးဖွင့်ပါ။"
},
poker: {
chat_1: "အားလုံးပါဝင်သည်",
chat_2: "ကံကောင်းစွာဖြင့်",
chat_3: "လက်အားလုံး",
chat_4: "မြန်မြန်လုပ်ပါ အန်တီ",
chat_5: "ဘုရင်၏ဧည့်ခန်း",
chat_6: "အရမ်းမည်းနေတယ်",
chat_7: "နေကောင်းပါတယ် :)",
chat_8: "ငွေအတွက် :)",
chat_9: "ပျင်းစရာကောင်းလိုက်တာ",
chat_10: "တစ်ရွာလုံးစားပါ :)",
chat_11: "အားလုံးကို စွန့်စားရဲတယ်",
chat_12: "ကောင်းသော တိုက်ပွဲ",
double: "နှစ်ဆ",
tripple: "သုံးဆ",
allin: "အယ်လင်",
check: "စစ်ဆေးခြင်း",
fold: "ခေါက်",
open: "ဖွင့်",
follow: "ခေါ်ဆိုရန်",
call: "ခေါ်ဆိုရန်",
bet: "မြှင့်",
raise: "လောင်းကစား",
royalflush: "Royal Flush",
straightflush: "Straight flush",
fourofakind: "Four of a kind",
fullhouse: "Full house",
flush: "Flush",
straight: "Straight",
threeofakind: "Three of a kind",
twopair: "Two pair",
pair: "Pair",
highcard: "High Card"
}
},
room_info: (o = {
id_room: "ID ရိုက်ပါ...",
hide_full_table: "Hide full table",
room_not_found: "ရွေးချယ်ထားသောအခန်းကို ရှာမတွေ့ပါ။",
please_add_idroom: "သင်ရှာဖွေလိုသောဇယားကို ကျေးဇူးပြု၍ ထည့်သွင်းပါ။",
not_create_room: "ဤဇယားကို ဖန်တီး၍မရပါ။",
not_enough_money: "လက်ကျန်ငွေ မလုံလောက်ပါ၊ ငွေဖြည့်ပါ။",
no_room_avaiable_found: "မှန်ကန်သောဇယားကို ရှာမတွေ့ပါ။",
error_check: "အချက်အလက်စစ်ဆေးရာတွင် အမှားအယွင်းရှိသည်။"
}, o.no_room_avaiable_found = "သောဇယားကိုမတွေ့ပါ။", o.bao_tri = "စနစ်သည် ပြုပြင်ထိန်းသိမ်းခြင်းဖြစ်သည်", 
o.time_wait = "အခန်းဝင်ခန်းတစ်ခုစီသည် 10 စက္ကန့်ခြားနေရပါမည်။", o.password_error = "အခန်းစကားဝှက် မမှန်ကန်ပါ!", 
o.room_full = "အခန်းပြည့်နေပြီ!", o.ban_room = "အခန်းပိုင်ရှင်က စားပွဲကို ဝင်ခွင့်မပေးဘူး။", 
o.info_create_room_error = "ဇယားဖန်တီးမှု အချက်အလက် မမှန်ကန်ပါ။", o.not_enough_vip = "စားပွဲတစ်ခုဖန်တီးရန် သင်သည် VIP အဆင့်မဟုတ်ပေ။", 
o.not_enough_vip2 = "လက်ရှိ VIP အဆင့်ဖြင့် ဇယားများ ထပ်မံဖန်တီး၍ မရပါ။", o),
keno: {
door: {
tai: "Big",
xiu: "Small",
chan: "Even",
le: "Odd",
kim: "Metal",
moc: "Wood",
thuy: "Water",
hoa: "Fire",
tho: "Earth"
},
type_bet: {
number: "Number",
xien: "Xien",
truotxien: "Not Appear",
tx: "Big Small",
cl: "Odd Even",
xien2: "Xien 2",
xien3: "Xien 3",
xien4: "Xien 4",
xien5: "Xien 5",
truotxien4: "N-A Xien 4",
truotxien5: "N-A Xien 5",
truotxien6: "N-A Xien 6",
truotxien7: "N-A Xien 7",
truotxien8: "N-A Xien 8",
truotxien9: "N-A Xien 9",
truotxien10: "N-A Xien 10"
},
btn: {
chat: "CHAT",
vecuoc: "BET TICKET",
statistic: "STATISTICS",
number_bet: "NUMBER BET",
base_bet: "BASE BET",
guide: "GUIDE",
most: "MOST",
at_least: "AT LEAST",
consecutive: "CONSECUTIVE",
no_result: "NO RESULT",
bet: "BET",
cancel: "CANCEL",
off: "OFF",
dont_show_again: "Don't show again",
transaction: "Transaction"
},
statistic: {
number_kytai: "Total Big:",
number_kyxiu: "Total Small:",
number_kychan: "Total Odd:",
number_kyle: "Total Even:",
ratio: "Rate:",
explain: "Explain",
tai: "=BIG",
xiu: "=SMALL",
chan: "=ODD",
le: "=EVEN",
today: "Today",
yesterday: "Yesterday",
number: "Number",
session50: "50 session",
session100: "100 session",
session200: "200 session",
session400: "400 session",
frequency: "Frequency",
tx: "Big Small",
cl: "Odd Even"
},
popup_title: {
confirm_ticket: "Confirm ticket",
you_know: "Do you know",
history_transfer: "History transfer",
result: "Result"
},
popup_confirm: {
selected: "Selected",
money_bet: "Money bet",
total_bet: "Total bet:",
total_prize: "Total prize:"
},
editbox: {
placeholder_session: "Type session number"
},
message: {
times: "fre",
rounding: "ROUNDING",
total: "TOTAL: ",
result_session: "RESULT SESSION #",
get: "1 GET",
error_number: "number!",
error_enough_number: "You must choose enough",
error_choose_maximum: "You only choose maximum",
selected: "Selected:  ",
success_bet: "Successful bet!",
error_bet1: "The system is being interrupted.\n Please try again later!",
error_bet2: "Currently the system is stopping \n the drawing of prizes.\n Please contact hotline!",
error_bet3: "The betting session has ended.\n Please bet next session!",
error_bet4: "Login error!",
error_bet5: "Please select bet type,\n number and money to complete the bet!",
error_bet6: "Please deposit to bet!",
error_bet7: "There is no bet type.\n Please bet again!",
error_bet8: "Money too small/bet!",
error_bet9: "Money is too big/bet!",
error_bet10: "The amount has exceeded the stake threshold/number.\n Please bet smaller amount\n or try again with another number\n or try again later session.",
error_bet11: "Not enough balance.\n Please try again!",
error_bet12: "Params is the wrong format!",
error_bet13: "Bet time out!",
error_bet14: "Unavailable balance!",
error_bet15: "Invalid amount!"
},
popup: {
rlt_number: "No",
rlt_session: "Session",
rlt_result: "Result",
rlt_total: "Total",
rlt_tx: "Big/Small",
rlt_cl: "Odd/even",
rlt_ngu_hanh: "5 Ele",
rlh_session: "Session",
rlh_bet_type: "Bet Type",
rlh_bet_money: "Money",
rlh_prize: "Prize",
rlh_time: "Time"
}
},
lode79: {
ld_txt_dat: "Bet",
ld_txt_tai: "BIG",
ld_txt_xiu: "SMALL",
ld_txt_le: "EVEN",
ld_txt_chan: "ODD",
ld_tit_chuyen_rut: "TRANSFER/WITHDRAWAL",
ld_xo_so: "ထီပေါက်သည်။",
ld_phien: "အပိုင်း",
ld_so_du: "လက်ကျန်",
ld_so_tien: "ငွေပမာဏ",
ld_so_diem: "နိုင်ပြီ",
ld_tong_diem: "စုစုပေါင်းပမာဏ",
ld_thanh_tien: "ငွေထဲသို့",
ld_tong_tien: "စုစုပေါင်းပမာဏ",
bet_success: "အောင်မြင်သောအလောင်းအစား",
bet_fail: "အလောင်းအစား မအောင်မြင်ပါ။",
mien_bac: "မြောက်ပိုင်း",
mien_trung: "ဗဟို",
mien_nam: "တောင်",
dat_cuoc: "လောင်းကစား",
ltr_huy: "လုပ်တော့",
result: {
txt_giai_db: "အထူးဆု",
txt_giai_1: "ပထမဆု",
txt_giai_2: "ဒုတိယဆု",
txt_giai_3: "တတိယဆု",
txt_giai_4: "စတုတ္ထဆု",
txt_giai_5: "၅ ကြိမ်မြောက်ဆု",
txt_giai_6: "ဆဋ္ဌမဆု",
txt_giai_7: "သတ္တမဆု",
txt_giai_8: "အဋ္ဌမဆု"
},
lib: {
re_mien_bac: "မြောက်ပိုင်း",
re_mien_trung: "ဗဟို",
re_mien_nam: "တောင်",
re_short_mien_bac: "မြောက်ပိုင်း",
re_short_mien_trung: "ဗဟို",
re_short_mien_nam: "တောင်",
qs_con_giap: "တိရိစ္ဆာန်သတ်မှတ်ခြင်း ၁၂",
cg_ty_9: "ကြွက် (၉)",
cg_suu_9: "(၉) နွား၊",
cg_dan_9: "ကျား(၉)ဦး၊",
cg_mao_9: "ကြောင် (၉)",
cg_thin_8: "နဂါး (၈)၊",
cg_ti_8: "(၈) မြွေ၊",
cg_ngo_8: "မြင်း(၈)စီး၊",
cg_mui_8: "ဆိတ် (၈)",
cg_than_8: "မျောက် (၈)",
cg_dau_8: "ကြက်ဖ (၈)၊",
cg_tuat_8: "ခွေး(၈)ဦး၊",
cg_hoi_8: "ဝက်(၈)၊",
qs_bo_so: "အုပ်စုနံပါတ်",
bo_so_01: "အုပ်စုနံပါတ် ၀၁",
bo_so_02: "အုပ်စုနံပါတ် ၀၂",
bo_so_03: "အုပ်စုနံပါတ် ၀၃",
bo_so_04: "အုပ်စုနံပါတ် ၀၄",
bo_so_12: "နံပါတ် ၁၂ တွဲ",
bo_so_13: "ဖော်ကိန်း ၁၃",
bo_so_14: "အုပ်စုနံပါတ် ၁၄",
bo_so_23: "De အုပ်စု ၂၃",
bo_so_24: "နံပါတ် ၂၄ တွဲ",
bo_so_34: "နံပါတ် ၃၄ တွဲ",
qs_so_kep: "နှစ်ဆ",
kep_bang: "နှစ်ထပ်တူ",
bo_00: "00 အစုံ",
bo_11: "11 အစုံ",
bo_22: "22 အစုံ",
bo_33: "33 အစုံ",
bo_44: "44 အစုံ",
qs_de_tong: "စုစုပေါင်း",
tong_0: "စုစုပေါင်း 0",
tong_1: "စုစုပေါင်း ၁",
tong_2: "စုစုပေါင်း ၂",
tong_3: "စုစုပေါင်း ၃",
tong_4: "စုစုပေါင်း ၄",
tong_5: "စုစုပေါင်း ၅",
tong_6: "စုစုပေါင်း ၆",
tong_7: "စုစုပေါင်း ၇",
tong_8: "စုစုပေါင်း ၈",
tong_9: "စုစုပေါင်း ၉",
type_de: "တရ",
type_de_dau: "De ပဌမ",
type_de_duoi: "De နောက်ဆုံး",
type_de_giai_8: "De ပဌမနံပါတ် အဋ္ဌမဆု",
type_de_giai_nhat: "ပထမဆု",
type_de_giai_7: "De Seventh ဆု",
type_de_dau_db: "ပထမ နံပါတ် အထူးဆု",
type_de_duoi_db: "De နောက်ဆုံးနံပါတ် အထူးဆု",
type_de_3_cang: "De နောက်ဆုံးနံပါတ် 3 ခု အထူးဆု",
type_3d_dac_biet: "3D အထူးဆု",
type_3d_giai_7: "3D သတ္တမဆု",
type_3d_duoi: "3D နောက်ဆုံး",
type_lo: "အကယ်",
type_lo_xien_2: "စကားဝိုင်း Lo ၂",
type_lo_xien_3: "စကားဝိုင်း Lo ၃",
type_lo_xien_4: "စကားဝိုင်း Lo ၄",
type_lo_truot_4: "လော်ပြတ် ၄",
type_lo_truot_8: "လော်ပြတ် ၈",
type_lo_truot_10: "လော်ပြတ် ၁၀",
type_tai_xiu: "အကြီးအသေး",
type_chan_le: "အထူးအဆန်းပင်",
type_s_de: "တရ",
type_s_de_dau: "De ပဌမ",
type_s_de_duoi: "De နောက်ဆုံး",
type_s_de_giai_8: "De ပဌမနံပါတ် အဋ္ဌမဆု",
type_s_de_giai_nhat: "ပထမဆု",
type_s_de_giai_7: "De Seventh ဆု",
type_s_de_dau_db: "ပထမ နံပါတ် အထူးဆု",
type_s_de_duoi_db: "De နောက်ဆုံးနံပါတ် အထူးဆု",
type_s_de_3_cang: "De နောက်ဆုံးနံပါတ် 3 အထူးဆု",
type_s_3d_dac_biet: "3D အထူးဆု",
type_s_3d_giai_7: "3D သတ္တမဆု",
type_s_3d_duoi: "3D နောက်ဆုံး",
type_s_lo: "အကယ်",
type_s_lo_xien_2: "စကားဝိုင်း Lo ၂",
type_s_lo_xien_3: "စကားဝိုင်း Lo ၃",
type_s_lo_xien_4: "စကားဝိုင်း Lo ၄",
type_s_lo_truot_4: "လော်ပြတ် ၄",
type_s_lo_truot_8: "လော်ပြတ် ၈",
type_s_lo_truot_10: "လော်ပြတ် ၁၀",
type_s_tai_xiu: "အကြီးအသေး",
type_s_chan_le: "အထူးအဆန်းပင်"
},
responseWs: {
bet_success: "အောင်မြင်သောအလောင်းအစား။",
bet_fail: "အလောင်းအစား မအောင်မြင်ပါ။",
resNotifyLivestream1: "XS LiveStream XXXX - YYYY \n စက်ရှင်တွင် လောင်းကစားရန် \n သင့်အား ဖိတ်ကြားအပ်ပါသည်။",
resNotifyLivestream2: "လောလောဆယ် လည်ပတ်နေပါတယ်။ \n နောက်ဆက်ရှင်ကိုဖွင့်ရန် မိနစ်အနည်းငယ်စောင့်ပါ။",
resNotifyLivestream3: "ကျေးဇူးပြု၍ လောင်းကစားခြင်းကို \n ရပ်ပါ။ စနစ်သည် လက်ရှိစက်ရှင်ကို စတင်လည်ပတ်ပါမည်။",
resNotifyLivestream4: "လာမည့်စက်ရှင် XS XXXX Session YYYY \n တွင် အလောင်းအစားများဖွင့်ပါ။ ကျေးဇူးပြု၍ \n သင်၏အလောင်းအစားများကို နေရာချပါ။",
resBet_am_1: "တိုကင်သည် ဖော်မတ်မှားနေသည်။",
resBet_0: "เအောင်မြင်သောအလောင်းအစား။",
resBet_1: "စနစ်က အလုပ်ရှုပ်နေတယ်၊ ​​ကျေးဇူးပြုပြီး မိနစ်အနည်းငယ်အကြာမှာ ထပ်စမ်းကြည့်ပါ။",
resBet_2: "ဖွဲ့စည်းမှုပုံစံမရှိပါ။",
resBet_3: "ဆုမဲများကို ယနေ့ ခေတ္တရပ်နားထားပါသည်။",
resBet_4: "ထီအချိန်လောင်းကြေးကို တင်၍မရပါ။",
resBet_5: "လောင်းကစားဖွင့်ရန် အချိန်မရောက်သေးပါ။",
resBet_6: "အကောင့်မရှိပါ။",
resBet_7: "ဘာမှမဖြစ်",
resBet_8: "အလောင်းအစားများသည် လိုအပ်သော အချက်အလက်ဖြစ်သည်။",
resBet_9: "စနစ်က အလုပ်ရှုပ်နေတယ်၊ ​​ကျေးဇူးပြုပြီး မိနစ်အနည်းငယ်အကြာမှာ ထပ်စမ်းကြည့်ပါ။",
resBet_10: "လောင်းကြေးပမာဏသည် အလွန်သေးငယ်သည်။",
resBet_11: "လောင်းကြေးက အရမ်းကြီးတယ်။",
resBet_12: "ထီအမျိုးအစားမရှိပါ။",
resBet_13: "လောင်းကြေးက အရမ်းကြီးတယ်။",
resBet_14: "လောင်းကြေးပမာဏသည် အလွန်သေးငယ်သည်။",
resBet_15: "အလောင်းအစားများသည် မှန်ကန်သောပုံစံတွင် မရှိပါ။",
resBet_16: "လောင်းကစားနံပါတ်သည် မှန်ကန်သောဖော်မတ်မဟုတ်ပေ။",
resBet_17: "လောင်းကြေးက အရမ်းကြီးတယ်။",
resBet_18: "သင့်အကောင့်က မလုံလောက်ပါဘူး။",
resBet_19: "ပြည်နယ် မရှိပါ။",
resBet_20: "စနစ်က အလုပ်ရှုပ်နေတယ်၊ ​​ကျေးဇူးပြုပြီး မိနစ်အနည်းငယ်အကြာမှာ ထပ်စမ်းကြည့်ပါ။",
resBet_21: "ယနေ့ ဤနေရာ၌ ဆုမဲများ မရှိပါ။",
resBet_22: "စနစ်က အလုပ်ရှုပ်နေတယ်၊ ​​ကျေးဇူးပြုပြီး မိနစ်အနည်းငယ်အကြာမှာ ထပ်စမ်းကြည့်ပါ။",
resBet_23: "အလောင်းအစား",
resBet_24: "အလောင်းအစား",
resBet_25: "အလောင်းအစား",
resBet_26: "အလောင်းအစား",
resBet_27: "အလောင်းအစား",
resBet_28: "စနစ်က အလုပ်ရှုပ်နေတယ်၊ ​​ကျေးဇူးပြုပြီး မိနစ်အနည်းငယ်အကြာမှာ ထပ်စမ်းကြည့်ပါ။",
resBet_29: "လောင်းကြေးပမာဏသည် အလွန်ကြီးမားသည်။",
resBet_30: "စနစ်က အလုပ်ရှုပ်နေတယ်၊ ​​ကျေးဇူးပြုပြီး မိနစ်အနည်းငယ်အကြာမှာ ထပ်စမ်းကြည့်ပါ။",
resBet_31: "စနစ်က အလုပ်ရှုပ်နေတယ်၊ ​​ကျေးဇူးပြုပြီး မိနစ်အနည်းငယ်အကြာမှာ ထပ်စမ်းကြည့်ပါ။",
resBet_32: "စနစ်က အလုပ်ရှုပ်နေတယ်၊ ​​ကျေးဇူးပြုပြီး မိနစ်အနည်းငယ်အကြာမှာ ထပ်စမ်းကြည့်ပါ။",
resBet_33: "အကောင့်ဆက်ရှင် သက်တမ်းကုန်သွားပါပြီ။ ကျေးဇူးပြု၍ ဝင်ရောက်ပြီး ထပ်မံလုပ်ဆောင်ပါ။",
resBet_34: "လောင်းကစားရန် အရည်အချင်းပြည့်မီရန် အနည်းဆုံး အပ်ငွေ လိုအပ်ပါသည်။"
},
popup: {
title_huong_dan: "လမ်းညွှန်",
title_thong_so: "ကန့်သတ်ချက်",
title_thong_so_tra: "ရိုးရာဘောင်များ",
title_thong_so_liv: "တိုက်ရိုက်ထုတ်လွှင့်မှု သတ်မှတ်ချက်များ",
thong_so_header_gia_ban: "စျေးနှုန်း",
thong_so_header_tra_thuong: "ဆုလာဘ်",
thong_so_header_toi_da_lan_cuoc: "အများဆုံး/လောင်းကစားအရေအတွက်",
thong_so_header_toi_da_so: "အများဆုံး/နံပါတ်",
title_sao_ke: "ထုတ်ပြန်ချက်",
title_sao_ke_tra: "ရိုးရာပဲနော်။",
title_sao_ke_liv: "တိုက်ရိုက်ထုတ်လွှင့်ချက်",
sao_ke_loai_phien: "Session အမျိုးအစား",
sao_ke_thoi_gian: "အချိန်",
sao_ke_de_lo: "De/Lo",
sao_ke_tien_cuoc: "ကစားနည်း",
sao_ke_nhan_thuong: "ဆုချီးမြှင့်ပါ။",
title_bang_cuoc: "လောင်းကြေးစားပွဲ",
title_bang_cuoc_tra: "ရိုးရာလောင်းကစားစားပွဲ",
title_bang_cuoc_liv: "တိုက်ရိုက်လောင်းကစားစားပွဲ",
bang_cuoc_loai_phien: "Session အမျိုးအစား",
bang_cuoc_thoi_gian: "အချိန်",
bang_cuoc_de_lo: "De/Lo",
bang_cuoc_tien_cuoc: "ကစားနည်း",
quy_tit_chuyen_quy: "ရန်ပုံငွေလွှဲပြောင်းမှု",
quy_tit_rut_quy: "ငွေထုတ်ခြင်း",
quy_lbcq_gold_c: "ငွေထုတ်ခြင်း",
quy_lbcq_gold_n: "ရရှိသောရွှေပမာဏ-",
quy_lbrq_gold_r: "ထုတ်ယူထားသော ရွှေပမာဏ-",
quy_lbrq_gold_n: "ရရှိသောရွှေပမာဏ-",
quy_tit_ti_le: "အချိုး-",
quy_tit_so_du: "လက်ရှိပမာဏ-",
quy_btn_chuyen_quy: "ရန်ပုံငွေလွှဲပြောင်းမှု",
quy_btn_rut_quy: "ငွေထုတ်ခြင်း",
quy_btn_choi_ngay: "ယခုကစားပါ။"
},
validate: {
vli_1: "လက်ကျန်ငွေ မရရှိနိုင်ပါ။",
vli_2: "နံပါတ်တစ်ခုကို သင်မရွေးချယ်ရသေးပါ။",
vli_3: "ပမာဏကို ထည့်ပါ။",
vli_4: "ရမှတ်ကို ထည့်ပါ။",
vli_5: "ကျေးဇူးပြု၍ လုံလောက်သော XXXX နံပါတ်/lo ကို ရွေးပါ။",
vli_6: "နောက်ဆက်ရှင်ကို လောလောဆယ်\n မဖွင့်ရသေးပါ။ ကျေးဇူးပြုပြီးခဏစောင့်ပါ",
vli_7: "ကျေးဇူးပြု၍ 10 နံပါတ်/လောင်းကြေး \n အလုံအလောက်ရွေးပါ။."
},
resChuyenRutQuy: {
res_01: "ပမာဏ မမှန်ပါ။",
res_02: "ထုတ်ယူရမည့်ပမာဏသည် လက်ကျန်ငွေထက် ကျော်လွန်နေပါသည်။",
res_03: "လက်ကျန်ငွေ မရရှိနိုင်ပါ။",
res_cp_0: "ရန်ပုံငွေလွှဲပြောင်းမှု အောင်မြင်ပါပြီ။",
res_rq_0: "အောင်မြင်စွာ ရုပ်သိမ်းခြင်း။"
}
},
shankoemee: {
cannot_out_room: "မင်းက ဘဏ်လုပ်ငန်းရှင် တစ်ယောက်ဖြစ်ပြီး အခန်းထဲက ထုတ်လို့မရဘူး",
cancel_leave_room: "Cancel leave",
refresh_room: "ပြန်လည်ဆန်းသစ်ပါ။",
skm_card_score: "နိုင်ပြီ",
skm_nguoi_choi: "ကစားသမား",
skm_muc_cuoc: "လောင်းကြေး အဆင့်အတန်း",
draw_card: "ကတ်ဆွဲ",
do_not_draw_card: "မဆွဲဘူး",
bet: "လောင်းကြေး",
quick_chat_1: "မင်းအေးနေသေးလား",
quick_chat_2: "အသက်ဘယ်လောက်ရှိပြီလဲ?",
quick_chat_3: "ဘဝဆိုတာ အိမ်မက်မဟုတ်ဘူး။",
quick_chat_4: "ကံကောင်းတယ်။",
quick_chat_5: "အလွန်ကောင်းသည်",
quick_chat_6: "ကံမကောင်းပါ။",
quick_chat_7: "ဒါပေမယ့် တောင်းဆိုနေဆဲပါ။",
quick_chat_8: "ဒါသေပြီ။",
quick_chat_9: "ကတ်က မကောင်းဘူး။",
quick_chat_10: "မင်းစွံ့အ သွားပြီလား",
quick_chat_11: "ရှုံးသွားပြီ သူငယ်ချင်း",
quick_chat_12: "မြန်မြန်လုပ်ပါ",
enter_chat_content: "အကြောင်းအရာ...",
do_not: "မရှိ",
accept: "လက်ခံပါတယ်။",
invite: "ဖိတ်ကြားသည်။",
double_banker: "ဘဏ်လုပ်ငန်းဆက်လက်လုပ်ကိုင်ရန် ဘဏ်သို့ ငွေပမာဏ နှစ်ဆထည့်လိုပါသလား။",
play_now: "ယခုကစားပါ။",
choose_room: "အခန်းရွေးပါ။",
bank: "ဘဏ်",
enter_table_id: "ဇယားအိုင်ဒီရိုက်ထည့်ပါ...",
hidden_table_full: "ဝှက်ထားသော စားပွဲအပြည့်",
table_id: "ဇယား- %{table}#%{ကစားပွဲ}",
bet_value: "လောင်းကြေး",
bet_value_num: "လောင်းကြေး",
watching: "စောင့်ကြည့်",
empty_list: "ဗလာစာရင်း",
not_enough_money_to_join_the_table: "အခန်းထဲဝင်ဖို့ ပိုက်ဆံမလောက်ဘူး။",
value_slot: "%{value} အပေါက်",
pot_bank: "အိုး- %{value}",
banker_turn: "ဒိုင်အလှည့်- %{turn}",
banker_turn2: "ဒိုင်အဝိုင်း 2 ဖြစ်ပါစေ။",
banker_turn3: "%{turn} ကွေ့ရန်",
waiting_new_game: "ဂိမ်းအသစ် စတင်ရန် စောင့်နေသည်။",
waiting_banker: "ဒိုင်စောင့်",
change_banker: "ဒိုင်ပြောင်းပါ။",
banker_win_title: "ဒိုင်အနိုင်ရ",
not_open_yet: "လုပ်ဆောင်ချက် မဖွင့်ပါ။",
can_not_find_table_selected: "ရွေးချယ်ထားသောအခန်းကို ရှာမတွေ့ပါ။",
enter_the_table_you_want_to_search: "သင်ရှာဖွေလိုသောဇယားကို ကျေးဇူးပြု၍ ထည့်သွင်းပါ။",
can_not_create_table: "ဤဂိမ်းသည် ဇယားများဖန်တီးခြင်းကို ခွင့်မပြုပါ။",
no_valid_table_found: "မှန်ကန်သောဇယားကို ရှာမတွေ့ပါ။",
invite_user: "%{name} က သင့်အား ကစားရန် ဖိတ်ခေါ်ပါသည်၊ သင် ပါဝင်လိုပါသလား။",
error_not_defined: "အမှား %{id}၊ သတ်မှတ်မထားသော။",
error_check_infomation: "အချက်အလက်စစ်ဆေးရာတွင် အမှားအယွင်းရှိနေသည်။",
error_can_not_find_table_try_again: "သင့်လျော်သောအခန်းကို ရှာမတွေ့ပါ။ ကျေးဇူးပြု၍နောက်မှ ထပ်စမ်းကြည့်ပါ။",
error_not_enough_money_to_join_table: "ဤအခန်းသို့ ဝင်ရန် သင့်တွင် ပိုက်ဆံအလုံအလောက် မရှိပါ။",
error_join_room_too_fast: "အခန်းထဲဝင်တာ အရမ်းမြန်တယ်။",
error_server_maintenance: "ပြုပြင်ထိန်းသိမ်းမှုစနစ်။",
error_can_not_find_table: "ကစားခန်း မတွေ့ပါ။",
error_password_table_not_correct: "ဂိမ်းအခန်း စကားဝှက် မမှန်ပါ။",
error_room_full: "ကစားခန်းက ပြည့်နေတယ်။",
error_has_been_kick: "အခန်းပိုင်ရှင်က စားပွဲကို ဝင်ခွင့်မပေးဘူး။",
register_leave_table_success: "အခန်းထဲက ထွက်ဖို့ စာရင်းသွင်းပြီးပါပြီ။",
place_bet: "လောင်းကစားနေရာ",
error_bet_already: "လောင်းပြီးသား",
error_not_enough_money: "မလုံလောက်တဲ့ပိုက်ဆံ",
error_bet_not_correct: "လောင်းကြေးတန်ဖိုး မမှန်ကန်ပါ။",
not_enough_gold_please_deposit: "လက်ကျန်ငွေ မလုံလောက်ပါ၊ ငွေဖြည့်ပါ။",
cancel_register_leave_table: "အခန်းမှထွက်ရန် သင်သည် စာရင်းသွင်းမှုမှ ရပ်ဆိုင်းလိုက်ပါပြီ။",
open_card: "ကတ်ဖွင့်ပါ။",
id: "အိုင်ဒီ",
table_name: "နာမည်",
table_require: "လိုအပ်သည်။",
table_min_bet: "အနည်းဆုံးလောင်းကြေး",
table_num_user: "အသုံးပြုသူ",
leave_room_title: "Leave",
leave_room_contect: "စားပွဲမှ ထွက်သွားဖို့ သေချာသလား။",
on_sound: "ဖွင့်သည်",
off_sound: "ပိတ်သည်။",
send_chat: "ပို့ပါ။"
},
boogyi: {
cannot_out_room: "မင်းက ဘဏ်လုပ်ငန်းရှင် တစ်ယောက်ဖြစ်ပြီး အခန်းထဲက ထုတ်လို့မရဘူး",
cancel_leave_room: "Cancel leave",
boo_tong_diem: "စုစုပေါင်းပမာဏ",
refresh_room: "ပြန်လည်ဆန်းသစ်ပါ။",
skm_card_score: "နိုင်ပြီ",
skm_nguoi_choi: "ကစားသမား",
skm_muc_cuoc: "လောင်းကြေး အဆင့်အတန်း",
draw_card: "ကတ်ဆွဲ",
do_not_draw_card: "မဆွဲဘူး",
bet: "လောင်းကြေး",
quick_chat_1: "မင်းအေးနေသေးလား",
quick_chat_2: "အသက်ဘယ်လောက်ရှိပြီလဲ?",
quick_chat_3: "ဘဝဆိုတာ အိမ်မက်မဟုတ်ဘူး။",
quick_chat_4: "ကံကောင်းတယ်။",
quick_chat_5: "အလွန်ကောင်းသည်",
quick_chat_6: "ကံမကောင်းပါ။",
quick_chat_7: "ဒါပေမယ့် တောင်းဆိုနေဆဲပါ။",
quick_chat_8: "ဒါသေပြီ။",
quick_chat_9: "ကတ်က မကောင်းဘူး။",
quick_chat_10: "မင်းစွံ့အ သွားပြီလား",
quick_chat_11: "ရှုံးသွားပြီ သူငယ်ချင်း",
quick_chat_12: "မြန်မြန်လုပ်ပါ",
enter_chat_content: "အကြောင်းအရာ...",
do_not: "မရှိ",
accept: "လက်ခံပါတယ်။",
invite: "ဖိတ်ကြားသည်။",
double_banker: "ဘဏ်လုပ်ငန်းဆက်လက်လုပ်ကိုင်ရန် ဘဏ်သို့ ငွေပမာဏ နှစ်ဆထည့်လိုပါသလား။",
play_now: "ယခုကစားပါ။",
choose_room: "အခန်းရွေးပါ။",
bank: "ဘဏ်",
enter_table_id: "ဇယားအိုင်ဒီရိုက်ထည့်ပါ...",
hidden_table_full: "ဝှက်ထားသော စားပွဲအပြည့်",
table_id: "ဇယား- %{table}#%{game}",
bet_value: "လောင်းကြေး",
bet_value_num: "လောင်းကြေး",
watching: "စောင့်ကြည့်",
empty_list: "ဗလာစာရင်း",
not_enough_money_to_join_the_table: "အခန်းထဲဝင်ဖို့ ပိုက်ဆံမလောက်ဘူး။",
value_slot: "%{value} အပေါက်",
pot_bank: "အိုး- %{value}",
banker_turn: "ဒိုင်အလှည့်- %{turn}",
banker_turn2: "ဒိုင်အဝိုင်း 2 ဖြစ်ပါစေ။",
banker_turn3: "%{turn} ကွေ့ရန်",
waiting_new_game: "ဂိမ်းအသစ် စတင်ရန် စောင့်နေသည်။",
waiting_banker: "ဒိုင်စောင့်",
change_banker: "ဒိုင်ပြောင်းပါ။",
banker_win_title: "ဒိုင်အနိုင်ရ",
not_open_yet: "လုပ်ဆောင်ချက် မဖွင့်ပါ။",
can_not_find_table_selected: "ရွေးချယ်ထားသောအခန်းကို ရှာမတွေ့ပါ။",
enter_the_table_you_want_to_search: "သင်ရှာဖွေလိုသောဇယားကို ကျေးဇူးပြု၍ ထည့်သွင်းပါ။",
can_not_create_table: "ဤဂိမ်းသည် ဇယားများဖန်တီးခြင်းကို ခွင့်မပြုပါ။",
no_valid_table_found: "မှန်ကန်သောဇယားကို ရှာမတွေ့ပါ။",
invite_user: "%{name} က သင့်အား ကစားရန် ဖိတ်ခေါ်ပါသည်၊ သင် ပါဝင်လိုပါသလား။",
error_not_defined: "အမှား %{id}၊ သတ်မှတ်မထားသော။",
error_check_infomation: "အချက်အလက်စစ်ဆေးရာတွင် အမှားအယွင်းရှိနေသည်။",
error_can_not_find_table_try_again: "သင့်လျော်သောအခန်းကို ရှာမတွေ့ပါ။ ကျေးဇူးပြု၍နောက်မှ ထပ်စမ်းကြည့်ပါ။",
error_not_enough_money_to_join_table: "ဤအခန်းသို့ ဝင်ရန် သင့်တွင် ပိုက်ဆံအလုံအလောက် မရှိပါ။",
error_join_room_too_fast: "အခန်းထဲဝင်တာ အရမ်းမြန်တယ်။",
error_server_maintenance: "ပြုပြင်ထိန်းသိမ်းမှုစနစ်။",
error_can_not_find_table: "ကစားခန်း မတွေ့ပါ။",
error_password_table_not_correct: "ဂိမ်းအခန်း စကားဝှက် မမှန်ပါ။",
error_room_full: "ကစားခန်းက ပြည့်နေတယ်။",
error_has_been_kick: "အခန်းပိုင်ရှင်က စားပွဲကို ဝင်ခွင့်မပေးဘူး။",
register_leave_table_success: "အခန်းထဲက ထွက်ဖို့ စာရင်းသွင်းပြီးပါပြီ။",
place_bet: "လောင်းကစားနေရာ",
error_bet_already: "လောင်းပြီးသား",
error_not_enough_money: "မလုံလောက်တဲ့ပိုက်ဆံ",
error_bet_not_correct: "လောင်းကြေးတန်ဖိုး မမှန်ကန်ပါ။",
not_enough_gold_please_deposit: "လက်ကျန်ငွေ မလုံလောက်ပါ၊ ငွေဖြည့်ပါ။",
cancel_register_leave_table: "အခန်းမှထွက်ရန် သင်သည် စာရင်းသွင်းမှုမှ ရပ်ဆိုင်းလိုက်ပါပြီ။",
open_card: "ကတ်ဖွင့်ပါ။",
id: "အိုင်ဒီ",
table_name: "နာမည်",
table_require: "လိုအပ်သည်။",
table_min_bet: "အနည်းဆုံးလောင်းကြေး",
table_num_user: "အသုံးပြုသူ",
leave_room_title: "Leave",
leave_room_contect: "စားပွဲမှ ထွက်သွားဖို့ သေချာသလား။",
on_sound: "ဖွင့်သည်",
off_sound: "ပိတ်သည်။",
send_chat: "ပို့ပါ။",
test: "test",
zero_slot: "ယိုစိမ့်ခြင်း။",
confirm: "အတည်ပြုပါ။",
not_bid: "မမဟုတ် bid",
place_bid: "လေလံပွဲဖိတ်ကြားခြင်း။",
bid_value: "bid x%{value}",
bid_error_1: "အဆင့် bid မမှန်ပါ။",
bid_error_2: "မလုံလောက်တဲ့ပိုက်ဆံ",
start_compare: "ကတ်များကို နှိုင်းယှဉ်ပါ။"
},
shweshan: {
cannot_out_room: "မင်းက ဘဏ်လုပ်ငန်းရှင် တစ်ယောက်ဖြစ်ပြီး အခန်းထဲက ထုတ်လို့မရဘူး",
cancel_leave_room: "Cancel leave",
shw_resort: "ပြန်စီပါ။",
game_name: "Shweshan",
zero_slot: "ယိုစိမ့်ခြင်း။",
arranage_done: "Arrange done",
shweshan_nguoi_choi: "ကစားသမား",
shweshan_muc_cuoc: "လောင်းကြေး အဆင့်အတန်း",
watching: "စောင့်ကြည့်",
do_not: "မရှိ",
accept: "လက်ခံပါတယ်။",
invite: "ဖိတ်ကြားသည်။",
refresh_room: "ပြန်လည်ဆန်းသစ်ပါ။",
empty_list: "ဗလာစာရင်း",
play_now: "ယခုကစားပါ။",
confirm: "အတည်ပြုပါ။",
start_compare: "ကတ်များကို နှိုင်းယှဉ်ပါ။",
skm_card_score: "နိုင်ပြီ",
skm_nguoi_choi: "ကစားသမား",
skm_muc_cuoc: "လောင်းကြေး အဆင့်အတန်း",
draw_card: "ကတ်ဆွဲ",
do_not_draw_card: "မဆွဲဘူး",
bet: "လောင်းကြေး",
quick_chat_1: "မင်းအေးနေသေးလား",
quick_chat_2: "အသက်ဘယ်လောက်ရှိပြီလဲ?",
quick_chat_3: "ဘဝဆိုတာ အိမ်မက်မဟုတ်ဘူး။",
quick_chat_4: "ကံကောင်းတယ်။",
quick_chat_5: "အလွန်ကောင်းသည်",
quick_chat_6: "ကံမကောင်းပါ။",
quick_chat_7: "ဒါပေမယ့် တောင်းဆိုနေဆဲပါ။",
quick_chat_8: "ဒါသေပြီ။",
quick_chat_9: "ကတ်က မကောင်းဘူး။",
quick_chat_10: "မင်းစွံ့အ သွားပြီလား",
quick_chat_11: "ရှုံးသွားပြီ သူငယ်ချင်း",
quick_chat_12: "မြန်မြန်လုပ်ပါ",
enter_chat_content: "အကြောင်းအရာ...",
double_banker: "ဘဏ်လုပ်ငန်းဆက်လက်လုပ်ကိုင်ရန် ဘဏ်သို့ ငွေပမာဏ နှစ်ဆထည့်လိုပါသလား။",
choose_room: "အခန်းရွေးပါ။",
bank: "ဘဏ်",
enter_table_id: "ဇယားအိုင်ဒီရိုက်ထည့်ပါ...",
hidden_table_full: "ဝှက်ထားသော စားပွဲအပြည့်",
table_id: "ဇယား- %{table}#%{game}",
bet_value: "လောင်းကြေး",
bet_value_num: "လောင်းကြေး",
not_enough_money_to_join_the_table: "အခန်းထဲဝင်ဖို့ ပိုက်ဆံမလောက်ဘူး။",
value_slot: "အပေါက်:%{value}",
pot_bank: "အိုး- %{value}",
banker_turn: "ဒိုင်အလှည့်- %{turn}",
banker_turn2: "ဒိုင်အဝိုင်း 2 ဖြစ်ပါစေ။",
banker_turn3: "%{turn} ကွေ့ရန်",
waiting_new_game: "ဂိမ်းအသစ် စတင်ရန် စောင့်နေသည်။",
waiting_banker: "ဒိုင်စောင့်",
change_banker: "ဒိုင်ပြောင်းပါ။",
banker_win_title: "ဒိုင်အနိုင်ရ",
not_open_yet: "လုပ်ဆောင်ချက် မဖွင့်ပါ။",
can_not_find_table_selected: "ရွေးချယ်ထားသောအခန်းကို ရှာမတွေ့ပါ။",
enter_the_table_you_want_to_search: "သင်ရှာဖွေလိုသောဇယားကို ကျေးဇူးပြု၍ ထည့်သွင်းပါ။",
can_not_create_table: "ဤဂိမ်းသည် ဇယားများဖန်တီးခြင်းကို ခွင့်မပြုပါ။",
no_valid_table_found: "မှန်ကန်သောဇယားကို ရှာမတွေ့ပါ။",
invite_user: "%{name} က သင့်အား ကစားရန် ဖိတ်ခေါ်ပါသည်၊ သင် ပါဝင်လိုပါသလား။",
error_not_defined: "အမှား %{id}၊ သတ်မှတ်မထားသော။",
error_check_infomation: "အချက်အလက်စစ်ဆေးရာတွင် အမှားအယွင်းရှိနေသည်။",
error_can_not_find_table_try_again: "သင့်လျော်သောအခန်းကို ရှာမတွေ့ပါ။ ကျေးဇူးပြု၍နောက်မှ ထပ်စမ်းကြည့်ပါ။",
error_not_enough_money_to_join_table: "ဤအခန်းသို့ ဝင်ရန် သင့်တွင် ပိုက်ဆံအလုံအလောက် မရှိပါ။",
error_join_room_too_fast: "အခန်းထဲဝင်တာ အရမ်းမြန်တယ်။",
error_server_maintenance: "ပြုပြင်ထိန်းသိမ်းမှုစနစ်။",
error_can_not_find_table: "ကစားခန်း မတွေ့ပါ။",
error_password_table_not_correct: "ဂိမ်းအခန်း စကားဝှက် မမှန်ပါ။",
error_room_full: "ကစားခန်းက ပြည့်နေတယ်။",
error_has_been_kick: "အခန်းပိုင်ရှင်က စားပွဲကို ဝင်ခွင့်မပေးဘူး။",
register_leave_table_success: "အခန်းထဲက ထွက်ဖို့ စာရင်းသွင်းပြီးပါပြီ။",
place_bet: "လောင်းကစားနေရာ",
error_bet_already: "လောင်းပြီးသား",
error_not_enough_money: "မလုံလောက်တဲ့ပိုက်ဆံ",
error_bet_not_correct: "လောင်းကြေးတန်ဖိုး မမှန်ကန်ပါ။",
not_enough_gold_please_deposit: "လက်ကျန်ငွေ မလုံလောက်ပါ၊ ငွေဖြည့်ပါ။",
cancel_register_leave_table: "အခန်းမှထွက်ရန် သင်သည် စာရင်းသွင်းမှုမှ ရပ်ဆိုင်းလိုက်ပါပြီ။",
open_card: "ကတ်ဖွင့်ပါ။",
id: "အိုင်ဒီ",
table_name: "နာမည်",
table_require: "လိုအပ်သည်။",
table_min_bet: "အနည်းဆုံးလောင်းကြေး",
table_num_user: "အသုံးပြုသူ",
leave_room_title: "Leave",
leave_room_contect: "စားပွဲမှ ထွက်သွားဖို့ သေချာသလား။",
on_sound: "ဖွင့်သည်",
off_sound: "ပိတ်သည်။",
send_chat: "ပို့ပါ။"
}
};
cc._RF.pop();
}, {} ],
polyglot: [ function(e, t, n) {
(function(e) {
"use strict";
cc._RF.push(t, "7ae8fgp2ZROFqI2ZcqYAXkY", "polyglot");
(function(e, o) {
"function" == typeof define && define.amd ? define([], function() {
return o(e);
}) : "object" == typeof n ? t.exports = o(e) : e.Polyglot = o(e);
})("undefined" != typeof e ? e : void 0, function(e) {
var t = String.prototype.replace;
function n(e) {
e = e || {};
this.phrases = {};
this.extend(e.phrases || {});
this.currentLocale = e.locale || "en";
this.allowMissing = !!e.allowMissing;
this.warn = e.warn || g;
}
n.VERSION = "1.0.0";
n.prototype.locale = function(e) {
e && (this.currentLocale = e);
return this.currentLocale;
};
n.prototype.extend = function(e, t) {
var n;
for (var o in e) if (e.hasOwnProperty(o)) {
n = e[o];
t && (o = t + "." + o);
"object" == typeof n ? this.extend(n, o) : this.phrases[o] = n;
}
};
n.prototype.unset = function(e, t) {
var n;
if ("string" == typeof e) delete this.phrases[e]; else for (var o in e) if (e.hasOwnProperty(o)) {
n = e[o];
t && (o = t + "." + o);
"object" == typeof n ? this.unset(n, o) : delete this.phrases[o];
}
};
n.prototype.clear = function() {
this.phrases = {};
};
n.prototype.replace = function(e) {
this.clear();
this.extend(e);
};
n.prototype.t = function(e, t) {
var n, o;
"number" == typeof (t = null == t ? {} : t) && (t = {
smart_count: t
});
if ("string" == typeof this.phrases[e]) n = this.phrases[e]; else if ("string" == typeof t._) n = t._; else if (this.allowMissing) n = e; else {
this.warn('Missing translation for key: "' + e + '"');
o = e;
}
if ("string" == typeof n) {
t = p(t);
o = d(o = c(n, this.currentLocale, t.smart_count), t);
}
return o;
};
n.prototype.has = function(e) {
return e in this.phrases;
};
var o = "||||", a = {
chinese: function() {
return 0;
},
german: function(e) {
return 1 !== e ? 1 : 0;
},
french: function(e) {
return e > 1 ? 1 : 0;
},
russian: function(e) {
return e % 10 == 1 && e % 100 != 11 ? 0 : e % 10 >= 2 && e % 10 <= 4 && (e % 100 < 10 || e % 100 >= 20) ? 1 : 2;
},
czech: function(e) {
return 1 === e ? 0 : e >= 2 && e <= 4 ? 1 : 2;
},
polish: function(e) {
return 1 === e ? 0 : e % 10 >= 2 && e % 10 <= 4 && (e % 100 < 10 || e % 100 >= 20) ? 1 : 2;
},
icelandic: function(e) {
return e % 10 != 1 || e % 100 == 11 ? 1 : 0;
}
}, _ = {
chinese: [ "fa", "id", "ja", "ko", "lo", "ms", "th", "tr", "zh" ],
german: [ "da", "de", "en", "es", "fi", "el", "he", "hu", "it", "nl", "no", "pt", "sv" ],
french: [ "fr", "tl", "pt-br" ],
russian: [ "hr", "ru" ],
czech: [ "cs", "sk" ],
polish: [ "pl" ],
icelandic: [ "is" ]
};
function i(e) {
var t, n, o, a = {};
for (t in e) if (e.hasOwnProperty(t)) {
n = e[t];
for (o in n) a[n[o]] = t;
}
return a;
}
var r = /^\s+|\s+$/g;
function c(e, n, a) {
var _, i;
return null != a && e ? (i = (_ = e.split(o))[l(n, a)] || _[0], t.call(i, r, "")) : e;
}
function s(e) {
var t = i(_);
return t[e] || t.en;
}
function l(e, t) {
return a[s(e)](t);
}
var u = /\$/g, h = "$$$$";
function d(e, n) {
for (var o in n) if ("_" !== o && n.hasOwnProperty(o)) {
var a = n[o];
"string" == typeof a && (a = t.call(n[o], u, h));
e = t.call(e, new RegExp("%\\{" + o + "\\}", "g"), a);
}
return e;
}
function g(t) {
e.console && e.console.warn && e.console.warn("WARNING: " + t);
}
function p(e) {
var t = {};
for (var n in e) t[n] = e[n];
return t;
}
return n;
});
cc._RF.pop();
}).call(this, "undefined" != typeof global ? global : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {});
}, {} ],
tl: [ function(e, t) {
"use strict";
cc._RF.push(t, "6a468GgaKdJq4uSTGRmnxDV", "tl");
var n, o;
t.exports = {
"": "",
alert: {
title_notification: "การแจ้งเตือน",
ok: "ยอมรับ",
yes: "ใช่",
no: "ไม่",
loaded: "เติม",
close: "ยกเลิก",
refuse: "ปฏิเสธ",
veritify: "ยึนยัน",
fail: "เกิดข้อผิดพลาด",
discard: "เลือกใหม่",
confirm_logout: "คุณแน่ใจว่าคุณต้องการที่จะออกจากระบบ?",
you_need_veritify_pin: "คุณต้องมีการยืนยัน PIN",
you_need_veritify_phone_number: "คุณต้องยืนยันหมายเลขโทรศัพท์ของคุณ!",
you_need_veritify_loaded_card: "คุณต้องเติมเงิน!",
coming_soon: "พบกับฟังก์ชั่นเร็วๆนี้",
coming_soon_game: "พบกับเกมเร็วๆนี้",
game_maintian: "เกมอยู่ระหว่างการปรับปรุง!",
fucntion_maintian: "ฟังก์ชันยู่ระหว่างการปรับปรุง!",
fucntion_use_lobby: "ฟังก์ชั่นนี้สามารถใช้ได้เฉพาะภายนอกล็อบบี้เท่านั้น!",
action_fast: "คุณดำเนินการเร็วเกินไป\nโปรดลองอีกครั้งในอีกสักครู่!",
error: {
not_enough_gold: "เหรียญไม่พอXU",
wrong_captcha: "โค้ด Captcha ผิด",
wrong_syntax: "ไวยากรณ์ผิด",
wrong_pin: "PIN ไม่ถูกต้อง หรือยังไม่ได้ลงทะเบียน PIN",
wrong_pin_or_not_reg_pin: "PIN ผิดหรือไม่ได้ลงทะเบียนรหัส PIN",
account_undefined: "ผู้เล่นไม่มีอยู่",
connector: {
fail: "ไม่มีการเชื่อมต่ออินเทอร์เน็ต . ตรวจสอบการเชื่อมต่อของคุณอีกครั้ง!",
a_2: "ต้องต่อเน็ต!!!",
a_3: "การเชื่อมต่อกับระบบ",
a_4: "คุณยังไม่มีของขวัญ . . เข้าร่วมกิจกรรมเพื่อรับของขวัญ!",
a_5: "กรุณาป้อน PIN",
a_6: "กรุณาป้อน Captcha!",
expired: "การเข้าสู่ระบบหมดอายุ กรุณาเข้าสู่ระบบใหม่อีกครั้ง",
ban: "บัญชีนี้ถูกล็อคโดยระบบ",
a_9: "ระบบกำลังปรับปรุง โปรดกลับมาใหม่!",
some_where: "บัญชีถูกเข้าสู่ระบบที่อื่นแล้ว"
},
services: {
a_10: "บัญชีหรือรหัสผ่านไม่ถูกต้อง",
a_11: "บัญชีถูกใช้งานแล้ว",
a_12: "ไม่มีบัญชี",
a_13: "รหัสผ่านผิด",
a_14: "คุณลงทะเบียนบัญชีมากเกินไป.",
a_15: "โปรดรอสักครู่เพื่อสร้างบัญชีต่อ.",
a_16: "คุณสร้างบัญชีมากเกินไป โปรดกลับมาพรุ่งนี้"
},
defined: {
fail: "ข้อผิดพลาดที่ไม่รู้จัก",
param_invalid: "พารามิเตอร์ไม่ถูกต้อง",
maintain_system: "ระบบกำลังปรับปรุง",
session_key_invalid: "ไม่มีคีย์เซสชัน",
session_expired: "รหัสเซสชันหมดอายุ",
session_room_not_exist: "ไม่มีห้องเล่น",
session_not_enough_min_buy_in: "เดิมพันขั้นต่ำไม่พอ",
out_buy_in_range: "นอกระบบเดิมพัน",
game_structure_invalid: "ไม่มีโครงสร้างเกม",
already_in_game: "คุณอยู่ในเกมแล้ว",
entering_game: "เข้าเกม",
gift_code_invalid: "ไม่มีรหัสของขวัญ",
gift_code_is_used: "ใช้รหัสของขวัญไปแล้ว",
gift_code_is_expired: "รหัสของขวัญหมดอายุ",
login_banned_ip: "IP ของคุณถูกล็อค . กรุณาติดต่อฝ่ายบริการลูกค้าสำหรับรายละเอียดเพิ่มเติม!",
login_banned_user: "บัญชีของคุณถูกล็อค. . กรุณาติดต่อฝ่ายบริการลูกค้าสำหรับรายละเอียดเพิ่มเติม!",
player_action_invalid: "การดำเนินการไม่ถูกต้อง",
player_action_fail: "การดำเนินการผิดพลาด",
not_enough_gold: "เหรียญไม่พอXU",
default: "ข้อผิดพลาด",
not_bet_too_long: "คุณได้รับเชิญออกจากระบบเนื่องจากไม่ได้โต้ตอบนานเกินไป"
}
}
},
LuckyWheel: {
system_error: "ระบบผิดพลาด",
received_code: "บัญชีได้รับรหัสของขวัญที่ปลอดภัย",
system_error_cache: "ระบบผิดพลาด. เกิดข้อผิดพลาดในการแคช Redis!",
system_error_database: "ระบบผิดพลาด. บันทึกข้อผิดพลาดฐานข้อมูล!",
success: "ยินดีด้วย คุณเพิ่งได้รับของขวัญ %{XXX} GOLD โปรดติดต่อฝ่ายบริการลูกค้าเพื่อรับรางวัลของคุณ",
contact: "ติดต่อฝ่ายบริการลูกค้าเพื่อรับของขวัญ"
},
loading: {
check_server: "Checking server information",
update: "Update",
update_success: "Update successful",
update_fail: "Update failed",
please_wait_update_version: "Please update to the latest version",
check_version: "Checking version",
progress_loading_new: "Updating the new version.",
not_loading_manifest: "Could not load manifest",
latest_current_version: "Latest current version",
load: "Loading"
},
lobby: {
lobby_notify_no_talk: "ขณะนี้ไม่ได้ถ่ายทอดสด โปรดกลับมาใหม่.",
not_have_account: "คุณไม่มีบัญชี",
forgot_password: "ลืมรหัสผ่าน",
login: "เข้าสู่ระบบ",
register: "ลงทะเบียน",
title_naprut: "เติมเงิน / เบิกเงิน",
title_support: "สนับสนุน",
title_security: "ความปลอดภัย",
title_mail: "กล่องจดหมาย",
title_fanpage: "Fanpage",
title_giftcode: "Gift Code",
title_group: "Group",
logout: "ออกจากระบบ",
jackpot: {
jungle_spirit: "Jungle Spirit",
captians: "Captian's",
agent_royale: "Agent Royale",
sexy_girl: "Dance Girl",
avangers: "Avangers",
fortune: "Fortune"
},
tab_game: {
all_game: "All Game",
mini_game: "Mini Game",
betting: "Betting",
live_game: "Live Game",
slot: "Slot Game",
casino: "Casino"
},
warning: {
error_try_gain: "เกิดข้อผิดพลาด. โปรดลองอีกครั้งในภายหลัง!",
minimum_transfer_500k: "จำนวนเงินขั้นต่ำคือ 500k Gold!",
not_enough_gold: "ยอดเงินไม่พร้อมใช้งาน",
maximum_bet_10M: "บัญชีเดิมพันกีฬาต้องไม่เกิน 10M",
transfer_success: "ยินดีด้วย! คุณเพิ่งโอนสำเร็จ: ",
error_in_processing: "เกิดข้อผิดพลาดในการประมวลผล!",
you_need_type_withdraw_money: "คุณต้องป้อนจำนวนเงินที่ถอน!",
wrong_money: "จำนวนเงินไม่ถูกต้อง!",
cant_get_credit_try_again: "ไม่สามารถรับยอดเงินได้ กรุณาลองอีกครั้ง!",
withdraw_success: "ยินดีด้วย! คุณถอนสำเร็จแล้ว",
delete_mail_success: "ลบข้อความสำเร็จ!",
you_sure_delete_mail: "คุณแน่ใจว่าต้องการลบข้อความ",
error: "เกิดข้อผิดพลาด",
developing_feature: "ฟีเจอร์นี้กำลังพัฒนา!",
wrong_giftcode_check_again: "รหัสของขวัญไม่ถูกต้อง โปรดตรวจสอบอีกครั้ง!",
gift_code_is_used: "รหัสของขวัญ ถูกใช้แล้ว!",
congluratulation: "ยินดีด้วย! คุณได้รับแล้ว!",
invalid_giftcode: "รหัสของขวัญที่ป้อนไม่ถูกต้อง!",
over_exp_giftcode: "รหัสของขวัญ หมดอายุแล้ว!",
unsecury_account: "บัญชียังไม่ได้ลงทะเบียนความปลอดภัย!",
giftcode_cant_use_phone_number: "รหัสของขวัญใช้ไม่ได้กับบัญชีที่ปกป้องด้วยหมายเลขโทรศัพท์เวียดนาม",
giftcode_cant_use_this_account: "ไม่สามารถใช้รหัสของขวัญสำหรับบัญชีนี้ได้!",
please_type_num_money: "กรุณากรอกจำนวนเงิน!",
minimum_trade: "ธุรกรรมขั้นต่ำ",
gold_up: "ทอง",
gold_n: "ทอง",
not_enough_gold1: "ยอดเงินในบัญชีไม่เพียงพอ",
username_must_same: "ชื่อบัญชีต้องเหมือนกัน!",
please_type_full_info: "กรุณากรอกข้อมูลให้ครบถ้วน! (ชื่อตัวแทน ชื่อเล่น จำนวนเงิน)",
un_phone_number_verify_account: "บัญชียังไม่ได้รับการยืนยันความปลอดภัยของหมายเลขโทรศัพท์",
cant_transfer_yourselft: "โอนให้ตัวเองไม่ได้",
change_avatar_success: "เปลี่ยนอวาตาร์สำเร็จ!",
please_type_full_info1: "กรุณากรอกข้อมูลให้ครบถ้วน!",
password_confirm_password_must_same: "รหัสผ่านใหม่และรหัสผ่านที่ป้อนใหม่จะต้องเหมือนกัน!",
old_password_wrong: "รหัสผ่านเก่าไม่ถูกต้อง",
you_sure_withdraw: "คุณแน่ใจหรือว่าต้องการถอน VND. จำนวนทอง",
unexist_account: "ไม่มีบัญชี!",
untype_username: "คุณยังไม่ได้ป้อนชื่อผู้ใช้",
untype_password: "คุณยังไม่ได้ป้อนรหัสผ่าน",
server_lost_connect: "ขาดการเชื่อมต่อเซิร์ฟเวอร์",
account_logining_please_logout: "บัญชีของคุณกำลังเข้าสู่ระบบที่อื่น กรุณาออกจากระบบก่อนเข้าสู่ระบบ",
account_banning: "บัญชีถูกแบน.",
invalid_authentication_code: "รหัสยืนยันไม่ถูกต้อง",
overtime_authentication: "รหัสยืนยันหมดอายุแล้ว",
server_maintain_go_later: "ระบบกำลังบำรุงรักษา โปรดกลับมาใหม่.",
password_wrong: "รหัสผ่านผิด",
login_banned: "ถูแบนเข้าสู่ระบบ",
unexist_user: "ไม่มีชื่อผู้ใช้",
you_not_create_username: "คุณยังไม่ได้สร้างชื่อตัวละครสำหรับบัญชี.",
username_warning: "ชื่อผู้ใช้ต้องมีความยาวตั้งแต่ 6 - 18 ตัวอักษร เขียนติดกัน, ไม่มีวรรณยุกต์, ไม่มีอักขระพิเศษ!",
password_same_warning: "รหัสผ่านที่ป้อนใหม่ไม่ตรงกับรหัสผ่านที่ป้อน",
verify_code_wrong: "รหัสไม่ถูกต้อง",
internet_unstable: "การเชื่อมต่อเครือข่ายไม่เสถียร โปรดตรวจสอบการเชื่อมต่อ wifi/3g",
invalid_username: "ชื่อผู้ใช้ที่ไม่ถูกต้อง",
username_exist: "มีชื่อผู้ใช้อยู่แล้ว",
invite_code_unexist: "ไม่มีรหัสอ้างอิง",
invite_code_wrong_type: "รหัสอ้างอิงไม่ถูกต้อง (เช่น:K1234567)",
captcha_wrong: "รหัส captcha ไม่ถูกต้อง",
captcha_error: "captcha ผิดพลาด",
nickname_invalid: "ชื่อเล่นไม่ถูกต้อง",
nickname_exist: "มีชื่อเล่นอยู่แล้ว",
nickname_not_same_username: "ชื่อเล่นต้องไม่เหมือนกับชื่อผู้ใช้",
nickname_had: "มีชื่อเล่นแล้ว.",
nickname_not_sentitive: "อย่าเลือกชื่อเล่นที่ละเอียดอ่อน",
check_network: "การเชื่อมต่อเครือข่ายไม่เสถียร",
logined_other_device: "คุณเข้าสู่ระบบในอุปกรณ์อื่น",
giftcode_please_enter_full: "กรุณากรอกรหัสของขวัญให้ครบถ้วน",
info_update_success_contact_to_complete: "อัปเดตสำเร็จแล้ว! กรุณาแชทกับ  bot tele เพื่อทำตามขั้นตอนการรักษาความปลอดภัยให้เสร็จสิ้น",
info_error_update: "เกิดข้อผิดพลาดขณะอัปเดตข้อมูล!",
info_email_wrong_type: "รูปแบบอีเมลไม่ถูกต้อง!",
info_phone_number_wrong_type: "รูปแบบหมายเลขโทรศัพท์ไม่ถูกต้อง!",
info_email_registered_other_account: "อีเมลถูกลงทะเบียนโดยบัญชีอื่นแล้ว!",
info_not_need_otp_unsecure_account: "ไม่ต้องใช้ OTP สำหรับบัญชีที่ไม่ปลอดภัย!",
info_phone_number_registered_try_other: "หมายเลขโทรศัพท์ถูกลงทะเบียนแล้ว กรุณาใช้หมายเลขโทรศัพท์อื่น!",
phone_number_warning: "เบอร์โทรต้องยาว 10-15 ตัวเลข!",
otp_required: "รหัส OTP เป็นข้อมูลที่จำเป็น",
otp_tele_wrong: "ป้อนรหัส Tele OTP ผิด. กรุณาลองอีกครั้ง",
otp_wrong: "รหัส OTP ไม่ถูกต้อง!",
otp_unexist: "ไม่มีรหัส OTP",
otp_overtime_use: "รหัส OTP หมดอายุแล้ว",
you_sure_out_game: "คุณแน่ใจหรือไม่ว่าต้องการออกจากเกม?",
password_change_success: "เปลี่ยนรหัสผ่านสำเร็จ!",
password_required: "รหัสผ่านใหม่เป็นข้อมูลที่จำเป็น",
password_confirm_required: "จำเป็นต้องป้อนข้อมูลใหม่อีกครั้ง",
password_confirm_wrong: "ยืนยันรหัสผ่านใหม่ไม่ถูกต้อง",
password_current_wrong: "รหัสผ่านปัจจุบันไม่ถูกต้อง",
account_login_fb_gg_cant_use_feature: "บัญชีที่เข้าสู่ระบบด้วย Facebook หรือ Google+ ไม่สามารถใช้ฟังก์ชันนี้ได้!",
feature_for_register_secury_account: "ฟังก์ชันนี้มีไว้สำหรับบัญชีที่ลงทะเบียนแล้วความปลอดภัย!",
account_warning_nickname: "ระบบไม่รองรับบัญชีที่ยังไม่ได้อัพเดทชื่อเล่น",
you_need_enter_money: "คุณต้องป้อนจำนวนเงิน!",
deposit_order_double: "คุณสร้างคำสั่งเติมเงิน 2 ครั้งในเวลาใกล้กันเกินไป",
deposit_order_limit_per_day: "เกินขีดจำกัดในการสร้างคำสั่งฝากในหนึ่งวัน! จำเป็นต้องโอนเงินเพื่อทำการฝากเงินก่อนสร้างคำสั่งครั้งต่อไป",
buy_gold_faild: "ซื้อทองล้มเหลว!",
withdraw_money_faild: "ถอนเงินไม่สำเร็จ",
withdraw_maximum_is: "จำนวนเงินที่สามารถโอนได้สูงสุดคือ ",
withdraw_maximum_is_after: " ตามกลไกของ GIFTCODE สำหรับข้อมูลเพิ่มเติม กรุณาติดต่อ ซีเอสเคเอช",
withdraw_fail: "การถอนเงินล้มเหลว!",
success: "สำเร็จ!",
bank_id_required: "ต้องระบุรหัสธนาคาร!",
account_number_required: "ต้องระบุหมายเลขบัญชี!",
username_required: "ต้องระบุชื่อผู้ใช้!",
nickname_required: "ต้องระบุชื่อเล่น!",
num_gold_required: "ต้องใส่จำนวนทอง!",
account_number_wrong_type: "หมายเลขบัญชีไม่ถูกต้อง!",
num_gold_wrong_type: "จำนวนทองไม่ถูกต้อง!",
account_banned_transfer: "บัญชีถูกล็อคฟังก์ชั่นการโอน!",
withdraw_money_minimum: "บัญชีถูกล็อคฟังก์ชั่นการโอน!",
error_undetermine: "ข้อผิดพลาดที่ไม่รู้จัก",
not_enough_transfer_require_contact_service: "คุณไม่มีสิทธิ์ทำธุรกรรม รายละเอียดกรุณาติดต่อฝ่ายบริการลูกค้า!",
attendance_success: "การเข้าร่วมสำเร็จ!",
attendance_fail: "การเข้าร่วมล้มเหลว",
account_unregister_secure: "บัญชียังไม่ได้ลงทะเบียนความปลอดภัย",
account_unregister_secure_contact_service: "บัญชีไม่ได้ลงทะเบียนฟังก์ชั่นความปลอดภัย โปรดติดต่อ Telegram:@cskhboss79 หรือ โทร 19006896 เพื่อขอความช่วยเหลือ ตรวจสอบข้อมูลบัญชีเพื่อรับรหัสผ่าน ขอขอบคุณ!",
account_unexist: "ไม่มีบัญชี",
server_unconnect: "ไม่ได้เชื่อมต่อกับเซิร์ฟเวอร์",
server_terminate_interupt: "เซิฟเวอร์ขัดข้องชั่วคราว",
account_not_enter: "คุณยังไม่ได้ป้อนชื่อผู้ใช้",
password_not_enter: "คุณยังไม่ได้ป้อนรหัสผ่าน",
play_game_fun: "ขอให้คุณสนุกกับการเล่นเกม",
good_luck_later: "ขอให้โชคดีในครั้งต่อไป",
transfer_account_receive_unexist: "ไม่มีบัญชีรับ!",
transfer_minimum_money: "จำนวนเงินโอนน้อยกว่ามูลค่าธุรกรรมขั้นต่ำ!",
account_not_enought_transfer_condition: "บัญชีไม่มีสิทธิ์ในการทำธุรกรรม โปรดติดต่อผุ้จำหน่าย!",
sercure_feature_auto_active: "ฟังก์ชั่นความปลอดภัยจะเปิดใช้งานโดยอัตโนมัติหลังจาก 24 ชั่วโมงนับจากเวลาที่ลงทะเบียนสำเร็จ!",
transfer_limit: "คุณสามารถโอนเงินจำนวนหนึ่งให้กับตัวแทนทั่วไปเท่านั้น",
transfer_over_credit: "ยอดโอนเกินกำหนด!",
transfer_account_send_unexist: "ไม่มีบัญชีโอน!",
transfer_enter_content: "จำเป็นต้องใส่เนื้อหาการโอน!",
tranfer_same_account: "บัญชีโอนเหมือนกับบัญชีรับ",
transfer_local_feature_terminated_contact_service: "ฟังก์ชันการโอนภายในถูกระงับชั่วคราว โปรดติดต่อฝ่ายบริการลูกค้าเพื่อขอความช่วยเหลือ!",
transfer_local_feature_terminated_contact_service1: "ฟังก์ชันการโอนภายในถูกปิดใช้งานชั่วคราว กรุณาติดต่อฝ่ายบริการลูกค้าสำหรับรายละเอียดเพิ่มเติม!"
},
gui_profile: {
profile_title: "โปรไฟล์",
join_time: "วันที่เข้าร่วม",
birth_date: "วันเกิด",
ip_address: "ที่อยู่ IP",
invite_code: "รหัสอ้างอิง",
change_password: "เปลี่ยนรหัสผ่าน",
change_password1: "เปลี่ยนรหัสผ่าน",
change_avatar: "เปลี่ยนรูปประจำตัว",
back: "กลับ",
change: "เปลี่ยน",
current_password: "รหัสผ่านปัจจุบัน",
new_password: "รหัสผ่านใหม่",
confirm_new_password: "ใส่รหัสผ่านใหม่อีกครั้ง",
update: "อัปเดต",
alert: {
warning_1: "รูปประจำตัวของคุณ ไม่ต่างจากรูปประจำตัวก่อนหน้า",
warning_2: "เลือกรูปประจำตัวที่คุณต้องการเปลี่ยน"
}
},
gui_agency: {
deposit_title: "เติมทอง",
deposit_gold: "เติมทอง",
deposit_history: "ประวัติการเติมเงิน",
sell_title: "ขายGold",
sell_gold: "ขายGold",
sell_history: "ประวัติการขาย",
current_credit: "ยอดปัจจุบัน",
agency: "ตัวแทน",
deposit_money: "ฝากเงิน",
receive_gold: "รับทอง",
agency_note: "หมายเหตุ: ตรวจสอบข้อมูลของตัวแทนอย่างละเอียดก่อนโอน โอนไปยังผู้จำหน่ายที่ไม่ถูกต้องซึ่งไม่รองรับ หลังจาก 5 นาทียังไม่ได้รับทอง ติดต่อที่:",
or_call_to: "หรือโทร",
note: "หมายเหตุ",
minimum_trade: "ธุรกรรมขั้นต่ำ",
rate_trade: "Transaction Fee",
exchange_rate: "อัตราการแลกเปลี่ยน",
account_number: "หมายเลขบัญชี",
account_name: "ชื่อบัญชี",
area: "พื้นที่",
confirm: "ยืนยัน",
deposit_note: "คุณได้สร้างคำสั่งฝากเงินสำเร็จแล้ว. ต่อไป เพื่อทำขั้นตอนการฝากเงินให้เสร็จสิ้น โปรดติดต่อฝ่ายบริการลูกค้าเพื่อส่งใบแจ้งหนี้การโอนเงิน",
notify_title: "แจ้งเตือน",
num_transfer_gold: "จำนวนทองที่โอน",
receive_money: "จำนวนเงินที่ได้รับ",
branch: "สาขา",
account_owner_name: "ชื่อเจ้าของบัญชี",
continue: "ดำเนินการต่อ",
status: "สถานะ",
time: "เวลา",
transfer_code_short: "รหัสธุรกรรม",
num_transfer_money: "จำนวนเงินโอน",
title_new_bank: "ใส่ชื่อธนาคาร",
title_bank_other: "ธนาคารอื่นๆ",
title_new_bank_message: "ใส่ชื่อธนาคารที่คุณต้องการถอนเงิน",
lao: "ลาว",
taiwan: "ไต้หวัน",
vietnam: "เวียดนาม",
thailan: "ประเทศไทย",
pending: "กำลังประมวลผล",
accepted: "ที่ได้รับการอนุมัติ",
rejected: "ยกเลิก",
huy: "ยกเลิก"
},
gui_list_agency: {
country_code: {
VN: "Vietnamese",
JP: "Japan",
KR: "Korea",
TW: "Taiwan",
LA: "Laos",
KH: "Cambodia",
US: "United States",
MM: "Myanmar",
TH: "Thailand",
LD: "LD",
WB: "WB",
JL: "JL"
},
agency_title: "ตัวแทน",
korea: "Korea",
japan: "Japan",
taiwan: "Taiwan",
lao: "Laos",
campuchia: "Cambodia",
singapore: "Singapore",
thailand: "Thailand",
myanmar: "Myanmar",
no: "ลำดับ",
agency: "ตัวแทน",
nickname: "ชื่อเล่น",
phone_number: "หมายเลขโทรศัพท์",
contact: "ติดต่อ",
area: "พื้นที่",
action: "การกระทำ",
buy: "ซื้อ",
sell: "ขาย",
rate: "ประเมิน",
people_rate: " ผู้คนให้คะแนนมัน",
action_rate: "คลิกเพื่อให้คะแนนตัวแทน",
title_rate: "ประเมินผลตอบรับเกี่ยวกับตัวแทน ",
feedback_rate: "ผลตอบรับจากผู้อื่น",
enter_content: "เข้าสู่เนื้อหาแชท...",
rate_success: "เรตติ้งสำเร็จ ",
rate_fail: "เรตติ้งล้มเหลว",
dk_rate: "คุณต้องซื้อขายทองคำขั้นต่ำ 100,000 ทองกับตัวแทนเพื่อรับการตรวจสอบ ขอบคุณ!",
dk_rate_1: "กรุณากรอกเนื้อหาความคิดเห็นเพื่อทำการตรวจสอบให้เสร็จสิ้น (ขั้นต่ำ 12 ตัวอักษร)",
dk_rate_2: "การทำธุรกรรมที่ประสบความสำเร็จ โปรดสละเวลาให้คะแนนตัวแทนเพื่อให้เราสามารถปรับปรุงบริการของเราได้ดียิ่งขึ้น",
dk_rate_content_0: "ตัวแทนการค้าที่เชื่อถือได้",
dk_rate_content_1: "ตัวแทนการทำธุรกรรมที่รวดเร็ว",
dk_rate_content_2: "OK",
dk_rate_content_3: "ตัวแทนสนับสนุน",
dk_rate_content_4: "ขออวยพรให้ตัวแทนมีโชคลาภและความเจริญรุ่งเรือง"
},
gui_attendance: {
attendance: "การเข้าร่วม",
attendance_title: "การเข้าร่วม",
day: "วัน",
day1: "วันที่ 1",
day2: "วันที่ 2",
day3: "วันที่ 3",
day4: "วันที่ 4",
day5: "วันที่ 5",
day6: "วันที่ 6",
day7: "วันที่ 7",
attendance_note: "โปรดเข้าร่วมอย่างเต็มที่เพื่อรับรางวัลที่น่าสนใจในช่วงสุดสัปดาห์"
},
gui_open_egg: {
open_egg: "เปิดไข่",
gold_egg: "ไข่ทองคำ",
white_egg: "ไข่ขาว",
no_egg: "ไม่มีไข่"
},
gui_bundle_download: {
download_game: "ดาวน์โหลดเกม",
download: "ดาวน์โหลด"
},
gui_event_list_giftcode: {
list_giftcode_title: "รายการรหัสของขวัญ"
},
gui_events: {
event_title: "กิจกรรม",
event: "กิจกรรม",
event_top_bet: "กิจกรรมเดิมพันสูงสุด",
event_attendace: "กิจกรรมการเข้าร่วม",
event_receive_bet: "กิจกรรมรับเดิมพัน",
event_find_million: "กิจกรรมตามหาเศรษฐีเงินล้าน",
event_sicbo: "กิจกรรมไฮ-โล",
event_jackpot_sicbo: "แจ็คพอตไฮ-โล",
rules: "อัตราส่วน",
daily_top: "ยอดรายจำวัน",
top_bet: "เดิมพันสูงสุด",
attendace_again: "เข้าร่วมอีกครั้ง",
rank: "อันดับ",
user: "ผู้เล่น",
bet: "เดิมพัน",
refund: "คืนเงิน",
money: "จำนวนเงิน"
},
gui_trade_history: {
trade_history_title: "ประวัติการทำธุรกรรม",
trade_history: "ประวัติการทำธุรกรรม",
play_gold: "เล่นทอง",
play_chip: "เล่นเหรียญ",
deposit_chip: "เติมเหรียญ",
deposit_gold: "เติมทอง",
expense_gold: "ใช้ทอง",
trade_code: "รหัสธุรกรรม",
time: "เวลา",
service: "บริการ",
incurred: "ที่เกิดขึ้น",
credit: "ยอดเงิน",
description: "คำอธิบาย",
detail: "รายละเอียด",
view: "ดู"
},
gui_forgot_password: (n = {
account: "บัญชี",
account_title: "บัญชี",
account_note_full_info: "เพื่อรับการสนับสนุน กรุณากรอกข้อมูลด้านล่าง",
account_note_username: "ชื่อตัวละครเป็นข้อมูลที่จำเป็น",
type_login_name: "ใส่ชื่อผู้ใช้",
authentication_code: "รหัสยืนยัน",
send: "ส่ง",
forgot_password: "ลืมรหัสผ่าน",
forgot_password_title: "ลืมรหัสผ่าน",
telegram_authentication_code: "รหัสยืนยันโทรเลข..."
}, n.send = "ส่ง", n.new_password = "รหัสผ่านใหม่", n.confirm_new_password = "ใส่รหัสผ่านใหม่ของคุณอีกครั้ง", 
n),
gui_display_name: {
account_title: "บัญชี",
account_note_username: "ชื่อตัวละครเป็นข้อมูลที่จำเป็น",
username: "ชื่อตัวละคร",
account_note_username1: "ชื่อตัวละครจะอยู่ระหว่าง 6-16 อักขระ ไม่มีอักขระที่ละเอียดอ่อน อักขระพิเศษ และไม่มีการเว้นวรรค",
create_new: "สร้างใหม่"
},
gui_login: {
login_title: "บัญชี",
login_name: "ชื่อผู้ใช้",
password: "รหัสผ่าน",
save_password: "บันทึกรหัสผ่าน",
login: "เข้าสู่ระบบ",
forgot_password: "ลืมรหัสผ่าน"
},
gui_registry: {
register_title: "ลงทะเบียน",
register: "ลงทะเบียน",
login_name: "ชื่อผู้ใช้",
password: "รหัสผ่าน",
confirm_password: "รหัสผ่าน",
invite_code_note: "รหัสอ้างอิง (ไม่บังคับ)",
captcha: "Captcha"
},
gui_mailbox: {
title: "หัวข้อ:",
content: "เนื้อหา:",
sender: "ผู้ส่ง:",
unread: "ยังไม่ได้อ่าน",
read: "อ่าน",
mailbox_title: "กล่องจดหมาย",
mess_delete_mail: "คุณแน่ใจว่าต้องการลบข้อความ?"
},
gui_minigame: {
game_download: "ดาวน์โหลดเกม",
taixiu: "ไฮโล",
caothap: "สูงและต่ำ",
chanle: "คี่ - คู่",
xocdia: "ทอยลูกเต๋า",
pokego: "โปเกมอน",
baucua: "KLA KLOUK"
},
gui_confirm_transfer: {
notify: "แจ้งเตือน",
agency_account: "บัญชีเอเจนซี่",
notify_note_cheat: "ควรทำธุรกรรมกับตัวแทนเท่านั้นเพื่อหลีกเลี่ยงการฉ้อโกง",
you_sure_send: "คุณแน่ใจว่าต้องการโอนไปที่",
amount_money: "จำนวนเงิน",
reason: "จำนวนเงิน",
reject: "ยกเลิก",
accept: "ยอมรับ",
account: "บัญชี",
confirm_transfer_title: "แจ้งเตือน"
},
gui_buy_gold: {
buy_gold: "ซื้อทอง",
buy_gold_title: "ซื้อทอง",
current_credit: "ยอดปัจจุบัน",
agency: "ตัวแทน",
enter_agency: "ป้อนตัวแทน",
nickname: "ชื่อเล่น",
enter_nickname: "ใส่ชื่อเล่น",
buy_money: "เงินเติม",
number_buy_money: "ใส่จำนวนเงินที่เติม...",
gold: "ทอง",
receive_gold: "รับทอง",
other_agency: "ตัวแทนอื่นๆ",
lb_warning_1: "ติดต่อตัวแทนสำหรับการทำธุรกรรมโดยตรง",
lb_warning_2: "เบอร์โทรตัวแทนจำหน่าย: ",
lb_warning_3: "หรือเยี่ยมชมลิงค์: "
},
gui_sell_gold: {
sell_gold: "ขายGold",
sell_gold_title: "ขายGold",
current_credit: "ยอดปัจจุบัน",
agency: "ตัวแทน",
enter_agency: "ป้อนตัวแทน",
nickname: "ชื่อเล่น",
enter_nickname: "ใส่ชื่อเล่น",
buy_money: "ฝากเงิน",
number_sell_gold: "จำนวนทองที่โอน",
gold: "ทอง",
receive_money: "จำนวนเงินที่ได้รับ",
other_agency: "ตัวแทนอื่นๆ",
continue: "ดำเนินการต่อ",
transfer_reason: "เหตุผล",
lao: "ลาว",
cam: "กัมพูชา",
vn: "เวียดนาม",
kor: "เกาหลีใต้",
jp: "ญี่ปุ่น",
tw: "ไต้หวัน"
},
safetybox: {
safetybox_title: "ตู้เชฟ",
lb_goldin: "ทองในตู้นิรภัย",
note: "สร้างรหัสผ่านเพื่อใช้ตู้เซฟ!",
lb_btn: {
chuyen: "โอน",
rut: "ถอน",
doimk: "เปลี่ยนรหัสผ่าน",
dongy: "ยอมรับ",
back: "กลับ"
},
lb_editbox: {
lb_chuyen: "จำนวนทองที่โอน",
lb_rut: "จำนวนทองที่ถอนออก",
placeholder_password_rut: "ป้อนรหัสผ่านที่ปลอดภัยเพื่อถอนเงิน",
"สร้างรหัสผ่าน": "สร้างรหัสผ่าน",
placeholder_re_password_create: "ยืนยันรหัสผ่าน",
placeholder_password_old: "รหัสผ่านเก่า",
placeholder_new_password_update: "รหัสผ่านใหม่",
placeholder_re_new_password_update: "ใส่รหัสผ่านใหม่อีกครั้ง"
},
message: {
wrong_password: "คุณป้อนรหัสผ่านผิด โปรดป้อนใหม่!",
wrong_password_retype: "รหัสผ่านไม่ถูกต้อง โปรดลองอีกครั้ง",
wrong_old_pass: "รหัสผ่านเก่าไม่ถูกต้อง โปรดป้อนใหม่!",
withdraw_success: "ถอนสำเร็จ!",
transfer_success: "ย้ายเข้าเรียบร้อยแล้ว!",
transfer_failed: "การถอนเงินล้มเหลว!",
create_password_success: "สร้างรหัสผ่านสำเร็จ!",
update_password_success: "เปลี่ยนรหัสผ่านสำเร็จ!",
please_type_money_withdraw: "กรุณาใส่จำนวนเงินที่คุณต้องการถอน",
please_type_money_transfer: "กรุณากรอกจำนวนเงินที่ต้องการโอน",
error_create: "เกิดข้อผิดพลาดระหว่างการสร้าง. โปรดป้อนใหม่!",
error_update: "เกิดข้อผิดพลาดขณะอัปเดตข้อมูล! โปรดลองอีกครั้ง!",
error_network: "การเชื่อมต่อไม่เสถียร โปรดลองอีกครั้ง!"
}
},
gui_setting: {
music: "เสียง",
music_on: "เสียง (เปิด)",
music_off: "เสียง (ปิด)",
term_of_use: "ข้อกำหนดการใช้งาน",
feedBack: "ข้อเสนอแนะ"
},
gui_notify: {
title_notify: "แจ้งเตือน",
notify_common_admin: "คณะกรรมการบริหาร BOSS79 เรียนประกาศ",
notify_common_noti: "ผู้จำหน่ายเรียนประกาศ",
notify_common_content: 'เพื่อตอบสนองความต้องการของตัวแทนและลูกค้า \n เราเปิดไซต์อื่นอย่างเป็นทางการ:                                 \n ด้วยเกมส์ที่หลากหลาย, "ลอตเตอรีเหนือ กลาง และใต้ ด้วยอัตราการจ่ายที่น่าสนใจอย่างยิ่งเมื่อเทียบกับท้องตลาด" และเกมคาสิโนที่หลากหลาย เดิมพันกีฬา\nบาคาร่า ด้วยอัตราผลตอบแทนที่สูงมาก,\nมอบประสบการณ์ที่น่าดึงดูดอย่างยิ่งด้วยอัตราส่วนการฝาก/ถอน\n1:1.'
},
gui_chuyen_quy: {
transfer_withdraw_title: "เติม/ถอนBank",
num_transfer_gold: "จำนวนทองที่โอน",
receive_money: "จำนวนเงินที่ได้รับ",
transfer_fund: "การโอนเงิน",
play_now: "เล่นเลย",
withdraw_fund: "ถอนออก",
withdraw_money: "จำนวนเงินที่จะถอน",
num_receive_gold: "จำนวนทองที่ได้รับ",
type_num_gold: "ใส่จำนวนทอง",
type_num_money: "กรุณากรอกจำนวนเงิน!",
receive_gold: "รับทอง",
current_money: "เงินปัจจุบัน"
},
gui_transfer: {
transfer: "โอนเงิน",
transfer_title: "โอนตัง",
current_credit: "ยอดปัจจุบัน",
enter_nickname: "ใส่ชื่อเล่น",
re_enter_nickname: "ใส่ชื่อเล่นอีกครั้ง",
enter_sell_money: "จำนวนทองที่โอน",
receive_gold: "จำนวนทองที่ได้รับ",
reason: "เหตุผลที่โอน",
continue: "ดำเนินการต่อ",
agency: "ตัวแทน",
gold: "ทอง",
amount_less_than_minimum: "ยอดโอนน้อยกว่ามูลค่าธุรกรรมขั้นต่ำ!",
unregister_security: "บัญชีที่ไม่ได้ลงทะเบียนเพื่อความปลอดภัย! กรุณาติดต่อฝ่ายบริการลูกค้า!",
otp_expired: "รหัส OTP หมดอายุแล้ว!",
otp_not_correct: "รหัส OTP ไม่ถูกต้อง!",
otp_error: "รหัส OTP ผิดพลาด!",
una_balance: "ยอดเงินคงเหลือ!",
lock_transfer: "ชื่อเล่นถูกล็อคจากฟังก์ชั่นการโอน!",
acc_not_exist: "ไม่มีชื่อเล่น!",
enter_details: "กรุณากรอกรายละเอียดการโอน!",
not_transfer_yourself: "ไม่สามารถโอนให้ตัวเองได้",
not_transfer_agency: "ตัวแทนไม่สามารถโอนให้ตัวแทนได้",
not_transfer_agency2: "ตัวแทนระดับ 2 ไม่สามารถถ่ายโอนไปยังตัวแทนระดับ 2",
not_transfer_not_your_agency2: "คุณไม่สามารถโอนเงินไปยังตัวแทนระดับ 2 ที่ไม่ใช่ของคุณ!",
amount_maximum: "\n\nจำนวนเงินสูงสุดที่สามารถโอนได้คือ %{money} ตามกลไกของ GIFTCODE สำหรับรายละเอียดเพิ่มเติม กรุณาติดต่อฝ่ายบริการลูกค้า!",
transfer_fail: "โอนไม่สำเร็จ!",
transfer_success: "โอนสำเร็จ ",
sell_gold: "ขายทองให้กับ",
sell_gold_user_text_0: " ลัคกี้ ลัคกี้",
sell_gold_user_text_1: "ชัยชนะที่มั่นใจ ",
sell_gold_user_text_2: "%{myNickName} โอน GOLD ไปที่ %{otherNickName} ",
sell_gold_user_text_3: "Lucky Money "
},
gui_logout: {
logout_title: "ออกจากระบบ",
warning: "คุณแน่ใจหรือไม่ว่าต้องการออกจากเกม?",
no: "ยกเลิก",
yes: "ยอมรับ"
},
gui_policy: {
policy_title: "นโยบาย"
},
gui_security: {
security_title: "โปรไฟล์",
account_name: "ชื่อบัญชี",
username: "ชื่อตัวละคร",
cmtnd: "หมายเลขบัตรประชาชน",
email: "อีเมล",
phone_number: "หมายเลขโทรศัพท์",
update: "อัปเดต",
active: "เปิดใช้งาน",
get_otp: "รหัส OTP"
},
gui_buy_and_sold: {
buy_and_sold_title: "ร้านค้า",
transfer: "โอนเงิน",
sell_gold: "ขายGold",
input_otp: "กรอก OTP"
},
gui_gift_code: {
notice: "* หากต้องการรับรหัสของขวัญ โปรดป้อนรหัสที่ถูกต้องและจดเวลารับรหัสของขวัญ.\n* รหัสของขวัญแต่ละรหัสใช้ได้กับ1บัญชีเท่านั้น",
gift_code_title: "Gift Code",
enter_gift_code: "ใส่ GiftCode",
receive: "รับ",
price: "ราคา: ",
code: "รหัส: "
},
gui_header: {
logout: "ออกจากระบบ",
safetybox: "ปลอดภัย",
history: "ประวัติ",
language: "ภาษา",
shop: "ร้านค้า",
setting: "การตั้งค่า",
confirm_change_language: "คุณแน่ใจหรือไม่ว่าต้องการเปลี่ยนธีมเป็น\n %{language} ?",
ok: "ใช่",
cancel: "ไม่",
win: "ชนะ",
day: "วัน"
},
gui_choose_nation: {
choose_nation_title: "เลือกประเทศ"
},
gui_language: {
language_title: "ภาษา"
},
mergeWord: {
transaction_failed: "Transaction failed. Please try again later!",
transaction_success: "Successful transaction",
seller_not_online: "The seller is currently not online",
insufficient_balance: "Insufficient balance!",
letter_not_exist: "Letters/Numbers do not exist!",
sys_err: "System error. Please try again later!",
price_greater: "The price of letters/numbers must be greater than the floor price!",
wants_to_sell: " wants to sell you the letter/number",
price: "Price: ",
please_choose_letters: "Please choose the letters from the inventory on the left to combine them!",
pairing_fail: "Pairing letters failed.",
pairing_success: "Pairing letters successfully. You receive ",
empty_data: "Empty data",
word_incorrect: "The word set is incorrect!",
not_enough_letters: "You don't have enough letters/numbers!",
account_not_exist: "Account does not exist!",
selling_failed: "Selling words failed. Please try again later!",
selling_success: "Selling words successfully. Please wait for the buyer to confirm!",
buyer_not_online: "The buyer is not online. Please try again later!",
action_fast: "You act too fast. Please try again in a moment!",
greater_minimum: "The transaction amount must be greater than the specified minimum transaction amount",
minimum_selling: "Minimum selling price is 10,000 Gold.",
transaction_fee: "Transaction fee is 5% (Minimum is 10,000 Gold)",
transaction_note: "You want to trade this word with someone else. Please carefully check the sender information and denomination, if the operation is wrong, no refund will be given!",
selling_err: " An error occurred when selling %s for %s to %s",
acepted_buy: "%s agrees to buy letter %s for %s Gold",
not_acepted_buy: "%s doesn't agree to buy letter %s for %s Gold",
please_choose_word: "Please select letter to sell",
please_type_nickname: "Please enter a nickname!",
please_type_price: "Please enter selling price!",
buy: "Buy",
sell: "Sell",
history_buy_sell: "Transaction History",
history_trade_word: "History of letter exchange",
nickname: "Nickname"
}
},
minigame: {
chat: {
input_chat: "แชท",
send: "ส่ง",
error: "ข้อผิดพลาด",
greeting: "ขอให้คุณสนุกกับการเล่นเกม",
banned: "*** คุณไม่ได้รับอนุญาตให้แชท!",
temp_banned: "*** ถูกแบนจากการแชทชั่วคราว!",
limited_length: "*** เนื้อหาแชทยาวเกินไป!",
not_enough_gold: "*** ยอดคงเหลือไม่เพียงพอสำหรับการแชท.",
ban_forever: "*** คุณถูกแบนจากการแชทตลอดไป.",
action_quickly: "*** คุณแชทเร็วเกินไป.",
require_length: "กรุณาใส่มากกว่า 1 ตัวอักษร",
require_topup: "คุณต้องเติมเงินเพื่อเปิดฟีเจอร์แชท"
},
common: {
rebet: "เดิมพันใหม่",
accept: "ยอมรับ",
destroy: "ยกเลิก",
select: "เลือก",
all_in: "หมดมือ",
dice_1: "ลูกเต๋า 1",
dice_2: "ลูกเต๋า 2",
dice_3: "ลูกเต๋า 3",
top_day: "วัน",
top_month: "เดือน",
top_year: "ปี",
top_round: "รัฐ",
top_round1: "รัฐ 1",
top_round2: "รัฐ 2",
title_help: "แนะนำ",
title_session_detail: "รายละเอียดรอบ",
title_session: "รอบ",
title_nickname: "ชื่อเล่น",
title_name: "ชื่อ",
title_time: "เวลา",
title_side: "ช่องเดิมพัน",
title_bet: "เดิมพัน",
title_refund: "คืนเงิน",
title_reward: "รับ",
title_result: "ผลลัพธ์",
title_total_bet_refund: "ยอดคืนเงิน/เดิมพัน",
title_transaction_history: "ประวัติการทำธุรกรรม",
title_top_bet: "รวยที่สุด",
title_top_daily: "ยอดรายจำวัน",
title_top_monthly: "ยอดรายเดือน",
title_top_rule: "ยอดรายเดือน",
title_top_number: "เลขลำดับ",
title_account: "บัญชี",
title_top_money: "เงิน",
title_top_reward: "รางวัล",
title_top_refund: "คืนเงิน",
xiu: "เล็ก",
tai: "ใหญ่",
chan: "คู่",
le: "คี่",
bet_success: "เดิมพันสำเร็จ",
bet_fail: "เดิมพันล้มเหลว",
bet_system_error: "ระบบผิดพลาด",
bet_timeout: "หมดเวลาเดิมพัน",
bet_not_enough_chip: "ยอดเงินไม่พอ",
bet_money_invalid: "เดิมพันไม่ถูกต้อง",
bet_money_invalid_tour: "เดิมพันไม่ถูกต้อง",
bet_min_100: "จำนวนเงินต้องมากกว่า 100",
bet_min_1000: "จำนวนเงินต้องมากกว่า 1,000",
bet_only_1_side: "เดิมพันที่อื่นแล้ว",
bet_invalid_side: "ช่องเดิมพันไม่ถูกต้อง",
bet_side_other: "เดิมพันได้เพียง 1 ช่อง",
bet_invalid: "คุณยังไม่ได้เลือกช่องเดิมพัน!",
prestart_phase: "รอรอบใหม่!",
start_phase: "เริ่มเกมใหม่!",
bet_phase: "เชิณเดิมพัน",
result_phase: "หยุดเดิมพัน",
reward_phase: "จ่ายรางวัล!",
win_streak: "แนวการชนะ",
lose_streak: "แพ้สตรีค",
nan: "กลิ้ง",
bo_nan: "เปิด",
no_data: "เซสชันนี้ไม่มีข้อมูล"
},
sicbo: {
gate: {
0: "เล็ก",
1: "ใหญ่",
2: "sicbo เล็ก",
3: "sicbo ใหญ่",
4: "คู่",
5: "คี่",
6: "sicbo คู่",
7: "sicbo คี่",
14: "รวม 4",
15: "รวม 5",
16: "รวม 6",
17: "รวม 7",
18: "รวม 8",
19: "รวม 9",
20: "รวม 10",
21: "รวม 11",
22: "รวม 12",
23: "รวม 13",
24: "รวม 14",
25: "รวม 15",
26: "รวม 16",
27: "รวม 17",
31: "หมายเลข 1",
32: "หมายเลข 2",
33: "หมายเลข 3",
34: "หมายเลข 4",
35: "หมายเลข 5",
36: "หมายเลข 6",
40: "พายุต่างๆ",
41: "พายุ 1",
42: "พายุ 2",
43: "พายุ 3",
44: "พายุ 4",
45: "พายุ 5",
46: "พายุ 6"
},
bao: "พายุ",
bet_side_other: "ลูกค้าสามารถวาง 1 ใน 2 ประตูเท่านั้น: ใหญ่หรือเล็ก."
},
taixiu: {
bet_tai: "เดิมพันใหญ่",
bet_xiu: "เดิมพันเล็ก",
open: "เปิด",
chitietbangdau: {
group_A: "กรุ๊ป A",
group_B: "กลุ่ม B",
group_C: "กลุ่ม C",
group_D: "กลุ่ม D",
group_E: "กลุ่ม E",
group_F: "กลุ่ม F",
group_G: "กลุ่ม G",
group_H: "กลุ่ม H",
nickname: "ชื่อเล่น",
gold: "จำนวนเงิน",
time: "เวลา",
small_gate: "เล็ก",
big_gate: "ใหญ่",
group: "กลุ่ม",
rank: "อันดับ",
finnal: "Final"
},
jackpot: {
Tai: "ช่องใหญ่แจ็คพอตที่คุณได้รับ ",
Xiu: "ช่องเล็กแจ็คพอตที่คุณได้รับ "
}
},
xocdia: {
gate: {
0: "คู่ 4 แดง",
1: "คี่ 1 ดำ",
2: "คู่",
3: "คี่ 1 แดง",
4: "คู่ 4 ดำ"
}
},
chanle: {
bet_chan: "เดิมพันคู่",
bet_le: "เดิมพันคี่",
open: "เปิด"
},
rutloc: {
quy_loc: "กองทุนโชคลาภ",
tan_loc: "เสี่ยงโชค",
rut_loc: "ถอนโชคลาภ",
bet_success: "เสี่ยงโชคสำเร็จ. ขอให้คุณโชคดี!",
bet_fail: "เสี่ยงโชคสำเร็จ!",
bet_min_1000: "เสี่ยงโชคต้องมากกว่า 1,000 GOLD!",
bet_outtime: "การถอนเงินล้มเหลว! รอ 30 วินาทีสุดท้าย!",
bet_nexttime: "ขอให้คุณโชคดีในครั้งต่อไป!",
reward: "คุญถอนเงินได้",
not_money: "เงินไม่พอ",
out: "คุณหมดงวดถอนแล้ว!"
},
tournament: {
no: "ลำดับ",
title_user: "ผู้เล่น",
title_user_history: "ประวัติการเล่น",
phien: "รอบ",
time: "เวลา",
bet_1: "เดิมพัน",
result: "ผลลัพธ์",
bet_2: "เดิมพัน",
rev: "รับ",
gold: "ยอดเงิน",
nickname: "ชื่อเล่น",
day: "วันที่",
tour_status_1: "ทัวร์นาเมนต์กำลังจะมา!",
tour_status_2: "ทัวร์นาเมนต์พร้อม!",
tour_status_3: "ทัวร์นาเมนต์กำลังจะเริ่ม!",
tour_status_4: "ทัวร์นาเมนต์กำลังดำเนินการ",
tour_status_5: "สิ้นสุดรอบ",
tour_status_6: "สิ้นสุดการแข่งขัน",
tit_players: "ผู้เล่น",
tit_tour_info: "ข้อมูล",
tit_join_tour: "เข้าร่วมทัวร์",
tit_num_players: "ผู้เล่น:",
tit_num_rounds: "รอบ:",
tit_min_bet: "เดิมพันขั้นต่ำ:",
tit_ticket_prize: "รางวัลตั๋ว:",
tit_nph_prize: "Discount:",
tit_reg: "ลงทะเบียนสำหรับทีม",
err_reg_0: "ลงทะเบียนสำเร็จ",
err_reg_1: "รหัสไม่ถูกต้อง",
err_reg_2: "รหัสซ้ำ",
err_reg_4: "ไม่พบผู้ใช้",
err_reg_5: "ไม่พบรหัส",
err_reg_6: "รหัสถูกใช้งานแล้ว",
err_reg_7: "รหัสหมดอายุ",
err_reg_8: "ไม่พบทัวร์",
err_reg_9: "ทัวร์โดยไม่ต้องใช้รหัส",
err_reg_10: "ผู้ใช้อยู่ในทัวร์",
err_reg_11: "ไม่พบทีม",
err_reg_12: "การแข่งขันได้เริ่มขึ้น ไม่สามารถลงทะเบียนได้",
err_reg_14: "ทัวร์นาเมนต์มีผู้เล่นถึงจำนวนสูงสุดแล้ว",
tit_ticket: "ค่าตั๋ว",
tit_top_tour_0: "ด้านบนของสัปดาห์",
tit_top_tour_1: "TOP ของเดือน",
tit_top_tour_2: "การแข่งขันอันดับสูงสุด",
tit_top_tour_3: "การแข่งขันอันดับสูงสุด",
thele: {
week: {
text_1: "- การแข่งขันรายสัปดาห์\nเกิดขึ้นทุกวันเสาร์",
text_2: "* การแข่งขันวันหยุดสุดสัปดาห์\nรูปแบบการแข่งขัน: เข้าร่วมรอบน็อกเอาต์จากผู้เล่น 32 คน แบ่งเป็น 8 กลุ่ม กลุ่มละ 4 คน เลือกผู้เล่นที่มีผลงานดีที่สุดในแต่ละกลุ่ม 2 คนเข้าสู่รอบต่อไป รวม 8 ผู้เข้ารอบสุดท้ายของสัปดาห์เพื่อแข่งขันและค้นหา 3 อันดับแรกของสัปดาห์เพื่อแข่งขันในทัวร์นาเมนต์ประจำเดือน",
prize_0: "+ รางวัลที่หนึ่งของสัปดาห์: %{money} Gold “เพื่อเข้าร่วมรอบชิงชนะเลิศประจำเดือน”  ",
prize_1: "+ รางวัลที่สองของสัปดาห์: %{money} Gold “เพื่อเข้าร่วมรอบชิงชนะเลิศประจำเดือน”  ",
prize_2: "+ รางวัลสามสัปดาห์: %{money} Gold “เพื่อเข้าร่วมรอบชิงชนะเลิศประจำเดือน”  ",
prize_3: "+ รางวัลที่สี: %{money} Gold ",
prize_4: "+ รางวัลห้าสัปดาห์: %{money} Gold ",
prize_5: "+ รางวัลหกสัปดาห์: %{money} Gold ",
prize_6: "+ รางวัลเจ็ดสัปดาห์: %{money} Gold ",
prize_7: "+ รางวัลแปดสัปดาห์: %{money} Gold ",
text_3: "* สำหรับผู้ชม",
text_4: "+ 3 รางวัล: 1,000,000 Gold - 500K - 200K สำหรับผู้ที่ทายถูกหรือ ใกล้เคียงกับ 4 ชื่อตัวละครในรอบรองชนะเลิศ",
text_5: "+ รางวัลชมเชย 30 รางวัล : รหัส 50K ให้ผู้ร่วมทาย + แท็ก 5 เพื่อนญี่ปุ่น-เกาหลี-ไต้หวัน “ไม่นับโคลนนิ่ง FB เสมือน เฉพาะเฟสบุ๊คจริงที่มีเพื่อนตั้งแต่ 200 คนขึ้นไป”"
},
month: {
text_1: "- การแข่งขันประจำเดือน\nจัดขึ้นทุกคืนวันอาทิตย์สิ้นเดือน",
text_2: "* การแข่งขันเดือน รูปแบบการแข่งขัน: การแข่งขันประจำเดือน 16 คน แบ่งออกเป็น 4 กลุ่ม แต่ละกลุ่ม 4 ผู้เล่นต่อสู้กัน คัดเลือก 8 คนที่มีผลงานดีที่สุดเข้าสู่รอบสุดท้ายของเดือน",
prize_0: "+ รางวัลที่หนึ่งของเดือน: %{money} Gold ",
prize_1: "+ รางวัลที่สองของเดือน: %{money} Gold ",
prize_2: "+ รางวัลที่สาม: %{money} Gold ",
prize_3: "+ รางวัลที่สี่: %{money} Gold ",
prize_4: "+ รางวัลประจำปี: %{money} Gold ",
prize_5: "+ รางวัลหกเดือน: %{money} Gold ",
prize_6: "+ รางวัลเจ็ดเดือน: %{money} Gold ",
prize_7: "+ รางวัลแปดเดือน: %{money} Gold ",
text_3: "* สำหรับผู้ชม",
text_4: "+ 3 รางวัล: 1,000,000 Gold - 500K - 200K สำหรับผู้ที่ทายถูกหรือ ใกล้เคียงกับ 4 ชื่อตัวละครในรอบรองชนะเลิศ",
text_5: "+ รางวัลชมเชย 30 รางวัล : รหัส 50K ให้ผู้ร่วมทาย + แท็ก 5 เพื่อนญี่ปุ่น-เกาหลี-ไต้หวัน “ไม่นับโคลนนิ่ง FB เสมือน เฉพาะเฟสบุ๊คจริงที่มีเพื่อนตั้งแต่ 200 คนขึ้นไป”"
}
}
}
},
minibaucua: {
check_ball: "เช็คบอล",
rebet: "เดิมพันอีกครั้ง",
accept: "ยอมรับ",
destroy: "ยกเลิก",
popup: {
guide_title: "แนะนำ",
history_title: "ประวัติการทำธุรกรรม",
honor_title: "เดิมพันสูงสุด",
session: "รอบ",
time: "เวลา",
bet_position: "ช่องเดิมพัน",
result: "ผลลัพธ์",
bet: "เดิมพัน",
return: "คืน",
gain: "รับ",
detail: "รายละเอียด",
rank: "อันดับ",
account: "บัญชี",
win: "ชนะ"
},
his_detail: {
session: "รอบ:",
day: "วัน:",
result: "ผลลัพธ์:",
bau: "น้ำเต้า",
cua: "ปู",
tom: "กุ้ง",
ca: "ปลา",
ga: "ไก่",
huou: "กวาง"
},
toast: {
bet_fail: "เดิมพันล้มเหลว",
unreach_bet_time: "ยังไม่ถึงเวลาเดิมพัน",
over_bet_time: "หมดเวลาเดิมพัน",
not_enough_gold: "ยอดเงินไม่เพียงพอ",
bet_success: "เดิมพันสำเร็จ",
action_too_quick: "ดำเนินการเร็วเกินไป",
bet_no_position: "คุณยังไม่ได้ช่องเดิมพัน",
no_bet_last_session: "คุณยังไม่ได้เดิมพันรอบก่อนหน้า",
no_bet_before: "คุณไม่เคยวางเดิมพันมาก่อน",
only_rebet_in_first_time: "คุณสามารถรีเซ็ตได้เฉพาะการเดิมพันครั้งแรกเท่านั้น"
}
},
caothap: {
play: "เล่น",
stop: "หยุด",
popup: {
guide_title: "แนะนำ",
history_title: "ประวัติ",
honor_title: "เกียรติยศ",
session: "รอบ",
time: "เวลา",
bet: "เดิมพัน",
step: "ขั้นตอน",
result: "ผลลัพธ์",
bet_door: "ช่องเดิมพัน",
win: "ชนะ",
account: "บัญชี",
bet_level: "ระดับการเดิมพัน",
status: "สถานะ",
jackpot: "แจ็คพอต",
big_win: "ชนะครั้งใหญ่",
high: "สูง",
low: "ต่ำ"
},
toast: {
not_enough_gold: "ยอดเงินไม่พอ, กรุณาเติมเงิน",
you_loose: "คุณแพ้! โชคดีในครั้งต่อไป!",
congratulations: "ยินดีด้วย! คุณชนะ!",
gold: "ทอง",
click_to_start_game: 'คลิก "เล่น" เพื่อเริ่มเกม',
action_too_quick: "คุณดำเนินการเร็วเกินไป",
not_enough_gold_at_bet_level: "คุณไม่มีเงินเพียงพอที่จะเล่นเดิมพันนี้"
}
},
minilongho: {
accept: "ยอมรับ",
destroy: "ยกเลิก",
bet_dragon: "เดิมพันมังกร",
bet_draw: "เดิมพันเสมอ",
bet_tiger: "เดิมพันเสือ",
dragon: "มังกร",
tiger: "เสือ",
draw: "เสมอ",
big_road: "Big road",
disk_road: "Disk road",
top_bet: "เดิมพันสูงสุด",
total_game: "สถิติเกมทั้งหมด",
popup: {
guide_title: "แนะนำ",
history_title: "ประวัติ",
honor_title: "ชนะสูงสุดภายในวัน",
session: "รอบ",
bet_door: "ช่องเดิมพัน",
bet: "เงินเดิมพัน",
time: "เวลา",
win: "ชนะ",
result: "ผลลัพธ์",
no: "ลำดับ",
account: "บัญชี",
bet_money: "จำนวนเงินเดิมพัน",
win_money: "เงินรางวัล"
},
toast: {
start_new_game: "เริ่มเกมใหม่!",
start_return_reward: "เริ่มจ่ายรางวัล",
have_err_betting: "มีข้อผิดพลาดระหว่างกระบวนการเดิมพัน",
minimum_bet: "ยอดเดิมพันต้องมากกว่า 1,000",
not_enough_gold: "ยอดเงินไม่พอ",
over_bet_time: "เกินเวลาเดิมพัน",
not_in_bet_time: "ยังไม่ถึงเวลาเดิมพัน!"
}
},
pokemon: {
line: "แถว",
spin: "หมุน",
autoSpin: "หมุนอัตโนมัติ",
stop: "หยุด",
popup: {
detail_title: "รายละเอียดการเดิมพัน",
guide_title: "แนะนำ",
history_title: "ประวัติการเล่น",
honor_title: "เกียรติยศ",
select_line_title: "เลือกแถว",
session: "รอบ",
time: "เวลา",
bet_level: "ระดับการเดิมพัน",
bet_line: "แถวเดิมพัน",
bet: "เดิมพัน",
gain_gift: "รับรางวัล",
room: "ห้อง",
detail: " รายละเอียด",
account: "บัญชี",
status: "สถานะ",
win: "ชนะ",
unselect: "ยกเลิกการเลือก",
even_line: "แถวคู่",
odd_line: "แถวคี่",
all_line: "ทั้งหมด",
line_win: "แถวชนะ",
jackpot: "แจ็คพอต",
big_win: "ชนะครั้งใหญ่"
},
toast: {
action_too_quick: "คุณดำเนินการเร็วเกินไป",
you_need_choose_at_least_1_line: "คุณต้องเลือกอย่างน้อย 1 แถว",
not_enough_gold: "เหรียญไม่พอกรุณาเติมเงิน",
error_try_again: "มีข้อผิดพลาดเกิดขึ้นโปรดลองอีกครั้ง",
connecting_server: "กำลังเชื่อมต่อกับเซิร์ฟเวอร์"
}
},
minipoker: {
auto_spin: "หมุนอัตโนมัติ",
play_gold: "เล่นทอง",
play_chip: "เล่นเหรียญ",
popup: {
guide_title: "แนะนำ",
history_title: "ประวัติการทำธุรกรรม",
honor_title: "ตารางเกียรติยศ",
time: "เวลา",
bet: "ระดับ",
type: "ชุดไพ่",
win: "ชนะ",
account: "บัญชี",
straight: "ล็อบบี้",
pair_j: "คู่ของ J++",
full_house: "ตองคู่",
two_pair: "2คู่",
flush: "กล่อง",
three_of_a_kind: "ตอง",
straight_flush: "สเตรทฟลัช",
jackpot: "แจ็คพอต",
four_of_a_kind: "โฟร์การ์ด"
},
toast: {
action_too_quick: "คุณดำเนินการเร็วเกินไป",
not_enough_gold: "ยอดเงินไม่พอ กรุณาเติมเงิน",
error_try_later: "มีข้อผิดพลาดเกิดขึ้นโปรดลองอีกครั้ง.",
game_in_auto_spin: "เกมอยู่ในโหมดหมุนอัตโนมัติ"
}
},
xeng: {
day: "วัน",
month: "เดือน",
year: "ปี",
title_help: "แนะนำ",
title_transaction: "ประวัติการทำธุรกรรม",
title_top: "เดิมพันสูงสุด",
title_session: "รอบ",
title_time: "เวลา",
title_side: "ช่องเดิมพัน",
title_result: "ผลลัพธ์",
title_bet: "เดิมพัน",
title_reward: "รับ",
title_stt: "ลำดับ",
title_account: "บัญชี",
title_gold: "จำนวนทอง",
bet_phase: "เริ่มเดิมพัน!!",
result_phase: "หมดเวลาเดิมพัน!",
bet_success: "เดิมพันสำเร็จ!",
bet_invalid_money: "เดิมพันไม่ถูกต้อง",
bet_not_enough_money: "ยอดเงินไม่พอ",
bet_fail: "เดิมพันล้มเหลว"
},
lodenormal: {
betted: "เดิมพันแล้ว",
betting: "กำลังเดิมพัน",
bet: "เดิมพัน",
winned: "ถูกรางวัล",
eat: "ชนะ",
de: "หวย",
lo: "หวย",
de_3_num: "หวย 3 ตัวเลข",
de_first: "หวยหัว",
de_last: "หวยท้าย",
lo_through_2: "หวย พาร์เลย์ 2 ",
lo_through_3: "หวย พาร์เลย์ 3 ",
lo_through_4: "หวย พาร์เลย์ 4",
lo_fail_10: "หวยทวน 10",
de_group: "ชุดหวย",
no_group: "ชุดตัวเลข",
couple_number: "ตัวเลขคู่",
rate_number: "ค่าสัมประสิทธิ์ หวย",
group: "ชุด",
double_group: "ชุดคู่",
double_type: "ชุดแบบคู่",
type_double: "คู่แบบ",
type_double1: "แบบคู่",
num_lo_de_group: "ชุดเลขหวย",
animal_designation_12: "12 นักษัตร",
double_similar: "คู่เท่ากัน",
double_dif: "คู่ไม่เท่ากัน",
de_sum: "หวย รวม",
special: "พิเศษ",
first_prize: "รางวัลที่หนึ่ง",
second_prize: "รางวัลที่สอง",
third_prize: "รางวัลที่สาม",
fourth_prize: "รางวัลที่สี่",
fifth_prize: "รางวัลที่ห้า",
sixth_prize: "รางวัลที่หก",
seventh_prize: "รางวัลที่เจ็ด",
north_lottery: "หวยเหนือ",
last_second: "วินาทีที่แล้ว",
lsst_minute: "นาทีที่แล้ว",
last_hour: "ชั่วโมงที่แล้ว",
last_day: "เมื่อวาน",
last_month: "เดือนที่แล้ว",
last_year: "ปีที่แล้ว",
rat: "ชวด",
ox: "ฉลู",
tiger: "ขาล",
cat: "เถาะ",
dragon: "มะโรง",
snake: "มะเส็ง",
horse: "มะเมีย",
goat: "มะแม",
monkey: "วอก",
rooster: "ระกา",
dog: "จอ",
pig: "กุน",
popup: {
month: "เดือน",
year: "ปี",
end_bet_title: "ข้อมูล",
inputbet_title: "เติมเงิน",
choose_de_num_title: "เลือกเลขหวย",
choose_lo_num_title: "เลือกเลขหวย",
de_3_num_title: "หวย 3 ตัวเลข",
choose_de_group_title: "เลือกชุดตัวเลขหวย",
choose_lo_through_2: "เลือก หวยพาร์เลย์ 2",
choose_lo_through_3: "เลือก หวยพาร์เลย์ 3",
choose_lo_through_4: "เลือก หวยพาร์เลย์ 4",
choose_lo_fail_10: "เลือกหวยทวน 10",
choose_num_group_12: "เลือกกลุ่มตัวเลข 12 นักษัตร",
choose_double_similar: "หวยเลขคู่ที่เป็นเลขเดียวกัน",
double_similar_detail: " ชุดตัวเลข: 00, 11, 22, 33, 44, 55, 66, 77, 88, 99",
choose_double_dif: "เลือกชุดตัวเลขคู่ที่ไม่เท่ากัน",
choose_de_sum_title: "เลือกชุดเลขหวยรวม",
confirm: "ยืนยัน",
reject: "ยกเลิก",
bet: "เดิมพัน",
bet_num: "จำนวนเดิมพัน",
bet_money: "เงินเดิมพัน",
bet_money_total: "เงินเดิมพันทั้งหมด",
win_total: "รวมการชนะทั้งหมด",
de: "หวย",
lo: "หวย",
end_bet_warning: "กรุณายืนยันข้อมูลการเดิมพันของคุณ",
bet_money_total1: "จำนวนเงินเดิมพันทั้งหมด",
input_bet_placeholder: "เติมเงินตำนวน",
input_num_placeholder: "ใส่หมายเลข",
gold: "Gold",
bet_total: "เดิมพันทั้งหมด",
time_warning: "เวลา 18:10 ถึง 18:45 น. (เวลาเวียดนาม) เป็นเวลาจับรางวัลและจ่ายเงิน เราไม่รับเดิมพันในช่วงเวลานี้"
},
warning: {
bet_success: "เดิมพันสำเร็จ!",
invalid_bet: "จำนวนเงินเดิมพันไม่ถูกต้อง",
error_in_betting: "เกิดข้อผิดพลาดขณะวางเดิมพัน",
cant_bet_this_time: "ไม่สามารถวางเดิมพันได้ในช่วงเวลานี้",
not_enough_gold: "ยอดเงินของคุณม่เพียงพอ",
please_choose_bet: "โปรดเลือกระดับการเดิมพันของคุณ",
server_stop_spin_and_return_reward: "วันนี้ระบบหยุดหมุนและจ่ายรางวัล",
please_cash_in_before_bet: "กรุณาทำการเติมเงินก่อนวางเดิมพัน",
please_choose_no_bet: "กรุณาเลือกหมายเลขเดิมพัน",
please_choose_bet_money: "โปรดเลือกจำนวนเงินเดิมพันของคุณ",
over_bet_bound: "เกินขีดจำกัดการเดิมพัน",
only_can_bet: "คุณสามารถเดิมพัน",
gold: "Gold",
no: "ตัวเลข",
error_in_betting_door: "เกิดข้อผิดพลาดในการวางเดิมพัน"
}
},
longho: {
dragon: "มังกร",
tiger: "เสือ",
draw: "เสมอ",
tai: "ใหญ่",
xiu: "เล็ก",
black: "ดำ",
red: "แดง",
session: "รอบ",
menu: {
exit: "ออกจากโต๊ะ",
rule: "กฎ",
history: "ประวัติ",
rank: "อันดับ"
},
popup: {
chat_title: "แชท",
playing_people_title: "คนที่เล่นด้วยกัน",
check_ball_title: "รายละเอียดรอบปัจจุบัน",
guide_title: "แนะนำ",
history_title: "ประวัติการทำธุรกรรม",
rank_title: "ผู้ชนะสูงสุด",
chat_placeholder: "แชท",
exit_table: "ออกจากโต๊ะ",
history: "ประวัติ",
rule: "กฎ",
rank: "อันดับ",
title_statitics: "ทางสถิติ",
title_count_statitics: "สถิติเกมทั้งหมด",
title_dishroad: "Dish road",
title_bigroad: "Big road",
nick_name: "ชื่อเล่น",
bet_door: "ช่องเดิมพัน",
money: "จำนวนเงิน",
time: "เวลา",
session: "รอบ",
bet_money: "เงินเดิมพัน",
win_money: "เงินรางวัล",
result: "ผลลัพธ์",
dragon: "มังกร",
tiger: "เสือ",
no: "ลำดับ",
user_name: "ชื่อผู้ใช้",
play_together: "ผู้เล่นด้วยกัน"
},
toast: {
no_chat_permission: "*** คุณไม่ได้รับอนุญาตให้แชท!",
banned_chat: "*** ถูกแบนจากการแชทชั่วคราว!",
too_long_chat_content: "*** เนื้อหาแชทยาวเกินไป!",
banned_chat_to: "คุณถูกแบนแชทกับ",
serverr_busy_try_later: "ระบบไม่ว่าง กรุณาลองใหม่ภายหลัง",
not_enough_gold: "ยอดเงินในบัญชีไม่เพียงพอต่อการเดิมพัน",
bet_too_small: "จำนวนเงินเดิมพันน้อยเกินไป",
only_allow_bet_dragon_or_tiger: "คุณวางเดิมพันเฉพาะมังกรหรือเสือ",
only_alow_bet_red_or_black_dragon: "คุณสามารถเดิมพันได้เพียงช่องเดียวจาก 2 ช่อง มังกร-แดง หรือ มังกรดำ",
only_alow_bet_tai_or_xiu_dragon: "คุณสามารถเดิมพันได้เพียงหนึ่งใน 2 ช่อง มังกรใหญ่ หรือ มังกรเล็ก",
only_alow_bet_red_or_black_tiger: "คุณสามารถเดิมพันได้เพียงหนึ่งใน 2 ช่อง มังกร-แดง หรือ มังกร-ดำ",
only_alow_bet_tai_or_xiu_tiger: "คุณสามารถเดิมพันได้เพียงหนึ่งใน 2 ช่อง มังกรใหญ่ หรือ มังกรเล็ก",
start_return_reward: "เริ่มจ่ายรางวัล",
start_bet_door: "เริ่มเดิมพัน",
not_in_bet_time: "ตอนนี้ไม่ใช่เวลาเดิมพัน",
please_choose_bet: "กรุณาเลือกเดิมพัน",
over_time_bet: "หมดเวลาเดิมพัน",
not_enough_gold1: "ยอดเงินไม่เพียงพอ"
}
},
slot_avengers: {
unhappen: " ยังไม่เริ่ม",
music: "ดนตรี",
sound: "เสียง",
win: "เพิ่งชนะ",
total_bet: "เดิมพันทั้งหมด:",
line: "แถว",
autoSpin: "หมุนอัตโนมัติ",
bet: "เดิมพัน",
play_trial: "ทดลองเล่น",
play_real: "เล่นจริง",
popup: {
jackpot_history_title: "ประวัติแจ็คพอต",
choose_line_title: "เลือกแถว",
trade_history_title: "ประวัติการทำธุรกรรม",
x2_win_title: "โบนัส X2",
time: "เวลา",
level: "ระดับการเดิมพัน",
jackpot: "แจ็คพอต",
account: "บัญชี",
result: "ผลลัพธ์",
session: "รอบ",
line_bet: "แถวเดิมพัน",
line_win: "แถวชนะ",
receive_gold: "รับทอง",
even_line: "แถวคู่",
odd_line: "แถวคี่",
all_line: "ทั้งหมด",
re_select: "เลือกใหม่",
big_win: "ชนะครั้งใหญ่",
choose_pearl: "เลือกไข่มุก",
congratulations: "ยินดีด้วย! คุณชนะ"
},
toast: {
need_choose_minimum_1_line: "คุณต้องเลือกอย่างน้อย 1 แถว",
function_dont_work_in_trial: "ฟีเจอร์นี้ใช้ไม่ได้ในโหมดทดลองใช้งาน",
off_auto_spin_to_leave: "ปิดการหมุนอัตโนมัติเพื่อออกจากโต๊ะ",
function_in_develop: "ฟังก์ชันกำลังพัฒนา",
not_enough_gold: "ยอดเงินไม่พอกรุณาเติมเงิน",
error_try_again: "เกิดข้อผิดพลาด โปรดลองอีกครั้ง"
}
},
slot_dancing_girls: {
holdToSpin: "ถือเพื่อหมุนเอง",
unhappen: " ยังไม่เริ่ม",
music: "ดนตรี",
sound: "เสียง",
win: "เพิ่งชนะ",
total_bet: "เดิมพันทั้งหมด:",
line: "แถว",
autoSpin: "หมุนอัตโนมัติ",
bet: "เดิมพัน",
play_trial: "ทดลองเล่น",
play_real: "เล่นจริง",
popup: {
jackpot_history_title: "ประวัติแจ็คพอต",
choose_line_title: "เลือกแถว",
guide_title: "ตารางรางวัล",
trade_history_title: "ประวัติการทำธุรกรรม",
x2_win_title: "โบนัส X2",
time: "เวลา",
level: "ระดับการเดิมพัน",
jackpot: "แจ็คพอต",
account: "บัญชี",
result: "ผลลัพธ์",
session: "รอบ",
line_bet: "แถวเดิมพัน",
line_win: "แถวชนะ",
receive_gold: "รับทอง",
even_line: "แถวคู่",
odd_line: "แถวคี่",
all_line: "ทั้งหมด",
re_select: "เลือกใหม่",
big_win: "ชนะครั้งใหญ่",
choose_pearl: "เลือกไข่มุก",
congratulations: "ยินดีด้วย! คุณชนะ"
},
toast: {
need_choose_minimum_1_line: "คุณต้องเลือกอย่างน้อย 1 แถว",
function_dont_work_in_trial: "ฟีเจอร์นี้ใช้ไม่ได้ในโหมดทดลองใช้งาน",
off_auto_spin_to_leave: "ปิดการหมุนอัตโนมัติเพื่อออกจากโต๊ะ",
function_in_develop: "ฟังก์ชันกำลังพัฒนา",
not_enough_gold: "ยอดเงินไม่พอกรุณาเติมเงิน",
error_try_again: "เกิดข้อผิดพลาด โปรดลองอีกครั้ง"
}
},
slotkhobau: {
unhappen: " ยังไม่เริ่ม",
music: "ดนตรี",
sound: "เสียง",
bet: "เดิมพัน",
total_bet: "เดิมพันทั้งหมด",
last_win: "เพิ่งชนะ",
hide: "ซ่อน",
line: "แถว",
autoSpin: "หมุนอัตโนมัติ",
popup: {
choose_line_title: "เลือกแถว",
x2_win_title: "โบนัส X2",
guide_title: "ตารางรางวัล",
jackpot_history_title: "ประวัติแจ็คพอต",
trade_history_title: "ประวัติการทำธุรกรรม",
time: "เวลา",
level: "ระดับ",
jackpot: "แจ็คพอต",
account: "บัญชี",
result: "ผลลัพธ์",
session: "รอบ",
line_bet: "แถวเดิมพัน",
line_win: "แถวชนะ",
receive_gold: "รับทอง",
even_line: "รับทอง",
odd_line: "แถวคี่",
all_line: "ทั้งหมด",
re_select: "เลือกใหม่",
big_win: "ชนะครั้งใหญ่",
choose_pearl: "เลือกไข่มุก",
you_win: "จำนวนแต้มที่ชนะ",
remain_turn: "จำนวนเทิร์นที่เหลืออยู่:",
total_score: "คะแนนสะสม:",
click_to_exit: "คลิกเพื่อออก",
minigame_title: "มินิเกมขุมทรัพย์"
},
toast: {
function_dont_work_on_trial: "ฟังก์ชันนี้ใช้ไม่ได้ในโหมดทดลองใช้งาน",
off_auto_spin_to_leave: "ปิดการหมุนอัตโนมัติเพื่อออกจากโต๊ะ",
funtion_in_develop: "ฟังก์ชันกำลังพัฒนา",
not_enough_gold: "ยอดเงินไม่พอกรุณาเติมเงิน",
spin_unsuccess: "หมุนไม่สำเร็จ",
unvalid_bet: "เดิมพันไม่ถูกต้อง",
unvalid_spin: "การหมุนไม่ถูกต้อง",
error_try_again: "เกิดข้อผิดพลาด โปรดลองอีกครั้ง",
atleast_1_line: "คุณต้องเลือกอย่างน้อย 1 แถว"
}
},
SlotTreeOfFortune: {
main: {
total_bet: "เดิมพันทั้งหมด:",
total_win: "ชนะ:",
music: "ดนตรี",
sound: "เสียง"
},
choose_line: {
title: "เลือกแถว",
even_line: "รับทอง",
odd_line: "แถวคี่",
all_line: "ทั้งหมด",
re_line: "เลือกใหม่"
},
mini_game: {
notice: "คลิก/แตะที่ต้นไม้เพื่อสั่น",
close: "ปิด",
you_get: "คุณได้รับรางวัล",
time_left: "จำนวนเทิร์นที่เหลืออยู่:",
score: "คะแนนสะสม:"
},
history: {
title: "ประวัติ",
phien: "รอบ",
time: "เวลา",
muc: "ระดับการเดิมพัน",
line_bet: "แถวเดิมพัน",
line_win: "แถวชนะ",
gold_receive: "รับทอง"
},
guide: "แนะนำ",
top: {
title: "เดิมพันสูงสุด",
time: "เวลา",
muc: "ระดับการเดิมพัน",
jackpot: "แจ็คพอต",
account: "บัญชี",
result: "ผลลัพธ์",
nohu: "แจ็คพอต"
},
message: {
message1: "คุณลักษณะนี้ใช้ไม่ได้ในโหมดทดลองใช้งาน",
message2: "การหมุนรายวันไม่สามารถใช้โหมดหมุนอัตโนมัติได้",
message3: "คุณกำลังย้ายห้อง โปรดรอสักครู่",
message4: "คุณกำลังถ่ายหมุน โปรดรอให้การถ่ายหมุนเสร็จสิ้น",
message5: "ระบบกำลังดำเนินการ กรุณารอสักครู่",
message6: "คุณอยู่ในโหมดทดลองใช้ ไม่ต้องเลือกสาย",
message7: "คุณเหลือฟรีสปิน",
message8: "คุณกำลังหมุนโดยอัตโนมัติ",
message9: "หมุนไม่สำเร็จ",
message10: "เดิมพันไม่ถูกต้อง",
message11: "เงินไม่พอ",
message12: "การหมุนไม่ถูกต้อง",
message13: "ขอให้โชคดีในครั้งต่อไป",
message14: "คุณต้องเลือกอย่างน้อย 1 บรรทัด"
}
},
card_game_52: {
tlmn_title: "ไพ่ภาคใต้",
sam_title: "เฮลล์",
binh_title: "โป๊กเกอร์จีน",
bacay_title: "ไพ่สามใบ",
poker_title: "โป๊กเกอร์",
xizach_title: "Xì Zách",
baicao_title: "Bài Cào",
sort_card: "เรียงลำดับไพ่",
hit_card: "เล่นไพ่",
next_turn: "ผ่าน",
bao_sam: "บัตรรายงาน",
huy_sam: "ยกเลิกบัตรรายงาน",
watting_for_start_game: "รอเกมใหม่เริ่ม",
table: "โต๊ะ: ",
bet_money: "จำนวนเงินเดิมพัน: ",
viewing: "กำลังรับชม",
chat_place_holder: "พิมพ์",
invite_game: "ชวนเล่น",
no_one_invite: "ไม่มีผู้เล่นที่เหมาะสม",
not_open: "ฟังก์ชันไม่เปิดชั่วคราว",
create_room: "สร้างโต๊ะ",
create_room_place_holder: "ตั้งชื่อห้อง",
play_now: "เล่นเลย",
refresh_room: "รีเฟรช",
choose_bet_value: "เลือก",
player: "ผู้เล่น",
password_room: "รหัสผ่านห้อง",
buy_in: "ซื้อใน",
auto_buy_in: "ซื้อเข้าอัตโนมัติเมื่อชิปหมด",
result: "ผลลัพธ์",
confirm: "ยืนยัน",
dang_ki_exit_success: "คุณลงทะเบียนออกจากห้องสำเร็จแล้ว!",
huy_dang_ki: "คุณได้ยกเลิกการออกจากห้อง!",
first_turn: " เทิร์นแรก",
no_select_card: "คุณยังไม่ได้เลือกการ์ด!",
card_avaiable_found: "พบบัตรที่มีอยู่",
time_bet: "Time bet",
reg_buyin: "ลงทะเบียนเพื่อซื้อใน",
unreg_buyin: "ยกเลิกการสมัคร Buy In",
play_tour: "Tournament",
play_normal: "Normal",
not_enough_gold: "The coins is not enough, please top up",
tlmn: {
chat_1: "ชนะไม่ได้ 555!",
chat_2: "กดไลค์ให้หน่อย !",
chat_3: "ขอบคุณ!",
chat_4: "โชคดี!",
chat_5: "ดี~",
chat_6: "โชคไม่ดี!",
chat_7: "เฉียดฉิว!!",
chat_8: "อ๊ะ ขออภัย!",
chat_9: "ไม่นะ…",
chat_10: "ฉันได้สิ่งนี้!",
chat_11: "คุณจะสูญเสีย!",
chat_12: "เร็วเข้า!",
special_result_0: "สวนมังกร",
special_result_1: "สี่ไตรมาสที่ 2",
special_result_2: "5 ต้นสนคู่",
special_result_3: "6 คู่",
special_result_4: "13 สี",
special_result_5: "12 สี",
result_0: "สอง",
result_1: "ดับเบิ้ลทู",
result_2: "3 สอง",
result_3: "3 ดับเบิ้ลผ่าน",
result_4: "4 สองเท่า",
result_cong: "เย็น",
result_batcong: "จับแฮงค์",
result_toitrang: "โกไวท์",
result_thuatoitrang: "แพ้"
},
sam: {
chat_1: "ชนะไม่ได้ 555!",
chat_2: "กดไลค์ให้หน่อย !",
chat_3: "ขอบคุณ!",
chat_4: "โชคดี!",
chat_5: "ดี~",
chat_6: "โชคไม่ดี!",
chat_7: "เฉียดฉิว!!",
chat_8: "อ๊ะ ขออภัย!",
chat_9: "ไม่นะ…",
chat_10: "ฉันได้สิ่งนี้!",
chat_11: "คุณจะสูญเสีย!",
chat_12: "เร็วเข้า!",
special_6: "ยอดโสม",
special_7: "ไตรมาสที่สอง",
special_8: "ห้าคู่",
"พิเศษ_9": "สีเดียวกัน",
special_4: "บล็อคโสม",
special_16: "โสมล้มเหลว",
result_3: "ชนะ",
result_7: "โสม",
result_6: "ชนะและบล็อค Sam",
result_2: "ยอดโสม",
result_4: "ไตรมาสที่สอง",
result_1: "ห้าคู่",
result_0: "สีเดียวกัน",
result_8: "วัด",
result_5: "เสมอกัน",
result_9: "แพ้",
result_10: "วัดสาม",
bao_sam: "คุณต้องการเตือนแซมไหม",
sam: "คำเตือน",
ko_bao_sam: "อย่าเตือนแซม",
co_bao_sam: "คำเตือนแซม"
},
poker: {
chat_1: "ทั้งหมด",
chat_2: "โชคดี",
chat_3: "มือทั้งหมด",
chat_4: "เร็วเข้าป้า",
chat_5: "คิงล็อบบี้",
chat_6: "ดำจัง",
chat_7: "ฉันสบายดี :)",
chat_8: "ไปที่เงิน :)",
chat_9: "น่าเบื่อจัง",
chat_10: "กินทั้งหมู่บ้าน :)",
chat_11: "กล้าที่จะออกไปให้สุด",
chat_12: "สู้ๆนะ",
double: "สองเท่า",
tripple: "สามเท่า",
allin: "อลิน",
check: "ตรวจสอบ",
fold: "พับ",
open: "เปิด",
follow: "โทร",
call: "โทร",
bet: "เพิ่ม",
raise: "เดิมพัน",
royalflush: "Royal Flush",
straightflush: "Straight flush",
fourofakind: "Four of a kind",
fullhouse: "Full house",
flush: "Flush",
straight: "Straight",
threeofakind: "Three of a kind",
twopair: "Two pair",
pair: "Pair",
highcard: "High Card"
}
},
room_info: (o = {
id_room: "Type ID room ...",
hide_full_table: "Hide full table",
room_not_found: "ไม่พบห้องที่เลือก",
please_add_idroom: "กรุณากรอกโต๊ะที่ท่านต้องการค้นหา",
not_create_room: "ไม่สามารถสร้างโต๊ะนี้ได้!",
not_enough_money: "ยอดเงินไม่พอกรุณาเติมเงิน",
no_room_avaiable_found: "ไม่พบโต๊ะที่ถูกต้อง",
error_check: "เกิดข้อผิดพลาดในการตรวจสอบข้อมูล"
}, o.no_room_avaiable_found = "ไม่พบตารางที่ถูกต้อง", o.bao_tri = "ระบบกำลังบำรุงรักษา", 
o.time_wait = "การเข้าห้องแต่ละครั้งต้องห่างกัน 10 วินาที!", o.password_error = "รหัสผ่านห้องไม่ถูกต้อง!", 
o.room_full = "เต็มห้องเลยทีนี้!", o.ban_room = "คุณไม่ได้รับอนุญาตให้เข้าโต๊ะโดยเจ้าของห้อง!", 
o.info_create_room_error = "ข้อมูลสร้างตารางไม่ถูกต้อง", o.not_enough_vip = "คุณไม่มีระดับวีไอพีพอที่จะสร้างโต๊ะได้!", 
o.not_enough_vip2 = "ไม่สามารถสร้างโต๊ะเพิ่มด้วยระดับวีไอพีปัจจุบัน!", o),
game_sam: {
bao_sam: "คุณต้องการรายงานการ์ดหรือไม่"
},
game_mau_binh: {
sort_again: "จัดลำดับใหม่",
sort_done: "เรียงลำดับสำเร็จ",
bao_binh: "ผู้สื่อข่าว"
},
bacay: {
chicken_money: "เงินวางไก่ ",
bet_in_chicken: "วางไก่",
open_all: "เปิดทั้งหมด"
},
slotdechemaya: {
unhappen: " ยังไม่เริ่ม",
music: "ดนตรี",
sound: "เสียง",
last_win: "เพิ่งชนะ",
total_bet: "เดิมพันทั้งหมด",
play_trial: "ทดลองเล่น",
play_real: "เล่นจริง",
line: "แถว",
spin: "หมุน",
autoSpin: "หมุนอัตโนมัติ",
stop: "หยุด",
bet: "เดิมพัน",
popup: {
choose_line_title: "เลือกแถว",
x2_win_title: "โบนัส X2",
guide_title: "ตารางรางวัล",
jackpot_history_title: "ประวัติแจ็คพอต",
trade_history_title: "ประวัติการทำธุรกรรม",
even_line: "แถวคู่",
odd_line: "แถวคี่",
all_line: "ทั้งหมด",
re_line: "เลือกใหม่",
line_bet: "แถวเดิมพัน",
line_win: "แถวชนะ",
chose_room_title: "เลือกห้อง",
resident: "ผู้พักอาศัย",
leader: "ผู้นำ",
boss: "เจ้านาย",
honor_title: "เกียรติยศ",
congratulations_account: "ขอแสดงความยินดีกับบัญชี",
remain_turn: "จำนวนเทิร์นที่เหลืออยู่",
total_score: "คะแนนสะสม",
lucky_box_title: "หีบทองนำโชค",
you_win: "ยินดีด้วย! คุณชนะ",
time: "เวลา",
level: "ระดับ",
jackpot: "แจ็คพอต",
account: "บัญชี",
result: "ผลลัพธ์",
session: "รอบ",
detail: "รายละเอียด",
view: "ดู",
receive_gold: "รับทอง",
jackpotx2: "แจ็คพอต x2"
},
toast: {
function_dont_work_on_trial: "ฟังก์ชันนี้ใช้ไม่ได้ในโหมดทดลองใช้งาน",
off_auto_spin_to_leave: "ปิดการหมุนอัตโนมัติเพื่อออกจากโต๊ะ",
funtion_in_develop: "ฟังก์ชันกำลังพัฒนา",
not_enough_gold: "ยอดเงินไม่พอกรุณาเติมเงิน",
spin_unsuccess: "หมุนไม่สำเร็จ",
unvalid_bet: "เดิมพันไม่ถูกต้อง",
unvalid_spin: "การหมุนไม่ถูกต้อง",
error_try_again: "เกิดข้อผิดพลาด โปรดลองอีกครั้ง",
atleast_1_line: "คุณต้องเลือกอย่างน้อย 1 แถว"
}
},
keno: {
door: {
tai: "ใหญ่",
xiu: "เล็ก",
chan: "คู่",
le: "คี่",
kim: "ทอง",
moc: "ไม้",
thuy: "น้ำ",
hoa: "ไฟ",
tho: "ดิน"
},
type_bet: {
number: "ตัวเลข",
xien: "เฉียง",
truotxien: "สไลด์เฉียง",
tx: "ไฮโล",
cl: "คู่ คี่",
xien2: "เฉียง 2",
xien3: "เฉียง 3",
xien4: "เฉียง 4",
xien5: "เฉียง 5",
truotxien4: "สไลด์เฉียง 4",
truotxien5: "สไลด์เฉียง 5",
truotxien6: "สไลด์เฉียง 6",
truotxien7: "สไลด์เฉียง 7",
truotxien8: "สไลด์เฉียง 8",
truotxien9: "สไลด์เฉียง 9",
truotxien10: "สไลด์เฉียง 10"
},
btn: {
chat: "แชท",
vecuoc: "เดิมพันตั๋ว",
statistic: "สถิติ",
number_bet: "เดิมพันหมายเลข",
base_bet: "เดิมพันพื้นฐาน",
guide: "แนะนำ",
most: "ที่สุด",
at_least: "อย่างน้อย",
consecutive: "ติดต่อกัน",
no_result: "ไม่มีผลลัพธ์",
bet: "เดิมพัน",
cancel: "ยกเลิก",
off: "ปิด",
dont_show_again: "ไม่แสดงอีกครั้ง",
transaction: "ธุรกรรม"
},
statistic: {
number_kytai: "จำนวนเซสชันใหญ่:",
number_kyxiu: "จำนวนเซสชันเล็ก:",
number_kychan: "จำนวนเซสชันคู่:",
number_kyle: "จำนวนเซสชันคี่:",
ratio: "อัตราส่วน:",
explain: "เขบ็ต",
tai: "=ใหญ่",
xiu: "=เล็ก",
chan: "=คู่",
le: "=คี่",
today: "วันนี้",
yesterday: "เมื่อวาน",
number: "ตัวเลข",
session50: "50 เซสชัน",
session100: "100 เซสชัน",
session200: "200 เซสชัน",
session400: "400 เซสชัน",
frequency: "ความถี่",
tx: "ไฮโล",
cl: "คู่ คี่"
},
popup_title: {
confirm_ticket: "ยืนยันตั๋วเดิมพัน",
you_know: "คุณรู้หรือไม่",
history_transfer: "โอนประวัติ",
result: "ผลลัพธ์"
},
popup_confirm: {
selected: "เลือกแล้ว",
money_bet: "เดิมพัน",
total_bet: "เดิมพันทั้งหมด:",
total_prize: "เงินรางวัล:"
},
editbox: {
placeholder_session: "ป้อนหมายเลขเซสชัน"
},
message: {
times: "ครั้ง",
rounding: "รางวัลปั่น",
total: "ทั้งหมด: ",
result_session: "ผลเซสชั่น #",
get: "1 รับ ",
error_number: "ตัวเลข!",
error_enough_number: "คุณต้องเลือกให้เพียงพอ",
error_choose_maximum: "คุณสามารถเลือกได้สูงสุดเท่านั้น",
selected: "เลือกแล้ว:  ",
success_bet: "เดิมพันสำเร็จ!",
error_bet1: "ระบบไม่ว่าง กรุณาลองใหม่ภายหลัง!",
error_bet2: "ขณะนี้ระบบกำลังหยุดการจับรางวัล\n โปรดติดต่อฝ่ายบริการลูกค้าสำหรับรายละเอียดเพิ่มเติม.",
error_bet3: "เซสชั่นที่คุณเดิมพันสิ้นสุดลงแล้ว\n โปรดเดิมพันเซสชั่นถัดไป!",
error_bet4: "ข้อผิดพลาดในการเข้าสู่ระบบบัญชี",
error_bet5: "โปรดเลือกประเภทการเดิมพัน\n หมายเลข และป้อนมูลค่าเดิมพันเพื่อสิ้นสุดการเดิมพัน!",
error_bet6: "กรุณาฝากเงินเพื่อเข้าร่วมเดิมพัน",
error_bet7: "การเดิมพันที่คุณเลือกไม่มีอยู่\n โปรดวางเดิมพันอีกครั้ง",
error_bet8: "เงินเดิมพันน้อยเกินไปที่จะเข้าร่วม",
error_bet9: "จำนวนเงินที่คุณเดิมพันมากกว่าจำนวนเงินสูงสุดที่อนุญาตในการเดิมพัน 1 ครั้ง!",
error_bet10: "จำนวนเงินเดิมพันเกินเกณฑ์เดิมพัน \n โปรดเดิมพันด้วยจำนวนที่น้อยลง\n หรือลองอีกครั้งด้วยหมายเลขอื่นหรือลองอีกครั้งในภายหลัง",
error_bet11: "ยอดเงินไม่เพียงพอสำหรับวางเดิมพัน\n โปรดตรวจสอบอีกครั้ง",
error_bet12: "Params เป็นรูปแบบที่ไม่ถูกต้อง",
error_bet13: "เดิมพันหมดเวลา!",
error_bet14: "ยอดคงเหลือไม่พร้อมใช้งาน!",
error_bet15: "จำนวนเงินเดิมพันไม่ถูกต้อง!"
},
popup: {
rlt_number: "ลำดับ",
rlt_session: "รอบ",
rlt_result: "ผลลัพธ์",
rlt_total: "รวม",
rlt_tx: "ไฮโล",
rlt_cl: "คู่ คี่",
rlt_ngu_hanh: "ธาตุทั้ง 5",
rlh_session: "รอบ",
rlh_bet_type: "ประเภทการเดิมพัน",
rlh_bet_money: "เงินเดิมพัน",
rlh_prize: "รางวัล",
rlh_time: "เวลา"
}
},
lode79: {
ld_txt_dat: "เดิมพัน",
ld_txt_tai: "ใหญ่",
ld_txt_xiu: "เล็ก",
ld_txt_le: "คี่",
ld_txt_chan: "คู่",
ld_tit_chuyen_rut: "โอน/ถอน",
ld_xo_so: "หวย",
ld_phien: "รอบ",
ld_so_du: "ยอดเงิน",
ld_so_tien: "จำนวนเงิน",
ld_so_diem: "คะแนน",
ld_tong_diem: "คะแนนรวม",
ld_thanh_tien: "เป็นเงิน",
ld_tong_tien: "จำนวนเงินทั้งหมด",
bet_success: "เดิมพันสำเร็จ",
bet_fail: "เดิมพันล้มเหลว",
mien_bac: "ภาคเหนือ",
mien_trung: "ภาคกลาง",
mien_nam: "ภาคใต้",
dat_cuoc: "เดิมพัน",
ltr_huy: "ยกเลิก",
result: {
txt_giai_db: "รางวัลพิเศษ",
txt_giai_1: "รางวัลที่หนึ่ง",
txt_giai_2: "รางวัลที่สอง",
txt_giai_3: "รางวัลที่สาม",
txt_giai_4: "รางวัลที่สี่",
txt_giai_5: "รางวัลที่ห้า",
txt_giai_6: "รางวัลที่หก",
txt_giai_7: "รางวัลที่เจ็ด",
txt_giai_8: "รางวัลที่แปด"
},
lib: {
re_mien_bac: "ภาคเหนือ",
re_mien_trung: "ภาคกลาง",
re_mien_nam: "ภาคใต้",
re_short_mien_bac: "ภาคเหนือ",
re_short_mien_trung: "ภาคกลาง",
re_short_mien_nam: "ภาคใต้",
qs_con_giap: "12 นักษัตร",
cg_ty_9: "ชวด (9)",
cg_suu_9: "ฉลู (9)",
cg_dan_9: "ขาล (9)",
cg_mao_9: "เถาะ (9)",
cg_thin_8: "มะโรง (8)",
cg_ti_8: "มะเส็ง (8)",
cg_ngo_8: "มะเมีย (8)",
cg_mui_8: "มะแม (8)",
cg_than_8: "วอก (8)",
cg_dau_8: "ระกา (8)",
cg_tuat_8: "จอ (8)",
cg_hoi_8: "กุน (8)",
qs_bo_so: "กลุ่มตัวเลข",
bo_so_01: "กลุ่มตัวเลข 01",
bo_so_02: "กลุ่มตัวเลข 02",
bo_so_03: "กลุ่มตัวเลข 03",
bo_so_04: "กลุ่มตัวเลข 04",
bo_so_12: "คู่ตัวเลข 12",
bo_so_13: "ค่าสัมประสิทธิ์13",
bo_so_14: "กลุ่มตัวเลข 14",
bo_so_23: "กลุ่มตัวเลข 23",
bo_so_24: "คู่ตัวเลข 24",
bo_so_34: "คู่ตัวเลข 34",
qs_so_kep: "เลขคู่",
kep_bang: "เลขคู่ที่เป็นตัวเลขเดียวกัน",
bo_00: "ชุด 00",
bo_11: "ชุด 11",
bo_22: "ชุด 22",
bo_33: "ชุด 33",
bo_44: "ชุด 44",
qs_de_tong: "ยอดรวม",
tong_0: "รวม 0",
tong_1: "รวม 1",
tong_2: "รวม 2",
tong_3: "รวม 3",
tong_4: "รวม 4",
tong_5: "รวม 5",
tong_6: "รวม 6",
tong_7: "รวม 7",
tong_8: "รวม 8",
tong_9: "รวม 9",
type_de: "หวย",
type_de_dau: "หวยหัว",
type_de_duoi: "หวยท้าย",
type_de_giai_8: "หวยหัว รางวัลที่แปด",
type_de_giai_nhat: "รางวัลที่หนึ่ง",
type_de_giai_7: "รางวัลที่เจ็ด",
type_de_dau_db: "หวยหัวรางวัลพิเศษ",
type_de_duoi_db: "หวยท้ายรางวัลพิเศษ",
type_de_3_cang: "หวย 3 ตัวสุดท้าย ",
type_3d_dac_biet: "3D รางวัลพิเศษ",
type_3d_giai_7: "3D รางวัลที่เจ็ด",
type_3d_duoi: "3D ท้าย",
type_lo: "หวย",
type_lo_xien_2: "หวยพาร์เลย์ 2",
type_lo_xien_3: "หวยพาร์เลย์ 3",
type_lo_xien_4: "หวยพาร์เลย์ 4",
type_lo_truot_4: "หวยทวน 4",
type_lo_truot_8: "หวยทวน 8",
type_lo_truot_10: "หวยทวน 10",
type_tai_xiu: "ไฮโล",
type_chan_le: "คู่ คี่",
type_s_de: "หวย",
type_s_de_dau: "หวยหัว",
type_s_de_duoi: "หวยท้าย",
type_s_de_giai_8: "หวยหัว รางวัลที่แปด",
type_s_de_giai_nhat: "รางวัลที่หนึ่ง",
type_s_de_giai_7: "รางวัลที่เจ็ด",
type_s_de_dau_db: "หวยหัวรางวัลพิเศษ",
type_s_de_duoi_db: "หวยท้ายรางวัลพิเศษ",
type_s_de_3_cang: "หวย 3 ตัวสุดท้าย ",
type_s_3d_dac_biet: "3D รางวัลพิเศษ ",
type_s_3d_giai_7: "3D รางวัลที่เจ็ด",
type_s_3d_duoi: "3D ท้าย",
type_s_lo: "หวย",
type_s_lo_xien_2: "หวยพาร์เลย์ 2",
type_s_lo_xien_3: "หวยพาร์เลย์ 3",
type_s_lo_xien_4: "หวยพาร์เลย์ 4",
type_s_lo_truot_4: "หวยทวน 4",
type_s_lo_truot_8: "หวยทวน 8",
type_s_lo_truot_10: "หวยทวน 10",
type_s_tai_xiu: "ไฮโล",
type_s_chan_le: "คู่ คี่"
},
responseWs: {
bet_success: "เดิมพันสำเร็จ",
bet_fail: "เดิมพันล้มเหลว",
resNotifyLivestream1: "เชิญคุณเดิมพันในรอบ\n XS LiveStream\n XXXX - รอบ YYYY",
resNotifyLivestream2: "ขณะนี้อยู่ในช่วงหมุน\n โปรดรอสักครู่เพื่อเปิดเดิมพันรอบถัดไป!",
resNotifyLivestream3: "กรุณาหยุดเดิมพัน ระบบจะเริ่มหมุนรอบปัจจุบัน!",
resNotifyLivestream4: "เปิดเดิมพันในรอบถัดไป\n XS XXXX รอบ YYYY\n กรุณาวางเดิมพันของคุณ!",
resBet_am_1: "Token ไม่ถูกต้อง",
resBet_0: "เดิมพันที่ประสบความสำเร็จ",
resBet_1: "ระบบไม่ว่าง โปรดลองอีกครั้งในอีกสักครู่!",
resBet_2: "ไม่มีการกำหนดค่า",
resBet_3: "วันนี้งดหมุนรางวัล",
resBet_4: "โหลดเดิมพันลอตเตอรี่ไม่สำเร็จ",
resBet_5: "ยังไม่ถึงเวลาเปิดเดิมพัน",
resBet_6: "ไม่มีบัญชี",
resBet_7: "ไม่มีอะไร",
resBet_8: "เดิมพันเป็นข้อมูลที่จำเป็น",
resBet_9: "ระบบไม่ว่าง โปรดลองอีกครั้งในอีกสักครู่!.",
resBet_10: "จำนวนเงินเดิมพันน้อยเกินไป",
resBet_11: "จำนวนเงินเดิมพันมากเกินไป",
resBet_12: "ไม่มีประเภทลอตเตอรี",
resBet_13: "จำนวนเงินเดิมพันมากเกินไป",
resBet_14: "จำนวนเงินเดิมพันน้อยเกินไป",
resBet_15: "เงินเดิมพันไม่อยู่ในรูปแบบที่ถูกต้อง",
resBet_16: "หมายเลขเดิมพันอยู่ในรูปแบบที่ไม่ถูกต้อง",
resBet_17: "จำนวนเงินเดิมพันมากเกินไป",
resBet_18: "บัญชีของคุณไม่เพียงพอ",
resBet_19: "จังหวัดเปิดให้รางวัลไม่มีอยู่จริง",
resBet_20: "ระบบไม่ว่าง โปรดลองอีกครั้งในอีกสักครู่!.",
resBet_21: "วันนี้ไม่มีการหมุนรางวัลในสถานที่นี้",
resBet_22: "ระบบไม่ว่าง โปรดลองอีกครั้งในอีกสักครู่!.",
resBet_23: "วางเดิมพัน",
resBet_24: "วางเดิมพัน",
resBet_25: "วางเดิมพัน",
resBet_26: "วางเดิมพัน",
resBet_27: "วางเดิมพัน",
resBet_28: "ระบบไม่ว่าง โปรดลองอีกครั้งในอีกสักครู่!",
resBet_29: "จำนวนเงินเดิมพันมากเกินไป",
resBet_30: "ระบบไม่ว่าง โปรดลองอีกครั้งในอีกสักครู่!",
resBet_31: "ระบบไม่ว่าง โปรดลองอีกครั้งในอีกสักครู่!",
resBet_32: "ระบบไม่ว่าง โปรดลองอีกครั้งในอีกสักครู่!",
resBet_33: "บัญชีหมดอายุเข้าระบบแล้ว\n กรุณาเข้าสู่ระบบและดำเนินการอีกครั้ง!",
resBet_34: "ต้องเติมเงินขั้นต่ำจึงจะมีสิทธิ์เดิมพัน!"
},
popup: {
title_huong_dan: "แนะนำ",
title_thong_so: "พารามิเตอร์",
title_thong_so_tra: "พารามิเตอร์ดั้งเดิม",
title_thong_so_liv: "สเปกการถ่ายทอดสด",
thong_so_header_gia_ban: "ราคา",
thong_so_header_tra_thuong: "รางวัล",
thong_so_header_toi_da_lan_cuoc: "สูงสุด/ครั้งเดิมพัน",
thong_so_header_toi_da_so: "สูงสุด/จำนวน",
title_sao_ke: "สเตทเม้น",
title_sao_ke_tra: "สเตทเม้นดั้งเดิม",
title_sao_ke_liv: "สเตทเม้นการถ่ายทอดสด",
sao_ke_loai_phien: "ประเภทรอบ",
sao_ke_thoi_gian: "เวลา",
sao_ke_de_lo: "หวย",
sao_ke_tien_cuoc: "เดิมพัน",
sao_ke_nhan_thuong: "รับรางวัล",
title_bang_cuoc: "ตารางเดิมพัน",
title_bang_cuoc_tra: "ตารางการเดิมพันแบบดั้งเดิม",
title_bang_cuoc_liv: "ตารางเดิมพันถ่ายทอดสด",
bang_cuoc_loai_phien: "ประเภทรอบ",
bang_cuoc_thoi_gian: "เวลา",
bang_cuoc_de_lo: "หวย",
bang_cuoc_tien_cuoc: "เดิมพัน",
quy_tit_chuyen_quy: "การโอนเงิน",
quy_tit_rut_quy: "ถอนออก",
quy_lbcq_gold_c: "จำนวนทองที่โอน:",
quy_lbcq_gold_n: "จำนวนทองที่ได้รับ:",
quy_lbrq_gold_r: "จำนวนทองที่ถอนออก:",
quy_lbrq_gold_n: "จำนวนทองที่ได้รับ:",
quy_tit_ti_le: "อัตราส่วน:",
quy_tit_so_du: "จำนวนเงินปัจจุบัน:",
quy_btn_chuyen_quy: "การโอนเงิน",
quy_btn_rut_quy: "ถอนออก",
quy_btn_choi_ngay: "เล่นเลย"
},
validate: {
vli_1: "ยอดคงเหลือไม่พร้อมใช้งาน",
vli_2: "คุณยังไม่ได้เลือกหมายเลข",
vli_3: "กรุณากรอกจำนวนเงิน",
vli_4: "กรุณากรอกคะแนน",
vli_5: "โปรดเลือก XXXX ตัวเลข/ล็อตให้เพียงพอ",
vli_6: "เซสชันถัดไปยังไม่เปิดให้เดิมพัน โปรดรอ!",
vli_7: "กรุณาเลือกทั้งหมด 10 หมายเลข/เดิมพัน."
},
resChuyenRutQuy: {
res_01: "จำนวนเงินไม่ถูกต้อง!",
res_02: "จำนวนเงินที่จะถอนเกินยอดคงเหลือ",
res_03: "ยอดเงินไม่พอ",
res_cp_0: "โอนเงินสำเร็จ",
res_rq_0: "ถอนสำเร็จ"
}
},
MiniHoaQua: {
big_win: "ชนะครั้งใหญ่",
jackpot: "แจ็คพอต",
line: "แถว",
spin: "หมุน",
autoSpin: "หมุนอัตโนมัติ",
stop: "หยุด",
popup: {
detail_title: "รายละเอียดการเดิมพัน",
guide_title: "แนะนำ",
history_title: "ประวัติ",
honor_title: "เกียรติยศ",
select_line_title: "เลือกแถว",
session: "รอบ",
time: "เวลา",
bet_level: "ระดับการเดิมพัน",
bet_line: "แถวเดิมพัน",
bet: "เดิมพัน",
gain_gift: "รับรางวัล",
room: "ห้อง",
detail: " รายละเอียด",
account: "บัญชี",
status: "สถานะ",
win: "ชนะ",
unselect: "ยกเลิกการเลือก",
even_line: "แถวคู่",
odd_line: "แถวคี่",
all_line: "ทั้งหมด",
line_win: "แถวชนะ"
},
toast: {
action_too_quick: "คุณดำเนินการเร็วเกินไป",
you_need_choose_at_least_1_line: "คุณต้องเลือกอย่างน้อย 1 แถว",
not_enough_gold: "ยอดเงินไม่พอกรุณาเติมเงิน",
error_try_again: "เกิดข้อผิดพลาด โปรดลองอีกครั้ง",
connecting_server: "กำลังเชื่อมต่อกับเซิร์ฟเวอร์"
}
},
slotnudiepvien: {
unhappen: " ยังไม่เริ่ม",
music: "ดนตรี",
sound: "เสียง",
last_win: "เพิ่งชนะ",
total_bet: "เดิมพันทั้งหมด",
play_trial: "ทดลองเล่น",
play_real: "เล่นจริง",
line: "แถว",
bet_level: "ระดับการเดิมพัน",
popup: {
choose_line_title: "เลือกแถว",
x2_win_title: "โบนัส X2",
guide_title: "ตารางรางวัล",
jackpot_history_title: "ประวัติแจ็คพอต",
trade_history_title: "ประวัติการทำธุรกรรม",
even_line: "รับทอง",
odd_line: "แถวคี่",
all_line: "ทั้งหมด",
re_line: "เลือกใหม่",
line_bet: "แถวเดิมพัน",
line_win: "แถวชนะ",
chose_room_title: "เลือกห้อง",
resident: "ผู้พักอาศัย",
leader: "ผู้นำ",
boss: "เจ้านาย",
honor_title: "เกียรติยศ",
congratulations_account: "ขอแสดงความยินดีกับบัญชี",
remain_turn: "จำนวนเทิร์นที่เหลืออยู่:",
total_score: "คะแนนสะสม:",
lucky_box_title: "หีบทองนำโชค",
you_win: "ยินดีด้วย! คุณชนะ",
time: "เวลา",
level: "จำนวนเงินเดิมพัน",
jackpot: "แจ็คพอต",
account: "บัญชี",
result: "ผลลัพธ์",
session: "รอบ",
detail: "รายละเอียด",
view: "ดู",
receive_gold: "รับทอง",
jackpotx2: "แจ็คพอต x2",
minigame_title: "กระเป๋าเดินทาง อเนกประสงค์",
extra_turns: "เพิ่มรอบ"
},
toast: {
function_dont_work_on_trial: "ฟังก์ชันนี้ใช้ไม่ได้ในโหมดทดลองใช้งาน",
off_auto_spin_to_leave: "ปิดการหมุนอัตโนมัติเพื่อออกจากโต๊ะ",
funtion_in_develop: "ฟังก์ชันกำลังพัฒนา",
not_enough_gold: "ยอดเงินไม่พอกรุณาเติมเงิน",
spin_unsuccess: "หมุนไม่สำเร็จ",
unvalid_bet: "เดิมพันไม่ถูกต้อง",
unvalid_spin: "การหมุนไม่ถูกต้อง",
error_try_again: "เกิดข้อผิดพลาด โปรดลองอีกครั้ง",
atleast_1_line: "คุณต้องเลือกอย่างน้อย 1 แถว"
}
},
shankoemee: {
cannot_out_room: "คุณเป็นนายธนาคารไม่สามารถหาที่ว่างได้",
cancel_leave_room: "Cancel leave",
refresh_room: "รีเฟรช",
skm_card_score: "คะแนน",
skm_nguoi_choi: "เหงืยฉ่วย",
skm_muc_cuoc: "มัคคึค",
choose_room: "เลือกห้อง",
play_now: "เล่นเลย",
draw_card: "จั่วการ์ด",
do_not_draw_card: "ไม่วาด",
bet: "เดิมพัน",
quick_chat_1: "หนาวยัง?",
quick_chat_2: "อายุเท่าไหร่ที่จะจับ",
quick_chat_3: "ชีวิตไม่ใช่ความฝัน",
quick_chat_4: "โชดดีแค่ไหนเนี่ย",
quick_chat_5: "ของกิน :v",
quick_chat_6: "มันดำมาก",
quick_chat_7: "แต่ก็ยังเรียกร้อง",
quick_chat_8: "ตาย",
quick_chat_9: "เพลงมันน่าเบื่อ",
quick_chat_10: "คุณแตกยัง?",
quick_chat_11: "เสียที่รัก",
quick_chat_12: "เร็วเข้าป้า",
enter_chat_content: "เข้าสู่เนื้อหาแชท...",
do_not: "เลขที่",
accept: "ยอมรับ",
invite: "เชิญ",
double_banker: "คุณต้องการเพิ่มเงินเป็นสองเท่าให้กับธนาคารเพื่อที่จะเป็นนายธนาคารต่อไปหรือไม่?",
bank: "ธนาคาร",
enter_table_id: "ป้อนรหัสตาราง...",
hidden_table_full: "ตารางที่ซ่อนอยู่เต็ม",
table_id: "โต๊ะ: %{table}#%{game}",
bet_value: "เดิมพัน",
bet_value_num: "เดิมพัน:",
watching: "การรับชม",
empty_list: "รายการที่ว่างเปล่า",
not_enough_money_to_join_the_table: "เงินค่าห้องไม่พอ!",
value_slot: "%{value} สล็อต",
pot_bank: "หม้อ: %{value}",
banker_turn: "เทิร์นนายธนาคาร: %{turn}",
banker_turn2: "เป็นนายธนาคารรอบ 2 ต่อไป",
banker_turn3: "เปลี่ยน %{turn}",
waiting_new_game: "รอเกมใหม่เริ่ม",
waiting_banker: "นายธนาคารรออยู่",
change_banker: "เปลี่ยนนายธนาคาร",
banker_win_title: "นายธนาคารชนะ",
not_open_yet: "ฟังก์ชั่นไม่เปิด",
can_not_find_table_selected: "ไม่พบห้องที่เลือก",
enter_the_table_you_want_to_search: "กรุณากรอกตารางที่ต้องการค้นหา",
can_not_create_table: "เกมนี้ไม่อนุญาตให้สร้างตาราง",
no_valid_table_found: "ไม่พบตารางที่ถูกต้อง",
invite_user: "%{name} ชวนคุณเล่น คุณอยากเข้าร่วมไหม?",
error_not_defined: "ข้อผิดพลาด %{id}, ไม่ได้กำหนด.",
error_check_infomation: "ข้อผิดพลาดในการตรวจสอบข้อมูล",
error_can_not_find_table_try_again: "ข้อผิดพลาดในการตรวจสอบข้อมูล...",
error_not_enough_money_to_join_table: "คุณมีเงินไม่พอที่จะเข้าห้องนี้",
error_join_room_too_fast: "เข้าห้องเร็วเกินไป",
error_server_maintenance: "ระบบบำรุงรักษา",
error_can_not_find_table: "ไม่พบห้องเด็กเล่น",
error_password_table_not_correct: "รหัสผ่านห้องเกมไม่ถูกต้อง",
error_room_full: "ห้องเด็กเล่นเต็ม",
error_has_been_kick: "คุณไม่ได้รับอนุญาตให้เข้าโต๊ะโดยเจ้าของห้อง",
register_leave_table_success: "คุณได้ลงทะเบียนเพื่อออกจากห้อง",
place_bet: "วางเดิมพัน",
error_bet_already: "เดิมพันได้แล้ว",
error_not_enough_money: "เงินไม่พอ",
error_bet_not_correct: "มูลค่าเดิมพันไม่ถูกต้อง",
not_enough_gold_please_deposit: "ยอดเงินไม่พอกรุณาเติมเงิน",
cancel_register_leave_table: "คุณยกเลิกการสมัครเพื่อออกจากห้อง",
open_card: "เปิดไพ่",
id: "รหัส",
table_name: "ชื่อ",
table_require: "จำเป็นต้อง",
table_min_bet: "เดิมพันขั้นต่ำ",
table_num_user: "User",
leave_room_title: "Leave",
leave_room_contect: "คุณแน่ใจหรือที่จะออกจากโต๊ะ?",
on_sound: "บน",
off_sound: "ปิด",
send_chat: "ส่ง"
},
boogyi: {
cannot_out_room: "คุณเป็นนายธนาคารไม่สามารถหาที่ว่างได้",
cancel_leave_room: "Cancel leave",
boo_tong_diem: "คะแนนรวม",
refresh_room: "รีเฟรช",
skm_card_score: "คะแนน",
skm_nguoi_choi: "เหงืยฉ่วย",
skm_muc_cuoc: "มัคคึค",
choose_room: "เลือกห้อง",
play_now: "เล่นเลย",
draw_card: "จั่วการ์ด",
do_not_draw_card: "ไม่วาด",
bet: "เดิมพัน",
quick_chat_1: "หนาวยัง?",
quick_chat_2: "อายุเท่าไหร่ที่จะจับ",
quick_chat_3: "ชีวิตไม่ใช่ความฝัน",
quick_chat_4: "โชดดีแค่ไหนเนี่ย",
quick_chat_5: "ของกิน :v",
quick_chat_6: "มันดำมาก",
quick_chat_7: "แต่ก็ยังเรียกร้อง",
quick_chat_8: "ตาย",
quick_chat_9: "เพลงมันน่าเบื่อ",
quick_chat_10: "คุณแตกยัง?",
quick_chat_11: "เสียที่รัก",
quick_chat_12: "เร็วเข้าป้า",
enter_chat_content: "เข้าสู่เนื้อหาแชท...",
do_not: "เลขที่",
accept: "ยอมรับ",
invite: "เชิญ",
double_banker: "คุณต้องการเพิ่มเงินเป็นสองเท่าให้กับธนาคารเพื่อที่จะเป็นนายธนาคารต่อไปหรือไม่?",
bank: "ธนาคาร",
enter_table_id: "ป้อนรหัสตาราง...",
hidden_table_full: "ตารางที่ซ่อนอยู่เต็ม",
table_id: "โต๊ะ: %{table}#%{game}",
bet_value: "เดิมพัน",
bet_value_num: "เดิมพัน:",
watching: "การรับชม",
empty_list: "รายการที่ว่างเปล่า",
not_enough_money_to_join_the_table: "เงินค่าห้องไม่พอ!",
value_slot: "%{value} สล็อต",
pot_bank: "หม้อ: %{value}",
banker_turn: "เทิร์นนายธนาคาร: %{turn}",
banker_turn2: "เป็นนายธนาคารรอบ 2 ต่อไป",
banker_turn3: "เปลี่ยน %{turn}",
waiting_new_game: "รอเกมใหม่เริ่ม",
waiting_banker: "นายธนาคารรออยู่",
change_banker: "เปลี่ยนนายธนาคาร",
banker_win_title: "นายธนาคารชนะ",
not_open_yet: "ฟังก์ชั่นไม่เปิด",
can_not_find_table_selected: "ไม่พบห้องที่เลือก",
enter_the_table_you_want_to_search: "กรุณากรอกตารางที่ต้องการค้นหา",
can_not_create_table: "เกมนี้ไม่อนุญาตให้สร้างตาราง",
no_valid_table_found: "ไม่พบตารางที่ถูกต้อง",
invite_user: "%{name} ชวนคุณเล่น คุณอยากเข้าร่วมไหม?",
error_not_defined: "ข้อผิดพลาด %{id}, ไม่ได้กำหนด.",
error_check_infomation: "ข้อผิดพลาดในการตรวจสอบข้อมูล",
error_can_not_find_table_try_again: "ข้อผิดพลาดในการตรวจสอบข้อมูล...",
error_not_enough_money_to_join_table: "คุณมีเงินไม่พอที่จะเข้าห้องนี้",
error_join_room_too_fast: "เข้าห้องเร็วเกินไป",
error_server_maintenance: "ระบบบำรุงรักษา",
error_can_not_find_table: "ไม่พบห้องเด็กเล่น",
error_password_table_not_correct: "รหัสผ่านห้องเกมไม่ถูกต้อง",
error_room_full: "ห้องเด็กเล่นเต็ม",
error_has_been_kick: "คุณไม่ได้รับอนุญาตให้เข้าโต๊ะโดยเจ้าของห้อง",
register_leave_table_success: "คุณได้ลงทะเบียนเพื่อออกจากห้อง",
place_bet: "วางเดิมพัน",
error_bet_already: "เดิมพันได้แล้ว",
error_not_enough_money: "เงินไม่พอ",
error_bet_not_correct: "มูลค่าเดิมพันไม่ถูกต้อง",
not_enough_gold_please_deposit: "ยอดเงินไม่พอกรุณาเติมเงิน",
cancel_register_leave_table: "คุณยกเลิกการสมัครเพื่อออกจากห้อง",
open_card: "เปิดไพ่",
id: "รหัส",
table_name: "ชื่อ",
table_require: "จำเป็นต้อง",
table_min_bet: "เดิมพันขั้นต่ำ",
table_num_user: "User",
leave_room_title: "Leave",
leave_room_contect: "คุณแน่ใจหรือที่จะออกจากโต๊ะ?",
on_sound: "บน",
off_sound: "ปิด",
send_chat: "ส่ง",
test: "test",
zero_slot: "Leaks",
confirm: "ยืนยัน",
not_bid: "Không bid",
place_bid: "Mời đấu giá",
bid_value: "bid x%{value}",
bid_error_1: "Mức bid không đúng",
bid_error_2: "Không đủ tiền",
start_compare: "So bài"
},
shweshan: {
cannot_out_room: "คุณเป็นนายธนาคารไม่สามารถหาที่ว่างได้",
cancel_leave_room: "Cancel leave",
shw_resort: "จัดเรียงใหม่",
game_name: "Shweshan",
zero_slot: "Leaks",
arranage_done: "Arrange done",
shweshan_nguoi_choi: "เหงืยฉ่วย",
shweshan_muc_cuoc: "มัคคึค",
watching: "การรับชม",
do_not: "เลขที่",
accept: "ยอมรับ",
invite: "เชิญ",
refresh_room: "รีเฟรช",
empty_list: "รายการที่ว่างเปล่า",
play_now: "เล่นเลย",
confirm: "ยืนยัน",
start_compare: "Compare",
skm_card_score: "คะแนน",
skm_nguoi_choi: "เหงืยฉ่วย",
skm_muc_cuoc: "มัคคึค",
choose_room: "เลือกห้อง",
draw_card: "จั่วการ์ด",
do_not_draw_card: "ไม่วาด",
bet: "เดิมพัน",
quick_chat_1: "หนาวยัง?",
quick_chat_2: "อายุเท่าไหร่ที่จะจับ",
quick_chat_3: "ชีวิตไม่ใช่ความฝัน",
quick_chat_4: "โชดดีแค่ไหนเนี่ย",
quick_chat_5: "ของกิน :v",
quick_chat_6: "มันดำมาก",
quick_chat_7: "แต่ก็ยังเรียกร้อง",
quick_chat_8: "ตาย",
quick_chat_9: "เพลงมันน่าเบื่อ",
quick_chat_10: "คุณแตกยัง?",
quick_chat_11: "เสียที่รัก",
quick_chat_12: "เร็วเข้าป้า",
enter_chat_content: "เข้าสู่เนื้อหาแชท...",
double_banker: "คุณต้องการเพิ่มเงินเป็นสองเท่าให้กับธนาคารเพื่อที่จะเป็นนายธนาคารต่อไปหรือไม่?",
bank: "ธนาคาร",
enter_table_id: "ป้อนรหัสตาราง...",
hidden_table_full: "ตารางที่ซ่อนอยู่เต็ม",
table_id: "โต๊ะ: %{table}#%{game}",
bet_value: "เดิมพัน",
bet_value_num: "เดิมพัน:",
not_enough_money_to_join_the_table: "เงินค่าห้องไม่พอ!",
value_slot: "สล็อต:%{value}",
pot_bank: "หม้อ: %{value}",
banker_turn: "เทิร์นนายธนาคาร: %{turn}",
banker_turn2: "เป็นนายธนาคารรอบ 2 ต่อไป",
banker_turn3: "เปลี่ยน %{turn}",
waiting_new_game: "รอเกมใหม่เริ่ม",
waiting_banker: "นายธนาคารรออยู่",
change_banker: "เปลี่ยนนายธนาคาร",
banker_win_title: "นายธนาคารชนะ",
not_open_yet: "ฟังก์ชั่นไม่เปิด",
can_not_find_table_selected: "ไม่พบห้องที่เลือก",
enter_the_table_you_want_to_search: "กรุณากรอกตารางที่ต้องการค้นหา",
can_not_create_table: "เกมนี้ไม่อนุญาตให้สร้างตาราง",
no_valid_table_found: "ไม่พบตารางที่ถูกต้อง",
invite_user: "%{name} ชวนคุณเล่น คุณอยากเข้าร่วมไหม?",
error_not_defined: "ข้อผิดพลาด %{id}, ไม่ได้กำหนด.",
error_check_infomation: "ข้อผิดพลาดในการตรวจสอบข้อมูล",
error_can_not_find_table_try_again: "ข้อผิดพลาดในการตรวจสอบข้อมูล...",
error_not_enough_money_to_join_table: "คุณมีเงินไม่พอที่จะเข้าห้องนี้",
error_join_room_too_fast: "เข้าห้องเร็วเกินไป",
error_server_maintenance: "ระบบบำรุงรักษา",
error_can_not_find_table: "ไม่พบห้องเด็กเล่น",
error_password_table_not_correct: "รหัสผ่านห้องเกมไม่ถูกต้อง",
error_room_full: "ห้องเด็กเล่นเต็ม",
error_has_been_kick: "คุณไม่ได้รับอนุญาตให้เข้าโต๊ะโดยเจ้าของห้อง",
register_leave_table_success: "คุณได้ลงทะเบียนเพื่อออกจากห้อง",
place_bet: "วางเดิมพัน",
error_bet_already: "เดิมพันได้แล้ว",
error_not_enough_money: "เงินไม่พอ",
error_bet_not_correct: "มูลค่าเดิมพันไม่ถูกต้อง",
not_enough_gold_please_deposit: "ยอดเงินไม่พอกรุณาเติมเงิน",
cancel_register_leave_table: "คุณยกเลิกการสมัครเพื่อออกจากห้อง",
open_card: "เปิดไพ่",
id: "รหัส",
table_name: "ชื่อ",
table_require: "จำเป็นต้อง",
table_min_bet: "เดิมพันขั้นต่ำ",
table_num_user: "User",
leave_room_title: "Leave",
leave_room_contect: "คุณแน่ใจหรือที่จะออกจากโต๊ะ?",
on_sound: "บน",
off_sound: "ปิด",
send_chat: "ส่ง"
}
};
cc._RF.pop();
}, {} ],
vn: [ function(e, t) {
"use strict";
cc._RF.push(t, "7dfffRjtXBHlbf42oe4MzcZ", "vn");
var n, o;
t.exports = {
"": "",
alert: {
title_notification: "Thông báo",
ok: "ĐỒNG Ý",
yes: "Có",
no: "KHÔNG",
loaded: "NẠP",
close: "HỦY",
refuse: "TỪ CHỐI",
veritify: "Xác thực",
fail: "Lỗi",
discard: "Chọn lại",
confirm_logout: "Bạn chắn chắn muốn đăng xuất không?",
you_need_veritify_pin: "Bạn cần xác thực mã PIN",
you_need_veritify_phone_number: "Bạn cần xác thực số điện thoại!",
you_need_veritify_loaded_card: "Bạn cần nạp thẻ!",
coming_soon: "Chức năng sắp ra mắt",
coming_soon_game: "Game sắp ra mắt!",
game_maintian: "Game đang bảo trì!",
require_login: "Bạn cần đăng nhập!",
fucntion_maintian: "Chức năng đang bảo trì!",
fucntion_use_lobby: "Chức năng chỉ có thể được sử dụng bên ngoài sảnh!",
action_fast: "Bạn thao tác quá nhanh.\nVui lòng thử lại sau giây lát!",
error: {
not_enough_gold: "Không đủ XU",
wrong_captcha: "Sai mã captcha",
wrong_syntax: "Sai cú pháp",
wrong_pin: "Mã PIN không đúng, hoặc chưa đăng ký mã PIN",
wrong_pin_or_not_reg_pin: "Sai mã PIN hoặc chưa đăng ký mã PIN",
account_undefined: "Người chơi không tồn tại",
connector: {
fail: "Không có kết nối Internet\n Kiểm tra lại kết nối của bạn!",
a_2: "Bạn cần có kết nối mạng!!!",
a_3: "Đang kết nối đến hệ thống",
a_4: "Bạn chưa có quà.\n \n Hãy tham gia Event để nhận quà!",
a_5: "Vui lòng nhập mã PIN",
a_6: "Vui lòng nhập Captcha!",
expired: "Phiên đăng nhập đã hết hạn, mời bạn đăng nhập lại",
ban: "Tài khoản này đã bị khóa bởi hệ thống",
a_9: "Hệ thống đang bảo trì\nXin vui lòng quay lại sau!",
some_where: "The account is already logged in elsewhere"
},
services: {
a_10: "Tài khoản hoặc mật khẩu không đúng",
a_11: "Tài khoản đã được sử dụng",
a_12: "Tài khoản không tồn tại",
a_13: "Sai mật khẩu",
a_14: "Bạn đã đăng kí quá nhiều tài khoản.",
a_15: "Vui lòng chờ ít phút để tiếp tục tạo tài khoản.",
a_16: "Bạn đã tạo quá nhiều tài khoản \n vui lòng quay lại vào ngày mai."
},
defined: {
fail: "Lỗi không xác định",
param_invalid: "Tham số không chính xác",
maintain_system: "Hệ thống đang bảo trì",
session_key_invalid: "Session key ko tồn tại",
session_expired: "Session key hết hạn",
session_room_not_exist: "Phòng chơi không tồn tại",
session_not_enough_min_buy_in: "Không đủ mức cược tối thiểu",
out_buy_in_range: "Ngoài mức cược",
game_structure_invalid: "Game structure không tồn tại",
already_in_game: "Bạn đã trong game",
entering_game: "Đang vào game",
gift_code_invalid: "Giftcode không tồn tại",
gift_code_is_used: "Giftcode đã được sử dụng",
gift_code_is_expired: "Giftcode đã hêt hạn",
login_banned_ip: "IP của bạn đã bị khoá.\n Vui liên hệ CSKH để biết thêm thông tin chi tiết!",
login_banned_user: "Tài khoản của bạn đã bị khoá.\n Vui liên hệ CSKH để biết thêm thông tin chi tiết!",
player_action_invalid: "Thao tác không hợp lệ",
player_action_fail: "Thao tác lỗi",
not_enough_gold: "Không đủ  XU",
default: "Lỗi",
not_bet_too_long: "Bạn bị mời ra khỏi hệ thống\ndo không tương tác quá lâu"
}
}
},
LuckyWheel: {
system_error: "Lỗi hệ thống.",
received_code: "Tài khoản đã nhận giftcode bảo mật",
system_error_cache: "Lỗi hệ thống. Lưu cache redis lỗi!",
system_error_database: "Lỗi hệ thống. Lưu database lỗi!",
success: "Chúc mừng quý khách vừa trúng thưởng quà tặng %{XXX} GOLD. Vui lòng liên hệ chăm sóc khách hàng để nhận thưởng",
contact: "Liên hệ chăm sóc khách hàng để nhận quà"
},
loading: {
check_server: "Checking server information",
update: "Update",
update_success: "Update successful",
update_fail: "Update failed",
please_wait_update_version: "Please update to the latest version",
check_version: "Checking version",
progress_loading_new: "Updating the new version.",
not_loading_manifest: "Could not load manifest",
latest_current_version: "Latest current version",
load: "Loading"
},
lobby: {
lobby_notify_no_talk: "Hiện tại đang không phát Live.\nQuý khách vui lòng quay lại sau.",
not_have_account: "Bạn chưa có tài khoản?",
forgot_password: "Quên mật khẩu",
login: "Đăng nhập",
register: "Đăng ký",
title_naprut: "Nạp / Rút",
title_support: "Hỗ Trợ",
title_security: "Bảo Mật",
title_mail: "Hộp Thư",
title_fanpage: "Fanpage",
title_giftcode: "Gift Code",
title_group: "Cộng đồng",
logout: "Đăng xuất",
jackpot: {
jungle_spirit: "Đế Chế Maya",
captians: "Kho Báu",
agent_royale: "Nữ Điệp Viên",
sexy_girl: "Gái Nhảy",
avangers: "Siêu Anh Hùng",
fortune: "Thần Tài"
},
tab_game: {
all_game: "Tất Cả",
mini_game: "Mini Game",
betting: "Betting",
live_game: "Live Game",
slot: "Slot",
casino: "Game Bài"
},
warning: {
error_try_gain: "Có lỗi xảy ra. Vui lòng thử lại sau!",
minimum_transfer_500k: "Số tiền thối thiểu là 500k Gold!",
not_enough_gold: "Số dư không khả dụng",
maximum_bet_10M: "Tài khoản cược thể thao không được quá 10M",
error_in_processing: "Có lỗi trong quá trình xử lý!",
you_need_type_withdraw_money: "Bạn cần nhập số tiền rút!",
wrong_money: "Số tiền không đúng!",
cant_get_credit_try_again: "Không lấy được số dư. Vui lòng thử lại!",
withdraw_success: "Chúc mừng!\nBạn vừa rút thành công",
delete_mail_success: "Xóa thư thành công!",
you_sure_delete_mail: "Bạn chắc chắn muốn xóa thư",
error: "Có lỗi xảy ra",
developing_feature: "Tính năng đang phát triển!",
wrong_giftcode_check_again: "Mã Giftcode không đúng. Vui lòng kiểm tra lại!",
gift_code_is_used: "Mã Giftcode đã được sử dụng!",
congluratulation: "Chúc mừng! Bạn đã nhận được!",
invalid_giftcode: "Giftcode đã nhập không hợp lệ!",
over_exp_giftcode: "Giftcode đã hết hạn sử dụng!",
unsecury_account: "Tài khoản chưa đăng ký bảo mật!",
giftcode_cant_use_phone_number: "Giftcode không áp dụng với tài khoản bảo mật bằng số điệnt thoại VN",
giftcode_cant_use_this_account: "Giftcode không sử dụng được cho tài khoản này!",
please_type_num_money: "Vui lòng nhập số tiền!",
minimum_trade: "Giao dịch tối thiểu",
gold_up: "GOLD",
gold_n: "gold",
not_enough_gold1: "Số dư tài khoản không đủ",
username_must_same: "Tên tài khoản phải giống nhau!",
please_type_full_info: "Vui lòng nhập đầy đủ thông tin!\n(Tên đại lý, Nickname, Số tiền)",
un_phone_number_verify_account: "Tài khoản chưa xác thực bảo mật số điện thoại",
cant_transfer_yourselft: "Bạn không thể chuyển khoản cho chính mình",
change_avatar_success: "Đổi avatar thành công!",
please_type_full_info1: "Vui lòng điển đầy đủ thông tin!",
password_confirm_password_must_same: "Mật khẩu mới và mật khẩu mới nhập lại phải giống nhau!",
old_password_wrong: "Mật khẩu cũ không đúng",
you_sure_withdraw: "Bạn có chắc muốn rút tiền VND.\n Số GOLD ",
unexist_account: "Tài khoản không tồn tại!",
untype_username: "Bạn chưa nhập tên tài khoản",
untype_password: "Bạn chưa nhập mật khẩu",
server_lost_connect: "Mất kết nối server",
account_logining_please_logout: "Tài khoản của bạn đang được đăng nhập ở nơi khác. \nHãy đăng xuất trước khi đăng nhập.",
account_banning: "Tài khoản đang bị khóa.",
invalid_authentication_code: "Mã xác thực không chính xác.",
overtime_authentication: "Mã xác thực đã hết thời gian sử dụng.",
server_maintain_go_later: "Hệ thống đang bảo trì. Vui lòng quay trở lại sau.",
password_wrong: "Sai mật khẩu",
login_banned: "Bị ban login.",
unexist_user: "User không tồn tại.",
you_not_create_username: "Bạn chưa tạo tên nhân vật cho tài khoản.",
username_warning: "Tên tài khoản phải từ 6 - 18 ký tự, viết liền không dấu, không có ký tự đặc biệt!",
password_same_warning: "Mật khẩu nhập lại không trùng với mật khẩu đã nhập.",
verify_code_wrong: "Mã xác nhận không đúng",
internet_unstable: "Kết nối mạng không ổn định.\nVui lòng kiểm tra kết nối wifi/3g",
invalid_username: "Username không hợp lệ",
username_exist: "Username đã tồn tại",
invite_code_unexist: "Mã giới thiệu không tồn tại",
invite_code_wrong_type: "Mã giới thiệu không đúng định dạng (vd:K1234567)",
captcha_wrong: "Mã captcha không chính xác",
captcha_error: "Lỗi captcha",
nickname_invalid: "Nickname không hợp lệ",
nickname_exist: "Nickname đã tồn tại",
nickname_not_same_username: "Nickname không được trùng với Username",
nickname_had: "Đã có Nickname rồi.",
nickname_not_sentitive: "Không chọn Nickname nhạy cảm.",
check_network: "ERROR_CHECK_YOUR_NETWORK",
logined_other_device: "Bạn đã đăng nhập ở thiết bị khác",
giftcode_please_enter_full: "Vui lòng điền đẩy đủ Giftcode",
info_update_success_contact_to_complete: "Cập nhật thông tin thành công!\nQuý khách vui lòng chat với bot tele để hoàn thành bước bảo mật.",
info_error_update: "Xảy ra lỗi trong quá trình cập nhật thông tin!",
info_email_wrong_type: "Email định dạng không đúng!",
info_phone_number_wrong_type: "Số điện thoại định dạng không đúng!",
info_email_registered_other_account: "Email đã được đăng ký bởi tài khoản khác!",
info_not_need_otp_unsecure_account: "Không yêu cầu mã OTP cho tài khoản chưa bảo mật!",
info_phone_number_registered_try_other: "Số điện thoại đã được đăng ký. Vui lòng sử dụng số điện thoại khác!",
phone_number_warning: "Số điện thoại phải có độ dài từ 10-15 số!",
otp_required: "Mã OTP là thông tin bắt buộc",
otp_tele_wrong: "Nhập sai mã Tele OTP. Vui lòng thử lại",
otp_wrong: "Mã OTP không đúng!",
otp_unexist: "Mã OTP không tồn tại",
otp_overtime_use: "Mã OTP đã hết hạn sử dụng",
you_sure_out_game: "Bạn có chắc chắn muốn thoát khỏi trò chơi?",
password_change_success: "Thay đổi mật khẩu thành công!",
password_required: "Mật khẩu mới là thông tin bắt buộc",
password_confirm_required: "Nhập lại mới là thông tin bắt buộc",
password_confirm_wrong: "Nhập lại mật khẩu mới không đúng.",
password_current_wrong: "Mật khẩu hiện tại không đúng",
account_login_fb_gg_cant_use_feature: "Tài khoản đăng nhập bằng Facebook hoặc Google+\n không thể sử dụng chức năng này!",
feature_for_register_secury_account: "Chức năng này dành cho các tài khoản đã đăng ký bảo mật!",
account_warning_nickname: "Hệ thống không hỗ trợ các tài khoản chưa cập nhật Nickname",
you_need_enter_money: "Bạn cần nhập số tiền!",
deposit_order_double: "Bạn tạo 2 lệnh nạp gần nhau quá",
deposit_order_limit_per_day: "Quá giới hạn tạo lệnh nạp trong một ngày!\n Yêu cầu chuyển khoản để hoàn thành lệnh nạp trước khi\n tạo lệnh tiếp theo",
buy_gold_faild: "Mua GOLD thất bại!",
withdraw_money_faild: "Rút tiền thất bại!",
withdraw_maximum_is: "Số tiền tối đa có thể chuyển khoản\nlà ",
withdraw_maximum_is_after: " theo cơ chế GIFTCODE.\n Để biết thêm chi tiết vui lòng liên hệ CSKH",
withdraw_fail: "Rút thất bại",
success: "Thành công!",
bank_id_required: "ID ngân hàng là thông tin bắt buộc!",
account_number_required: "Số tài khoản là thông tin bắt buộc!",
username_required: "Tên tài khoản là thông tin bắt buộc!",
nickname_required: "Nickname là thông tin bắt buộc!",
num_gold_required: "Số GOLD là thông tin bắt buộc!",
account_number_wrong_type: "Số tài khoản không đúng định dạng!",
num_gold_wrong_type: "Số GOLD không đúng định dạng!",
account_banned_transfer: "Tài khoản đang bị khóa chức năng chuyển khoản!",
withdraw_money_minimum: "Số tiền rút phải lớn hơn hoặc bằng",
error_undetermine: "Lỗi không xác định",
not_enough_transfer_require_contact_service: "Quý khách không đủ điều kiện giao dịch. Chi tiết xin vui lòng liên hệ CSKH!",
attendance_success: "Điểm danh thành công!",
attendance_fail: "Điểm danh thất bại",
account_unregister_secure: "Tài khoản chưa đăng ký bảo mật",
account_unregister_secure_contact_service: "Tài khoản chưa đăng ký chức năng bảo mật.\n Vui lòng liên hệ Telegram:@cskhboss79 hoặc tổng đài 19006896 để được hỗ trợ, xác minh thông tin tài khoản để lấy lại mật khẩu.Xin cám ơn!",
account_unexist: "Tài khoản không tồn tại",
support: "BẠN VUI LÒNG LIÊN HỆ CSKH ĐỂ ĐƯỢC HỖ TRỢ!",
server_unconnect: "Chưa kết nối tới server",
server_terminate_interupt: "Server đang tạm thời gián đoạn",
account_not_enter: "Bạn chưa nhập tên tài khoản",
password_not_enter: "Bạn chưa nhập mật khẩu",
play_game_fun: "Chúc các bạn chơi game vui vẻ",
good_luck_later: "Chúc bạn may mắn lần sau",
transfer_account_receive_unexist: "Tài khoản nhận tiền không tồn tại!",
transfer_minimum_money: "Số tiền chuyển nhỏ hơn giá trị giao dịch tối thiểu!",
account_not_enought_transfer_condition: "Tài khoản chưa đủ điều kiện giao dịch. Vui lòng liên hệ với NPH!",
sercure_feature_auto_active: "Chức năng bảo mật sẽ tự động kích hoạt sau 24h kể thừ thời điểm đăng\nký thành công!",
transfer_limit: "Bạn chỉ được chuyển cho Đại lý tổng trong khoảng tiền nhất định",
transfer_over_credit: "Số tiền chuyển khoản vượt quá hạn mức!",
transfer_account_send_unexist: "Tài khoản chuyển tiền không tồn tại!",
transfer_enter_content: "Yêu cầu nhập nội dung chuyển khoản!",
tranfer_same_account: "Tài khoản chuyển tiền trùng với tài khoản nhận tiền",
transfer_local_feature_terminated_contact_service: "Chức năng chuyển khoản nội bộ tạm dừng hoạt động. Vui lòng liên hệ CSKH để được hỗ trợ!",
transfer_local_feature_terminated_contact_service1: "Chức năng chuyển khoản nội bộ \ntạm thời dừng hoạt động. \nVui lòng liên hệ CSKH để biết thêm chi tiết!"
},
gui_profile: {
profile_title: "Hồ sơ",
join_time: "Ngày tham gia",
birth_date: "Ngày sinh",
ip_address: "Địa chỉ IP",
invite_code: "Mã giới thiệu",
change_password: "Đổi mk",
change_password1: "Đổi mật khẩu",
change_avatar: "Đổi avt",
back: "Quay lại",
change: "Thay đổi",
current_password: "Mật khẩu hiện tại",
new_password: "Mật khẩu mới",
confirm_new_password: "Nhập lại mật khẩu mới",
update: "Cập nhật",
alert: {
warning_1: "Avatar của bạn không khác avatar trước.",
warning_2: "Chọn Avatar muốn thay đổi."
}
},
gui_agency: {
deposit_title: "Nạp Gold",
deposit_gold: "Nạp Gold",
deposit_history: "Lịch sử nạp",
sell_title: "Bán Gold",
sell_gold: "Bán Gold",
sell_history: "Lịch sử bán",
current_credit: "Số dư hiện tại",
agency: "Đai lý",
deposit_money: "Tiền nạp",
receive_gold: "Gold Nhận",
agency_note: "Chú ý: Kiểm tra kỹ thông tin của đại lý trước khi \nchuyển, chuyển nhầm NPH không hỗ trợ.\nSau 5 phút chưa nhận được gold liên hệ:",
or_call_to: "Hoặc gọi tới",
note: "Chú ý",
minimum_trade: "GD tối thiểu:",
rate_trade: "Phí giao dịch:",
exchange_rate: "Tỉ lệ quy đổi:",
account_number: "Số tài khoản",
account_name: "Tên tài khoản",
area: "Khu vực",
confirm: "Xác nhận",
deposit_note: "Quý khách đã tạo lệnh nạp thành công.\nTiếp theo, để hoàn thành quá trình nạp tiền.\nXin vui lòng liên hệ CSKH để gửi hóa đơn\nchuyển khoản.",
notify_title: "Thông báo",
num_transfer_gold: "Số GOLD Chuyển",
receive_money: "Số tiền",
branch: "Chi nhánh",
account_owner_name: "Tên chủ tài khoản",
continue: "Tiếp tục",
status: "Trạng thái",
time: "Thời gian",
transfer_code_short: "MGD",
num_transfer_money: "Số tiền chuyển",
title_new_bank: "Nhập tên ngân hàng",
title_bank_other: "Ngân hàng khác",
title_new_bank_message: "Nhập tên ngân hàng bạn muốn rút tiền",
lao: "Lào",
taiwan: "Đài loan",
vietnam: "Việt Nam",
thailan: "Thái Lan",
pending: "Đang xử lý",
accepted: "Đã duyệt",
rejected: "Hủy lệnh",
huy: "Hủy"
},
gui_list_agency: {
country_code: {
VN: "Việt Nam",
JP: "Nhật Bản",
KR: "Hàn Quốc",
TW: "Đài Loan",
LA: "Lào",
KH: "Campuchia",
US: "MỸ",
MM: "Myanmar",
TH: "Thái Lan",
LD: "LD",
WB: "WB",
JL: "JL"
},
agency_title: "Đại lý",
korea: "Hàn quốc",
japan: "Nhật Bản",
taiwan: "Đài Loan",
lao: "Lào",
campuchia: "Campuchia",
singapore: "Singapore",
thailand: "Thái Lan",
myanmar: "Myanmar",
no: "STT",
agency: "Đại lý",
nickname: "NICKNAME",
phone_number: "SĐT",
contact: "Liên hệ",
area: "Khu vực",
action: "Hành động",
buy: "Mua",
sell: "Bán",
rate: "Đánh giá",
people_rate: " người đã đánh giá",
action_rate: "Chạm vào để đánh giá đại lý",
title_rate: "Đánh giá phản hồi về đại lý ",
feedback_rate: "Phản hồi từ người khác",
enter_content: "Nhập nội dung ...",
rate_success: "Đánh giá thành công",
rate_fail: "Đánh giá thành công",
dk_rate: "Quý khách cần giao dịch tối thiểu 100.000 GOLD với đại lý để có lượt đánh giá. Xin cảm ơn!",
dk_rate_1: "Vui lòng nhập nội dung bình luận để hoàn tất việc đánh giá (tối thiểu 12 kí tự).",
dk_rate_2: "Giao dịch thành công. Bạn hãy dành chút thời gian đánh giá đại lý để chúng tôi cải thiện dịch vụ tốt hơn.",
dk_rate_content_0: "Đại lý giao dịch úy tín",
dk_rate_content_1: "Đại lý giao dịch nhanh",
dk_rate_content_2: "OK",
dk_rate_content_3: "Ủng hộ Đại Lý",
dk_rate_content_4: "Chúc đại lý phát tài phát lộc"
},
gui_attendance: {
attendance: "Điểm danh",
attendance_title: "Điểm danh",
day: "Ngày",
day1: "Ngày 1",
day2: "Ngày 2",
day3: "Ngày 3",
day4: "Ngày 4",
day5: "Ngày 5",
day6: "Ngày 6",
day7: "Ngày 7",
attendance_note: "Hãy điểm danh đầy đủ để nhận thưởng hấp dẫn vào cuối tuần"
},
gui_open_egg: {
open_egg: "Đập trứng",
gold_egg: "Trứng vàng",
white_egg: "Trứng trắng",
no_egg: "Không có quả trứng nào"
},
gui_bundle_download: {
download_game: "Tải game",
download: "Tải"
},
gui_event_list_giftcode: {
list_giftcode_title: "DS Giftcode"
},
gui_events: {
event_title: "Sự kiện",
event: "Sự kiện",
event_top_bet: "SK Top Cược",
event_attendace: "SK Điểm Danh",
event_receive_bet: "SK Nhận Cược",
event_find_million: "SK Tìm Triệu Phú",
event_sicbo: "SK Tài Xỉu",
event_jackpot_sicbo: "Nỗ hũ tài xỉu",
rules: "Thể lệ",
daily_top: "TOP Ngày",
top_bet: "TOP Bet",
attendace_again: "Điểm danh bù",
rank: "Xếp hạng",
user: "Nhân vật",
bet: "Tiền cược",
refund: "Hoàn cược",
money: "Số tiền"
},
gui_trade_history: {
trade_history_title: "Lịch sử GD",
trade_history: "Lịch sử GD",
play_gold: "Chơi gold",
play_chip: "Chơi xu",
deposit_chip: "Nạp xu",
deposit_gold: "Nạp GOLD",
expense_gold: "Tiêu gold",
trade_code: "Mã gd",
time: "Thời gian",
service: "Dịch vụ",
incurred: "Phát sinh",
credit: "Số dư",
description: "Mô tả",
detail: "Chi tiết",
view: "Xem"
},
gui_forgot_password: (n = {
account: "Tài khoản",
account_title: "Tài khoản",
account_note_full_info: "Để nhận được hỗ trợ. Vui lòng nhập đầy đủ thông tin \ndưới đây",
account_note_username: "Tên nhân vật là thông tin bắt buộc",
type_login_name: "Nhập tên đăng nhập",
authentication_code: "Mã xác nhận",
send: "Gửi",
forgot_password: "Quên mật khẩu",
forgot_password_title: "Quên mật khẩu",
telegram_authentication_code: "Mã xác thực telegram..."
}, n.send = "Gửi", n.new_password = "Mật khẩu mới", n.confirm_new_password = "Nhập lại mật khẩu mới", 
n),
gui_display_name: {
account_title: "Tài Khoản",
account_note_username: "Tên nhân vật là thông tin bắt buộc",
username: "Tên nhân vật",
account_note_username1: "Tên nhận vật trong khoảng 6-16 ký tự, không chứa các ký tự nhạy cảm, các ký tự đặc biệt và không có khoảng trắng",
create_new: "Tạo mới"
},
gui_login: {
login_title: "Tài Khoản",
login_name: "Tên đăng nhập",
password: "Mật khẩu",
save_password: "Lưu mật khẩu",
login: "Đăng nhập",
forgot_password: "Quên mật khẩu"
},
gui_registry: {
register_title: "Đăng ký",
register: "Đăng ký",
login_name: "Tên đăng nhập",
password: "Mật khẩu",
confirm_password: "Nhập lại mật khẩu",
invite_code_note: "Mã giới thiệu (Không bắt buộc)",
captcha: "Captcha"
},
gui_mailbox: {
title: "Tiêu Đề:",
content: "Nội Dung:",
sender: "Người gửi:",
unread: "Chưa xem",
read: "Đã xem",
mailbox_title: "Hòm thư",
mess_delete_mail: "Bạn có chắc chắn muốn xoá thư?"
},
gui_minigame: {
game_download: "Tải game",
taixiu: "Tài Xỉu",
caothap: "Cao Thấp",
chanle: "Chẵn Lẻ",
xocdia: "Xóc Đĩa",
pokego: "Poke Go",
baucua: "Bầu Cua"
},
gui_confirm_transfer: {
notify: "Thông báo",
agency_account: "Tài khoản đại lý",
notify_note_cheat: "Chỉ nên giao dịch với đại lý để tránh lừa đảo",
you_sure_send: "Bạn chắc chắn muốn chuyển cho",
amount_money: "Số tiền",
reason: "Lý do",
reject: "Hủy",
accept: "Đồng ý",
account: "Tài khoản",
confirm_transfer_title: "Thông báo"
},
gui_buy_gold: {
buy_gold: "Mua Gold",
buy_gold_title: "Mua Gold",
current_credit: "Số dư hiện tại",
agency: "Đại lý",
enter_agency: "Nhập Đại lý",
nickname: "NickName",
enter_nickname: "Nhập Nickname",
buy_money: "Tiền nạp",
number_buy_money: "Số tiền nạp...",
gold: "Gold",
receive_gold: "Gold nhận...",
other_agency: "Đại lý khác",
lb_warning_1: "Liên hệ đại lý để trực tiếp giao dịch",
lb_warning_2: "Số điện thoại đại lý: ",
lb_warning_3: "hoặc truy cập link: "
},
gui_sell_gold: {
sell_gold: "Bán Gold",
sell_gold_title: "Bán Gold",
current_credit: "Số dư hiện tại",
agency: "Đại lý",
enter_agency: "Nhập Đại lý",
nickname: "NickName",
enter_nickname: "Nhập Nickname",
buy_money: "Tiền nạp",
number_sell_gold: "Số gold cần chuyển",
gold: "Gold",
receive_money: "Số tiền nhận được",
other_agency: "Đại lý khác",
continue: "Tiếp tục",
transfer_reason: "Lí do chuyển khoản",
lao: "Lào",
cam: "Campuchia",
vn: "Việt Nam",
kor: "Hàn Quốc",
jp: "Nhật Bản",
tw: "Đài Loan"
},
safetybox: {
safetybox_title: "KÉT SẮT",
lb_goldin: "Gold trong két",
note: "Để sử dụng két sắt trước tiên bạn phải tạo mật khẩu",
lb_btn: {
chuyen: "CHUYỂN VÀO",
rut: "RÚT RA",
doimk: "ĐỔI MK",
dongy: "ĐỒNG Ý",
back: "QUAY LẠI"
},
lb_editbox: {
lb_chuyen: "Số Gold chuyển",
lb_rut: "Số Gold rút",
placeholder_password_rut: "Nhập mật khẩu két sắt để rút ra",
placeholder_password_create: "Tạo mật khẩu",
placeholder_re_password_create: "Nhập lại mật khẩu",
placeholder_password_old: "Mật khẩu cũ",
placeholder_new_password_update: "Mật khẩu mới",
placeholder_re_new_password_update: "Nhập lại mật khẩu mới"
},
message: {
wrong_password: "Bạn đã nhập sai mật khẩu. Vui lòng nhập lại!",
wrong_password_retype: "Nhập lại mật khẩu không đúng. Vui lòng nhập lại!",
wrong_old_pass: "Mật khẩu cũ không đúng. Vui lòng nhập lại!",
withdraw_success: "Rút ra thành công!",
transfer_success: "Chuyển vào thành công!",
transfer_failed: "Chuyển vào thất bại",
create_password_success: "Tạo mật khẩu thành công!",
update_password_success: "Cập nhật mật khẩu thành công!",
please_type_money_withdraw: "Vui lòng nhập số tiền muốn rút",
please_type_money_transfer: "Vui lòng nhập số tiền muốn chuyển",
error_create: "Có lỗi trong quá trình tạo. Vui lòng nhập lại!",
error_update: "Có lỗi trong quá trình cập nhật. Vui lòng nhập lại!",
error_network: "Kết nối mạng không ổn định. Vui lòng thử lại sau!"
}
},
gui_setting: {
music: "Âm thanh",
music_on: "Âm thanh (Bật)",
music_off: "Âm thanh (Tắt)",
term_of_use: "Điều khoản sử dụng",
feedBack: "Góp ý"
},
gui_notify: {
title_notify: "Thông báo",
notify_common_admin: "Ban Quản Trị BOSS79 Xin Trân Trọng Thông Báo",
notify_common_noti: "Nhà phát hành trân trọng thông báo",
notify_common_content: 'Để đáp ứng ng nhu cầu của đại lý và quý khách hàng, chúng\ntôi chính thức mở thêm cổng:                                   \nVới trò chơi đa dạng, phong phú "Lô Đề Bắc, Trung, Nam\nvới tỉ lệ trả thưởng vô cùng hấp dẫn so với thị trường"\nvà nhiều trò chơi Casino đa dạng, cược Thể Thao, Baccarat\nvới tỉ lệ hoàn cược cực cao, đem lại trải nghiệm\ncực hấp dẫn cùng tỉ lệ nạp rút 1:1.'
},
gui_chuyen_quy: {
transfer_withdraw_title: "NẠP/RÚT",
num_transfer_gold: "Số Gold chuyển",
receive_money: "Số tiền nhận",
transfer_fund: "Chuyển quỹ",
play_now: "Chơi ngay",
withdraw_fund: "Rút Quỹ",
withdraw_money: "Số tiền cần rút",
num_receive_gold: "Số gold nhận",
type_num_gold: "Nhập số gold",
type_num_money: "Nhập số tiền",
receive_gold: "Gold nhận",
current_money: "Số tiền hiện tại"
},
gui_transfer: {
transfer: "Chuyển khoản",
transfer_title: "Chuyển khoản",
current_credit: "Số dư hiện tại",
enter_nickname: "Nhập nickname",
re_enter_nickname: "Nhập lại Nickname",
enter_sell_money: "Số gold chuyển",
receive_gold: "Số Gold nhận",
reason: "Lí do chuyển khoản",
continue: "Tiếp tục",
agency: "Đại lý",
gold: "Gold",
amount_less_than_minimum: "Số tiền chuyển nhỏ hơn giá trị giao dịch tối thiểu!",
unregister_security: "Tài khoản chưa đăng ký bảo mật! Liên hệ CSKH.",
otp_expired: "Mã OTP đã hết hạn!",
otp_not_correct: "Mã OTP không đúng!",
otp_error: "Lỗi OTP!",
una_balance: "Số dư không đủ!",
lock_transfer: "Nickname bị khoá chuyển khoản!",
acc_not_exist: "Nickname không tồn tại!",
enter_details: "Vui lòng nhập nội dung chuyển khoản!",
not_transfer_yourself: "Không thể chuyển khoản cho chính mình!",
not_transfer_agency: "Đại lý không thể chuyển khoản cho đại lý!",
not_transfer_agency2: "Đại lý cấp 2 không thể chuyển khoản cho đại lý cấp 2!",
not_transfer_not_your_agency2: "Không thể chuyển khoản cho đại lý cấp 2 không phải của mình!",
amount_maximum: "\n\nSố tiền tối đa có thể chuyển khoản\nlà %{money} theo cơ chế GIFTCODE.\n Để biết thêm chi tiết vui lòng liên hệ CSKH!",
transfer_fail: "Chuyển khoản thất bại",
transfer_success: "Chuyển khoản thành công ",
sell_gold: "Bán Gold cho ",
sell_gold_user_text_0: " Lộc may mắn",
sell_gold_user_text_1: "Tự tin chiến thắng ",
sell_gold_user_text_2: "%{myNickName} chuyển GOLD cho %{otherNickName} ",
sell_gold_user_text_3: "Lucky Money "
},
gui_logout: {
logout_title: "Đăng xuất",
warning: "Bạn có chắc chắn muốn thoát khỏi trò chơi?",
no: "Hủy",
yes: "Đồng ý"
},
gui_policy: {
policy_title: "Điều khoản"
},
gui_security: {
security_title: "Bảo mật",
account_name: "Tên tài khoản",
username: "Tên nhật vật",
cmtnd: "CMTND",
email: "Email",
phone_number: "Số điện thoại",
update: "Cập nhật",
active: "Kích hoạt",
get_otp: "Lấy OTP"
},
gui_buy_and_sold: {
buy_and_sold_title: "Cửa hàng",
transfer: "Chuyển khoản",
sell_gold: "Bán Gold",
input_otp: "Nhập OTP"
},
gui_gift_code: {
notice: "* Để nhận được giftcode vui lòng nhập đúng mã và lưu ý thời gian nhận giftcode.\n* Mỗi giftcode chỉ áp dụng cho 1 tài khoản",
gift_code_title: "Gift Code",
enter_gift_code: "Nhập mã Gift Code",
receive: "Nhận",
price: "Mệnh giá: ",
code: "Mã code: "
},
gui_header: {
logout: "Đăng xuất",
safetybox: "Két sắt",
history: "Lịch sử",
language: "Ngôn ngữ",
shop: "Cửa hàng",
setting: "Cài đặt",
confirm_change_language: "Bạn có chắc chắn muốn đổi\ngiao diện sang %{language} ?",
ok: "Đồng ý",
cancel: "Không",
win: "Thắng",
day: "ngày"
},
gui_choose_nation: {
choose_nation_title: "quốc gia"
},
gui_language: {
language_title: "Ngôn ngữ"
},
mergeWord: {
transaction_failed: "Giao dịch thất bại. Vui lòng thử lại sau!",
transaction_success: "Giao dịch thành công!",
seller_not_online: "Người bán không online!",
insufficient_balance: "Số dư không đủ!",
letter_not_exist: "Chữ/số không tồn tại!",
sys_err: "Lỗi hệ thống. Vui lòng thử lại sau!",
price_greater: "Giá chữ phải lớn hơn giá sàn!",
wants_to_sell: " muốn bán cho bạn chữ/số:",
price: "Giá: ",
please_choose_letters: "Vui lòng chọn các chữ trong kho bên trái để ghép chữ!",
pairing_fail: "Ghép chữ thất bại",
pairing_success: "Ghép chữ thành công, bạn nhận được ",
empty_data: "Dữ liệu rỗng",
word_incorrect: "Bộ chữ không đúng!",
not_enough_letters: "Bạn không đủ chữ/số!",
account_not_exist: "Tài khoản không tồn tại!",
selling_failed: "Bán chữ thất bại. Vui lòng thử lại sau!",
selling_success: "Bán chữ thành công, vui lòng chờ người mua chấp nhận!",
buyer_not_online: "Người mua đang không online. Vui lòng thử lại sau",
action_fast: "Bạn thao tác quá nhanh, vui lòng thử lại sau giây lát!",
greater_minimum: "Số tiền giao dịch phải lớn hơn số tiền giao dịch tối thiểu quy định",
minimum_selling: "Giá bán tối thiểu là 10.000 Gold.",
transaction_fee: "Phí giao dịch là 5% (Tối thiểu là 10.000 Gold)",
transaction_note: "Bạn muốn giao dịch chữ cái này với người khác vui lòng kiểm tra kỹ thông tin người chuyển và mệnh giá, nếu nhầm sẽ không được hoàn trả!",
selling_err: "Đã có lỗi xảy ra khi bán %s với giá %s cho %s",
acepted_buy: "%s đồng ý mua %s với giá %s",
not_acepted_buy: "%s không đồng ý mua %s với giá %s",
please_choose_word: "Vui lòng chọn chữ để bán!",
please_type_nickname: "Vui lòng nhập nickname!",
please_type_price: "Vui lòng nhập giá bán!",
buy: "Mua",
sell: "Bán",
history_buy_sell: "Lịch sử giao dịch",
history_trade_word: "Lịch sử đổi chữ",
nickname: "Tên nhân vật"
}
},
minigame: {
chat: {
input_chat: "Nhập để chat",
send: "Gửi",
error: "Lỗi",
greeting: "Chúc các bạn chơi game may mắn!",
banned: "*** Bạn không có quyền Chat!",
temp_banned: "*** Tạm thời bạn bị cấm Chat!",
limited_length: "*** Nội dung Chat quá dài!",
not_enough_gold: "*** Số dư không đủ để Chat.",
ban_forever: "*** Bạn bị cấm Chat vĩnh viễn.",
action_quickly: "*** Bạn Chat quá nhanh.",
require_length: "Vui lòng nhập nhiều hơn 1 kí tự",
require_topup: "Yêu cầu quý khách nạp tiền để mở tính năng chat"
},
common: {
rebet: "Đặt lại",
accept: "Đồng ý",
destroy: "Hủy",
select: "Chọn",
all_in: "Tất tay",
dice_1: "Xúc xắc 1",
dice_2: "Xúc xắc 2",
dice_3: "Xúc xắc 3",
top_day: "Ngày",
top_month: "Tháng",
top_year: "Năm",
top_round: "Chặng",
top_round1: "Chặng 1",
top_round2: "Chặng 2",
title_help: "Hướng dẫn",
title_session_detail: "Chi tiết phiên",
title_session: "Phiên",
title_nickname: "Nickname",
title_name: "Tên",
title_time: "Thời gian",
title_side: "Cửa đặt",
title_bet: "Đặt",
title_refund: "Hoàn",
title_reward: "Nhận",
title_result: "Kết quả",
title_total_bet_refund: "Tổng hoàn/đặt",
title_transaction_history: "LS Giao dịch",
title_top_bet: "TOP Đại Gia",
title_top_daily: "TOP Ngày",
title_top_monthly: "TOP Tháng",
title_top_rule: "Thể lệ",
title_top_number: "HẠNG",
title_account: "Tài khoản",
title_top_money: "Số tiền cược",
title_top_reward: "Giải thưởng",
title_top_refund: "Bồi hoàn",
xiu: "Xỉu",
tai: "Tài",
chan: "Chẵn",
le: "Lẻ",
bet_success: "Đặt cửa thành công.",
bet_fail: "Đặt cửa không thành công.",
bet_system_error: "Lỗi hệ thống.",
bet_timeout: "Quá thời gian đặt.",
bet_not_enough_chip: "Không đủ số dư.",
bet_money_invalid: "Tiền cược không hợp lệ",
bet_money_invalid_tour: "Tổng tiền đặt trong phiên không hợp lệ.\n Tối thiểu là: ",
bet_min_100: "Số tiền phải lớn hơn 100.",
bet_min_1000: "Số tiền phải lớn hơn 1.000.",
bet_only_1_side: "Đã đặt ở cửa khác.",
bet_invalid_side: "Cửa đặt không tồn tại.",
bet_side_other: "Chỉ được đặt cược 1 cửa.",
bet_invalid: "Bạn chưa chọn cửa!",
prestart_phase: "Đợi ván mới nhé!",
start_phase: "Bắt đầu ván mới!",
bet_phase: "Xin mời đặt!",
result_phase: "Dừng cược nhé!",
reward_phase: "Trả thưởng nhé!",
win_streak: "DÂY THẮNG",
lose_streak: "DÂY THUA",
nan: "NẶN",
bo_nan: "MỞ",
no_data: "Phiên này không có dữ liệu"
},
sicbo: {
gate: {
0: "Xỉu",
1: "Tài",
2: "Xỉu sicbo",
3: "Tài sicbo",
4: "Chẵn",
5: "Lẻ",
6: "Chẵn sicbo",
7: "Lẻ sicbo",
14: "Tổng 4",
15: "Tổng 5",
16: "Tổng 6",
17: "Tổng 7",
18: "Tổng 8",
19: "Tổng 9",
20: "Tổng 10",
21: "Tổng 11",
22: "Tổng 12",
23: "Tổng 13",
24: "Tổng 14",
25: "Tổng 15",
26: "Tổng 16",
27: "Tổng 17",
31: "Số 1",
32: "Số 2",
33: "Số 3",
34: "Số 4",
35: "Số 5",
36: "Số 6",
40: "Bão bất kỳ",
41: "Bão 1",
42: "Bão 2",
43: "Bão 3",
44: "Bão 4",
45: "Bão 5",
46: "Bão 6"
},
bao: "Bão",
bet_side_other: "Khách hàng chỉ được đặt 1 trong 2 cửa Tài hoặc Xỉu."
},
taixiu: {
bet_tai: "ĐẶT TÀI",
bet_xiu: "ĐẶT XỈU",
open: "Mở",
chitietbangdau: {
group_A: "Bảng A",
group_B: "Bảng B",
group_C: "Bảng C",
group_D: "Bảng D",
group_E: "Bảng E",
group_F: "Bảng F",
group_G: "Bảng G",
group_H: "Bảng H",
nickname: "TÊN",
gold: "SỐ TIỀN",
time: "THỜI GIAN",
small_gate: "CỬA XỈU",
big_gate: "CỬA TÀI",
group: "BẢNG\nĐẤU",
rank: "HẠNG",
finnal: "Chung\nKết"
},
jackpot: {
Tai: "CỬA TÀI NỔ HŨ BẠN NHẬN ĐƯỢC ",
Xiu: "CỬA XỈU NỔ HŨ BẠN NHẬN ĐƯỢC "
}
},
xocdia: {
gate: {
0: "Chẵn 4 đỏ",
1: "Lẻ 1 đen",
2: "Chẵn",
3: "Lẻ 1 đỏ",
4: "Chẵn 4 đen"
}
},
chanle: {
bet_chan: "ĐẶT CHẴN",
bet_le: "ĐẶT LẺ",
open: "Open"
},
rutloc: {
quy_loc: "QUỸ LỘC",
tan_loc: "TÁN LỘC",
rut_loc: "RÚT LỘC",
bet_success: "Tán lộc thành công. Chúc bạn gặp nhiều may mắn!",
bet_fail: "Tán lộc không thành công!",
bet_min_1000: "Tán lộc phải lớn hơn 1.000 GOLD!",
bet_outtime: "Rút lộc không thành công! Chờ 30 giây cuối cùng nhé!",
bet_nexttime: "Chúc bạn may mắn lần sau!",
reward: "Bạn rút lộc được",
not_money: "Quỹ lộc không đủ",
out: "Bạn đã hết lượt rút lộc!"
},
tournament: {
no: "STT",
title_user: "Người chơi",
title_user_history: "LS chơi",
phien: "Phiên",
time: "Thời gian",
bet_1: "Đặt",
result: "Kết quả",
bet_2: "Cược",
rev: "Nhận",
nickname: "Tên",
gold: "Số dư",
day: "ngày",
tour_status_1: "Sắp có giải đấu!",
tour_status_2: "Giải đấu sẵn sàng!",
tour_status_3: "Giải đấu sắp diễn ra!",
tour_status_4: "Giải đấu đang diễn ra",
tour_status_5: "Kết thúc vòng đấu",
tour_status_6: "Kết thúc giải đấu",
tit_players: "Danh sách người chơi",
tit_tour_info: "Thông tin giải đấu",
tit_join_tour: "Tham gia",
tit_num_players: "Số người chơi:",
tit_num_rounds: "Số phiên:",
tit_min_bet: "Tiền cược tối thiểu:",
tit_ticket_prize: "Giá vé:",
tit_nph_prize: "NPH tài trợ:",
tit_reg: "ĐĂNG KÝ THAM GIA GIẢI ĐẤU",
err_reg_0: "Đăng ký thành công",
err_reg_1: "Code không hợp lệ",
err_reg_2: "Code bị trùng",
err_reg_4: "Không tìm thấy user",
err_reg_5: "Không tìm thấy code",
err_reg_6: "Code đã bị dùng",
err_reg_7: "Code hết hạn",
err_reg_8: "Không tìm thấy tour",
err_reg_9: "Tour ko sử dụng code",
err_reg_10: "User đã ở trong tour",
err_reg_11: "Không tìm thấy đội",
err_reg_12: "Giải đấu đã bắt đầu. Không thể đăng ký",
err_reg_14: "Giải đấu đã đạt tối đa số người chơi",
tit_ticket: "Tiền vé",
tit_top_tour_0: "TOP GIẢI ĐẤU TUẦN",
tit_top_tour_1: "TOP GIẢI ĐẤU THÁNG",
tit_top_tour_2: "TOP GIẢI ĐẤU HẠNG",
tit_top_tour_3: "TOP GIẢI ĐẤU HẠNG",
thele: {
week: {
text_1: "- Giải đấu Tuần\nDiễn ra mỗi thứ 7 hàng tuần",
text_2: "*Giải đấu Tuần\nThể thức thi đấu: Tham Gia đánh Tài Xỉu loại trực tiếp 32 người chơi chia thành 8 bảng đấu, mỗi bảng 4 người, chọn 2 người thi đấu có thành tích tốt nhất mỗi bảng vào vòng sau. Tổng cộng 8 người vào chung kết tuần để thi đấu và tìm ra 3 người có thứ hạng cao nhất tuần để thi đấu Giải đấu Tháng.",
prize_0: "+ Giải Nhất tuần: %{money} Gold “được tham gia thi đấu chung kết tháng”  ",
prize_1: "+ Giải Nhì tuần: %{money} Gold “được tham gia thi đấu chung kết tháng”  ",
prize_2: "+ Giải Ba tuần: %{money} Gold “được tham gia thi đấu chung kết tháng”  ",
prize_3: "+ Giải Tư tuần: %{money} Gold ",
prize_4: "+ Giải Năm tuần: %{money} Gold ",
prize_5: "+ Giải Sáu tuần: %{money} Gold ",
prize_6: "+ Giải Bảy tuần: %{money} Gold ",
prize_7: "+ Giải Tám tuần: %{money} Gold ",
text_3: "* Dành cho khán giả",
text_4: "+ 3 giải: 1.000.000 Gold - 500K - 200K cho người dự đoán đúng hoặc gần đúng nhất 4 tên nhân vật của vòng bán kết",
text_5: "+ 30 giải khuyến khích: code 50K cho người tham gia dự đoán + tag 5 bạn bè tại Nhật Bản - Hàn Quốc - Đài Loan “ không tính nick clone, FB ảo chỉ tính Facebook thật có 200 bạn bè trở lên”"
},
month: {
text_1: "- Giải đấu Tháng\nDiễn ra tối chủ nhật mỗi cuối tháng",
text_2: "*Giải đấu Tháng\nThể thức thi đấu: Giải tháng có 16 người. Chia làm 4 bảng, mỗi bảng 4 người đấu với nhau. Chọn ra 8 người có thành tích tốt nhất vào chung kết Tháng.",
prize_0: "+ Giải Nhất tháng: %{money} Gold ",
prize_1: "+ Giải Nhì tháng: %{money} Gold ",
prize_2: "+ Giải Ba tháng: %{money} Gold ",
prize_3: "+ Giải Tư tháng: %{money} Gold ",
prize_4: "+ Giải Năm tháng: %{money} Gold ",
prize_5: "+ Giải Sáu tháng: %{money} Gold ",
prize_6: "+ Giải Bảy tháng: %{money} Gold ",
prize_7: "+ Giải Tám tháng: %{money} Gold ",
text_3: "* Dành cho khán giả",
text_4: "+ 3 giải: 1.000.000 Gold - 500K - 200K cho người dự đoán đúng hoặc gần đúng nhất 4 tên nhân vật của vòng bán kết",
text_5: "+ 30 giải khuyến khích: code 50K cho người tham gia dự đoán + tag 5 bạn bè tại Nhật Bản - Hàn Quốc - Đài Loan “ không tính nick clone, FB ảo chỉ tính Facebook thật có 200 bạn bè trở lên”"
}
}
}
},
minibaucua: {
check_ball: "SOI CẦU",
rebet: "ĐẶT LẠI",
accept: "ĐỒNG Ý",
destroy: "HỦY",
popup: {
guide_title: "HƯỚNG DẪN",
history_title: "LỊCH SỬ GD",
honor_title: "Top Cược",
session: "PHIÊN",
time: "THỜI GIAN",
bet_position: "CỬA ĐẶT",
result: "KẾT QUẢ",
bet: "ĐẶT",
return: "TRẢ LẠI",
gain: "NHẬN",
detail: "Chi tiết",
rank: "Hạng",
account: "Tài khoản",
win: "Thắng"
},
his_detail: {
session: "Phiên:",
day: "Ngày:",
result: "Kết quả:",
bau: "Bầu",
cua: "Cua",
tom: "Tôm",
ca: "Cá",
ga: "Gà",
huou: "Hươu"
},
toast: {
bet_fail: "Đặt cược thất bại.",
unreach_bet_time: "Chưa tới thời gian đặt cược.",
over_bet_time: "Quá thời gian đặt cược.",
not_enough_gold: "Số dư không đủ.",
bet_success: "Đặt cược thành công.",
action_too_quick: "Bạn thao tác quá nhanh.",
bet_no_position: "Bạn chưa đặt cửa.",
no_bet_last_session: "Bạn chưa đặt cược phiên trước",
no_bet_before: "Bạn chưa đặt cược trước đó.",
only_rebet_in_first_time: "Bạn chỉ có thể đặt lại cho lần cược đầu tiên."
}
},
caothap: {
play: "Chơi",
stop: "Dừng",
popup: {
guide_title: "Hướng dẫn",
history_title: "Lịch sử",
honor_title: "Vinh danh",
session: "Phiên",
time: "Thời gian",
bet: "Cược",
step: "Bước",
result: "Kết quả",
bet_door: "Cửa đặt",
win: "Thắng",
account: "Tài khoản",
bet_level: "Mức cược",
status: "Trạng thái",
jackpot: "Nổ hũ",
big_win: "Thắng lớn",
high: "Trên",
low: "Dưới"
},
toast: {
not_enough_gold: "Số dư không đủ, vui lòng nạp thêm",
you_loose: "Bạn đã thua! Chúc bạn may mắn lượt sau!",
congratulations: "Chúc mừng bạn đã thắng được ",
gold: "gold",
click_to_start_game: 'Click "Chơi" để bắt đầu ván chơi',
action_too_quick: "Bạn thao tác quá nhanh",
not_enough_gold_at_bet_level: "Bạn không đủ tiền chơi mực cược này."
}
},
minilongho: {
accept: "Đồng ý",
destroy: "Hủy",
bet_dragon: "Đặt Long",
bet_draw: "Đặt Hòa",
bet_tiger: "Đặt Hổ",
dragon: "Long",
tiger: "Hổ",
draw: "Hòa",
big_road: "Big road",
disk_road: "Disk road",
top_bet: "Top Cược",
total_game: "Số ván thống kê",
popup: {
guide_title: "Hướng dẫn",
history_title: "LS Chơi",
honor_title: "Top thắng",
session: "Phiên",
bet_door: "Cửa đặt",
bet: "Tiền cược",
time: "Thời gian",
win: "Tiền thắng",
result: "Kết quả",
no: "stt",
account: "Tài khoản",
bet_money: "Số tiền cược",
win_money: "Tiền Thắng"
},
toast: {
start_new_game: "Bắt đầu ván mới!",
start_return_reward: "Bắt đầu trả thưởng",
have_err_betting: "Đã có lỗi trong quá trình đặt cược",
minimum_bet: "Số tiền đặt cược phải lớn hơn 1.000",
not_enough_gold: "Không đủ số dư",
over_bet_time: "Quá thời gian đặt",
not_in_bet_time: "Chưa đến thời gian đặt cược!"
}
},
pokemon: {
line: "Dòng",
spin: "Quay",
autoSpin: "Tự quay",
stop: "Dừng",
popup: {
detail_title: "Chi tiết cược",
guide_title: "Hướng dẫn",
history_title: "Ls chơi",
honor_title: "Vinh Danh",
select_line_title: "Chọn dòng",
session: "Phiên",
time: "Thời gian",
bet_level: "Mức cược",
bet_line: "Dòng cược",
bet: "Cược",
gain_gift: "Nhận thưởng",
room: "Phòng",
detail: " Chi tiết",
account: "Tài khoản",
status: "Thạng thái",
win: "Thắng",
unselect: "Bỏ chọn",
even_line: "Dòng chẵn",
odd_line: "Dòng lẻ",
all_line: "Tất cả",
line_win: "Dòng thắng",
jackpot: "Nổ hũ",
big_win: "Thắng lớn"
},
toast: {
action_too_quick: "Bạn thao tác quá nhanh.",
you_need_choose_at_least_1_line: "Bạn cần chọn ít nhất 1 dòng.",
not_enough_gold: "Số dư không đủ, vui lòng nạp thêm",
error_try_again: "Có lỗi xảy ra, vui lòng thử lại sau",
connecting_server: "Đang kết nối đến server"
}
},
minipoker: {
auto_spin: "Tự Quay",
play_gold: "Chơi Gold",
play_chip: "Chơi xu",
popup: {
guide_title: "Hướng dẫn",
history_title: "Lịch sử giao dịch",
honor_title: "Bảng vinh danh",
time: "Thời gian",
bet: "Mức",
type: "Bộ bài",
win: "Thắng",
account: "Tài khoản",
straight: "Sảnh",
pair_j: "Đôi J++",
full_house: "Cù lũ",
two_pair: "Hai đôi",
flush: "Thùng",
three_of_a_kind: "Sám cô",
straight_flush: "Thùng phá sảnh",
jackpot: "Nổ hũ",
four_of_a_kind: "Tứ quý"
},
toast: {
action_too_quick: "Bạn thao tác quá nhanh.",
not_enough_gold: "Số dư không đủ, vui lòng nạp thêm.",
error_try_later: "Có lỗi xảy ra, vui lòng thử lại sau.",
game_in_auto_spin: "Game đang ở chế độ tự quay"
}
},
xeng: {
day: "Ngày",
month: "Tháng",
year: "Năm",
title_help: "Hướng dẫn",
title_transaction: "LS Giao dịch",
title_top: "TOP Cược",
title_session: "Phiên",
title_time: "Thời gian",
title_side: "Cửa đặt",
title_result: "Kết quả",
title_bet: "Đặt",
title_reward: "Nhận",
title_stt: "STT",
title_account: "Tài khoản",
title_gold: "Số gold",
bet_phase: "Bắt đầu đặt cược!",
result_phase: "Hết thời gian đặt cược!",
bet_success: "Đặt cược thành công!",
bet_invalid_money: "Tiền bet không hợp lệ",
bet_not_enough_money: "Không đủ số dư",
bet_fail: "Đặt cược thất bại"
},
lodenormal: {
betted: "Đã đặt",
betting: "Đang đặt",
bet: "Đặt cược",
winned: "Đã trúng",
eat: "ăn",
de: "Đề",
lo: "Lô",
de_3_num: "Đề 3 số",
de_first: "Đề đầu",
de_last: "Đề cuối",
lo_through_2: "Lô xiên 2",
lo_through_3: "Lô xiên 3",
lo_through_4: "Lô xiên 4",
lo_fail_10: "Lô trượt 10",
de_group: "Bộ đề",
no_group: "Bộ số",
couple_number: "Cặp số",
rate_number: "Hệ số đề",
group: "Bộ",
double_group: "Bộ kép",
double_type: "Bộ kép hệ",
type_double: "Kép hệ",
type_double1: "Hệ kép",
num_lo_de_group: "Bộ số lô đề",
animal_designation_12: "12 con giáp",
double_similar: "Kép bằng",
double_dif: "Kép lệch",
de_sum: "Đề tổng",
special: "Đặc Biệt",
first_prize: "Giải nhất",
second_prize: "Giải nhì",
third_prize: "Giải ba",
fourth_prize: "Giải tư",
fifth_prize: "Giải năm",
sixth_prize: "Giải sáu",
seventh_prize: "Giải bảy",
north_lottery: "Xổ số miền bắc",
last_second: "giây trước",
last_minute: "phút trước",
last_hour: "giờ trước",
last_day: "ngày trước",
last_month: "tháng trước",
last_year: "năm trước",
rat: "Tý",
ox: "Sửu",
tiger: "Dần",
cat: "Mão",
dragon: "Thìn",
snake: "Tỵ",
horse: "Ngọ",
goat: "Mùi",
monkey: "Thân",
rooster: "Dậu",
dog: "Tuất",
pig: "Hợi",
popup: {
month: "Tháng",
year: "Năm",
end_bet_title: "Thông tin",
inputbet_title: "Nhập tiền",
choose_de_num_title: "Chọn số đề",
choose_lo_num_title: "Chọn số lô",
de_3_num_title: "Chọn đề 3 số",
choose_de_group_title: "Chọn bộ số đề",
choose_lo_through_2: "Chọn lô xiên 2",
choose_lo_through_3: "Chọn lô xiên 3",
choose_lo_through_4: "Chọn lô xiên 4",
choose_lo_fail_10: "Chọn lô trượt 10",
choose_num_group_12: "Chọn bố số 12 con giáp",
choose_double_similar: "Đề kép bằng",
double_similar_detail: " Bộ số: 00, 11, 22, 33, 44, 55, 66, 77, 88, 99",
choose_double_dif: "Chọn bộ số đề kép lệch",
choose_de_sum_title: "Chọn bộ số đề tổng",
confirm: "Xác nhận",
reject: "Hủy",
bet: "Đặt cược",
bet_num: "Số đặt",
bet_money: "Tiền đặt",
bet_money_total: "Tổng tiền đặt",
win_total: "Tổng thắng",
de: "Đề",
lo: "Lô",
end_bet_warning: "Quý khác vui lòng xác nhận lại thông tin cược",
bet_money_total1: "Tổng số tiền đặt",
input_bet_placeholder: "Nhập số tiền",
input_num_placeholder: "Nhập con số",
gold: "Gold",
bet_total: "Tổng cược",
time_warning: "Thời gian từ 18:10 đến 18:45 (giờ Việt Nam) là thời gian quay thưởng và trả thưởng, chúng tôi không nhận lệnh đặt cược trong khoảng thời gian này."
},
warning: {
bet_success: "Đặt cược thành công!",
invalid_bet: "Số tiền đặt cược không hợp lệ",
error_in_betting: "Có lỗi trong quá trình đặt cược",
cant_bet_this_time: "Không thể đặt cược trong khoảng thời gian này",
not_enough_gold: "Bạn không đủ số dư",
please_choose_bet: "vui lòng chọn mức cược",
server_stop_spin_and_return_reward: "Hôm nay hệ thống dừng quay và trả thưởng",
please_cash_in_before_bet: "Bạn vui lòng nạp tiền trước khi đặt cược",
please_choose_no_bet: "Vui lòng chọn số đặt cược",
please_choose_bet_money: "Vui lòng chọn tiền đặt cược",
over_bet_bound: "vượt quá giới hạn đặt",
only_can_bet: "Bạn còn được đặt",
gold: "Gold",
no: "Số",
error_in_betting_door: "bị lỗi trong quá trình đặt cửa"
}
},
longho: {
dragon: "Rồng",
tiger: "Hổ",
draw: "Hòa",
tai: "Tài",
xiu: "Xỉu",
black: "Đen",
red: "Đỏ",
session: "PHIÊN",
menu: {
exit: "Thoát bàn",
rule: "Luật chơi",
history: "Lịch sử",
rank: "Xếp hạng"
},
popup: {
chat_title: "Trò Chuyện",
playing_people_title: "Những người cùng chơi",
check_ball_title: "Chi tiết phiên hiện tại",
guide_title: "Hướng dẫn",
history_title: "Lịch sử chơi",
rank_title: "Top thắng trong ngày",
chat_placeholder: "Nhập nội dung chat",
exit_table: "Thoát bàn",
history: "Lịch sử",
rule: "Luật chơi",
rank: "Xếp hạng",
title_statitics: "Thống kê",
title_count_statitics: "Số ván thống kê",
title_dishroad: "Dish road",
title_bigroad: "Big road",
nick_name: "Nick Name",
bet_door: "Cửa đặt",
money: "Số tiền",
time: "Thời gian",
session: "Phiên",
bet_money: "Tiền cược",
win_money: "Tiền Thắng",
result: "Kết quả",
dragon: "Long",
tiger: "Hổ",
no: "STT",
user_name: "Tên nhân vật",
play_together: "Người chơi cùng nhau"
},
toast: {
no_chat_permission: "*** Bạn không có quyền Chat!",
banned_chat: "*** Tạm thời bị cấm Chat!",
too_long_chat_content: "*** Nội dung Chat quá dài!",
banned_chat_to: "Bạn bị cấm Chat đến",
serverr_busy_try_later: "Hệ thống đang bận, xin vui lòng thử lại sau",
not_enough_gold: "Số dư tài khoản không đủ để đặt cược",
bet_too_small: "Số tiền đặt cược quá nhỏ",
only_allow_bet_dragon_or_tiger: "Bạn chỉ đặc đặt cược một trong hai cửa Long hoặc Hổ",
only_alow_bet_red_or_black_dragon: "Bạn chỉ được đặt cược một trong 2 cửa Long-Đỏ hoặc Long-Đen",
only_alow_bet_tai_or_xiu_dragon: "Bạn chỉ được đặt cược một trong 2 cửa Long-Tài hoặc Long-Xỉu",
only_alow_bet_red_or_black_tiger: "Bạn chỉ được đặt cược một trong 2 cửa Rồng-Đỏ hoặc Rồng-Đen",
only_alow_bet_tai_or_xiu_tiger: "Bạn chỉ được đặt cược một trong 2 cửa Rồng-Tài hoặc Rồng-Xỉu",
start_return_reward: "BẮT ĐẦU TRẢ THƯỞNG",
start_bet_door: "BẮT ĐẦU ĐẶT CỬA",
not_in_bet_time: "Hiện tại không phải thời gian đặt cược",
please_choose_bet: "Vui lòng chọn mức cược",
over_time_bet: "Quá thời gian đặt cược",
not_enough_gold1: "Số dư không đủ"
}
},
slot_avengers: {
unhappen: " Chưa diễn ra",
music: "Âm Thanh",
sound: "Nhạc Nền",
win: "Thắng",
total_bet: "Tổng đặt",
line: "Dòng",
autoSpin: "Tự quay",
bet: "Đặt cược",
play_trial: "Chơi thử",
play_real: "Chơi thật",
popup: {
jackpot_history_title: "Lịch sử trúng hũ",
choose_line_title: "Chọn Dòng",
trade_history_title: "Lịch sử giao dịch",
x2_win_title: "X2 Quỹ Thưởng",
time: "Thời gian",
level: "Mức",
jackpot: "Jackpot",
account: "Tài khoản",
result: "Kết quả",
session: "Phiên",
line_bet: "Số đặt",
line_win: "Dòng thắng",
receive_gold: "GOLD Nhận",
even_line: "Dòng Chẵn",
odd_line: "Dòng Lẻ",
all_line: "Tất Cả",
re_select: "Chọn Lại",
big_win: "Thắng Lớn",
choose_pearl: "Chọn ngọc",
congratulations: "Chúc mừng bạn được"
},
toast: {
need_choose_minimum_1_line: "Bạn cần chọn ít nhất 1 Dòng",
function_dont_work_in_trial: "Tính năng này không hoạt động ở chế độ chơi thử",
off_auto_spin_to_leave: "Tắt chế độ TỰ QUAY để thoát bàn",
function_in_develop: "Tính năng đang phát triển",
not_enough_gold: "Số dư không đủ, vui lòng nạp thêm",
error_try_again: "Có lỗi xảy ra, vui lòng thử lại"
}
},
slot_dancing_girls: {
holdToSpin: "GIỮ ĐỂ TỰ QUAY",
unhappen: " Chưa diễn ra",
music: "Âm Thanh",
sound: "Nhạc Nền",
win: "Thắng",
total_bet: "Tổng đặt",
line: "Dòng",
autoSpin: "Tự quay",
bet: "Đặt cược",
play_trial: "Chơi thử",
play_real: "Chơi thật",
popup: {
jackpot_history_title: "Lịch sử trúng hũ",
guide_title: "Bảng thưởng",
choose_line_title: "Chọn Dòng",
trade_history_title: "Lịch sử giao dịch",
x2_win_title: "X2 Quỹ Thưởng",
time: "Thời gian",
level: "Mức",
jackpot: "Jackpot",
account: "Tài khoản",
result: "Kết quả",
session: "Phiên",
line_bet: "Số đặt",
line_win: "Dòng thắng",
receive_gold: "GOLD Nhận",
even_line: "Dòng Chẵn",
odd_line: "Dòng Lẻ",
all_line: "Tất Cả",
re_select: "Chọn Lại",
big_win: "Thắng Lớn",
choose_pearl: "Chọn ngọc",
congratulations: "Chúc mừng bạn được"
},
toast: {
need_choose_minimum_1_line: "Bạn cần chọn ít nhất 1 Dòng",
function_dont_work_in_trial: "Tính năng này không hoạt động ở chế độ chơi thử",
off_auto_spin_to_leave: "Tắt chế độ TỰ QUAY để thoát bàn",
function_in_develop: "Tính năng đang phát triển",
not_enough_gold: "Số dư không đủ, vui lòng nạp thêm",
error_try_again: "Có lỗi xảy ra, vui lòng thử lại"
}
},
slotkhobau: {
unhappen: "Chưa diễn ra",
music: "Nhạc Nền",
sound: "Âm Thanh",
bet: "Mức",
total_bet: "Tổng Đặt",
last_win: "Thắng",
hide: "Ẩn",
line: "Dòng",
autoSpin: "Tự quay",
popup: {
choose_line_title: "Chọn Dòng",
x2_win_title: "X2 quỹ thưởng",
guide_title: "Bảng thưởng",
jackpot_history_title: "Bảng vinh danh",
trade_history_title: "Lịch sử giao dịch",
time: "Thời gian",
level: "Mức",
jackpot: "Jackpot",
account: "Tài khoản",
result: "Kết quả",
session: "Phiên",
line_bet: "Số đặt",
line_win: "Dòng thắng",
receive_gold: "GOLD Nhận",
even_line: "Dòng Chẵn",
odd_line: "Dòng Lẻ",
all_line: "Tất Cả",
re_select: "Chọn Lại",
big_win: "Thắng Lớn",
choose_pearl: "Chọn ngọc",
you_win: "Số điểm thắng",
remain_turn: "Số lần còn lại:",
total_score: "Điểm tích lũy:",
click_to_exit: "Click để thoát",
minigame_title: "Mini Game Kho Báu"
},
toast: {
function_dont_work_on_trial: "Tính năng này không hoạt động ở chế độ chơi thử.",
off_auto_spin_to_leave: "Tắt chế độ TỰ QUAY để thoát bàn",
funtion_in_develop: "Tính năng đang phát triển",
not_enough_gold: "Số dư không đủ, vui lòng nạp thêm",
spin_unsuccess: "Quay không thành công",
unvalid_bet: "Đặt cược không hợp lệ",
unvalid_spin: "Lượt quay không hợp lệ",
error_try_again: "Có lỗi xảy ra, vui lòng thử lại",
atleast_1_line: "Bạn cần chọn ít nhất 1 Dòng"
}
},
SlotTreeOfFortune: {
main: {
total_bet: "Tổng đặt:",
total_win: "Thắng:",
music: "Nhạc nền",
sound: "Âm thanh"
},
choose_line: {
title: "CHỌN DÒNG",
even_line: "DÒNG CHẴN",
odd_line: "DÒNG LẺ",
all_line: "TẤT CẢ",
re_line: "CHỌN LẠI"
},
mini_game: {
notice: "Click/Chạm vào cây để rung xu",
close: "Đóng",
you_get: "Bạn nhận được",
time_left: "SỐ LẦN CÒN LẠI:",
score: "ĐIỂM TÍCH LUỸ:"
},
history: {
title: "LỊCH SỬ",
phien: "PHIÊN",
time: "THỜI GIAN",
muc: "MỨC",
line_bet: "DÒNG ĐẶT",
line_win: "DÒNG THẮNG",
gold_receive: "GOLD NHẬN"
},
guide: "HƯỚNG DẪN",
top: {
title: "TOP",
time: "THỜI GIAN",
muc: "MỨC",
jackpot: "JACKPOT",
account: "TÀI KHOẢN",
result: "KẾT QUẢ",
nohu: "NỔ HŨ"
},
message: {
message1: "Chơi thử không dùng được chế độ tự quay",
message2: "Lượt quay hằng ngày không dùng được chế độ tự quay",
message3: "Bạn đang chuyển room, vui lòng chờ",
message4: "Bạn đang quay, vui lòng chờ quay xong",
message5: "Hệ thống đang xử lý, vui lòng chờ",
message6: "Bạn đang ở chế độ chơi thử, không được chọn dòng",
message7: "Bạn còn lượt quay miễn phí",
message8: "Bạn đang quay tự động",
message9: "Quay không thành công",
message10: "Đặt cược không hợp lệ",
message11: "Bạn không đủ tiền",
message12: "Lượt quay không hợp lệ",
message13: "Chúc bạn may mắn lần sau!",
message14: "Bạn phải chọn ít nhất 1 dòng"
}
},
room_info: {
id_room: "Nhập ID bàn ...",
hide_full_table: "Ẩn bản đầy",
room_not_found: "Không tìm thấy phòng đã chọn",
please_add_idroom: "Vui lòng điền bàn bạn muốn tìm kiếm",
not_create_room: "Không thể tạo bàn game này!",
not_enough_money: "Số dư không đủ, vui lòng nạp thêm",
error_check: "Lỗi kiểm tra thông tin",
no_room_avaiable_found: "Không tìm thấy bàn hợp lệ",
bao_tri: "Hệ thống đang bảo trì",
time_wait: "Mỗi lần vào phòng phải cách nhau 10 giây!",
password_error: "Mật khẩu phòng chơi không đúng!",
room_full: "Phòng chơi đã đủ người!",
ban_room: "Bạn bị chủ phòng không cho vào bàn!",
info_create_room_error: "Thông tin tạo bàn không chính xác!",
not_enough_vip: "Bạn chưa đủ cấp độ Vip để tạo bàn!",
not_enough_vip2: "Không thể tạo thêm bàn với cấp độ Vip hiện tại!"
},
tlmn: (o = {
tlmn_title: "Tiến Lên Miền Nam",
create_room: "Tạo bàn",
play_now: "Chơi ngay",
refresh_room: "Làm mới",
choose_bet_value: "Chọn",
player: "Người chơi",
password_room: "Mật Khẩu Phòng",
table: "Bàn: ",
bet_money: "Mức cược: ",
watting_for_start_game: "Đang chờ ván mới bắt đầu sau: ",
first_turn: " được đi lượt đầu tiên!",
sort_card: "Xếp bài",
hit_card: "Đánh bài",
next_turn: "Bỏ lượt",
viewing: "Đang xem",
no_select_card: "Bạn chưa chọn bài!",
card_avaiable_found: "Bài đánh không hợp lệ",
dang_ki_exit_success: "Bạn đã đăng ký rời phòng thành công!",
huy_dang_ki: "Bạn đã hủy đăng ký rời phòng!",
invite_game: "Mời chơi",
no_one_invite: "Không có người chơi thích hợp",
not_open: "Chức năng tạm thời chưa mở",
create_room_place_holder: "Đặt tên phòng",
chat_place_holder: "Nhập nội dung",
result: "Kết quả",
confirm: "Xác nhận",
room_not_found: "Không tìm thấy phòng đã chọn",
not_create_room: "Không thể tạo bàn game này!",
not_enough_money: "Số dư không đủ, vui lòng nạp thêm",
error_check: "Lỗi kiểm tra thông tin",
no_room_avaiable_found: "Không tìm thấy bàn hợp lệ",
bao_tri: "Hệ thống đang bảo trì",
time_wait: "Mỗi lần vào phòng phải cách nhau 10 giây!",
password_error: "Mật khẩu phòng chơi không đúng!",
room_full: "Phòng chơi đã đủ người!",
ban_room: "Bạn bị chủ phòng không cho vào bàn!",
info_create_room_error: "Thông tin tạo bàn không chính xác!",
not_enough_vip: "Bạn chưa đủ cấp độ Vip để tạo bàn!",
not_enough_vip2: "Không thể tạo thêm bàn với cấp độ Vip hiện tại!",
chat_1: "Cóng chưa",
chat_2: "Tuổi gì mà bắt",
chat_3: "Đời không như là mơ",
chat_4: "Hên thế",
chat_5: "Ăn hàng :v",
chat_6: "Đen vãi",
chat_7: "Thế mà cũng đòi sâm",
chat_8: "Chết nè",
chat_9: "Bài chán vãi",
chat_10: "Vỡ alo chưa ?",
chat_11: "Thua đi cưng",
chat_12: "Nhanh lên thím",
special_result_0: "SẢNH RỒNG",
special_result_1: "TỨ QUÝ 2",
special_result_2: "5 ĐÔI THÔNG",
special_result_3: "6 ĐÔI",
special_result_4: "13 LÁ ĐỒNG MÀU",
special_result_5: "12 LÁ ĐỒNG MÀU",
result_0: "HAI",
result_1: "ĐÔI HAI",
result_2: "3 CON HAI",
result_3: "3 ĐÔI THÔNG",
result_4: "4 ĐÔI THÔNG"
}, o.result_2 = "Thắng", o.result_4 = "Tới Trắng", o.result_11 = "Thua", o.result_12 = "Cóng", 
o.result_13 = "Thua Trắng", o),
sam: {
sam_title: "Sâm Lốc",
create_room: "Tạo bàn",
play_now: "Chơi ngay",
refresh_room: "Làm mới",
play_tour: "Giải Đấu",
play_normal: "Chơi Thường",
create_room_place_holder: "Đặt tên phòng",
choose_bet_value: "Chọn",
player: "Người chơi",
password_room: "Mật Khẩu Phòng",
table: "Bàn: ",
bet_money: "Mức cược: ",
watting_for_start_game: "Đang chờ ván mới bắt đầu sau: ",
first_turn: " được đi lượt đầu tiên!",
noti_bao_sam: "Bạn có muốn báo sâm không?",
bao: "Báo",
ko_bao_sam: "Không báo sâm",
co_bao_sam: "đã báo sâm",
sort_card: "Xếp bài",
hit_card: "Đánh bài",
next_turn: "Bỏ lượt",
viewing: "Đang xem",
bao_sam: "Báo sâm",
huy_sam: "Hủy báo",
dang_ki_exit_success: "Bạn đã đăng ký rời phòng thành công!",
huy_dang_ki: "Bạn đã hủy đăng ký rời phòng!",
no_select_card: "Bạn chưa chọn bài!",
card_avaiable_found: "Bài đánh không hợp lệ",
chat_place_holder: "Nhập nội dung",
invite_game: "Mời chơi",
no_one_invite: "Không có người chơi thích hợp",
not_open: "Chức năng tạm thời chưa mở",
result: "Kết quả",
confirm: "Xác nhận",
room_not_found: "Không tìm thấy phòng đã chọn",
not_create_room: "Không thể tạo bàn game này!",
not_enough_money: "Số dư không đủ, vui lòng nạp thêm",
error_check: "Lỗi kiểm tra thông tin",
no_room_avaiable_found: "Không tìm thấy bàn hợp lệ",
bao_tri: "Hệ thống đang bảo trì",
time_wait: "Mỗi lần vào phòng phải cách nhau 10 giây!",
password_error: "Mật khẩu phòng chơi không đúng!",
room_full: "Phòng chơi đã đủ người!",
ban_room: "Bạn bị chủ phòng không cho vào bàn!",
info_create_room_error: "Thông tin tạo bàn không chính xác!",
not_enough_vip: "Bạn chưa đủ cấp độ Vip để tạo bàn!",
not_enough_vip2: "Không thể tạo thêm bàn với cấp độ Vip hiện tại!",
chat_1: "Cóng chưa",
chat_2: "Tuổi gì mà bắt",
chat_3: "Đời không như là mơ",
chat_4: "Hên thế",
chat_5: "Ăn hàng :v",
chat_6: "Đen vãi",
chat_7: "Thế mà cũng đòi sâm",
chat_8: "Chết nè",
chat_9: "Bài chán vãi",
chat_10: "Vỡ alo chưa ?",
chat_11: "Thua đi cưng",
chat_12: "Nhanh lên thím",
special_6: "Sâm đỉnh",
special_7: "Tứ quý 2",
special_8: "Năm đôi",
special_9: "Đồng màu",
special_4: "Chặn sâm",
special_16: "Sâm thất bại",
result_3: "Thắng",
result_7: "Sâm",
result_6: "Thắng chặn Sâm",
result_2: "Sâm đỉnh",
result_4: "Tứ quý hai",
result_1: "Năm đôi",
result_0: "Đồng màu",
result_8: "Đền",
result_5: "Hòa",
result_9: "Thua",
result_10: "Đền Sâm"
},
binh: {
binh_title: "Mậu Binh",
watting_for_start_game: "Đang chờ ván mới bắt đầu sau: ",
watting_for_end_game: "Kết thúc ván sau: ",
table: "Bàn: ",
bet_money: "Mức cược: ",
viewing: "Đang xem",
chat_place_holder: "Nhập nội dung",
invite_game: "Mời chơi",
no_one_invite: "Không có người chơi thích hợp",
not_open: "Chức năng tạm thời chưa mở",
create_room: "Tạo bàn",
create_room_place_holder: "Đặt tên phòng",
play_now: "Chơi ngay",
refresh_room: "Làm mới",
choose_bet_value: "Chọn",
player: "Người chơi",
password_room: "Mật Khẩu Phòng",
result: "Kết quả",
confirm: "Xác nhận",
dang_ki_exit_success: "Bạn đã đăng ký rời phòng thành công!",
huy_dang_ki: "Bạn đã hủy đăng ký rời phòng!",
id_room: "Nhập ID bàn ...",
hide_full_table: "Ẩn bản đầy",
room_not_found: "Không tìm thấy phòng đã chọn",
please_add_idroom: "Vui lòng điền bàn bạn muốn tìm kiếm",
not_create_room: "Không thể tạo bàn game này!",
not_enough_money: "Số dư không đủ, vui lòng nạp thêm",
error_check: "Lỗi kiểm tra thông tin",
no_room_avaiable_found: "Không tìm thấy bàn hợp lệ",
bao_tri: "Hệ thống đang bảo trì",
time_wait: "Mỗi lần vào phòng phải cách nhau 10 giây!",
password_error: "Mật khẩu phòng chơi không đúng!",
room_full: "Phòng chơi đã đủ người!",
ban_room: "Bạn bị chủ phòng không cho vào bàn!",
info_create_room_error: "Thông tin tạo bàn không chính xác!",
not_enough_vip: "Bạn chưa đủ cấp độ Vip để tạo bàn!",
not_enough_vip2: "Không thể tạo thêm bàn với cấp độ Vip hiện tại!",
chat_1: "Xếp lâu thế!",
chat_2: "Nhanh lên thím",
chat_3: "Sảnh rồng nè :)",
chat_4: "3 cái thùng :)",
chat_5: "Đen vãi",
chat_6: "Lục phế bôn ;)",
chat_7: "3 cái sảnh ;)",
chat_8: "Sập hầm rồi",
chat_9: "Mậu binh hụt :((",
chat_10: "Bài chán thế",
chat_11: "Sám chi cuối ;)",
chat_12: "Thua đi cưng",
sorting: "Đang xếp",
sort_again: "Xếp lại",
sort_done: "Xếp xong",
bao_binh: "Báo binh",
sorting_time_remain: "Thời gian xếp bài còn lại",
rs_fail: "Binh Lủng",
rs_XAM_CHI_AT: "XÁM CHI ÁT",
rs_ROYAL_FLUSH: "SẢNH RỒNG",
rs_TU_QUY_CHI_AT: "TỨ QUÝ CHI ÁT",
rs_THUNG_PHA_SANH: "THÙNG PHÁ SẢNH",
rs_TU_QUY: "TỨ QUÝ",
rs_CU_LU: "CÙ LŨ",
rs_THUNG: "THÙNG",
rs_SANH: "SẢNH",
rs_XAM_CO: "XÁM",
rs_THU: "THÚ",
rs_DOI: "ĐÔI",
rs_MAU_THAU: "MẬU THẦU",
chi: "Chi"
},
bacay: {
bacay_title: "Ba Cây",
watting_for_start_game: "Đang chờ ván mới bắt đầu sau: ",
watting_for_end_game: "Kết thúc ván sau: ",
table: "Bàn: ",
bet_money: "Mức cược: ",
viewing: "Đang xem",
chat_place_holder: "Nhập nội dung",
invite_game: "Mời chơi",
no_one_invite: "Không có người chơi thích hợp",
not_open: "Chức năng tạm thời chưa mở",
create_room: "Tạo bàn",
create_room_place_holder: "Đặt tên phòng",
play_now: "Chơi ngay",
refresh_room: "Làm mới",
choose_bet_value: "Chọn",
player: "Người chơi",
password_room: "Mật Khẩu Phòng",
result: "Kết quả",
confirm: "Xác nhận",
dang_ki_exit_success: "Bạn đã đăng ký rời phòng thành công!",
huy_dang_ki: "Bạn đã hủy đăng ký rời phòng!",
time_bet: "Thời gian đặt cược",
id_room: "Nhập ID bàn ...",
hide_full_table: "Ẩn bản đầy",
room_not_found: "Không tìm thấy phòng đã chọn",
please_add_idroom: "Vui lòng điền bàn bạn muốn tìm kiếm",
not_create_room: "Không thể tạo bàn game này!",
not_enough_money: "Số dư không đủ, vui lòng nạp thêm",
error_check: "Lỗi kiểm tra thông tin",
no_room_avaiable_found: "Không tìm thấy bàn hợp lệ",
bao_tri: "Hệ thống đang bảo trì",
time_wait: "Mỗi lần vào phòng phải cách nhau 10 giây!",
password_error: "Mật khẩu phòng chơi không đúng!",
room_full: "Phòng chơi đã đủ người!",
ban_room: "Bạn bị chủ phòng không cho vào bàn!",
info_create_room_error: "Thông tin tạo bàn không chính xác!",
not_enough_vip: "Bạn chưa đủ cấp độ Vip để tạo bàn!",
not_enough_vip2: "Không thể tạo thêm bàn với cấp độ Vip hiện tại!",
not_enough_gold: "Số dư không đủ, vui lòng nạp thêm.",
chat_1: "Sáp nè",
chat_2: "Hên thế",
chat_3: "Cướp chương nhé",
chat_4: "Hên thế",
chat_5: "Nhanh lên thím",
chat_6: "Đen vãi",
chat_7: "Dây nè :)",
chat_8: "Sang tiền :)",
chat_9: "Bài chán vãi",
chat_10: "Vỡ alo chưa ?",
chat_11: "Thua đi cưng",
chat_12: "X2 cả Làng :)",
chicken_win: "Ăn Gà: ",
chicken_money: "Tiền Gà: ",
bet_in_chicken: "Vào Gà",
open_all: "Mở Luôn",
bet_phase: "Bắt đầu đặt cược!",
danh_bien: "Đánh biên",
ke_cua: "Ké cửa",
score: " Điểm",
all_lose: "Cả làng sang tiền",
all_win: "Phát lương cả làng",
chuong: "CHƯƠNG",
tit_name: "Người Chơi",
tit_bet: "Tiền cược",
tit_cuocga: "Cược Gà",
tit_kecua: "Ké Cửa",
tit_danhbien: "Đánh Biên",
tit_tong: "Tổng"
},
poker: {
poker_title: "Poker",
watting_for_start_game: "Đang chờ ván mới bắt đầu sau: ",
watting_for_end_game: "Kết thúc ván sau: ",
table: "Bàn: ",
bet_money: "Mức cược: ",
viewing: "Đang xem",
chat_place_holder: "Nhập nội dung",
invite_game: "Mời chơi",
no_one_invite: "Không có người chơi thích hợp",
not_open: "Chức năng tạm thời chưa mở",
create_room: "Tạo bàn",
create_room_place_holder: "Đặt tên phòng",
play_now: "Chơi ngay",
refresh_room: "Làm mới",
choose_bet_value: "Chọn",
player: "Người chơi",
password_room: "Mật Khẩu Phòng",
buy_in: "Mua thêm",
auto_buy_in: "Tự động mua khi hết chip",
result: "Kết quả",
confirm: "Xác nhận",
dang_ki_exit_success: "Bạn đã đăng ký rời phòng thành công!",
huy_dang_ki: "Bạn đã hủy đăng ký rời phòng!",
reg_buyin: "Đã đăng ký Buy In",
unreg_buyin: "Hủy đăng ký Buy In",
id_room: "Nhập ID bàn ...",
hide_full_table: "Ẩn bản đầy",
room_not_found: "Không tìm thấy phòng đã chọn",
please_add_idroom: "Vui lòng điền bàn bạn muốn tìm kiếm",
not_create_room: "Không thể tạo bàn game này!",
not_enough_money: "Số dư không đủ, vui lòng nạp thêm",
error_check: "Lỗi kiểm tra thông tin",
no_room_avaiable_found: "Không tìm thấy bàn hợp lệ",
bao_tri: "Hệ thống đang bảo trì",
time_wait: "Mỗi lần vào phòng phải cách nhau 10 giây!",
password_error: "Mật khẩu phòng chơi không đúng!",
room_full: "Phòng chơi đã đủ người!",
ban_room: "Bạn bị chủ phòng không cho vào bàn!",
info_create_room_error: "Thông tin tạo bàn không chính xác!",
not_enough_vip: "Bạn chưa đủ cấp độ Vip để tạo bàn!",
not_enough_vip2: "Không thể tạo thêm bàn với cấp độ Vip hiện tại!",
not_enough_gold: "Số dư không đủ, vui lòng nạp thêm.",
chat_1: "All in nè",
chat_2: "Hên thế",
chat_3: "Tất tay nhé",
chat_4: "Nhanh lên thím",
chat_5: "Sảnh vua nè",
chat_6: "Đen vãi",
chat_7: "Tố nè :)",
chat_8: "Sang tiền :)",
chat_9: "Bài chán thế",
chat_10: "Ăn cả Làng :)",
chat_11: "Dám tất tay không",
chat_12: "Đánh hay đấy",
double: "Gấp 2",
tripple: "Gấp 3",
allin: "Tất tay",
check: "Xem",
fold: "Úp",
open: "Mở",
follow: "Theo tất",
call: "Theo",
raise: "Tố",
bet: "Cược",
royalflush: "Sảnh rồng",
straightflush: "Thùng phá sảnh",
fourofakind: "Tứ quý",
fullhouse: "Cù lũ",
flush: "Thùng",
straight: "Sảnh",
threeofakind: "Sám",
twopair: "Hai đôi",
pair: "Đôi",
highcard: "Mậu thầu"
},
xizach: {
xizach_title: "Xì Zách",
watting_for_start_game: "Đang chờ ván mới bắt đầu sau: ",
table: "Bàn: ",
bet_money: "Mức cược: ",
viewing: "Đang xem",
chat_place_holder: "Nhập nội dung",
invite_game: "Mời chơi",
no_one_invite: "Không có người chơi thích hợp",
not_open: "Chức năng tạm thời chưa mở",
create_room: "Tạo bàn",
create_room_place_holder: "Đặt tên phòng",
play_now: "Chơi ngay",
refresh_room: "Làm mới",
choose_bet_value: "Chọn",
player: "Người chơi",
password_room: "Mật Khẩu Phòng",
confirm: "Xác nhận",
dang_ki_exit_success: "Bạn đã đăng ký rời phòng thành công!",
huy_dang_ki: "Bạn đã hủy đăng ký rời phòng!",
id_room: "Nhập ID bàn ...",
hide_full_table: "Ẩn bản đầy",
room_not_found: "Không tìm thấy phòng đã chọn",
please_add_idroom: "Vui lòng điền bàn bạn muốn tìm kiếm",
not_create_room: "Không thể tạo bàn game này!",
not_enough_money: "Số dư không đủ, vui lòng nạp thêm",
error_check: "Lỗi kiểm tra thông tin",
no_room_avaiable_found: "Không tìm thấy bàn hợp lệ",
bao_tri: "Hệ thống đang bảo trì",
time_wait: "Mỗi lần vào phòng phải cách nhau 10 giây!",
password_error: "Mật khẩu phòng chơi không đúng!",
room_full: "Phòng chơi đã đủ người!",
ban_room: "Bạn bị chủ phòng không cho vào bàn!",
info_create_room_error: "Thông tin tạo bàn không chính xác!",
not_enough_vip: "Bạn chưa đủ cấp độ Vip để tạo bàn!",
not_enough_vip2: "Không thể tạo thêm bàn với cấp độ Vip hiện tại!",
chat_1: "Nhanh lên thím",
chat_2: "Hên thế",
chat_3: "Tôi 20!",
chat_4: "Quắc Chưa?",
chat_5: "Đen vãi!",
chat_6: "Dằn non!",
chat_7: "Ngũ Linh nè!",
chat_8: "Quắc mẹ nó rồi!",
chat_9: "Đủ tuổi",
chat_10: "Sang tiền",
chat_11: "Trời! Ngũ linh luôn",
chat_12: "Ăn rồi",
act_danbai: "DẰN BÀI",
act_xetbai: "XÉT BÀI",
score_quac: "QUẮC",
score_xibang: "XÌ BÀNG",
score_xizach: "XÌ ZÁCH",
score_ngulinh: "NGŨ LINH",
score_21d: "21 ĐIỂM",
score_diem: " ĐIỂM"
},
slotdechemaya: {
unhappen: "Chưa diễn ra",
music: "Nhạc Nền",
sound: "Âm Thanh",
last_win: "Thắng",
total_bet: "Tổng đặt",
play_trial: "Chơi thử",
play_real: "Chơi thật",
line: "Dòng",
spin: "Quay",
autoSpin: "Tự quay",
stop: "Dừng",
bet: "Đặt cược",
popup: {
choose_line_title: "Chọn Dòng",
x2_win_title: "X2 quỹ thưởng",
guide_title: "Bảng thưởng",
jackpot_history_title: "Lịch sử trúng hũ",
trade_history_title: "Lịch sử giao dịch",
even_line: "Dòng chẵn",
odd_line: "Dòng lẻ",
all_line: "Tất cả",
re_line: "Chọn lại",
line_bet: "Dòng đặt",
line_win: "Dòng thắng",
chose_room_title: "Chọn phòng",
resident: "Tộc nhân",
leader: "Thủ lĩnh",
boss: "Tộc trưởng",
honor_title: "Vinh Danh",
congratulations_account: "Chúc mừng tài khoản",
remain_turn: "Số lượt còn lại",
total_score: "Điểm tích lũy",
lucky_box_title: "Rương vàng may mắn",
you_win: "Chúc mừng bạn đã thắng",
time: "Thời gian",
level: "Mức",
jackpot: "Nổ hũ",
account: "Tài khoản",
result: "Kết quả",
session: "Phiên",
detail: "Chi tiết",
view: "Xem",
receive_gold: "Gold Nhận",
jackpotx2: "Nổ hũ x2"
},
toast: {
function_dont_work_on_trial: "Tính năng này không hoạt động ở chế độ chơi thử.",
off_auto_spin_to_leave: "Tắt chế độ TỰ QUAY để thoát bàn",
funtion_in_develop: "Tính năng đang phát triển",
not_enough_gold: "Số dư không đủ, vui lòng nạp thêm",
spin_unsuccess: "Quay không thành công",
unvalid_bet: "Đặt cược không hợp lệ",
unvalid_spin: "Lượt quay không hợp lệ",
error_try_again: "Có lỗi xảy ra, vui lòng thử lại",
atleast_1_line: "Bạn cần chọn ít nhất 1 Dòng"
}
},
keno: {
door: {
tai: "Tài",
xiu: "Xỉu",
chan: "Chẵn",
le: "Lẻ",
kim: "Kim",
moc: "Mộc",
thuy: "Thủy",
hoa: "Hỏa",
tho: "Thổ"
},
type_bet: {
number: "Số",
xien: "Xiên",
truotxien: "Trượt xiên",
tx: "Tài xỉu",
cl: "Chẵn lẻ",
xien2: "Xiên 2",
xien3: "Xiên 3",
xien4: "Xiên 4",
xien5: "Xiên 5",
truotxien4: "Trượt xiên 4",
truotxien5: "Trượt xiên 5",
truotxien6: "Trượt xiên 6",
truotxien7: "Trượt xiên 7",
truotxien8: "Trượt xiên 8",
truotxien9: "Trượt xiên 9",
truotxien10: "Trượt xiên 10"
},
btn: {
chat: "CHAT",
vecuoc: "VÉ CƯỢC",
statistic: "THỐNG KÊ",
number_bet: "CƯỢC SỐ",
base_bet: "CƯỢC CƠ BẢN",
guide: "HƯỚNG DẪN",
most: "Nhiều nhất",
at_least: "Ít nhất",
consecutive: "Liên tiếp",
no_result: "Chưa về",
bet: "Đặt cược",
cancel: "Huỷ cược",
off: "Tắt",
dont_show_again: "Không hiển thị lại",
transaction: "Giao dịch"
},
statistic: {
number_kytai: "Số kỳ tài",
number_kyxiu: "Số kỳ xỉu",
number_kychan: "Số kỳ chẵn:",
number_kyle: "Số kỳ lẻ:",
ratio: "Tỷ lệ:",
explain: "CHÚ THÍCH",
tai: "=TÀI",
xiu: "=XỈU",
chan: "=CHẴN",
le: "=LẺ",
today: "Hôm nay",
yesterday: "Hôm qua",
number: "Số",
session50: "50 phiên",
session100: "100 phiên",
session200: "200 phiên",
session400: "400 phiên",
frequency: "Tần suất",
tx: "Tài xỉu",
cl: "Chẵn lẻ"
},
popup_title: {
confirm_ticket: "Xác nhận vé cược",
you_know: "Bạn có biết",
history_transfer: "Lịch sử giao dịch",
result: "Kết quả"
},
popup_confirm: {
selected: "Đã chọn",
money_bet: "Tiền cược",
total_bet: "Tổng cược:",
total_prize: "Tổng tiền thắng:"
},
editbox: {
placeholder_session: "Nhập số phiên"
},
message: {
times: " lần",
rounding: "ĐANG QUAY THƯỞNG",
total: "TỔNG: ",
result_session: "KẾT QUẢ PHIÊN #",
get: "1 ĂN ",
error_number: "số!",
error_enough_number: "Bạn phải chọn đủ",
error_choose_maximum: "Bạn chỉ được chọn tối đa",
selected: "Đã chọn:  ",
success_bet: "Đặt cược thành công!",
error_bet1: "Hệ thống đang bị gián đoạn.\n Xin vui lòng thử lại sau!",
error_bet2: "Hiện tại hệ thống đang dừng quay thưởng.\n Xin vui lòng liên hệ CSKH để biết thêm chi tiết.",
error_bet3: "Phiên bạn đặt cược đã kết thúc.\n Vui lòng đặt cược phiên tiếp theo!",
error_bet4: "Tài khoản lỗi đăng nhập",
error_bet5: "Vui lòng chọn loại cược,\n số và nhập giá trị tiền cược để hoàn thành lệnh cược!",
error_bet6: "Vui lòng nạp tiền để được tham gia đặt cược.",
error_bet7: "Không tồn tại loại cược mà quý khách đã chọn.\n Xin vui lòng đặt cược lại.",
error_bet8: "Tiền cược quá nhỏ để tham gia cược!",
error_bet9: "Tiền cược vượt quá giá trị giới hạn của 1 lệnh cược!",
error_bet10: "Số tiền cược đã vượt quá ngưỡng tiền cược / 1 số.\n Quý khách vui lòng đặt cược số tiền nhỏ hơn\n hoặc thử lại với số khác hoặc thử lại phiên sau.",
error_bet11: "Số dư không đủ để đặt cược.\n Xin quý khách vui lòng kiểm tra lại.",
error_bet12: "Params là định dạng sai",
error_bet13: "Hết thời gian đặt cược!",
error_bet14: "Số dư không khả dụng!",
error_bet15: "Số tiền cược không hợp lệ!"
},
popup: {
rlt_number: "STT",
rlt_session: "Phiên",
rlt_result: "Kết quả",
rlt_total: "Tổng",
rlt_tx: "Tài Xiu",
rlt_cl: "Chẵn Lẻ",
rlt_ngu_hanh: "Ngũ hành",
rlh_session: "Phiên",
rlh_bet_type: "Kiểu cược",
rlh_bet_money: "Tiền cược",
rlh_prize: "Trả thưởng",
rlh_time: "Thời gian"
}
},
lode79: {
ld_txt_dat: "Đặt",
ld_txt_tai: "TÀI",
ld_txt_xiu: "XỈU",
ld_txt_le: "LẺ",
ld_txt_chan: "CHẴN",
ld_tit_chuyen_rut: "CHUYỂN/RÚT",
ld_xo_so: "XỔ SỐ",
ld_phien: "P: ",
ld_so_du: "Số dư",
ld_so_tien: "Số tiền",
ld_so_diem: "Số điểm",
ld_tong_diem: "Tổng điểm",
ld_thanh_tien: "Thành tiền",
ld_tong_tien: "Tổng tiền",
bet_success: "Đặt cược thành công.",
bet_fail: "Đặt cược không thành công.",
mien_bac: "MIỀN BẮC",
mien_trung: "MIỀN TRUNG",
mien_nam: "MIỀN NAM",
dat_cuoc: "ĐẶT CƯỢC",
ltr_huy: "HỦY",
result: {
txt_giai_db: "Đặc biệt",
txt_giai_1: "Giải nhất",
txt_giai_2: "Giải nhì",
txt_giai_3: "Giải ba",
txt_giai_4: "Giải tư",
txt_giai_5: "Giải năm",
txt_giai_6: "Giải sáu",
txt_giai_7: "Giải bẩy",
txt_giai_8: "Giải tám"
},
lib: {
re_mien_bac: "Miền Bắc",
re_mien_trung: "Miền Trung",
re_mien_nam: "Miền Nam",
re_short_mien_bac: "M.Bắc",
re_short_mien_trung: "M.Trung",
re_short_mien_nam: "M.Nam",
qs_con_giap: "CON GIÁP",
cg_ty_9: "Tý (9)",
cg_suu_9: "Sửu (9)",
cg_dan_9: "Dần (9)",
cg_mao_9: "Mão (9)",
cg_thin_8: "Thìn (8)",
cg_ti_8: "Tỵ (8)",
cg_ngo_8: "Ngọ (8)",
cg_mui_8: "Mùi (8)",
cg_than_8: "Thân (8)",
cg_dau_8: "Dậu (8)",
cg_tuat_8: "Tuất (8)",
cg_hoi_8: "Hợi (8)",
qs_bo_so: "BỘ SỐ",
bo_so_01: "Bộ số 01",
bo_so_02: "Bộ số 02",
bo_so_03: "Bộ số 03",
bo_so_04: "Bộ số 04",
bo_so_12: "Cặp số 12",
bo_so_13: "Hệ số 13",
bo_so_14: "Bộ số 14",
bo_so_23: "Bộ đề 23",
bo_so_24: "Cặp số 24",
bo_so_34: "Cặp số 34",
qs_so_kep: "SỐ KÉP",
kep_bang: "Kép bằng",
bo_00: "Bộ 00",
bo_11: "Bộ 11",
bo_22: "Bộ 22",
bo_33: "Bộ 33",
bo_44: "Bộ 44",
qs_de_tong: "ĐỀ TỔNG",
tong_0: "Tổng 0",
tong_1: "Tổng 1",
tong_2: "Tổng 2",
tong_3: "Tổng 3",
tong_4: "Tổng 4",
tong_5: "Tổng 5",
tong_6: "Tổng 6",
tong_7: "Tổng 7",
tong_8: "Tổng 8",
tong_9: "Tổng 9",
type_de: "ĐỀ",
type_de_dau: "ĐỀ ĐẦU",
type_de_duoi: "ĐỀ ĐUÔI",
type_de_giai_8: "ĐỀ ĐẦU G8",
type_de_giai_nhat: "ĐỀ GIẢI NHẤT",
type_de_giai_7: "ĐỀ GIẢI 7",
type_de_dau_db: "ĐỀ ĐẦU ĐẶC BIỆT",
type_de_duoi_db: "ĐỀ ĐUÔI ĐẶC BIỆT",
type_de_3_cang: "ĐỀ 3 CÀNG",
type_3d_dac_biet: "3D ĐẶC BIỆT",
type_3d_giai_7: "3D GIẢI 7",
type_3d_duoi: "3D ĐUÔI",
type_lo: "LÔ",
type_lo_xien_2: "LÔ XIÊN 2",
type_lo_xien_3: "LÔ XIÊN 3",
type_lo_xien_4: "LÔ XIÊN 4",
type_lo_truot_4: "LÔ TRƯỢT 4",
type_lo_truot_8: "LÔ TRƯỢT 8",
type_lo_truot_10: "LÔ TRƯỢT 10",
type_tai_xiu: "TÀI XỈU",
type_chan_le: "CHẴN LẺ",
type_s_de: "ĐỀ",
type_s_de_dau: "ĐỀ ĐẦU",
type_s_de_duoi: "ĐỀ ĐUÔI",
type_s_de_giai_8: "ĐỀ ĐẦU G8",
type_s_de_giai_nhat: "ĐỀ GIẢI NHẤT",
type_s_de_giai_7: "ĐỀ GIẢI 7",
type_s_de_dau_db: "ĐỀ ĐẦU ĐB",
type_s_de_duoi_db: "ĐỀ ĐUÔI ĐB",
type_s_de_3_cang: "ĐỀ 3 CÀNG",
type_s_3d_dac_biet: "3D ĐẶC BIỆT",
type_s_3d_giai_7: "3D GIẢI 7",
type_s_3d_duoi: "3D ĐUÔI",
type_s_lo: "LÔ",
type_s_lo_xien_2: "LÔ XIÊN 2",
type_s_lo_xien_3: "LÔ XIÊN 3",
type_s_lo_xien_4: "LÔ XIÊN 4",
type_s_lo_truot_4: "LÔ TRƯỢT 4",
type_s_lo_truot_8: "LÔ TRƯỢT 8",
type_s_lo_truot_10: "LÔ TRƯỢT 10",
type_s_tai_xiu: "TÀI XỈU",
type_s_chan_le: "CHẴN LẺ"
},
responseWs: {
bet_success: "Đặt cược thành công.",
bet_fail: "Đặt cược không thành công.",
resNotifyLivestream1: "Mời quý khách đặt cược phiên\n XS LiveStream XXXX - Phiên YYYY",
resNotifyLivestream2: "Hiện tại đang trong thời gian quay thưởng.\nQuý khách vui lòng đợi ít phút \n để mở cược phiên tiếp theo!",
resNotifyLivestream3: "Quý khách vui lòng dừng cược. Hệ thống\n sẽ bắt đầu quay thưởng phiên hiện tại!",
resNotifyLivestream4: "Mở cược phiên tiếp theo XS XXXX\n Phiên YYYY. Xin mời quý khách đặt cược!",
resBet_am_1: "Token sai định dạng.",
resBet_0: "Đặt cược thành công.",
resBet_1: "Hệ thống đang bận, quý khách\n vui lòng thực hiện lại lệnh cược sau ít phút!",
resBet_2: "Cấu hình không tồn tại.",
resBet_3: "Hôm nay tạm dừng quay thưởng.",
resBet_4: "Không tải được cấu hình cược thời gian xổ số.",
resBet_5: "Chưa đến thời gian mở cược.",
resBet_6: "Tài khoản không tồn tại.",
resBet_7: "Nothing",
resBet_8: "Tiền cược là thông tin bắt buộc.",
resBet_9: "Hệ thống đang bận, quý khách\n vui lòng thực hiện lại lệnh cược sau ít phút!",
resBet_10: "Số tiền cược quá nhỏ.",
resBet_11: "Số tiền cược quá lớn.",
resBet_12: "Loại xổ số không tồn tại.",
resBet_13: "Số tiền cược quá lớn.",
resBet_14: "Số tiền cược quá nhỏ.",
resBet_15: "Tiền cược không đúng định dạng.",
resBet_16: "Số đặt cược không đúng định dạng.",
resBet_17: "Số tiền cược quá lớn.",
resBet_18: "Tài khoản của bạn không đủ.",
resBet_19: "Tỉnh mở thưởng không tồn tại.",
resBet_20: "Hệ thống đang bận, quý khách\n vui lòng thực hiện lại lệnh cược sau ít phút!",
resBet_21: "Hôm nay không có quay thưởng tại địa điểm này.",
resBet_22: "Hệ thống đang bận, quý khách\n vui lòng thực hiện lại lệnh cược sau ít phút!",
resBet_23: "respose bet",
resBet_24: "respose bet",
resBet_25: "respose bet",
resBet_26: "respose bet",
resBet_27: "respose bet",
resBet_28: "Hệ thống đang bận, quý khách\n vui lòng thực hiện lại lệnh cược sau ít phút!",
resBet_29: "Số tiền đặt cược quá lớn.",
resBet_30: "Hệ thống đang bận, quý khách\n vui lòng thực hiện lại lệnh cược sau ít phút!",
resBet_31: "Hệ thống đang bận, quý khách\n vui lòng thực hiện lại lệnh cược sau ít phút!.",
resBet_32: "Hệ thống đang bận, quý khách\n vui lòng thực hiện lại lệnh cược sau ít phút!.",
resBet_33: "Tài khoản hết phiên đăng nhập.\n Vui lòng đăng nhập và thao tác lại!.",
resBet_34: "Yêu cầu nạp số tiền tối thiểu\n để đủ điều kiện tham gia đặt cược!."
},
popup: {
title_huong_dan: "HƯỚNG DẪN",
title_thong_so: "THÔNG SỐ",
title_thong_so_tra: "Thông số truyền thống",
title_thong_so_liv: "Thông số livestream",
thong_so_header_gia_ban: "Giá Bán",
thong_so_header_tra_thuong: "Trả thưởng",
thong_so_header_toi_da_lan_cuoc: "Tối đa/lần cược",
thong_so_header_toi_da_so: "Tối đa/số",
title_sao_ke: "SAO KÊ",
title_sao_ke_tra: "Sao kê truyền thống",
title_sao_ke_liv: "Sao kê livestream",
sao_ke_loai_phien: "Loại phiên",
sao_ke_thoi_gian: "Thời gian",
sao_ke_de_lo: "Đề/lô",
sao_ke_tien_cuoc: "Tiền cược",
sao_ke_nhan_thuong: "Nhận thưởng",
title_bang_cuoc: "BẢNG CƯỢC",
title_bang_cuoc_tra: "Bảng cược truyền thống",
title_bang_cuoc_liv: "Bảng cược livestream",
bang_cuoc_loai_phien: "Loại phiên",
bang_cuoc_thoi_gian: "Thời gian",
bang_cuoc_de_lo: "Đề/lô",
bang_cuoc_tien_cuoc: "Tiền cược",
quy_tit_chuyen_quy: "CHUYỂN QUỸ",
quy_tit_rut_quy: "RÚT QUỸ",
quy_lbcq_gold_c: "Số gold chuyển:",
quy_lbcq_gold_n: "Số gold nhận:",
quy_lbrq_gold_r: "Số gold rút:",
quy_lbrq_gold_n: "Số gold nhận:",
quy_tit_ti_le: "Tỉ lệ:",
quy_tit_so_du: "Số tiền hiện tại:",
quy_btn_chuyen_quy: "CHUYỂN QUỸ",
quy_btn_rut_quy: "RÚT QUỸ",
quy_btn_choi_ngay: "CHƠI NGAY"
},
validate: {
vli_1: "Số dư không khả dụng.",
vli_2: "Bạn chưa chọn số.",
vli_3: "Vui lòng nhập số tiền.",
vli_4: "Vui lòng nhập số điểm.",
vli_5: "Vui lòng chọn đủ XXXX số/lô.",
vli_6: "Hiện tại chưa mở đặt cược phiên\ntiếp theo. Xin vui lòng chờ!",
vli_7: "Vui lòng chọn đủ 10 số/cược."
},
resChuyenRutQuy: {
res_01: "Số tiền không hợp lệ",
res_02: "Tiền cần rút vượt quá số dư",
res_03: "Không đủ số dư",
res_cp_0: "Chuyển quỹ thành công.",
res_rq_0: "Rút quỹ thành công."
}
},
MiniHoaQua: {
big_win: "Thắng lớn",
jackpot: "Nổ hũ",
line: "Dòng",
spin: "Quay",
autoSpin: "Tự quay",
stop: "Dừng",
popup: {
detail_title: "CHI TIẾT CƯỢC",
guide_title: "HƯỚNG DẪN",
history_title: "LS CHƠI",
honor_title: "VINH DANH",
select_line_title: "CHỌN DÒNG",
session: "PHIÊN",
time: "THỜI GIAN",
bet_level: "MỨC CƯỢC",
bet_line: "DÒNG CƯỢC",
bet: "CƯỢC",
gain_gift: "Nhận thưởng",
room: "PHÒNG",
detail: " CHI TIẾT",
account: "TÀI KHOẢN",
status: "TRẠNG THÁI",
win: "THẮNG",
unselect: "BỎ CHỌN",
even_line: "DÒNG CHẴN",
odd_line: "DÒNG LẺ",
all_line: "TẤT CẢ",
line_win: "DÒNG\nTHẮNG"
},
toast: {
action_too_quick: "Bạn thao tác quá nhanh.",
you_need_choose_at_least_1_line: "Bạn cần chọn ít nhất 1 dòng.",
not_enough_gold: "Số dư không đủ, vui lòng nạp thêm",
error_try_again: "Có lỗi xảy ra, vui lòng thử lại sau",
connecting_server: "Đang kết nối đến server"
}
},
slotnudiepvien: {
unhappen: "Chưa diễn ra",
music: "Nhạc Nền",
sound: "Âm Thanh",
last_win: "Thắng",
total_bet: "Tổng đặt",
play_trial: "Chơi thử",
play_real: "Chơi thật",
line: "Dòng",
bet_level: "Mức cược",
popup: {
choose_line_title: "Chọn Dòng",
x2_win_title: "X2 quỹ thưởng",
guide_title: "Bảng thưởng",
jackpot_history_title: "Lịch sử trúng hũ",
trade_history_title: "Lịch sử giao dịch",
even_line: "Dòng chẵn",
odd_line: "Dòng lẻ",
all_line: "Tất cả",
re_line: "Chọn lại",
line_bet: "Dòng đặt",
line_win: "Dòng thắng",
chose_room_title: "Chọn phòng",
resident: "Tộc nhân",
leader: "Thủ lĩnh",
boss: "Tộc trưởng",
honor_title: "Vinh Danh",
congratulations_account: "Chúc mừng tài khoản",
remain_turn: "Số lượt còn lại",
total_score: "Điểm tích lũy",
lucky_box_title: "Rương vàng may mắn",
you_win: "Chúc mừng bạn đã thắng",
time: "Thời gian",
level: "Mức",
jackpot: "Nổ hũ",
account: "Tài khoản",
result: "Kết quả",
session: "Phiên",
detail: "Chi tiết",
view: "Xem",
receive_gold: "Gold Nhận",
jackpotx2: "Nổ hũ x2",
minigame_title: "Vali đa năng",
extra_turns: "Thêm lượt"
},
toast: {
function_dont_work_on_trial: "Tính năng này không hoạt động ở chế độ chơi thử.",
off_auto_spin_to_leave: "Tắt chế độ TỰ QUAY để thoát bàn",
funtion_in_develop: "Tính năng đang phát triển",
not_enough_gold: "Số dư không đủ, vui lòng nạp thêm",
spin_unsuccess: "Quay không thành công",
unvalid_bet: "Đặt cược không hợp lệ",
unvalid_spin: "Lượt quay không hợp lệ",
error_try_again: "Có lỗi xảy ra, vui lòng thử lại",
atleast_1_line: "Bạn cần chọn ít nhất 1 Dòng"
}
},
shankoemee: {
cannot_out_room: "Bạn đang là banker không thể thực hiện out phòng",
cancel_leave_room: "Hủy rời phòng",
refresh_room: "Làm mới",
skm_card_score: "Điểm",
skm_nguoi_choi: "Người chơi",
skm_muc_cuoc: "Số dư tối thiểu",
draw_card: "Rút bài",
do_not_draw_card: "Không rút bài",
bet: "Cược",
quick_chat_1: "Cóng chưa",
quick_chat_2: "Tuổi gì mà bắt",
quick_chat_3: "Đời không như là mơ",
quick_chat_4: "Hên thế",
quick_chat_5: "Ăn hàng :v",
quick_chat_6: "Đen vãi",
quick_chat_7: "Thế mà cũng đòi sâm",
quick_chat_8: "Chết nè",
quick_chat_9: "Bài chán vãi",
quick_chat_10: "Vỡ alo chưa ?",
quick_chat_11: "Thua đi cưng",
quick_chat_12: "Nhanh lên thím",
enter_chat_content: "Nhập nội dung ...",
do_not: "Không",
accept: "Đồng ý",
invite: "MỜI CHƠI",
double_banker: "Bạn muốn thêm gấp đôi số tiền để tiếp tục làm banker không?",
play_now: "Chơi ngay",
choose_room: "Chọn phòng",
bank: "Bank",
enter_table_id: "Nhập ID bàn ...",
hidden_table_full: "Ẩn bàn đầy",
table_id: "Bàn: %{table}#%{game}",
bet_value: "MỨC CƯỢC",
bet_value_num: "Mức cược:",
watching: "Đang xem",
empty_list: "Không có người chơi thích hợp",
not_enough_money_to_join_the_table: "Không đủ tiền tham gia phòng!",
value_slot: "%{value} điểm",
pot_bank: "Pot: %{value}",
banker_turn: "Banker turn: %{turn}",
banker_turn2: "Tiếp tục làm banker vòng 2",
banker_turn3: "Tiếp tục làm banker vòng %{turn}",
waiting_new_game: "Chờ ván mới bắt đầu",
waiting_banker: "Chờ banker",
change_banker: "Đổi banker",
banker_win_title: "Banker win",
not_open_yet: "Chức năng tạm thời chưa mở",
can_not_find_table_selected: "Không tìm thấy phòng đã chọn",
enter_the_table_you_want_to_search: "Vui lòng điền bàn bạn muốn tìm kiếm",
can_not_create_table: "Game này không cho tạo bàn!",
no_valid_table_found: "Không tìm thấy bàn hợp lệ",
invite_user: "%{name} mời bạn chơi cùng, bạn có muốn tham gia không?",
error_not_defined: "Lỗi %{id}, không xác định.",
error_check_infomation: "Lỗi kiểm tra thông tin!",
error_can_not_find_table_try_again: "Không tìm được phòng thích hợp. Vui lòng thử lại sau!",
error_not_enough_money_to_join_table: "Bạn không đủ tiền vào phòng chơi này!",
error_join_room_too_fast: "Mỗi lần vào phòng phải cách nhau 10 giây!",
error_server_maintenance: "Hệ thống bảo trì!",
error_can_not_find_table: "Không tìm thấy phòng chơi!",
error_password_table_not_correct: "Mật khẩu phòng chơi không đúng!",
error_room_full: "Phòng chơi đã đủ người!",
error_has_been_kick: "Bạn bị chủ phòng không cho vào bàn!",
register_leave_table_success: "Bạn đã đăng ký rời phòng thành công!",
place_bet: "Mời đặt cược",
error_bet_already: "Đã đặt cược",
error_not_enough_money: "Không đủ tiền",
error_bet_not_correct: "Mức cược không đúng",
not_enough_gold_please_deposit: "Số dư không đủ, vui lòng nạp thêm",
cancel_register_leave_table: "Bạn đã hủy đăng ký rời phòng!",
open_card: "Mở bài",
id: "ID",
table_name: "Bàn:",
table_require: "Require",
table_min_bet: "Min bet",
table_num_user: "User",
leave_room_title: "Rời phòng",
leave_room_contect: "Bạn chắc chắn muốn rời phòng không?",
on_sound: "On",
off_sound: "Off",
send_chat: "Gửi"
},
boogyi: {
cannot_out_room: "Bạn đang là banker không thể thực hiện out phòng",
cancel_leave_room: "Cancel leave",
boo_tong_diem: "Tổng điểm",
refresh_room: "Làm mới",
skm_card_score: "Điểm",
skm_nguoi_choi: "Người chơi",
skm_muc_cuoc: "Số dư tối thiểu",
draw_card: "Rút bài",
do_not_draw_card: "Không rút bài",
bet: "Cược",
quick_chat_1: "Cóng chưa",
quick_chat_2: "Tuổi gì mà bắt",
quick_chat_3: "Đời không như là mơ",
quick_chat_4: "Hên thế",
quick_chat_5: "Ăn hàng :v",
quick_chat_6: "Đen vãi",
quick_chat_7: "Thế mà cũng đòi sâm",
quick_chat_8: "Chết nè",
quick_chat_9: "Bài chán vãi",
quick_chat_10: "Vỡ alo chưa ?",
quick_chat_11: "Thua đi cưng",
quick_chat_12: "Nhanh lên thím",
enter_chat_content: "Nhập nội dung ...",
do_not: "Không",
accept: "Đồng ý",
invite: "MỜI CHƠI",
double_banker: "Bạn muốn thêm gấp đôi số tiền để tiếp tục làm banker không?",
play_now: "Chơi ngay",
choose_room: "Chọn phòng",
bank: "Bank",
enter_table_id: "Nhập ID bàn ...",
hidden_table_full: "Ẩn bàn đầy",
table_id: "Bàn: %{table}#%{game}",
bet_value: "MỨC CƯỢC",
bet_value_num: "Mức cược:",
watching: "Đang xem",
empty_list: "Không có người chơi thích hợp",
not_enough_money_to_join_the_table: "Không đủ tiền tham gia phòng!",
value_slot: "%{value} điểm",
pot_bank: "Pot: %{value}",
banker_turn: "Banker turn: %{turn}",
banker_turn2: "Tiếp tục làm banker vòng 2",
banker_turn3: "Tiếp tục làm banker vòng %{turn}",
waiting_new_game: "Chờ ván mới bắt đầu",
waiting_banker: "Chờ banker",
change_banker: "Đổi banker",
banker_win_title: "Banker win",
not_open_yet: "Chức năng tạm thời chưa mở",
can_not_find_table_selected: "Không tìm thấy phòng đã chọn",
enter_the_table_you_want_to_search: "Vui lòng điền bàn bạn muốn tìm kiếm",
can_not_create_table: "Game này không cho tạo bàn!",
no_valid_table_found: "Không tìm thấy bàn hợp lệ",
invite_user: "%{name} mời bạn chơi cùng, bạn có muốn tham gia không?",
error_not_defined: "Lỗi %{id}, không xác định.",
error_check_infomation: "Lỗi kiểm tra thông tin!",
error_can_not_find_table_try_again: "Không tìm được phòng thích hợp. Vui lòng thử lại sau!",
error_not_enough_money_to_join_table: "Bạn không đủ tiền vào phòng chơi này!",
error_join_room_too_fast: "Mỗi lần vào phòng phải cách nhau 10 giây!",
error_server_maintenance: "Hệ thống bảo trì!",
error_can_not_find_table: "Không tìm thấy phòng chơi!",
error_password_table_not_correct: "Mật khẩu phòng chơi không đúng!",
error_room_full: "Phòng chơi đã đủ người!",
error_has_been_kick: "Bạn bị chủ phòng không cho vào bàn!",
register_leave_table_success: "Bạn đã đăng ký rời phòng thành công!",
place_bet: "Mời đặt cược",
error_bet_already: "Đã đặt cược",
error_not_enough_money: "Không đủ tiền",
error_bet_not_correct: "Mức cược không đúng",
not_enough_gold_please_deposit: "Số dư không đủ, vui lòng nạp thêm",
cancel_register_leave_table: "Bạn đã hủy đăng ký rời phòng!",
open_card: "Mở bài",
id: "ID",
table_name: "Bàn:",
table_require: "Require",
table_min_bet: "Min bet",
table_num_user: "User",
leave_room_title: "Rời phòng",
leave_room_contect: "Bạn chắc chắn muốn rời phòng không?",
on_sound: "On",
off_sound: "Off",
send_chat: "Gửi",
test: "test",
zero_slot: "Lủng",
confirm: "Xác nhận",
not_bid: "Không bid",
place_bid: "Mời đấu giá",
bid_value: "bid x%{value}",
bid_error_1: "Mức bid không đúng",
bid_error_2: "Không đủ tiền",
start_compare: "So bài"
},
shweshan: {
cannot_out_room: "Bạn đang là banker không thể thực hiện out phòng",
cancel_leave_room: "Cancel leave",
shw_resort: "Xếp lại",
game_name: "Shweshan",
arranage_done: "Xếp bài xong",
zero_slot: "Lủng",
shweshan_nguoi_choi: "Người chơi",
shweshan_muc_cuoc: "Số dư tối thiểu",
watching: "Đang xem",
do_not: "Không",
accept: "Đồng ý",
invite: "MỜI CHƠI",
refresh_room: "Làm mới",
empty_list: "Không có người chơi thích hợp",
play_now: "Chơi ngay",
confirm: "Xác nhận",
start_compare: "So bài",
skm_card_score: "Điểm",
skm_nguoi_choi: "Người chơi",
skm_muc_cuoc: "Số dư tối thiểu",
draw_card: "Rút bài",
do_not_draw_card: "Không rút bài",
bet: "Cược",
quick_chat_1: "Cóng chưa",
quick_chat_2: "Tuổi gì mà bắt",
quick_chat_3: "Đời không như là mơ",
quick_chat_4: "Hên thế",
quick_chat_5: "Ăn hàng :v",
quick_chat_6: "Đen vãi",
quick_chat_7: "Thế mà cũng đòi sâm",
quick_chat_8: "Chết nè",
quick_chat_9: "Bài chán vãi",
quick_chat_10: "Vỡ alo chưa ?",
quick_chat_11: "Thua đi cưng",
quick_chat_12: "Nhanh lên thím",
enter_chat_content: "Nhập nội dung ...",
double_banker: "Bạn muốn thêm gấp đôi số tiền để tiếp tục làm banker không?",
choose_room: "Chọn phòng",
bank: "Bank",
enter_table_id: "Nhập ID bàn ...",
hidden_table_full: "Ẩn bàn đầy",
table_id: "Bàn: %{table}#%{game}",
bet_value: "MỨC CƯỢC",
bet_value_num: "Mức cược:",
not_enough_money_to_join_the_table: "Không đủ tiền tham gia phòng!",
value_slot: "Số điểm:%{value}",
pot_bank: "Pot: %{value}",
banker_turn: "Banker turn: %{turn}",
banker_turn2: "Tiếp tục làm banker vòng 2",
banker_turn3: "Tiếp tục làm banker vòng %{turn}",
waiting_new_game: "Chờ ván mới bắt đầu",
waiting_banker: "Chờ banker",
change_banker: "Đổi banker",
banker_win_title: "Banker win",
not_open_yet: "Chức năng tạm thời chưa mở",
can_not_find_table_selected: "Không tìm thấy phòng đã chọn",
enter_the_table_you_want_to_search: "Vui lòng điền bàn bạn muốn tìm kiếm",
can_not_create_table: "Game này không cho tạo bàn!",
no_valid_table_found: "Không tìm thấy bàn hợp lệ",
invite_user: "%{name} mời bạn chơi cùng, bạn có muốn tham gia không?",
error_not_defined: "Lỗi %{id}, không xác định.",
error_check_infomation: "Lỗi kiểm tra thông tin!",
error_can_not_find_table_try_again: "Không tìm được phòng thích hợp. Vui lòng thử lại sau!",
error_not_enough_money_to_join_table: "Bạn không đủ tiền vào phòng chơi này!",
error_join_room_too_fast: "Mỗi lần vào phòng phải cách nhau 10 giây!",
error_server_maintenance: "Hệ thống bảo trì!",
error_can_not_find_table: "Không tìm thấy phòng chơi!",
error_password_table_not_correct: "Mật khẩu phòng chơi không đúng!",
error_room_full: "Phòng chơi đã đủ người!",
error_has_been_kick: "Bạn bị chủ phòng không cho vào bàn!",
register_leave_table_success: "Bạn đã đăng ký rời phòng thành công!",
place_bet: "Mời đặt cược",
error_bet_already: "Đã đặt cược",
error_not_enough_money: "Không đủ tiền",
error_bet_not_correct: "Mức cược không đúng",
not_enough_gold_please_deposit: "Số dư không đủ, vui lòng nạp thêm",
cancel_register_leave_table: "Bạn đã hủy đăng ký rời phòng!",
open_card: "Mở bài",
id: "ID:",
table_name: "Bàn:",
table_require: "Require",
table_min_bet: "Min bet",
table_num_user: "User",
leave_room_title: "Rời phòng",
leave_room_contect: "Bạn chắc chắn muốn rời phòng không?",
on_sound: "On",
off_sound: "Off",
send_chat: "Gửi"
}
};
cc._RF.pop();
}, {} ]
}, {}, [ "CapchaF", "DemoLog", "DemoReg", "GUIDisplayNameCtrl", "GG", "ItemGameIconCtrl", "ListGameCenter", "BhvShake", "BhvSine", "BGUI.d", "LabelFontSet", "LabelLocalized", "LanguageMgr", "SpineAnimationSet", "SpineLocalized", "SpriteFrameSet", "SpriteLocalized", "cam", "en", "mm", "tl", "vn", "polyglot", "GameCoreManager", "BundleDownLoad", "CommonAssetDefined", "DropDown", "DropDownItem", "DropDownOptionData", "LoginFeature", "PrefabEDefined", "UIAutoLayout", "UIButtonCommon", "UIDragDrop", "UIDraggable", "UIJoystick", "UIPersitsNode", "UIPopup", "UIPopupCommon", "UIScreen", "UIScrollBar", "UIScrollContent", "UIScrollView", "UITabbarController", "UITabbarItem", "UITableCell", "UITableView", "UITextManager", "UITooltipHandler", "UITooltipListener", "UITooltipManager", "UITooltipMessage", "UITouchHandler", "UIWaitingLayout", "UIWindow" ]);